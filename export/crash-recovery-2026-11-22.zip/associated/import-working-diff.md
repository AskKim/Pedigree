# Diff: Current Working Files vs. `/import/` Export (`AskKim/Pedigree`)

- **Import Source:** `AskKim/Pedigree` (`main` @ `847f8ec8a2fc88e92ecb94065d96cf1277189c07`, `/import/index_6c69368d.md`)
- **Diff Direction:** `working/<path>` (`---`) → `import/<path>` (`+++`)
- **Total Imported Files Parsed:** 284
- **Identical:** 197
- **Trailing-Newline Only Differences:** 2
- **Modified (Content Differs):** 83
- **Only in `/import/` (Missing in Working):** 2
- **Only in Working (Not in `/import/` Export):** 3

> Note: `import/`, `export/`, `node_modules/`, `dist/`, `.git/`, `public/assets/aistudio/`, and binary/lock files skipped by the upstream export (`bun.lock`, `android-wrapper/bun.lock`, PWA PNG icons) are excluded from the Only-in-Working list.

## 1. Summary Inventory

### Only in Working Tree (Not in `/import/`)
- `vitest.config.ts`
- `webSqliteAdapter.ts`
- `src/utils/__tests__/printPreviewHelpers.test.ts`

### Only in `/import/` (Missing in Working Tree)
- `android-wrapper/.env.example` *(source: `part-01_dfb892d4.md`)*
- `src/components/PedigreePrintNotice.tsx` *(source: `part-06_7db922b0.md`)*

### Trailing-Newline Only Differences
- `firebase-applet-config.json` *(source: `part-01_dfb892d4.md`)*
- `public/assets/aistudio/5aba587d-cee5-4775-bb8d-58e8d4fa0313_cbb8232e.txt` *(source: `part-02_8cc4d2d8.md`)*

### Modified Files Overview

| File | Import Part | `+` (in import) | `-` (in working) |
| --- | --- | ---: | ---: |
| `.env.example` | `part-01_dfb892d4.md` | +1 | -0 |
| `.github/structure.txt` | `part-01_dfb892d4.md` | +7 | -24 |
| `.github/workflows/ci.yml` | `part-01_dfb892d4.md` | +1 | -1 |
| `AGENTS.md` | `part-01_dfb892d4.md` | +1 | -3 |
| `IMPROVEMENTS.md` | `part-01_dfb892d4.md` | +48 | -23 |
| `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt` | `part-01_dfb892d4.md` | +1 | -1 |
| `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt` | `part-01_dfb892d4.md` | +14 | -132 |
| `docs/plans/suggestions-backlog.md` | `part-02_8cc4d2d8.md` | +8 | -16 |
| `package.json` | `part-01_dfb892d4.md` | +1 | -1 |
| `prompts/master_system_prompt.md` | `part-02_8cc4d2d8.md` | +1 | -2 |
| `public/version.json` | `part-02_8cc4d2d8.md` | +1 | -1 |
| `src/App.tsx` | `part-02_8cc4d2d8.md` | +57 | -13 |
| `src/components/AnimalPhotoGallery.tsx` | `part-02_8cc4d2d8.md` | +105 | -23 |
| `src/components/BreedingScreen.tsx` | `part-03_e26163f3.md` | +102 | -21 |
| `src/components/CrashErrorBoundary.tsx` | `part-03_e26163f3.md` | +12 | -7 |
| `src/components/DiagnosticsAndSupportPanel.tsx` | `part-03_e26163f3.md` | +13 | -11 |
| `src/components/ExternalImporterPanel.tsx` | `part-04_0b25b963.md` | +6 | -10 |
| `src/components/HerdScreen.tsx` | `part-05_2e3961d6.md` | +848 | -129 |
| `src/components/ImportExportHubScreen.tsx` | `part-05_2e3961d6.md` | +30 | -50 |
| `src/components/PedigreeScreen.tsx` | `part-06_7db922b0.md` | +83 | -0 |
| `src/components/PrintPreviewModal.tsx` | `part-06_7db922b0.md` | +120 | -183 |
| `src/components/SearchableParentPicker.tsx` | `part-06_7db922b0.md` | +156 | -117 |
| `src/components/SpeciesDashboardScreen.tsx` | `part-07_f04ec3b8.md` | +426 | -24 |
| `src/components/SpeciesMigrationModal.tsx` | `part-07_f04ec3b8.md` | +4 | -15 |
| `src/core/__tests__/exportersRegistry.test.ts` | `part-12.md` | +9 | -67 |
| `src/core/__tests__/reportCatalog.test.ts` | `part-12.md` | +3 | -1 |
| `src/core/__tests__/reportGenerators.test.ts` | `part-12.md` | +2 | -2 |
| `src/core/__tests__/speciesMigration.test.ts` | `part-13.md` | +0 | -65 |
| `src/core/__tests__/stageBResilience.test.ts` | `part-13.md` | +2 | -47 |
| `src/core/__tests__/suggestionsBacklog.test.ts` | `part-13.md` | +3 | -3 |
| `src/core/__tests__/syncAndExports.test.ts` | `part-13.md` | +99 | -0 |
| `src/core/__tests__/testFixtures.ts` | `part-13.md` | +4 | -0 |
| `src/core/archiveInspector.ts` | `part-08.md` | +0 | -15 |
| `src/core/backupArchive.ts` | `part-08.md` | +24 | -0 |
| `src/core/backupStatus.ts` | `part-08.md` | +12 | -0 |
| `src/core/backupVault.ts` | `part-08.md` | +12 | -0 |
| `src/core/dataHealthCheck.ts` | `part-09.md` | +77 | -0 |
| `src/core/exporters/exporterTypes.ts` | `part-13.md` | +0 | -1 |
| `src/core/exporters/registry.ts` | `part-13.md` | +16 | -407 |
| `src/core/imageOptimizationSpec.ts` | `part-09.md` | +80 | -13 |
| `src/core/improvementRegistry.ts` | `part-10.md` | +211 | -71 |
| `src/core/inputSanitization.ts` | `part-10.md` | +79 | -0 |
| `src/core/models.ts` | `part-10.md` | +327 | -0 |
| `src/core/pdfExporter.ts` | `part-10.md` | +33 | -3 |
| `src/core/pedigreePrintStyles.ts` | `part-10.md` | +32 | -2 |
| `src/core/reportCatalog.ts` | `part-11.md` | +16 | -0 |
| `src/core/reportGenerators.ts` | `part-11.md` | +181 | -0 |
| `src/core/sampleData.ts` | `part-11.md` | +134 | -2 |
| `src/core/shareablePedigreeCard.ts` | `part-11.md` | +22 | -0 |
| `src/core/speciesMigration.ts` | `part-11.md` | +39 | -35 |
| `src/core/syncAndExports.ts` | `part-11.md` | +348 | -3 |
| `src/core/syncOutbox.ts` | `part-11.md` | +49 | -1 |
| `src/core/upgradeGate.ts` | `part-12.md` | +1 | -1 |
| `src/hooks/useBarnStore.ts` | `part-14.md` | +929 | -31 |
| `src/index.css` | `part-02_8cc4d2d8.md` | +0 | -6 |
| `src/native/pedigreeBridge.test.ts` | `part-14.md` | +0 | -21 |
| `src/native/pedigreeBridge.ts` | `part-14.md` | +5 | -29 |
| `src/storage/__tests__/es2018AndPwaUpdate.test.ts` | `part-16.md` | +50 | -1 |
| `src/storage/__tests__/opfsStorage.test.ts` | `part-16.md` | +125 | -0 |
| `src/storage/__tests__/passphraseAndClockSkew.test.ts` | `part-16.md` | +1 | -1 |
| `src/storage/__tests__/photoHydrationAndWorker.test.ts` | `part-16.md` | +309 | -0 |
| `src/storage/backgroundFreezeCoordinator.ts` | `part-14.md` | +86 | -11 |
| `src/storage/capturedIdeasStore.ts` | `part-14.md` | +111 | -50 |
| `src/storage/crashLogger.ts` | `part-14.md` | +123 | -56 |
| `src/storage/deviceCapabilityDetector.ts` | `part-14.md` | +35 | -20 |
| `src/storage/feedTagOcr.ts` | `part-14.md` | +26 | -10 |
| `src/storage/localSyncChannels.ts` | `part-15.md` | +411 | -119 |
| `src/storage/offThreadWorkerClient.ts` | `part-15.md` | +15 | -13 |
| `src/storage/opfsStorage.ts` | `part-15.md` | +80 | -26 |
| `src/storage/opfsTempStream.ts` | `part-15.md` | +266 | -27 |
| `src/storage/pedigreeOcrScanner.ts` | `part-15.md` | +22 | -9 |
| `src/storage/photoHydration.ts` | `part-15.md` | +37 | -2 |
| `src/storage/pwaUpdateManager.ts` | `part-15.md` | +10 | -6 |
| `src/storage/storageAdapter.ts` | `part-15.md` | +27 | -0 |
| `src/storage/storageProtection.ts` | `part-15.md` | +107 | -40 |
| `src/storage/webImageOptimizer.ts` | `part-15.md` | +229 | -38 |
| `src/storage/webSqliteAdapter.ts` | `part-15.md` | +802 | -92 |
| `src/utils/es2018Shims.ts` | `part-16.md` | +100 | -74 |
| `src/utils/googleCalendarClient.ts` | `part-16.md` | +82 | -67 |
| `src/utils/webFileActions.ts` | `part-16.md` | +148 | -41 |
| `src/utils/webPdfActions.ts` | `part-16.md` | +29 | -11 |
| `tsconfig.json` | `part-01_dfb892d4.md` | +1 | -1 |
| `vite.config.ts` | `part-01_dfb892d4.md` | +1 | -45 |

## 2. Unified Diffs (`working` → `import`)

### `.env.example` (`+1` / `-0`, source: `part-01_dfb892d4.md`)

```diff
--- working/.env.example
+++ import/.env.example
@@ -1 +1,2 @@
 # No required environment variables.
+# Community Pedigree is 100% offline-first and stores all data locally in the browser.
```

### `.github/structure.txt` (`+7` / `-24`, source: `part-01_dfb892d4.md`)

```diff
--- working/.github/structure.txt
+++ import/.github/structure.txt
@@ -1,20 +1,12 @@
 Pedigree/
 ├── .github/
 │   ├── workflows/
-│   │   ├── build-android-apk.yml
 │   │   ├── ci.yml
-│   │   ├── deploy-pages.yml
-│   │   ├── export_repo_to_md.yml
-│   │   └── unzip.yml
+│   │   └── deploy-pages.yml
 │   └── structure.txt
-├── android-wrapper/                       <-- Native Android APK shell (Gradle + Kotlin WebView bridges)
 ├── docs/
 │   └── plans/
 │       └── suggestions-backlog.md
-├── fastlane/
-│   └── metadata/
-│       └── android/
-├── import/                                <-- Read-only staging folder (DO NOT execute, bundle, or boot without explicit confirmation)
 ├── prompts/                               <-- Do not remove prompts without confirmation (update src/components/PromptsDirectoryScreen.tsx, src/core/promptsCatalog.ts, and vite.config.ts if moved)
 │   ├── fix_error_log_prompt.md            <-- Active crash & error log remediation prompt
 │   ├── master_system_prompt.md            <-- Active Master System Prompt
@@ -25,23 +17,14 @@
 │   └── start_new_backlog_prompt.md        <-- Active backlog plan starter prompt
 ├── public/
 ├── scripts/
-│   └── verify-improvements.ts             <-- Anti-drift invariant checker (npm run verify:improvements)
 ├── src/
-│   ├── components/                        <-- React UI screens, modals & print preview
-│   ├── core/                              <-- Zero-DOM pure TypeScript domain, genetics, exporters, importers
-│   ├── hooks/                             <-- React store (useBarnStore.ts)
-│   ├── native/                            <-- Hybrid Android/iOS/Web bridge (pedigreeBridge.ts)
-│   ├── storage/                           <-- sql.js SQLite adapter, OPFS vault, workers, OCR scanner
-│   └── utils/                             <-- Browser DOM helpers (PDF, file actions, ES2018 shims)
-├── .env.example
-├── AGENTS.md
+│   ├── components/
+│   ├── core/
+│   ├── hooks/
+│   ├── storage/
+│   └── utils/
 ├── ARCHITECTURE.md
 ├── IMPROVEMENTS.md
 ├── LICENSE
-├── README.md
-├── firebase-applet-config.json
-├── index.html
-├── metadata.json
 ├── package.json
-├── tsconfig.json
-└── vite.config.ts
+└── README.md
```

### `.github/workflows/ci.yml` (`+1` / `-1`, source: `part-01_dfb892d4.md`)

```diff
--- working/.github/workflows/ci.yml
+++ import/.github/workflows/ci.yml
@@ -46,7 +46,7 @@
         run: |
           REPO_NAME="${{ github.event.repository.name }}"
           if [ -z "$REPO_NAME" ]; then
-            REPO_NAME="CPP2"
+            REPO_NAME="Pedigree"
           fi
           SUBPATH="/${REPO_NAME}/"
           npm run build -- --base="$SUBPATH"
```

### `AGENTS.md` (`+1` / `-3`, source: `part-01_dfb892d4.md`)

```diff
--- working/AGENTS.md
+++ import/AGENTS.md
@@ -1,12 +1,10 @@
 # Agent Instructions: Community Pedigree Project
 
-**Last-Edited Timestamp:** 2026-11-21
+**Last-Edited Timestamp:** 2026-11-20
 
 <SYSTEM_RULES_DIRECTIVE>
 Before reading code, answering questions, or proposing edits, read and strictly follow all binding rules, token-spend limits, and coding invariants in `prompts/master_system_prompt.md`.
 </SYSTEM_RULES_DIRECTIVE>
 
-- **CRITICAL RULE — Never Convert PWA Away From React:** The PWA portion of this project MUST NEVER be converted, rewritten, or migrated away from React (it must always remain React + Vite + TypeScript, even during build-crash recovery or refactors).
-- **Protected Staging Folder (`/import/` — Read-Only, No Execution Without Confirmation):** Agents and tooling may **read** from `/import/`, but MUST NEVER execute, test, serve, bundle, or import files from `/import/` without explicit user confirmation. Contents in `/import/` are likely non-React and are isolated from `tsconfig.json`, `vitest.config.ts`, and `vite.config.ts` so they cannot interfere with the React PWA boot sequence.
 - **Canonical Rules File:** `prompts/master_system_prompt.md` (do not delete, move, or edit without explicit confirmation from Kimberly).
 - **Architecture & Recovery Reference:** Consult `ARCHITECTURE.md` and `IMPROVEMENTS.md` only when relevant to the active task.
```

### `IMPROVEMENTS.md` (`+48` / `-23`, source: `part-01_dfb892d4.md`)

```diff
--- working/IMPROVEMENTS.md
+++ import/IMPROVEMENTS.md
@@ -20,7 +20,7 @@
 
 ---
 
-## Logged Improvements (47)
+## Logged Improvements (48)
 
 ### IMP-001: Backup Freshness Tracking, Reminders & Clean Human-Readable Exports
 
@@ -973,25 +973,50 @@
 2. Restore `src/core/economicsLedger.ts` and `src/core/__tests__/economicsLedger.test.ts` along with the 3 financial/production/youth presets in `reportCatalog.ts` and `reportGenerators.ts`.
 3. Keep store CRUD mutations in `src/hooks/useBarnStore.ts` and wire `EconomicsLedgerScreen.tsx` into `SpeciesDashboardScreen.tsx` and `App.tsx`.
 
-### IMP-047: Post-Crash Alignment, Ready External Exporters, Feed/Archive Parity & Android WebView Print/Share
-
-- **Category:** Stability & Mobile PWA (`stability-pwa`)
-- **Origin:** Session Improvement
-- **User Goal:** Realign the entire codebase after build-crash drift, keep the PWA locked to React + Vite + TypeScript, complete half-done exporters and migration/inspector coverage, and make pedigree/binder print & share work seamlessly on desktop, mobile web, and the Android WebView APK.
-- **Summary:** Enforces the React PWA preservation rule in `AGENTS.md` and `prompts/master_system_prompt.md`; aligns PWA/Android versions to `0.1.0-alpha.2`; migrates `feedBatches` and `feedAllocations` during cross-species moves; surfaces v3/v4 feed, ledger, processing, and 4-H/FFA counts in `archiveInspector.ts`; implements `herdboss-transfer-bundle` (.ZIP) and `registry-worksheet-csv` (.CSV) as ready exporters; and fixes `@media print` extraction, accent-ink preservation, native wrapper Share .HTM enablement, and Android `PrintBridge.kt` offscreen HTML + landscape/portrait printing while removing the stale `PedigreePrintNotice` banner.
-- **Tracked Files:** `AGENTS.md`, `.env.example`, `package.json`, `public/version.json`, `src/core/upgradeGate.ts`, `src/core/speciesMigration.ts`, `src/core/archiveInspector.ts`, `src/core/exporters/exporterTypes.ts`, `src/core/exporters/registry.ts`, `src/native/pedigreeBridge.ts`, `src/components/PrintPreviewModal.tsx`, `src/components/ImportExportHubScreen.tsx`, `src/index.css`, `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt`, `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt`, `.github/structure.txt`
-
-**Automated Invariants Checked:**
-- `AGENTS.md` must contain `Never Convert PWA Away From React` — *Workspace agent rules must lock the PWA against non-React rewrites.*
-- `src/core/speciesMigration.ts` must contain `feedBatchesMigrated`, `feedAllocationsMigrated` — *Cross-species migrations must move linked feedBatches and feedAllocations.*
-- `src/core/archiveInspector.ts` must contain `feedBatchCount`, `feedAllocationCount`, `ledgerEntryCount`, `processingLogCount`, `youthProjectBookCount` — *Pre-restore dry-run inspection must count v3/v4 feed, ledger, processing, and youth records.*
-- `src/core/exporters/registry.ts` must contain `herdboss-transfer-bundle`, `registry-worksheet-csv`, `binaryContent` — *HerdBoss Transfer Tables (.ZIP) and Breed Registry & Show Worksheets (.CSV) must stay active ready exporters.*
-- `src/components/PrintPreviewModal.tsx` must contain `canShareHtmlDocument`, `extractScopedPrintCssFromRules`, `detectDocumentPrintOrientation` — *PrintPreviewModal must enable Share .HTM on native wrappers, extract @media print rules, and forward orientation/HTML to native print.*
-- `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt` must contain `printFromBridge`, `printHtmlDocument`, `buildPrintAttributes` — *Android PrintBridge must render self-contained HTML in a hardened offscreen WebView with landscape/portrait PrintAttributes.*
-
-**Restoration Playbook if Overwritten:**
-1. Verify `AGENTS.md` and `prompts/master_system_prompt.md` keep the React PWA lock rule intact.
-2. Ensure `package.json`, `public/version.json`, and `src/core/upgradeGate.ts` match `android-wrapper/app/build.gradle.kts` (`0.1.0-alpha.2`).
-3. Keep `herdboss-transfer-bundle` and `registry-worksheet-csv` in `src/core/exporters/registry.ts` with `binaryContent` download dispatch in `ImportExportHubScreen.tsx`.
-4. Keep `@media print` extraction, native Share .HTM support, and Android `PrintBridge.kt` offscreen HTML rendering intact and do not reintroduce `PedigreePrintNotice`.
-
+### IMP-047: Client CRM, Buyer Waitlist, Reservations & Deposit Reminders
+
+- **Category:** Species & Herd UX (`species-ux`)
+- **Origin:** Session Improvement
+- **User Goal:** Track buyer contacts, waitlist queues, animal/litter reservations, deposit due reminders, and printable sales agreements offline without cloud dependencies.
+- **Summary:** Adds species-isolated local-first breeder CRM tracking buyer contacts (`ClientContact`), ranked waitlist inquiries (`WaitlistEntry`) with live unreserved animal/pairing match scoring (`findWaitlistMatches`), animal/litter-pick reservations (`AnimalReservation`) with sequential agreement numbering and deposit/balance progress (`evaluateReservationFinancials`), automated overdue/due/upcoming follow-up reminders (`evaluateCrmFollowUpReminders`) with 1-click Master Task creation, XSS-safe printable Sales Agreements with optional breeder logo and active withdrawal disclosures (`generateSalesAgreementHtml`), SQLite v5 persistence, sync outbox deltas, 2 CRM report presets, and `ClientCrmScreen.tsx` accessible from Species Dashboard & `C` shortcut.
+- **Tracked Files:** `src/core/models.ts`, `src/core/clientCrm.ts`, `src/core/__tests__/clientCrm.test.ts`, `src/core/reportCatalog.ts`, `src/core/reportGenerators.ts`, `src/core/syncOutbox.ts`, `src/storage/webSqliteAdapter.ts`, `src/hooks/useBarnStore.ts`, `src/components/ClientCrmScreen.tsx`, `src/components/SpeciesDashboardScreen.tsx`, `src/App.tsx`
+
+**Automated Invariants Checked:**
+- `src/core/models.ts` must contain `ClientContact`, `WaitlistEntry`, `AnimalReservation`, `RESERVATION_STATUSES`, `WAITLIST_STATUSES` — *ClientContact, WaitlistEntry, and AnimalReservation domain models and normalizers must remain intact.*
+- `src/core/clientCrm.ts` must contain `evaluateReservationFinancials`, `evaluateCrmFollowUpReminders`, `findWaitlistMatches`, `generateSalesAgreementHtml`, `formatReservationsCsv` — *Pure TS CRM financial evaluation, automated follow-up reminders, waitlist matching, CSV export, and printable Sales Agreement generator must stay zero-DOM.*
+- `src/storage/webSqliteAdapter.ts` must contain `client_contacts`, `waitlist_entries`, `animal_reservations`, `saveClientContact`, `saveWaitlistEntry`, `saveAnimalReservation` — *SQLite schema v5 and adapter CRUD methods must store and hydrate CRM contacts, waitlist entries, and reservations.*
+- `src/hooks/useBarnStore.ts` must contain `saveClientContact`, `saveWaitlistEntry`, `saveAnimalReservation`, `completeReservationSale`, `createCrmReminderTask` — *Store must expose species-isolated CRM mutations, atomic sale completion, and reminder task creation with delta outbox sync.*
+- `src/components/ClientCrmScreen.tsx` must contain `ClientCrmScreen`, `generateSalesAgreementHtml`, `evaluateCrmFollowUpReminders`, `findWaitlistMatches` — *ClientCrmScreen must render reminders, reservation/deposit tracking, ranked waitlist matching, client directory, and printable sales agreements.*
+- `src/App.tsx` must contain `ClientCrmScreen`, `route === 'crm'` — *Root router must lazy-load and mount ClientCrmScreen on route crm.*
+
+**Restoration Playbook if Overwritten:**
+1. Keep `ClientContact`, `WaitlistEntry`, and `AnimalReservation` interfaces and normalizers in `src/core/models.ts` plus SQLite v5 tables in `src/storage/webSqliteAdapter.ts`.
+2. Restore `src/core/clientCrm.ts` and `src/core/__tests__/clientCrm.test.ts` along with the 2 CRM presets in `reportCatalog.ts` and `reportGenerators.ts`.
+3. Keep CRM mutations in `src/hooks/useBarnStore.ts` and wire `ClientCrmScreen.tsx` into `SpeciesDashboardScreen.tsx` and `App.tsx`.
+
+### IMP-048: Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking
+
+- **Category:** Species & Herd UX (`species-ux`)
+- **Origin:** Session Improvement
+- **User Goal:** Support alternative companion birth/breeding certificates, printable/emailable show documents directly from show rosters, family portrait & IAGARB Angora pedigree templates, and wool/fiber harvest logging.
+- **Summary:** Adds privacy-scoped Pet-Sale Birth Certificates (omitting breeder contact info & pricing), official Breeding/Service Certificates, ARBA-style Show Entry Forms (`mailto:` + plain-text copy + Open/Youth/fees) & 4-up/1-up Show Remark Cards from ShowEvent rosters, Gen 0–2 multi-photo Family Portrait and IAGARB German Angora pedigree layouts, and SQLite v6 `wool_harvests` tracking with 7-position 100-pt IAGARB scoring and 90-day 325g shearing yield calculations.
+- **Tracked Files:** `src/core/models.ts`, `src/core/woolFiber.ts`, `src/core/alternativeCertificates.ts`, `src/core/showDocuments.ts`, `src/core/pedigreePrintStyles.ts`, `src/core/syncAndExports.ts`, `src/core/pdfExporter.ts`, `src/storage/webSqliteAdapter.ts`, `src/hooks/useBarnStore.ts`, `src/components/PrintPreviewModal.tsx`, `src/components/HerdScreen.tsx`, `src/components/PedigreeScreen.tsx`, `src/components/BreedingScreen.tsx`, `src/components/SpeciesDashboardScreen.tsx`, `src/App.tsx`, `src/core/__tests__/woolFiber.test.ts`, `src/core/__tests__/alternativeCertificates.test.ts`, `src/core/__tests__/showDocuments.test.ts`
+
+**Automated Invariants Checked:**
+- `src/core/models.ts` must contain `WoolHarvest`, `IagarbScorecard`, `WOOL_HARVEST_METHODS`, `normalizeWoolHarvestMethod` — *WoolHarvest and IagarbScorecard domain models and normalizers must remain intact.*
+- `src/core/woolFiber.ts` must contain `IAGARB_JUDGING_POSITIONS`, `computeIagarbScoreTotal`, `evaluateIagarbEligibility`, `compute90DayEquivalentGrams`, `summarizeAnimalWoolHarvests` — *Pure TS IAGARB 100-point rubric, 325g/90-day performance yield normalization, and harvest summary calculators must stay zero-DOM.*
+- `src/core/alternativeCertificates.ts` must contain `generatePetBirthCertificateHtml`, `generateBreedingCertificateHtml`, `buildPetBirthCertificateFileName`, `buildBreedingCertificateFileName` — *Pure TS Pet-Sale Birth Certificate (no breeder contact/pricing) and Breeding Certificate generators must remain zero-DOM and XSS-safe.*
+- `src/core/showDocuments.ts` must contain `generateShowEntryFormHtml`, `generateShowRemarkCardsHtml`, `buildShowEntryMailtoUrl`, `buildShowEntryPlainTextSummary` — *Pure TS ARBA Show Entry Form, emailable plain-text/mailto dispatchers, and 4-up/1-up Remark Card generators must remain zero-DOM.*
+- `src/core/pedigreePrintStyles.ts` must contain `family_portrait`, `iagarb_angora` — *Family Portrait and IAGARB German Angora pedigree presets must stay registered.*
+- `src/storage/webSqliteAdapter.ts` must contain `wool_harvests`, `saveWoolHarvest`, `deleteWoolHarvest` — *SQLite schema v6 must store and hydrate wool_harvests cleanly.*
+- `src/hooks/useBarnStore.ts` must contain `saveWoolHarvest`, `deleteWoolHarvest` — *Store must expose species-isolated wool harvest mutations with delta outbox sync.*
+- `src/components/HerdScreen.tsx` must contain `generatePetBirthCertificateHtml`, `onSaveWoolHarvest`, `IAGARB_JUDGING_POSITIONS` — *HerdScreen must provide Pet-Sale Birth Certificate previews and Wool / Fiber + IAGARB scoring.*
+- `src/components/BreedingScreen.tsx` must contain `generateBreedingCertificateHtml`, `Breeding Cert` — *BreedingScreen must expose Breeding Certificate preview controls.*
+- `src/components/SpeciesDashboardScreen.tsx` must contain `generateShowEntryFormHtml`, `generateShowRemarkCardsHtml`, `buildShowEntryMailtoUrl` — *SpeciesDashboardScreen must expose Show Entry Form and Remark Cards print/email previews directly from ShowEvents.*
+
+**Restoration Playbook if Overwritten:**
+1. Keep `WoolHarvest` and `IagarbScorecard` models in `src/core/models.ts` and `wool_harvests` SQLite v6 schema in `src/storage/webSqliteAdapter.ts`.
+2. Restore pure modules `src/core/woolFiber.ts`, `src/core/alternativeCertificates.ts`, and `src/core/showDocuments.ts` with their unit tests.
+3. Keep `family_portrait` & `iagarb_angora` rendering in `pedigreePrintStyles.ts`, `syncAndExports.ts`, and `pdfExporter.ts`, plus UI wiring in `HerdScreen.tsx`, `PedigreeScreen.tsx`, `BreedingScreen.tsx`, `SpeciesDashboardScreen.tsx`, and `App.tsx`.
+
+
```

### `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt` (`+1` / `-1`, source: `part-01_dfb892d4.md`)

```diff
--- working/android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt
+++ import/android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt
@@ -507,7 +507,7 @@
             }
 
             "REQUEST_PRINT" -> {
-                printBridge.printFromBridge(payload)
+                printBridge.printCurrentPage()
             }
 
             "OPEN_EXTERNAL_URL" -> {
```

### `android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt` (`+14` / `-132`, source: `part-01_dfb892d4.md`)

```diff
--- working/android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt
+++ import/android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt
@@ -6,26 +6,22 @@
 package org.askkim.pedigree.wrapper
 
 import android.content.Context
-import android.graphics.Color
 import android.os.Handler
 import android.os.Looper
 import android.print.PrintAttributes
 import android.print.PrintManager
-import android.webkit.WebResourceRequest
-import android.webkit.WebSettings
 import android.webkit.WebView
-import android.webkit.WebViewClient
 import android.widget.Toast
 import androidx.appcompat.app.AppCompatActivity
-import org.json.JSONObject
 
 /**
- * Handles `REQUEST_PRINT` messages from `pedigreeBridge` using Android's [PrintManager].
+ * Handles `REQUEST_PRINT` messages from `pedigreeBridge` using Android's [PrintManager]
+ * and `webView.createPrintDocumentAdapter("Pedigree")`.
  *
- * When the PWA provides a self-contained `htmlContent` payload (from `.HTM` / card / binder
- * print preview), it renders into a hardened, JavaScript-disabled ephemeral [WebView] so dark
- * mode classes and app shell chrome never leak onto printed pages and orientation (`landscape` vs
- * `portrait`) is honored automatically via [PrintAttributes].
+ * Why is this bridge needed?
+ * Inside Android `WebView`, calling JavaScript `window.print()` directly is a silent no-op.
+ * Bridging `REQUEST_PRINT` to Android's native [PrintManager] lets users print pedigree
+ * certificates, cage cards, and Barn Binders or export them via Android's built-in "Save as PDF".
  */
 class PrintBridge(
     private val activity: AppCompatActivity,
@@ -33,46 +29,26 @@
 ) {
     private val mainHandler = Handler(Looper.getMainLooper())
     private var destroyed = false
-    private var pendingPrintWebView: WebView? = null
 
     /**
-     * Opens the Android system print/PDF preview for the current WebView page.
+     * Opens the Android system print/PDF preview for the currently loaded WebView page.
+     * Safe to invoke from any thread; marshals automatically onto the Android main thread because
+     * `WebView.createPrintDocumentAdapter` must be called on the UI thread.
      */
     fun printCurrentPage() {
-        printFromBridge(null)
-    }
-
-    /**
-     * Opens the Android system print/PDF preview using optional `REQUEST_PRINT` payload fields:
-     * - `title`: sanitized print job / suggested PDF filename
-     * - `orientation`: `"landscape"` or `"portrait"`
-     * - `htmlContent`: self-contained HTML document to render cleanly in an offscreen WebView
-     */
-    fun printFromBridge(payload: JSONObject?) {
-        val rawTitle = payload?.optNonNullString("title") ?: ""
-        val jobTitle = sanitizePrintJobTitle(rawTitle)
-        val orientation = payload?.optNonNullString("orientation") ?: ""
-        val htmlContent = payload?.optNonNullString("htmlContent") ?: ""
-
         val runPrint = Runnable {
             if (destroyed || activity.isFinishing || activity.isDestroyed) return@Runnable
+            val wv = webViewProvider() ?: return@Runnable
             val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
             if (printManager == null) {
                 Toast.makeText(activity, R.string.print_unavailable, Toast.LENGTH_SHORT).show()
                 return@Runnable
             }
 
-            val attributes = buildPrintAttributes(orientation)
-
-            if (htmlContent.isNotBlank()) {
-                printHtmlDocument(printManager, jobTitle, htmlContent, attributes)
-                return@Runnable
-            }
-
-            val wv = webViewProvider() ?: return@Runnable
             try {
-                val adapter = wv.createPrintDocumentAdapter(jobTitle)
-                printManager.print(jobTitle, adapter, attributes)
+                val adapter = wv.createPrintDocumentAdapter(PRINT_DOCUMENT_NAME)
+                val attributes = PrintAttributes.Builder().build()
+                printManager.print(PRINT_DOCUMENT_NAME, adapter, attributes)
             } catch (_: Exception) {
                 Toast.makeText(activity, R.string.print_unavailable, Toast.LENGTH_SHORT).show()
             }
@@ -85,104 +61,10 @@
         }
     }
 
-    private fun buildPrintAttributes(orientation: String): PrintAttributes {
-        val mediaSize = if (orientation.equals("landscape", ignoreCase = true)) {
-            PrintAttributes.MediaSize.NA_LETTER.asLandscape()
-        } else {
-            PrintAttributes.MediaSize.NA_LETTER.asPortrait()
-        }
-        return PrintAttributes.Builder()
-            .setMediaSize(mediaSize)
-            .build()
-    }
-
-    private fun sanitizePrintJobTitle(rawTitle: String): String {
-        val cleaned = rawTitle
-            .replace(Regex("[\\r\\n\\t\\p{Cntrl}]+"), " ")
-            .trim()
-            .take(120)
-        return cleaned.ifEmpty { PRINT_DOCUMENT_NAME }
-    }
-
-    private fun JSONObject.optNonNullString(key: String): String {
-        return if (isNull(key)) "" else optString(key, "")
-    }
-
-    private fun printHtmlDocument(
-        printManager: PrintManager,
-        jobTitle: String,
-        htmlContent: String,
-        attributes: PrintAttributes
-    ) {
-        cleanupPendingPrintWebView()
-        try {
-            val printWv = WebView(activity).apply {
-                setBackgroundColor(Color.WHITE)
-                settings.apply {
-                    javaScriptEnabled = false
-                    allowFileAccess = false
-                    allowContentAccess = false
-                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
-                    loadWithOverviewMode = true
-                    useWideViewPort = true
-                }
-            }
-            pendingPrintWebView = printWv
-
-            printWv.webViewClient = object : WebViewClient() {
-                private var started = false
-
-                override fun shouldOverrideUrlLoading(
-                    view: WebView?,
-                    request: WebResourceRequest?
-                ): Boolean {
-                    return true
-                }
-
-                override fun onPageFinished(view: WebView?, url: String?) {
-                    if (started || destroyed || activity.isFinishing || activity.isDestroyed) {
-                        return
-                    }
-                    started = true
-                    try {
-                        val adapter = printWv.createPrintDocumentAdapter(jobTitle)
-                        printManager.print(jobTitle, adapter, attributes)
-                    } catch (_: Exception) {
-                        Toast.makeText(activity, R.string.print_unavailable, Toast.LENGTH_SHORT).show()
-                    }
-                }
-            }
-
-            printWv.loadDataWithBaseURL(
-                "https://appassets.androidplatform.net/",
-                htmlContent,
-                "text/html",
-                "UTF-8",
-                null
-            )
-        } catch (_: Exception) {
-            cleanupPendingPrintWebView()
-            Toast.makeText(activity, R.string.print_unavailable, Toast.LENGTH_SHORT).show()
-        }
-    }
-
-    private fun cleanupPendingPrintWebView() {
-        val existing = pendingPrintWebView ?: return
-        pendingPrintWebView = null
-        try {
-            existing.stopLoading()
-            existing.loadUrl("about:blank")
-            existing.destroy()
-        } catch (_: Exception) {
-            // Best-effort teardown of ephemeral print WebView
-        }
-    }
-
-    /** Cancels pending main-thread print callbacks and releases any offscreen print WebView. */
+    /** Cancels pending main-thread print callbacks when the hosting Activity is destroyed. */
     fun destroy() {
         destroyed = true
         mainHandler.removeCallbacksAndMessages(null)
-        cleanupPendingPrintWebView()
     }
 
     companion object {
```

### `docs/plans/suggestions-backlog.md` (`+8` / `-16`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/docs/plans/suggestions-backlog.md
+++ import/docs/plans/suggestions-backlog.md
@@ -3,41 +3,33 @@
 > **NOTE TO FUTURE SELF / CODING ASSISTANT:**
 > Whenever any suggestion on this list is implemented and verified, **remove that completed item from this file** (and update the "Remaining" count/numbering cleanly) so this document always reflects only unimplemented suggestions.
 >
-> *Audit note (2026-11-20): Removed already-completed ES2018 `Blob.prototype.arrayBuffer()` / `readBlobAsArrayBuffer` shim item, reorganized remaining items by criticality, completed & removed the GitHub Pages Subpath Build & Bun Toolchain fix, Active Medication Withdrawal Countdown & Safety Alerts (`IMP-024`), Align Sync Outbox Mutations & Reset Cleanup (`IMP-025`), Clock-Skew Consistency & Archive Export Double-Tap Locks (`IMP-026`), True Lazy 2–3 Gen SQLite/OPFS Pedigree Fetching & Windowed List Virtualization (`IMP-027`), Cage / Pen Capacity Warnings & Quick Occupant Assignment (`IMP-028`), Breeding Lab & Master Task List Refinements (`IMP-029`), Consolidated Import/Export Hub & Extensible Non-Native Exporter Registry (`IMP-030`), Interactive CSV Column Mapper, Starter Template & Unlinked Parent Preview (`IMP-031`), `src/core/` Isolation, Duplicate Removal & Metadata/Docs Sync, Low-RAM Export Streaming & Full OPFS `/tmp` Staging (`IMP-032`), Guard `useAsyncSubmitLock` & `useAsyncKeyedLock` Against StrictMode/Activity Remount Wedge, "Barn Bench" Fast Sequential Batch Entry Mode (`IMP-034`), Batch Cage Card, Compact Mini-Sheet & Pedigree Printing from Herd Multi-Select (`IMP-035`), QR-Coded Cage Cards & Visual Hutch-Row / Facility Pen Board (`IMP-036`), Side-by-Side Multi-Candidate Pairing Comparison Matrix (`IMP-037`), Color-Coded Allele Provenance, Unique-Ancestor Dimming & Registration Flags (`IMP-038`), Surface `.HTM` Download & Web Share Errors in Print Preview (`PrintPreviewModal.tsx`), Header `X` & Backdrop Dismiss on the Update Litter Outcome Modal (`BreedingScreen.tsx`), removed obsolete redundant-branch cleanup item in `universalPedigreeImporter.ts` (already simplified), completed & removed Pedigree Print Orientation Toggle, Optional Breeder Logo, ARBA `lbs.oz` Notation & Direct Offline PDF Export (`IMP-039`), completed & removed 8-Generation Pedigree Tree Mode, Custom Print Styling & Shareable Export Cards (`IMP-040`), completed & removed Structured Show Placements, Wins, Judge Notes & E-Leg Vault (`IMP-041`), completed & removed Genetic Variety / Coat Explorer Sandbox (`IMP-042`), completed & removed Rate of Gain, Comparative Weight Charts & Litter Survival Curves (`IMP-043`), completed & removed Feed Inventory Ledger, Tag Lot-Number OCR & Biosecurity Auto-Purge (`IMP-044`), completed & removed Offline Photo Pedigree Scanning & Local OCR Importer (`IMP-045`), and completed & removed Local Economic Ledger, Meat/Pelt Processing Yields & 4-H/FFA Project Books (`IMP-046`).*
+> *Audit note (2026-11-20): Removed already-completed ES2018 `Blob.prototype.arrayBuffer()` / `readBlobAsArrayBuffer` shim item, reorganized remaining items by criticality, completed & removed the GitHub Pages Subpath Build & Bun Toolchain fix, Active Medication Withdrawal Countdown & Safety Alerts (`IMP-024`), Align Sync Outbox Mutations & Reset Cleanup (`IMP-025`), Clock-Skew Consistency & Archive Export Double-Tap Locks (`IMP-026`), True Lazy 2–3 Gen SQLite/OPFS Pedigree Fetching & Windowed List Virtualization (`IMP-027`), Cage / Pen Capacity Warnings & Quick Occupant Assignment (`IMP-028`), Breeding Lab & Master Task List Refinements (`IMP-029`), Consolidated Import/Export Hub & Extensible Non-Native Exporter Registry (`IMP-030`), Interactive CSV Column Mapper, Starter Template & Unlinked Parent Preview (`IMP-031`), `src/core/` Isolation, Duplicate Removal & Metadata/Docs Sync, Low-RAM Export Streaming & Full OPFS `/tmp` Staging (`IMP-032`), Guard `useAsyncSubmitLock` & `useAsyncKeyedLock` Against StrictMode/Activity Remount Wedge, "Barn Bench" Fast Sequential Batch Entry Mode (`IMP-034`), Batch Cage Card, Compact Mini-Sheet & Pedigree Printing from Herd Multi-Select (`IMP-035`), QR-Coded Cage Cards & Visual Hutch-Row / Facility Pen Board (`IMP-036`), Side-by-Side Multi-Candidate Pairing Comparison Matrix (`IMP-037`), Color-Coded Allele Provenance, Unique-Ancestor Dimming & Registration Flags (`IMP-038`), Surface `.HTM` Download & Web Share Errors in Print Preview (`PrintPreviewModal.tsx`), Header `X` & Backdrop Dismiss on the Update Litter Outcome Modal (`BreedingScreen.tsx`), removed obsolete redundant-branch cleanup item in `universalPedigreeImporter.ts` (already simplified), completed & removed Pedigree Print Orientation Toggle, Optional Breeder Logo, ARBA `lbs.oz` Notation & Direct Offline PDF Export (`IMP-039`), completed & removed 8-Generation Pedigree Tree Mode, Custom Print Styling & Shareable Export Cards (`IMP-040`), completed & removed Structured Show Placements, Wins, Judge Notes & E-Leg Vault (`IMP-041`), completed & removed Genetic Variety / Coat Explorer Sandbox (`IMP-042`), completed & removed Rate of Gain, Comparative Weight Charts & Litter Survival Curves (`IMP-043`), completed & removed Feed Inventory Ledger, Tag Lot-Number OCR & Biosecurity Auto-Purge (`IMP-044`), completed & removed Offline Photo Pedigree Scanning & Local OCR Importer (`IMP-045`), completed & removed Local Economic Ledger, Meat/Pelt Processing Yields & 4-H/FFA Project Books (`IMP-046`), completed & removed Client CRM, Buyer Waitlist, Reservations & Deposit Reminders (`IMP-047`), and completed & removed Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking (`IMP-048`).*
 
 ---
 
-## Current App Suggestions & Remediation List (8 Remaining — Ordered by Criticality & Severity)
+## Current App Suggestions & Remediation List (6 Remaining — Ordered by Criticality & Severity)
 
 ### Priority 4: Specialized Operations, OCR Pipelines, Economics, CRM & Optional Cloud
 *Larger domain expansions, client-side OCR modules, financial/CRM tools, and strictly opt-in future cloud sync.*
 
-1. **Client CRM, Buyer Waitlist, Reservations & Deposit Reminders**
-   - Add a local-first breeder CRM tracking buyer waitlist inquiries, animal/litter reservations, deposit tracking with automated follow-up reminders, and printable/exportable sales agreements.
-
-2. **Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking**
-   - **Alternative Documents & Family Layouts:** Generate pet-sale Birth Certificates (omitting breeder contact info), Breeding Certificates, and multi-photo family portrait pedigree layouts.
-   - **Show Entry Forms & Remark Cards:** Generate printable/emailable official ARBA-style show entry forms and show remark card labels directly from `ShowEvent` entries.
-   - **Wool / Fiber Harvest & IAGARB Angora Template:** Log individual fiber harvests (prime vs. grade weights) with totals summarized onto pedigrees, plus breed-specific pedigree templates like the IAGARB standard for German Angoras with wool judging point calculations.
-
-3. **Founder Loss / Heritability Analytics & Interactive Barn Scheduler Gantt**
+1. **Founder Loss / Heritability Analytics & Interactive Barn Scheduler Gantt**
    - Add heritability coefficient trends and founder-loss / ancestor genetic contribution analytics in Breeding Lab & Pedigree Explorer.
    - Add an interactive drag-and-drop Barn Scheduler Gantt timeline with smart priority escalation for time-critical tasks (such as overdue nest boxes), paired with local P2P/LAN outbox reconciliation.
 
-4. **Zero-Server Breeder Showcase / "For Sale" Catalog Exporter**
+2. **Zero-Server Breeder Showcase / "For Sale" Catalog Exporter**
    - Generate a self-contained static HTML showcase page or buyer-ready stock sheet from animals marked `For Sale` (with photos, summarized pedigrees, and breeder contact info) that breeders can share or host free without a centralized marketplace server.
 
-5. **Health Reference Wiki Links & Local Veterinary PDF Folder Pointer**
+3. **Health Reference Wiki Links & Local Veterinary PDF Folder Pointer**
    - Add curated online links to external rabbit/livestock health wikis alongside a simple local device folder pointer for personal offline veterinary PDFs, paired with periodic reminders to back up external document folders.
 
-6. **Breeding Calendar Moon/Holiday/Weather Overlays, Mileage Tax Log & Personal Journal**
+4. **Breeding Calendar Moon/Holiday/Weather Overlays, Mileage Tax Log & Personal Journal**
    - **Calendar Overlays:** Add offline-computed moon-phase and holiday markers plus an optional online weekly weather forecast strip inside the Breeding Calendar.
    - **Mileage & Tax Report Log:** Log barn/show travel mileage and export tax-ready annual mileage reports.
    - **Personal Barn Journal:** Add a date-organized journal supporting rich text notes, color categories, star ratings, and full-text search.
 
-7. **The Judge's Notebook (Dedicated Show Judge Module)**
+5. **The Judge's Notebook (Dedicated Show Judge Module)**
    - Add an optional module for show judges to manage assigned show dates, club contacts, travel mileage, judging expenses, bid statuses, and judging contracts.
 
-8. **Optional Cloud App-Folder Sync (`Google Drive AppFolder` / `OneDrive approot`) & `403`/`507` Quota Circuit Breaker**
+6. **Optional Cloud App-Folder Sync (`Google Drive AppFolder` / `OneDrive approot`) & `403`/`507` Quota Circuit Breaker**
    - *(Optional future roadmap beyond current zero-cloud / local-folder SyncThing sync)* Trigger user-opted background delta syncs to isolated app-specific cloud folders (`AppFolder` / `approot`) with incremental delta chunking when storage thresholds are tight.
    - Intercept `403` / `507` QuotaExceeded cloud responses with an immediate circuit breaker that pauses failing automated cloud syncs, shows a persistent warning, and prunes rolling cloud backups without ever blocking or rolling back local IndexedDB writes.
```

### `package.json` (`+1` / `-1`, source: `part-01_dfb892d4.md`)

```diff
--- working/package.json
+++ import/package.json
@@ -2,7 +2,7 @@
   "name": "pedigree",
   "description": "Community Pedigree Project — App Name: Community Pedigree | Repo: AskKim/Pedigree | Package Name: pedigree",
   "license": "AGPL-3.0-or-later",
-  "version": "0.1.0-alpha.2",
+  "version": "0.1.0-prealpha.1",
   "type": "module",
   "scripts": {
     "dev": "vite --port=3000 --host=0.0.0.0",
```

### `prompts/master_system_prompt.md` (`+1` / `-2`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/prompts/master_system_prompt.md
+++ import/prompts/master_system_prompt.md
@@ -6,7 +6,7 @@
 
 # Master System Prompt: Offline-First Pedigree PWA
 
-**Last-Edited Timestamp:** 2026-11-21
+**Last-Edited Timestamp:** 2026-11-20
 > **Protection Flag (`DO_NOT_REMOVE_WITHOUT_CONFIRMATION`):** Do not delete, move, or remove this file from `/prompts/` without explicit user confirmation.
 
 ## 0. Minimal-Output Alignment Check
@@ -26,7 +26,6 @@
 - **Flag Uncertainty:** Mark unverified browser quirks/edge cases inline with `// UNVERIFIED: [reason]`.
 
 ## 2. Architecture & Type Safety
-- **CRITICAL RULE — Never Convert PWA Away From React:** The PWA portion of this project MUST NEVER be converted, rewritten, or migrated away from React. It must always remain a React + Vite + TypeScript application—even during build-crash recovery, emergency fixes, or refactoring.
 - **Stack & Target:** Unified React + Vite + strict TypeScript PWA (iOS, Android, Desktop), transpiled to ES2018 (`browserslist > 0.5%`). Offline-first, zero mandatory cloud/accounts.
 - **Strict Types:** Never silence TypeScript errors with `as any`, `@ts-ignore`, or `@ts-expect-error`; fix root types.
 - **Modularity & Sync:** Keep strict separation across `components/` (UI), `hooks/` (state), `storage/` (adapters/OPFS), and `core/` (pure TS domain logic, zero DOM/window). Preserve unit tests, run validation scripts after edits, and keep docs synced with code.
```

### `public/version.json` (`+1` / `-1`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/public/version.json
+++ import/public/version.json
@@ -1,5 +1,5 @@
 {
-  "appVersion": "0.1.0-alpha.2",
+  "appVersion": "0.1.0-prealpha.1",
   "schemaVersion": 6,
   "minDirectUpgradeSchema": 4,
   "releaseNotes": "Pedigree Gen 4+ lazy branch expansion, PWA update governor, offline toggle & SHA-256 upgrade gate."
```

### `src/App.tsx` (`+57` / `-13`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/src/App.tsx
+++ import/src/App.tsx
@@ -40,7 +40,6 @@
 import { AsyncErrorToastHost } from './components/AsyncErrorToastHost';
 import { HomeSpeciesScreen } from './components/HomeSpeciesScreen';
 import { TechyStuffErrorBoundary } from './components/TechyStuffErrorBoundary';
-import { WipedStorageRecoveryModal } from './components/WipedStorageRecoveryModal';
 import { formatSystemTaskTitle } from './core/calendarExport';
 import { isSameSpecies, normalizeCalendarSyncSettings } from './core/models';
 import { useBarnStore, WorkspaceRoute } from './hooks/useBarnStore';
@@ -87,6 +86,10 @@
   ComponentProps<typeof import('./components/EconomicsLedgerScreen')['EconomicsLedgerScreen']>
 >(() => import('./components/EconomicsLedgerScreen'), 'EconomicsLedgerScreen', 'Economics & 4-H Ledger');
 
+const ClientCrmScreen = lazyNamedRoute<
+  ComponentProps<typeof import('./components/ClientCrmScreen')['ClientCrmScreen']>
+>(() => import('./components/ClientCrmScreen'), 'ClientCrmScreen', 'Client CRM & Waitlist');
+
 const ReportsScreen = lazyNamedRoute<
   ComponentProps<typeof import('./components/ReportsScreen')['ReportsScreen']>
 >(() => import('./components/ReportsScreen'), 'ReportsScreen', 'Reports');
@@ -125,6 +128,14 @@
   () => import('./components/CalendarIntegrationModals'),
   'CalendarSyncConfirmModal',
   'Calendar Sync'
+);
+
+const WipedStorageRecoveryModal = lazyNamedRoute<
+  ComponentProps<typeof import('./components/WipedStorageRecoveryModal')['WipedStorageRecoveryModal']>
+>(
+  () => import('./components/WipedStorageRecoveryModal'),
+  'WipedStorageRecoveryModal',
+  'Storage Recovery'
 );
 
 const ROUTE_LABELS: Record<WorkspaceRoute, string> = {
@@ -136,6 +147,7 @@
   pedigree: 'Pedigree Explorer',
   feed: 'Feed Ledger',
   economics: 'Economics & 4-H Ledger',
+  crm: 'Client CRM & Waitlist',
   reports: 'Reports',
   memo: 'Species Memo',
   importExport: 'Import / Export Hub',
@@ -410,6 +422,7 @@
         p: { route: 'pedigree', label: 'Pedigree' },
         f: { route: 'feed', label: 'Feed Ledger' },
         e: { route: 'economics', label: 'Economics & 4-H Ledger' },
+        c: { route: 'crm', label: 'Client CRM & Waitlist' },
         o: { route: 'reports', label: 'Reports' },
         i: { route: 'importExport', label: 'Import / Export Hub' },
         s: { route: 'settings', label: 'Settings' },
@@ -1403,6 +1416,9 @@
             onUpdateSettings={(patch, options) => {
               void store.updateSettings(patch, options);
             }}
+            onSaveWoolHarvest={store.saveWoolHarvest}
+            onDeleteWoolHarvest={store.deleteWoolHarvest}
+            isConstrainedDevice={deviceCapability.assessment.shouldApplyLowMemoryHandling}
           />
         )}
 
@@ -1464,6 +1480,7 @@
               void store.restoreAnimalConflictAlert(animalId, kinds);
             }}
             onLoadFullPhoto={store.loadAnimalPhotoDataUrl}
+            onLoadFullPhotosBatch={store.loadAnimalPhotoDataUrlsBatch}
             onLoadPedigreeNeighborhood={store.loadPedigreeNeighborhood}
             onCheckPedigreeBranchesHaveAncestors={store.checkPedigreeBranchesHaveAncestors}
             onUpdateBreederLogo={(dataUrl) => {
@@ -1508,6 +1525,27 @@
             onDeleteProcessingLog={store.deleteProcessingLog}
             onSaveYouthProjectBook={store.saveYouthProjectBook}
             onDeleteYouthProjectBook={store.deleteYouthProjectBook}
+          />
+        )}
+
+        {route === 'crm' && (
+          <ClientCrmScreen
+            activeData={activeSpeciesData}
+            settings={snapshot.settings}
+            onBackToHub={() => setRoute('dashboard')}
+            onOpenAnimal={(animalId) => {
+              store.setSelectedAnimalId(animalId);
+              setRoute('herd');
+            }}
+            onOpenReports={() => setRoute('reports')}
+            onSaveClient={store.saveClientContact}
+            onDeleteClient={store.deleteClientContact}
+            onSaveWaitlistEntry={store.saveWaitlistEntry}
+            onDeleteWaitlistEntry={store.deleteWaitlistEntry}
+            onSaveReservation={store.saveAnimalReservation}
+            onDeleteReservation={store.deleteAnimalReservation}
+            onCompleteReservationSale={store.completeReservationSale}
+            onCreateReminderTask={store.createCrmReminderTask}
           />
         )}
 
@@ -1700,6 +1738,7 @@
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">B</kbd> Breeding ·{' '}
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">P</kbd> Pedigree ·{' '}
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">F</kbd> Feed ·{' '}
+              <kbd className="font-mono font-semibold text-[var(--barn-ink)]">C</kbd> CRM ·{' '}
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">O</kbd> Reports ·{' '}
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">I</kbd> Import/Export ·{' '}
               <kbd className="font-mono font-semibold text-[var(--barn-ink)]">S</kbd> Settings
@@ -1745,18 +1784,22 @@
       )}
 
       {/* Blocking Wiped-Browser-Storage Recovery Gate (IMP-018) */}
-      <WipedStorageRecoveryModal
-        context={store.wipedRecoveryContext}
-        archivedHerdBundles={store.archivedHerdBundles}
-        onRestoreLatestOpfs={store.restoreLatestOpfsOnWipedRecovery}
-        onRestoreArchivedBundle={(archiveKey) => store.restoreArchivedHerdBundle(archiveKey)}
-        onImportJsonReplace={(jsonText) => store.importJsonBackup(jsonText, 'replace')}
-        onImportArchiveReplace={(bytes, fileName) =>
-          store.importBackupArchiveBytes(bytes, fileName, 'replace')
-        }
-        onImportSqlite={store.importSqliteBytes}
-        onStartFresh={store.startFreshAfterWipedRecovery}
-      />
+      {store.wipedRecoveryContext?.detected && (
+        <Suspense fallback={null}>
+          <WipedStorageRecoveryModal
+            context={store.wipedRecoveryContext}
+            archivedHerdBundles={store.archivedHerdBundles}
+            onRestoreLatestOpfs={store.restoreLatestOpfsOnWipedRecovery}
+            onRestoreArchivedBundle={(archiveKey) => store.restoreArchivedHerdBundle(archiveKey)}
+            onImportJsonReplace={(jsonText) => store.importJsonBackup(jsonText, 'replace')}
+            onImportArchiveReplace={(bytes, fileName) =>
+              store.importBackupArchiveBytes(bytes, fileName, 'replace')
+            }
+            onImportSqlite={store.importSqliteBytes}
+            onStartFresh={store.startFreshAfterWipedRecovery}
+          />
+        </Suspense>
+      )}
 
       {/* Select Livestock Species Before Entering Herd from Home */}
       {showHerdSpeciesPicker && (
@@ -1859,6 +1902,7 @@
                 { key: 'P', label: 'Pedigree Explorer', desc: 'Interactive 3–6 generation ancestry tree' },
                 { key: 'F', label: 'Feed & Lot Ledger', desc: 'Feed purchases, tag OCR lot indexing & biosecurity purge' },
                 { key: 'E', label: 'Economics & 4-H Ledger', desc: 'Expenses, receipts, P&L margins, meat/pelt yields & 4-H/FFA books' },
+                { key: 'C', label: 'Client CRM & Waitlist', desc: 'Buyer contacts, ranked waitlist matching, deposits & sales agreements' },
                 { key: 'O', label: 'Reports', desc: 'Barn reports, printable herd rosters & inventory summaries' },
                 { key: 'I', label: 'Import / Export Hub', desc: 'System backups, native restores, sync & external exporters' },
                 { key: 'S', label: 'Settings', desc: 'Barn preferences, calendar sync, appearance & diagnostics' },
```

### `src/components/AnimalPhotoGallery.tsx` (`+105` / `-23`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/src/components/AnimalPhotoGallery.tsx
+++ import/src/components/AnimalPhotoGallery.tsx
@@ -34,6 +34,8 @@
   validateUploadFileSize,
 } from '../core/inputSanitization';
 import { Animal, AnimalPhoto } from '../core/models';
+import { logDiagnosticEvent } from '../storage/crashLogger';
+import { revokeBlobUrlIfNeeded } from '../storage/photoHydration';
 import { optimizeImageFile } from '../storage/webImageOptimizer';
 import { useAccessibleDialog } from '../utils/useAccessibleDialog';
 
@@ -89,22 +91,37 @@
   });
 
   const captionPulseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
+  const hydratedUrlsRef = useRef<Record<string, string>>({});
+  const hydrationQueueRef = useRef<Promise<void>>(Promise.resolve());
+
+  useEffect(() => {
+    hydratedUrlsRef.current = hydratedUrls;
+  }, [hydratedUrls]);
 
   useEffect(() => {
     return () => {
       if (captionPulseTimerRef.current !== null) {
         clearTimeout(captionPulseTimerRef.current);
       }
+      for (const url of Object.values(hydratedUrlsRef.current)) {
+        revokeBlobUrlIfNeeded(url);
+      }
+      hydratedUrlsRef.current = {};
     };
   }, []);
 
   // Clear per-animal resolved full-res image URLs when switching animals
   useEffect(() => {
-    setHydratedUrls({});
+    setHydratedUrls((prev) => {
+      for (const url of Object.values(prev)) {
+        revokeBlobUrlIfNeeded(url);
+      }
+      return {};
+    });
     setLoadingPhotoId(null);
   }, [animal.id]);
 
-  // Lazily fetch full-resolution dataUrl from SQLite when viewing a dehydrated photo
+  // Lazily and sequentially fetch full-resolution URL from SQLite when viewing a dehydrated photo
   useEffect(() => {
     if (!activePhoto || activePhoto.dataUrl || hydratedUrls[activePhoto.id] || !onLoadFullPhoto) {
       return;
@@ -112,22 +129,52 @@
     let cancelled = false;
     const targetId = activePhoto.id;
     setLoadingPhotoId(targetId);
-    void onLoadFullPhoto(targetId)
-      .then((resolved) => {
-        if (cancelled || !resolved) return;
+
+    const runLoad = async () => {
+      if (cancelled) return;
+      try {
+        const resolved = await onLoadFullPhoto(targetId);
+        if (cancelled) {
+          revokeBlobUrlIfNeeded(resolved);
+          return;
+        }
+        if (!resolved) return;
         setHydratedUrls((prev) => {
           if (prev[targetId] === resolved) return prev;
+          if (prev[targetId]) {
+            revokeBlobUrlIfNeeded(prev[targetId]);
+          }
           const entries = Object.entries(prev).filter(([k]) => k !== targetId);
           // Keep local component state bounded even on large multi-photo galleries
+          const evicted = entries.slice(0, Math.max(0, entries.length - 7));
+          for (const [, evictedUrl] of evicted) {
+            revokeBlobUrlIfNeeded(evictedUrl);
+          }
           const trimmed = entries.slice(-7);
           return Object.fromEntries([...trimmed, [targetId, resolved]]);
         });
-      })
-      .finally(() => {
+      } catch (err) {
+        logDiagnosticEvent({
+          level: 'warn',
+          category: 'media',
+          message: `Failed to load full-resolution photo "${targetId}"`,
+          error: err,
+        });
+        if (!cancelled) {
+          setUploadError(
+            err instanceof Error && err.message
+              ? `Could not load full photo: ${err.message}`
+              : 'Could not load full-resolution photo from local storage.'
+          );
+        }
+      } finally {
         if (!cancelled) {
           setLoadingPhotoId((curr) => (curr === targetId ? null : curr));
         }
-      });
+      }
+    };
+
+    hydrationQueueRef.current = hydrationQueueRef.current.then(runLoad, runLoad);
     return () => {
       cancelled = true;
     };
@@ -235,15 +282,53 @@
     if (!activePhoto) return;
     const trimmed = captionDraft.trim();
     if (trimmed === activePhoto.caption) return;
-    await onUpdateCaption(activePhoto.id, trimmed);
-    setCaptionSavedPulse(true);
-    if (captionPulseTimerRef.current !== null) {
-      clearTimeout(captionPulseTimerRef.current);
-    }
-    captionPulseTimerRef.current = setTimeout(() => {
-      captionPulseTimerRef.current = null;
-      setCaptionSavedPulse(false);
-    }, 1800);
+    try {
+      await onUpdateCaption(activePhoto.id, trimmed);
+      setCaptionSavedPulse(true);
+      if (captionPulseTimerRef.current !== null) {
+        clearTimeout(captionPulseTimerRef.current);
+      }
+      captionPulseTimerRef.current = setTimeout(() => {
+        captionPulseTimerRef.current = null;
+        setCaptionSavedPulse(false);
+      }, 1800);
+    } catch (err) {
+      setUploadError(
+        err instanceof Error && err.message ? err.message : 'Could not save photo caption.'
+      );
+    }
+  };
+
+  const handleSetPrimaryPhoto = async (photoId: string) => {
+    try {
+      setUploadError(null);
+      await onSetPrimary(photoId);
+    } catch (err) {
+      setUploadError(
+        err instanceof Error && err.message ? err.message : 'Could not update primary photo.'
+      );
+    }
+  };
+
+  const handleDeletePhoto = async (photoId: string) => {
+    try {
+      setUploadError(null);
+      await onDeletePhoto(photoId);
+      setHydratedUrls((prev) => {
+        const existing = prev[photoId];
+        if (!existing) return prev;
+        revokeBlobUrlIfNeeded(existing);
+        const next = { ...prev };
+        delete next[photoId];
+        return next;
+      });
+    } catch (err) {
+      setUploadError(
+        err instanceof Error && err.message ? err.message : 'Could not delete photo.'
+      );
+    } finally {
+      setConfirmDeleteId(null);
+    }
   };
 
   return (
@@ -390,7 +475,7 @@
                   ) : (
                     <button
                       type="button"
-                      onClick={() => void onSetPrimary(activePhoto.id)}
+                      onClick={() => void handleSetPrimaryPhoto(activePhoto.id)}
                       className="min-h-[28px] px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black/85 text-white text-[11px] font-medium inline-flex items-center gap-1 backdrop-blur-xs"
                     >
                       <Star className="w-3 h-3" aria-hidden="true" />
@@ -480,10 +565,7 @@
                     <div className="flex items-center gap-1">
                       <button
                         type="button"
-                        onClick={() => {
-                          void onDeletePhoto(activePhoto.id);
-                          setConfirmDeleteId(null);
-                        }}
+                        onClick={() => void handleDeletePhoto(activePhoto.id)}
                         className="min-h-[28px] px-2 py-0.5 rounded-md bg-[var(--barn-danger)] text-[var(--barn-on-danger)] text-[11px] font-semibold"
                       >
                         Remove
@@ -583,7 +665,7 @@
                           type="button"
                           disabled={p.isPrimary}
                           onClick={() => {
-                            void onSetPrimary(p.id);
+                            void handleSetPrimaryPhoto(p.id);
                             setSelectedPhotoId(p.id);
                             setShowPrimaryPrompt(false);
                           }}
```

### `src/components/BreedingScreen.tsx` (`+102` / `-21`, source: `part-03_e26163f3.md`)

```diff
--- working/src/components/BreedingScreen.tsx
+++ import/src/components/BreedingScreen.tsx
@@ -8,7 +8,7 @@
  * Logging a breeding automatically cascades downstream barn chores via the `Master Task List`.
  */
 
-import { AlertTriangle, Loader2, Plus, RefreshCw, Search, Trash2, UserPlus, X } from 'lucide-react';
+import { AlertTriangle, FileText, Loader2, Plus, RefreshCw, Search, Trash2, UserPlus, X } from 'lucide-react';
 import React, { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
 import {
   findLitterOffspringTattooConflicts,
@@ -60,11 +60,16 @@
 import { useAccessibleDialog } from '../utils/useAccessibleDialog';
 import { useAsyncKeyedLock, useAsyncSubmitLock } from '../utils/useAsyncSubmitLock';
 import { useVirtualWindow } from '../utils/useVirtualWindow';
+import {
+  buildBreedingCertificateFileName,
+  generateBreedingCertificateHtml,
+} from '../core/alternativeCertificates';
 import { ColorGeneticsNotice } from './ColorGeneticsNotice';
 import { CoatExplorerSandbox } from './CoatExplorerSandbox';
 import { AlleleProvenanceLegend, ColoredGenotypeDisplay } from './ColoredGenotypeDisplay';
 import { GrowthAndSurvivalLab } from './GrowthAndSurvivalLab';
 import { PairingComparisonMatrix } from './PairingComparisonMatrix';
+import { PrintPreviewModal } from './PrintPreviewModal';
 import { SearchableParentPicker } from './SearchableParentPicker';
 
 interface BreedingScreenProps {
@@ -131,6 +136,10 @@
   const [includeArchivedParents, setIncludeArchivedParents] = useState(false);
   const [ledgerQuery, setLedgerQuery] = useState('');
   const [ledgerStatusFilter, setLedgerStatusFilter] = useState<'all' | BreedingStatus>('all');
+  const [breedingCertPreview, setBreedingCertPreview] = useState<{
+    breeding: BreedingRecord;
+    customNotes: string;
+  } | null>(null);
 
   const archivedCount = useMemo(
     () => animals.filter((a) => isAnimalArchived(a)).length,
@@ -1541,6 +1550,17 @@
                           className="min-h-[44px] sm:min-h-[38px] px-3.5 py-1.5 rounded-lg border border-[var(--barn-border)] text-xs font-medium hover:bg-[var(--barn-subtle)] whitespace-nowrap"
                         >
                           Log {speciesProfile.birthEventLabel} / Counts
+                        </button>
+                        <button
+                          type="button"
+                          onClick={() =>
+                            setBreedingCertPreview({ breeding: b, customNotes: '' })
+                          }
+                          title="Generate printable Breeding Certificate"
+                          className="min-h-[44px] sm:min-h-[38px] px-3 py-1.5 rounded-lg border border-[var(--barn-border)] text-xs font-medium hover:bg-[var(--barn-subtle)] inline-flex items-center gap-1.5 whitespace-nowrap"
+                        >
+                          <FileText className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                          Breeding Cert
                         </button>
                         <button
                           type="button"
@@ -2244,31 +2264,92 @@
               className="w-full min-h-[40px] px-3 py-1.5 rounded-lg bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-xs"
             />
 
-            <div className="flex justify-end gap-2 pt-2">
-              <button
-                type="button"
-                disabled={outcomeSubmitLock.isSubmitting}
-                onClick={closeOutcomeModal}
-                className="min-h-[40px] px-4 py-2 rounded-lg border border-[var(--barn-border)] text-xs font-medium disabled:opacity-55"
-              >
-                Cancel
-              </button>
-              <button
-                type="submit"
-                disabled={outcomeSubmitLock.isSubmitting}
-                aria-busy={outcomeSubmitLock.isSubmitting}
-                className="min-h-[40px] px-5 py-2 rounded-lg bg-[var(--barn-sage)] text-[var(--barn-on-sage)] text-xs font-semibold disabled:opacity-60 inline-flex items-center justify-center gap-1.5"
-              >
-                {outcomeSubmitLock.isSubmitting && (
-                  <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
-                )}
-                {outcomeSubmitLock.isSubmitting ? 'Saving Outcome...' : 'Save Outcome'}
-              </button>
+            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
+              {editingRecord ? (
+                <button
+                  type="button"
+                  onClick={() =>
+                    setBreedingCertPreview({ breeding: editingRecord, customNotes: outNotes })
+                  }
+                  className="min-h-[40px] px-3.5 py-2 rounded-lg border border-[var(--barn-border)] text-xs font-medium hover:bg-[var(--barn-subtle)] inline-flex items-center gap-1.5"
+                >
+                  <FileText className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                  Breeding Cert
+                </button>
+              ) : (
+                <span />
+              )}
+              <div className="flex justify-end gap-2">
+                <button
+                  type="button"
+                  disabled={outcomeSubmitLock.isSubmitting}
+                  onClick={closeOutcomeModal}
+                  className="min-h-[40px] px-4 py-2 rounded-lg border border-[var(--barn-border)] text-xs font-medium disabled:opacity-55"
+                >
+                  Cancel
+                </button>
+                <button
+                  type="submit"
+                  disabled={outcomeSubmitLock.isSubmitting}
+                  aria-busy={outcomeSubmitLock.isSubmitting}
+                  className="min-h-[40px] px-5 py-2 rounded-lg bg-[var(--barn-sage)] text-[var(--barn-on-sage)] text-xs font-semibold disabled:opacity-60 inline-flex items-center justify-center gap-1.5"
+                >
+                  {outcomeSubmitLock.isSubmitting && (
+                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
+                  )}
+                  {outcomeSubmitLock.isSubmitting ? 'Saving Outcome...' : 'Save Outcome'}
+                </button>
+              </div>
             </div>
             </div>
           </form>
         </div>
       )}
+
+      {breedingCertPreview && (
+        <PrintPreviewModal
+          title={`Breeding Certificate — ${breedingCertPreview.breeding.sireName} × ${breedingCertPreview.breeding.damName}`}
+          filename={buildBreedingCertificateFileName(breedingCertPreview.breeding)}
+          htmlContent={generateBreedingCertificateHtml(
+            breedingCertPreview.breeding,
+            herdById.get(breedingCertPreview.breeding.sireId),
+            herdById.get(breedingCertPreview.breeding.damId),
+            speciesProfile,
+            settings ?? {
+              id: 'default',
+              barnName: 'Barn Registry',
+              breederName: '',
+              preferredUnit: 'lbs_oz',
+              defaultSpecies: speciesProfile.name,
+              pinnedLandingSpecies: '',
+              defaultGenerations: 3,
+              themeMode: 'light',
+              updatedAt: '',
+            },
+            { serviceNotes: breedingCertPreview.customNotes }
+          )}
+          extraToolbarContent={
+            <div className="flex flex-wrap items-center gap-2">
+              <span className="text-[11px] font-medium text-[var(--barn-muted)]">
+                Certificate Note:
+              </span>
+              <input
+                type="text"
+                value={breedingCertPreview.customNotes}
+                onChange={(e) =>
+                  setBreedingCertPreview((prev) =>
+                    prev ? { ...prev, customNotes: e.target.value } : null
+                  )
+                }
+                placeholder="Optional stud service / pedigree note for recipient..."
+                aria-label="Optional breeding certificate note"
+                className="flex-1 min-w-[240px] min-h-[30px] px-2.5 py-0.5 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] text-xs"
+              />
+            </div>
+          }
+          onClose={() => setBreedingCertPreview(null)}
+        />
+      )}
     </div>
   );
 }
```

### `src/components/CrashErrorBoundary.tsx` (`+12` / `-7`, source: `part-03_e26163f3.md`)

```diff
--- working/src/components/CrashErrorBoundary.tsx
+++ import/src/components/CrashErrorBoundary.tsx
@@ -189,12 +189,14 @@
           busy: false,
           lastBuiltMailMeta,
           feedback:
-            mode === 'shared'
-              ? `Opened share sheet with ${built.filename}.${recipient ? ` You can send the bug report directly to ${recipient}.` : ''}`
-              : `Saved ${built.filename}. Tap "Open Email Draft" below and attach the downloaded .ZIP${recipient ? ` to send to ${recipient}` : ''}.`,
+            mode === 'cancelled'
+              ? 'Share sheet cancelled — no file was saved.'
+              : mode === 'shared'
+                ? `Opened share sheet with ${built.filename}.${recipient ? ` You can send the bug report directly to ${recipient}.` : ''}`
+                : `Saved ${built.filename}. Tap "Open Email Draft" below and attach the downloaded .ZIP${recipient ? ` to send to ${recipient}` : ''}.`,
         });
       } else {
-        await shareBinaryFileOrDownload({
+        const mode = await shareBinaryFileOrDownload({
           filename: built.filename,
           bytes: built.bytes,
           mimeType: 'application/zip',
@@ -203,9 +205,12 @@
         this.setState({
           busy: false,
           lastBuiltMailMeta,
-          feedback: `Exported ${built.filename} (${built.logCount} logs${
-            built.includedData ? `, ${built.animalCount} animals` : ''
-          }).`,
+          feedback:
+            mode === 'cancelled'
+              ? 'Share sheet cancelled — no file was saved.'
+              : `Exported ${built.filename} (${built.logCount} logs${
+                  built.includedData ? `, ${built.animalCount} animals` : ''
+                }).`,
         });
       }
     } catch (err) {
```

### `src/components/DiagnosticsAndSupportPanel.tsx` (`+13` / `-11`, source: `part-03_e26163f3.md`)

```diff
--- working/src/components/DiagnosticsAndSupportPanel.tsx
+++ import/src/components/DiagnosticsAndSupportPanel.tsx
@@ -419,17 +419,19 @@
         });
 
         setFeedback(
-          mode === 'shared'
-            ? `Opened Share Sheet with ${built.filename} (${formatByteSizePure(
-                built.bytes.byteLength
-              )}). Choose your email app to send${recipient ? ` to ${recipient}` : ''}.`
-            : `Downloaded ${built.filename} (${formatByteSizePure(
-                built.bytes.byteLength
-              )}).${
-                recipient
-                  ? ` Tap "Open Email Draft" below and attach the downloaded .ZIP to email ${recipient}.`
-                  : ' Type a recipient email above or tap "Open Email Draft" below and attach the downloaded .ZIP.'
-              }`
+          mode === 'cancelled'
+            ? 'Share sheet cancelled — no file was saved.'
+            : mode === 'shared'
+              ? `Opened Share Sheet with ${built.filename} (${formatByteSizePure(
+                  built.bytes.byteLength
+                )}). Choose your email app to send${recipient ? ` to ${recipient}` : ''}.`
+              : `Downloaded ${built.filename} (${formatByteSizePure(
+                  built.bytes.byteLength
+                )}).${
+                  recipient
+                    ? ` Tap "Open Email Draft" below and attach the downloaded .ZIP to email ${recipient}.`
+                    : ' Type a recipient email above or tap "Open Email Draft" below and attach the downloaded .ZIP.'
+                }`
         );
       } else {
         await downloadBinaryFile(built.filename, built.bytes, 'application/zip');
```

### `src/components/ExternalImporterPanel.tsx` (`+6` / `-10`, source: `part-04_0b25b963.md`)

```diff
--- working/src/components/ExternalImporterPanel.tsx
+++ import/src/components/ExternalImporterPanel.tsx
@@ -319,8 +319,8 @@
         }
         return next;
       });
-    } catch (err: unknown) {
-      setParseError(err instanceof Error ? err.message : 'Could not read selected archive file(s).');
+    } catch (err: any) {
+      setParseError(err?.message || 'Could not read selected archive file(s).');
     }
   };
 
@@ -365,12 +365,10 @@
         setArchivePreview(parsed);
         setPreviewParseError(null);
       })
-      .catch((err: unknown) => {
+      .catch((err: any) => {
         if (cancelled || parseRequestSeqRef.current !== reqId) return;
         setArchivePreview(null);
-        setPreviewParseError(
-          err instanceof Error ? err.message : 'Failed to unpack or parse archive.'
-        );
+        setPreviewParseError(err?.message || 'Failed to unpack or parse archive.');
       })
       .finally(() => {
         if (!cancelled && parseRequestSeqRef.current === reqId) {
@@ -617,10 +615,8 @@
       setShowImportLifecycleList(false);
       setShowDiagnostics(false);
       onClearExternalOcrPreview?.();
-    } catch (err: unknown) {
-      setParseError(
-        err instanceof Error ? err.message : 'Failed while optimizing or importing archive data.'
-      );
+    } catch (err: any) {
+      setParseError(err?.message || 'Failed while optimizing or importing archive data.');
     } finally {
       setPhotoProgress(null);
       setIsImporting(false);
```

### `src/components/HerdScreen.tsx` (`+848` / `-129`, source: `part-05_2e3961d6.md`)

```diff
--- working/src/components/HerdScreen.tsx
+++ import/src/components/HerdScreen.tsx
@@ -29,13 +29,15 @@
   Plus,
   Printer,
   RotateCcw,
+  Scissors,
   Search,
   ShieldAlert,
   Trash2,
   TrendingUp,
   X,
 } from 'lucide-react';
-import React, { useCallback, useEffect, useMemo, useState } from 'react';
+import React, { ComponentProps, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
+import { lazyNamedRoute } from '../utils/lazyRoute';
 import { useAccessibleDialog } from '../utils/useAccessibleDialog';
 import { useAsyncKeyedLock, useAsyncSubmitLock } from '../utils/useAsyncSubmitLock';
 import { useVirtualWindow } from '../utils/useVirtualWindow';
@@ -76,6 +78,7 @@
   formatWeight,
   getSpeciesIdentifierLabels,
   getWeightInputMeta,
+  IagarbScorecard,
   isAnimalArchived,
   normalizeOwnershipType,
   parseWeightInputToGrams,
@@ -84,8 +87,27 @@
   todayDateIso,
   ULTRASOUND_RESULTS,
   UltrasoundResult,
+  WOOL_HARVEST_METHODS,
+  WoolHarvest,
+  WoolHarvestMethod,
 } from '../core/models';
-import { getPedigreeCompletenessSummary } from '../core/pedigreeCalculator';
+import {
+  buildPetBirthCertificateFileName,
+  generatePetBirthCertificateHtml,
+} from '../core/alternativeCertificates';
+import {
+  compute90DayEquivalentGrams,
+  computeDaysBetweenDateIso,
+  computeIagarbScoreTotal,
+  evaluateIagarbEligibility,
+  IAGARB_JUDGING_POSITIONS,
+  summarizeAnimalWoolHarvests,
+} from '../core/woolFiber';
+import {
+  CoiAnalysis,
+  createSpeciesCoiEvaluator,
+  getPedigreeCompletenessSummary,
+} from '../core/pedigreeCalculator';
 import { SpeciesMigrationOptions } from '../core/speciesMigration';
 import {
   BatchPrintOptions,
@@ -108,14 +130,26 @@
 } from '../core/syncAndExports';
 import { ArchivedHerdIndexEntry } from '../core/backupVault';
 import { ActiveSpeciesData } from '../hooks/useBarnStore';
-import { buildAndDownloadPedigreePdf } from '../utils/webPdfActions';
-import { AnimalEditorModal } from './AnimalEditorModal';
 import { AnimalPhotoGallery } from './AnimalPhotoGallery';
-import { ArchivedHerdsModal } from './ArchivedHerdsModal';
 import { ColorGeneticsNotice } from './ColorGeneticsNotice';
 import { ColoredGenotypeDisplay } from './ColoredGenotypeDisplay';
-import { PrintPreviewModal } from './PrintPreviewModal';
-import { SpeciesMigrationModal } from './SpeciesMigrationModal';
+import { PedigreePrintNotice } from './PedigreePrintNotice';
+
+const AnimalEditorModal = lazyNamedRoute<
+  ComponentProps<typeof import('./AnimalEditorModal')['AnimalEditorModal']>
+>(() => import('./AnimalEditorModal'), 'AnimalEditorModal', 'Animal Editor');
+
+const ArchivedHerdsModal = lazyNamedRoute<
+  ComponentProps<typeof import('./ArchivedHerdsModal')['ArchivedHerdsModal']>
+>(() => import('./ArchivedHerdsModal'), 'ArchivedHerdsModal', 'Archived Herds');
+
+const PrintPreviewModal = lazyNamedRoute<
+  ComponentProps<typeof import('./PrintPreviewModal')['PrintPreviewModal']>
+>(() => import('./PrintPreviewModal'), 'PrintPreviewModal', 'Print Preview');
+
+const SpeciesMigrationModal = lazyNamedRoute<
+  ComponentProps<typeof import('./SpeciesMigrationModal')['SpeciesMigrationModal']>
+>(() => import('./SpeciesMigrationModal'), 'SpeciesMigrationModal', 'Species Migration');
 
 export const HERD_PAGE_SIZE = 50;
 
@@ -169,6 +203,11 @@
   onOpenBarnBench?: () => void;
   onCompareGrowthForAnimals?: (animalIds: string[]) => void;
   onUpdateSettings?: (patch: Partial<BarnSettings>, options?: { silent?: boolean }) => void;
+  onSaveWoolHarvest?: (
+    draft: Omit<WoolHarvest, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
+  ) => Promise<string | null> | void;
+  onDeleteWoolHarvest?: (id: string) => void;
+  isConstrainedDevice?: boolean;
 }
 
 type HerdFilterTab =
@@ -227,6 +266,9 @@
   onOpenBarnBench,
   onCompareGrowthForAnimals,
   onUpdateSettings,
+  onSaveWoolHarvest,
+  onDeleteWoolHarvest,
+  isConstrainedDevice = false,
 }: HerdScreenProps) {
   const {
     speciesProfile,
@@ -240,6 +282,7 @@
     cages,
     careLogs,
     shows,
+    woolHarvests = [],
   } = activeData;
 
   const effectiveWeightUnit = resolveSpeciesWeightUnit(speciesProfile, settings);
@@ -312,7 +355,20 @@
     hasGenetics?: boolean;
     pedigreeSubject?: Animal;
     cageCardSubject?: Animal;
+    birthCertSubject?: Animal;
   } | null>(null);
+  const [birthCertOptions, setBirthCertOptions] = useState<{
+    companionFamilyName: string;
+    keepsakeMessage: string;
+    includePrimaryPhoto: boolean;
+  }>({
+    companionFamilyName: '',
+    keepsakeMessage: '',
+    includePrimaryPhoto: true,
+  });
+  const [familyPortraitPhotosByAnimalId, setFamilyPortraitPhotosByAnimalId] = useState<
+    Record<string, string>
+  >({});
   const [includeThermalCageCardQr, setIncludeThermalCageCardQr] = useState(true);
   const [hydratedPedigreePhoto, setHydratedPedigreePhoto] = useState<{
     photoId: string;
@@ -326,13 +382,19 @@
   const [batchPhotoHydrating, setBatchPhotoHydrating] = useState(false);
 
   useEffect(() => {
-    if (!previewDoc?.isPedigree || !previewDoc.pedigreeSubject || !settings.includePhotoOnPedigree) {
+    const photoSubject = previewDoc?.pedigreeSubject ?? previewDoc?.birthCertSubject;
+    const shouldIncludePhoto = previewDoc?.pedigreeSubject
+      ? Boolean(settings.includePhotoOnPedigree)
+      : previewDoc?.birthCertSubject
+      ? birthCertOptions.includePrimaryPhoto
+      : false;
+    if (!photoSubject || !shouldIncludePhoto) {
       if (hydratedPedigreePhoto !== null) {
         setHydratedPedigreePhoto(null);
       }
       return;
     }
-    const primary = primaryPhotoByAnimalId.get(previewDoc.pedigreeSubject.id);
+    const primary = primaryPhotoByAnimalId.get(photoSubject.id);
     if (!primary || primary.dataUrl || !onLoadFullPhoto) return;
     if (hydratedPedigreePhoto?.photoId === primary.id) return;
     let cancelled = false;
@@ -347,10 +409,69 @@
   }, [
     previewDoc,
     settings.includePhotoOnPedigree,
+    birthCertOptions.includePrimaryPhoto,
     primaryPhotoByAnimalId,
     onLoadFullPhoto,
     hydratedPedigreePhoto,
   ]);
+
+  useEffect(() => {
+    if (
+      !previewDoc?.isPedigree ||
+      !previewDoc.pedigreeSubject ||
+      pedigreePrintOptions.layoutPreset !== 'family_portrait'
+    ) {
+      setFamilyPortraitPhotosByAnimalId((prev) => (Object.keys(prev).length === 0 ? prev : {}));
+      return;
+    }
+    const animalById = new Map<string, Animal>(allAnimals.map((a) => [a.id, a]));
+    const subj = previewDoc.pedigreeSubject;
+    const sire = subj.sireId ? animalById.get(subj.sireId) : undefined;
+    const dam = subj.damId ? animalById.get(subj.damId) : undefined;
+    const familyIds = [
+      subj.id,
+      sire?.id,
+      dam?.id,
+      sire?.sireId,
+      sire?.damId,
+      dam?.sireId,
+      dam?.damId,
+    ].filter((id): id is string => Boolean(id));
+
+    const nextImmediate: Record<string, string> = {};
+    const photoIdsToHydrate: Array<{ animalId: string; photoId: string }> = [];
+    for (const animalId of familyIds) {
+      const rec = primaryPhotoByAnimalId.get(animalId);
+      if (!rec) continue;
+      if (rec.dataUrl) {
+        nextImmediate[animalId] = rec.dataUrl;
+      } else {
+        if (rec.thumbnailDataUrl) nextImmediate[animalId] = rec.thumbnailDataUrl;
+        if (onLoadFullPhotosBatch) {
+          photoIdsToHydrate.push({ animalId, photoId: rec.id });
+        }
+      }
+    }
+    setFamilyPortraitPhotosByAnimalId(nextImmediate);
+
+    if (photoIdsToHydrate.length === 0 || !onLoadFullPhotosBatch) return;
+    let cancelled = false;
+    void onLoadFullPhotosBatch(photoIdsToHydrate.map((x) => x.photoId)).then((loadedMap) => {
+      if (cancelled) return;
+      setFamilyPortraitPhotosByAnimalId((prev) => {
+        const merged = { ...prev };
+        for (const item of photoIdsToHydrate) {
+          if (loadedMap[item.photoId]) {
+            merged[item.animalId] = loadedMap[item.photoId];
+          }
+        }
+        return merged;
+      });
+    });
+    return () => {
+      cancelled = true;
+    };
+  }, [previewDoc, pedigreePrintOptions.layoutPreset, allAnimals, primaryPhotoByAnimalId, onLoadFullPhotosBatch]);
 
   useEffect(() => {
     if (!batchPrintSubjects || batchPrintSubjects.length === 0 || !batchPrintOptions.includePhotos) {
@@ -491,17 +612,20 @@
     [speciesProfile.name]
   );
 
-  const carrierAnalysisById = useMemo(() => {
+  const hasCarrierFilter =
+    carrierFilterMode !== 'all' || carrierTraitQuery.trim().length > 0;
+
+  const filteredCarrierAnalysisById = useMemo(() => {
     const map = new Map<string, AnimalCarrierLineageAnalysis>();
+    if (!hasCarrierFilter) return map;
     for (const a of animals) {
       map.set(a.id, analyzeAnimalCarrierLineage(a, herdById));
     }
     return map;
-  }, [animals, herdById]);
+  }, [hasCarrierFilter, animals, herdById]);
 
   const filteredAnimals = useMemo(() => {
     const q = query.trim().toLowerCase();
-    const hasCarrierFilter = carrierFilterMode !== 'all' || carrierTraitQuery.trim().length > 0;
     const filtered = animals.filter((a) => {
       const archived = isAnimalArchived(a);
       if (filterKey === 'Male' && a.sex !== 'Male') return false;
@@ -516,7 +640,7 @@
       }
 
       if (hasCarrierFilter) {
-        const analysis = carrierAnalysisById.get(a.id);
+        const analysis = filteredCarrierAnalysisById.get(a.id);
         if (!analysis || !doesAnimalMatchCarrierFilter(analysis, carrierFilterMode, carrierTraitQuery)) {
           return false;
         }
@@ -566,9 +690,10 @@
     query,
     filterKey,
     sortBy,
+    hasCarrierFilter,
     carrierFilterMode,
     carrierTraitQuery,
-    carrierAnalysisById,
+    filteredCarrierAnalysisById,
     conflictsByAnimalId,
     withdrawalByAnimalId,
   ]);
@@ -595,6 +720,43 @@
     () => (activeAnimal ? computeAnimalShowSummary(activeAnimal, shows, careLogs) : null),
     [activeAnimal, shows, careLogs]
   );
+
+  const activeAnimalWoolHarvests = useMemo(
+    () => (activeAnimal ? woolHarvests.filter((wh) => wh.animalId === activeAnimal.id) : []),
+    [activeAnimal, woolHarvests]
+  );
+
+  const activeAnimalWoolSummary = useMemo(
+    () =>
+      activeAnimal
+        ? summarizeAnimalWoolHarvests(activeAnimalWoolHarvests, activeAnimal.id)
+        : null,
+    [activeAnimal, activeAnimalWoolHarvests]
+  );
+
+  const [showWoolForm, setShowWoolForm] = useState(false);
+  const [woolDateIso, setWoolDateIso] = useState(() => todayDateIso());
+  const [woolIntervalDays, setWoolIntervalDays] = useState('90');
+  const [woolPrimeGrams, setWoolPrimeGrams] = useState('');
+  const [woolGradeGrams, setWoolGradeGrams] = useState('');
+  const [woolMethod, setWoolMethod] = useState<WoolHarvestMethod>('Shear');
+  const [woolStapleMm, setWoolStapleMm] = useState('');
+  const [woolWitnessedBy, setWoolWitnessedBy] = useState('');
+  const [woolNotes, setWoolNotes] = useState('');
+  const [showIagarbScorecard, setShowIagarbScorecard] = useState(false);
+  const [woolIagarbScore, setWoolIagarbScore] = useState<IagarbScorecard>(() => ({
+    weightPts: 0,
+    bodyTypePts: 0,
+    densityLengthPts: 0,
+    uniformityPts: 0,
+    texturePts: 0,
+    furnishingsPts: 0,
+    conditionPts: 0,
+    totalPts: 0,
+    evaluatorName: '',
+    evaluationDateIso: '',
+  }));
+  const woolSubmitLock = useAsyncSubmitLock({ postSettleCooldownMs: 250 });
 
   const [eLegLightbox, setELegLightbox] = useState<{
     imageUrl: string;
@@ -659,16 +821,13 @@
     [activeAnimal]
   );
 
-  const activeLineageAnalysis = useMemo(
-    () => (activeAnimal ? carrierAnalysisById.get(activeAnimal.id) ?? null : null),
-    [activeAnimal, carrierAnalysisById]
-  );
+  const isLowMemMode = Boolean(isConstrainedDevice);
 
   const herdVirtual = useVirtualWindow({
     itemCount: filteredAnimals.length,
     estimateSize: 80,
-    overscan: 8,
-    initialFallbackCount: HERD_PAGE_SIZE,
+    overscan: isLowMemMode ? 3 : 8,
+    initialFallbackCount: isLowMemMode ? 20 : HERD_PAGE_SIZE,
     resetKey: `${speciesProfile.name}::${filterKey}::${sortBy}::${query}::${carrierFilterMode}::${carrierTraitQuery}`,
   });
 
@@ -687,6 +846,43 @@
       herdVirtual.windowRange.endIndex,
     ]
   );
+
+  const visibleCarrierAnalysisById = useMemo(() => {
+    if (hasCarrierFilter) return filteredCarrierAnalysisById;
+    const map = new Map<string, AnimalCarrierLineageAnalysis>();
+    if (activeAnimal) {
+      map.set(activeAnimal.id, analyzeAnimalCarrierLineage(activeAnimal, herdById));
+    }
+    for (const a of visibleAnimals) {
+      if (!map.has(a.id)) {
+        map.set(a.id, analyzeAnimalCarrierLineage(a, herdById));
+      }
+    }
+    return map;
+  }, [hasCarrierFilter, filteredCarrierAnalysisById, activeAnimal, visibleAnimals, herdById]);
+
+  const activeLineageAnalysis = useMemo(
+    () => (activeAnimal ? visibleCarrierAnalysisById.get(activeAnimal.id) ?? null : null),
+    [activeAnimal, visibleCarrierAnalysisById]
+  );
+
+  const coiEvaluator = useMemo(() => createSpeciesCoiEvaluator(herdById), [herdById]);
+
+  const visibleCoiByAnimalId = useMemo(() => {
+    const map = new Map<string, CoiAnalysis>();
+    if (activeAnimal) {
+      map.set(
+        activeAnimal.id,
+        coiByAnimalId.get(activeAnimal.id) ?? coiEvaluator.calculateAnimalCoi(activeAnimal)
+      );
+    }
+    for (const a of visibleAnimals) {
+      if (!map.has(a.id)) {
+        map.set(a.id, coiByAnimalId.get(a.id) ?? coiEvaluator.calculateAnimalCoi(a));
+      }
+    }
+    return map;
+  }, [activeAnimal, visibleAnimals, coiByAnimalId, coiEvaluator]);
 
   const checkedIdSet = useMemo(() => new Set(checkedIds), [checkedIds]);
   const filteredIds = useMemo(() => filteredAnimals.map((a) => a.id), [filteredAnimals]);
@@ -728,10 +924,73 @@
     setLogUltrasoundFetalCount('');
   };
 
+  const resetWoolFields = () => {
+    setWoolDateIso(todayDateIso());
+    setWoolIntervalDays('90');
+    setWoolPrimeGrams('');
+    setWoolGradeGrams('');
+    setWoolMethod('Shear');
+    setWoolStapleMm('');
+    setWoolWitnessedBy('');
+    setWoolNotes('');
+    setShowIagarbScorecard(false);
+    setWoolIagarbScore({
+      weightPts: 0,
+      bodyTypePts: 0,
+      densityLengthPts: 0,
+      uniformityPts: 0,
+      texturePts: 0,
+      furnishingsPts: 0,
+      conditionPts: 0,
+      totalPts: 0,
+      evaluatorName: '',
+      evaluationDateIso: '',
+    });
+  };
+
   useEffect(() => {
     setShowLogForm(false);
     resetLogFields();
+    setShowWoolForm(false);
+    resetWoolFields();
   }, [speciesProfile.id, selectedAnimalId]);
+
+  const submitWoolHarvest = async (e: React.FormEvent) => {
+    e.preventDefault();
+    if (!activeAnimal || !onSaveWoolHarvest) return;
+    await woolSubmitLock.runLocked(async () => {
+      const prime = safeNonNegNumber(woolPrimeGrams, true, 100_000);
+      const grade = safeNonNegNumber(woolGradeGrams, true, 100_000);
+      const interval = safeNonNegNumber(woolIntervalDays, true, 1825);
+      const staple = safeNonNegNumber(woolStapleMm, false, 1000);
+      const hasIagarbFields = Object.values(woolIagarbScore).some(
+        (v) => typeof v === 'number' && Number.isFinite(v) && v > 0
+      );
+      await onSaveWoolHarvest({
+        species: speciesProfile.name,
+        animalId: activeAnimal.id,
+        harvestDateIso: woolDateIso || todayDateIso(),
+        shearingIntervalDays: interval > 0 ? interval : undefined,
+        primeWeightGrams: prime,
+        gradeWeightGrams: grade,
+        harvestMethod: woolMethod,
+        stapleLengthMm: staple > 0 ? staple : undefined,
+        iagarbScore:
+          showIagarbScorecard && hasIagarbFields
+            ? {
+                ...woolIagarbScore,
+                totalPts: computeIagarbScoreTotal(woolIagarbScore),
+                evaluatorName: woolWitnessedBy.trim(),
+                evaluationDateIso: woolDateIso || todayDateIso(),
+              }
+            : undefined,
+        witnessedBy: woolWitnessedBy.trim(),
+        notes: woolNotes.trim(),
+      });
+      resetWoolFields();
+      setShowWoolForm(false);
+    });
+  };
 
   const safeNonNegNumber = (raw: string, roundInt = false, max = Number.MAX_SAFE_INTEGER): number => {
     const num = Number(raw);
@@ -809,8 +1068,37 @@
           ...pedigreePrintOptions,
           shows,
           careLogs,
+          woolHarvests,
+          ancestorPhotosByAnimalId:
+            pedigreePrintOptions.layoutPreset === 'family_portrait'
+              ? familyPortraitPhotosByAnimalId
+              : undefined,
         }
       ),
+    });
+  };
+
+  const openBirthCertificatePreview = (subject: Animal) => {
+    setBatchPrintSubjects(null);
+    setBatchHydratedPhotos({});
+    setBirthCertOptions((prev) => ({
+      ...prev,
+      companionFamilyName: subject.buyerName || prev.companionFamilyName || '',
+    }));
+    const primaryRec = primaryPhotoByAnimalId.get(subject.id);
+    const photoUrl =
+      primaryRec && birthCertOptions.includePrimaryPhoto
+        ? primaryRec.dataUrl || primaryRec.thumbnailDataUrl
+        : undefined;
+    setPreviewDoc({
+      title: `Pet Birth Certificate — ${subject.name}`,
+      filename: buildPetBirthCertificateFileName(subject),
+      birthCertSubject: subject,
+      html: generatePetBirthCertificateHtml(subject, allAnimals, speciesProfiles, settings, {
+        primaryPhotoDataUrl: photoUrl,
+        companionFamilyName: subject.buyerName || birthCertOptions.companionFamilyName,
+        keepsakeMessage: birthCertOptions.keepsakeMessage,
+      }),
     });
   };
 
@@ -1277,6 +1565,15 @@
                   </button>
                   <button
                     type="button"
+                    onClick={() => openBirthCertificatePreview(activeAnimal)}
+                    title="Print keepsake Birth Certificate (omits breeder contact & sale pricing)"
+                    className="min-h-[40px] px-3 py-1.5 rounded-lg border border-[var(--barn-border)] text-xs font-medium hover:bg-[var(--barn-subtle)] inline-flex items-center gap-1.5 whitespace-nowrap"
+                  >
+                    <Award className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                    Birth Cert
+                  </button>
+                  <button
+                    type="button"
                     onClick={() => {
                       setEditingAnimal(activeAnimal);
                       setShowAnimalModal(true);
@@ -1289,6 +1586,7 @@
                 </div>
 
                 <div className="flex flex-wrap items-center justify-end gap-2">
+                  <PedigreePrintNotice compact />
                   {primaryPhotoByAnimalId.has(activeAnimal.id) && (
                     <label className="flex items-center gap-2 text-xs text-[var(--barn-muted)] cursor-pointer">
                       <input
@@ -1314,7 +1612,7 @@
               <div>
                 <div className="text-[var(--barn-muted)]">Wright COI</div>
                 {(() => {
-                  const activeCoi = coiByAnimalId.get(activeAnimal.id);
+                  const activeCoi = visibleCoiByAnimalId.get(activeAnimal.id);
                   const comp = activeCoi ? getPedigreeCompletenessSummary(activeCoi) : null;
                   return (
                     <div className="mt-0.5">
@@ -2120,6 +2418,340 @@
               )}
             </div>
 
+            {/* Wool / Fiber Harvests & IAGARB Angora Evaluation */}
+            <div className="border-t border-[var(--barn-border)] pt-5 space-y-3">
+              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
+                <div>
+                  <h3 className="text-sm font-semibold inline-flex items-center gap-1.5">
+                    <Scissors className="w-4 h-4 text-[var(--barn-sage)]" aria-hidden="true" />
+                    <span>Wool / Fiber Harvests &amp; IAGARB Scoring</span>
+                  </h3>
+                  <p className="text-xs text-[var(--barn-muted)]">
+                    Track prime &amp; grade fleece weights (g), 90-day shearing yield vs. 325g benchmark, and IAGARB 7-position scores.
+                  </p>
+                </div>
+                {onSaveWoolHarvest && (
+                  <button
+                    type="button"
+                    aria-expanded={showWoolForm}
+                    onClick={() => setShowWoolForm((v) => !v)}
+                    className="min-h-[38px] px-3 py-1.5 rounded-lg border border-[var(--barn-border)] text-xs font-medium hover:bg-[var(--barn-subtle)] inline-flex items-center gap-1 whitespace-nowrap self-start sm:self-auto"
+                  >
+                    <Plus className="w-3.5 h-3.5" aria-hidden="true" />
+                    Log Wool Harvest
+                  </button>
+                )}
+              </div>
+
+              {activeAnimalWoolSummary && activeAnimalWoolSummary.harvestCount > 0 && (
+                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-xl bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-xs">
+                  <div>
+                    <div className="text-[11px] text-[var(--barn-muted)]">Lifetime Total</div>
+                    <div className="font-mono font-semibold tabular-nums mt-0.5">
+                      {activeAnimalWoolSummary.totalGrams} g ({activeAnimalWoolSummary.harvestCount} clip{activeAnimalWoolSummary.harvestCount === 1 ? '' : 's'})
+                    </div>
+                  </div>
+                  <div>
+                    <div className="text-[11px] text-[var(--barn-muted)]">Prime vs Grade</div>
+                    <div className="font-mono font-semibold tabular-nums mt-0.5">
+                      {activeAnimalWoolSummary.primeGrams}g Prime / {activeAnimalWoolSummary.gradeGrams}g Grade
+                    </div>
+                  </div>
+                  <div>
+                    <div className="text-[11px] text-[var(--barn-muted)]">Latest 90-Day Rate</div>
+                    <div className="font-mono font-semibold tabular-nums mt-0.5">
+                      {activeAnimalWoolSummary.latest90DayRateGrams !== null
+                        ? `${activeAnimalWoolSummary.latest90DayRateGrams} g/90d`
+                        : '—'}
+                      {activeAnimalWoolSummary.eligibility.meets90DayYieldThreshold && (
+                        <span className="ml-1.5 px-1.5 py-0.5 rounded bg-[var(--barn-sage-tint)] text-[var(--barn-sage)] text-[10px]">
+                          ≥325g Pass
+                        </span>
+                      )}
+                    </div>
+                  </div>
+                  <div>
+                    <div className="text-[11px] text-[var(--barn-muted)]">Best IAGARB Score</div>
+                    <div className="font-mono font-semibold tabular-nums mt-0.5">
+                      {activeAnimalWoolSummary.highestIagarbScore !== null
+                        ? `${activeAnimalWoolSummary.highestIagarbScore.totalPts}/100`
+                        : '—'}
+                      {activeAnimalWoolSummary.eligibility.meetsPointsThreshold && (
+                        <span className="ml-1.5 px-1.5 py-0.5 rounded bg-[var(--barn-sage-tint)] text-[var(--barn-sage)] text-[10px]">
+                          Reg Eligible
+                        </span>
+                      )}
+                    </div>
+                  </div>
+                </div>
+              )}
+
+              {showWoolForm && onSaveWoolHarvest && (
+                <form
+                  onSubmit={submitWoolHarvest}
+                  className="p-4 rounded-xl bg-[var(--barn-canvas)] border border-[var(--barn-border)] space-y-3 text-xs"
+                >
+                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Harvest Date</span>
+                      <input
+                        type="date"
+                        required
+                        value={woolDateIso}
+                        onChange={(e) => {
+                          const nextDate = e.target.value;
+                          setWoolDateIso(nextDate);
+                          const lastDate = activeAnimalWoolHarvests[0]?.harvestDateIso;
+                          if (lastDate && nextDate) {
+                            const diff = computeDaysBetweenDateIso(lastDate, nextDate);
+                            if (diff !== null && diff > 0) setWoolIntervalDays(String(diff));
+                          }
+                        }}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] font-mono"
+                      />
+                    </label>
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Interval (Days)</span>
+                      <input
+                        type="number"
+                        min="0"
+                        max="1825"
+                        placeholder="90"
+                        value={woolIntervalDays}
+                        onChange={(e) => setWoolIntervalDays(e.target.value)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] font-mono tabular-nums"
+                      />
+                    </label>
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Prime Weight (g)</span>
+                      <input
+                        type="number"
+                        min="0"
+                        step="1"
+                        placeholder="e.g. 285"
+                        value={woolPrimeGrams}
+                        onChange={(e) => setWoolPrimeGrams(e.target.value)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] font-mono tabular-nums"
+                      />
+                    </label>
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Grade / Seconds (g)</span>
+                      <input
+                        type="number"
+                        min="0"
+                        step="1"
+                        placeholder="e.g. 60"
+                        value={woolGradeGrams}
+                        onChange={(e) => setWoolGradeGrams(e.target.value)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] font-mono tabular-nums"
+                      />
+                    </label>
+                  </div>
+
+                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Method</span>
+                      <select
+                        value={woolMethod}
+                        onChange={(e) => setWoolMethod(e.target.value as WoolHarvestMethod)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)]"
+                      >
+                        {WOOL_HARVEST_METHODS.map((m) => (
+                          <option key={m} value={m}>
+                            {m}
+                          </option>
+                        ))}
+                      </select>
+                    </label>
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Staple Length (mm)</span>
+                      <input
+                        type="number"
+                        min="0"
+                        step="0.5"
+                        placeholder="e.g. 75"
+                        value={woolStapleMm}
+                        onChange={(e) => setWoolStapleMm(e.target.value)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] font-mono tabular-nums"
+                      />
+                    </label>
+                    <label className="space-y-1">
+                      <span className="text-[11px] text-[var(--barn-muted)]">Witnessed By / Judge</span>
+                      <input
+                        type="text"
+                        placeholder="Registrar / judge name (optional)"
+                        value={woolWitnessedBy}
+                        onChange={(e) => setWoolWitnessedBy(e.target.value)}
+                        className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)]"
+                      />
+                    </label>
+                  </div>
+
+                  {(() => {
+                    const p = Number(woolPrimeGrams) || 0;
+                    const g = Number(woolGradeGrams) || 0;
+                    const d = Number(woolIntervalDays) || 0;
+                    const eq90 = compute90DayEquivalentGrams(p + g, d);
+                    const totalPts = computeIagarbScoreTotal(woolIagarbScore);
+                    const elig = evaluateIagarbEligibility(
+                      showIagarbScorecard ? totalPts : 0,
+                      eq90
+                    );
+                    return (
+                      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)]">
+                        <span className="font-mono text-[11px]">
+                          Total Clip: <strong>{Math.round(p + g)} g</strong>
+                          {eq90 !== null ? ` · 90-Day Est: ${eq90} g` : ''}
+                        </span>
+                        <span className="text-[11px] font-medium text-[var(--barn-sage)]">
+                          {elig.statusLabel}
+                        </span>
+                      </div>
+                    );
+                  })()}
+
+                  <div>
+                    <button
+                      type="button"
+                      onClick={() => setShowIagarbScorecard((v) => !v)}
+                      className="text-xs font-medium text-[var(--barn-sage)] hover:underline"
+                    >
+                      {showIagarbScorecard
+                        ? '− Hide IAGARB 7-Position Judging Scorecard'
+                        : '+ Add IAGARB 7-Position Judging Scorecard (100-Pt Scale)'}
+                    </button>
+                  </div>
+
+                  {showIagarbScorecard && (
+                    <div className="p-3 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] space-y-2">
+                      <div className="flex items-center justify-between gap-2">
+                        <span className="font-semibold">IAGARB 7-Position Scorecard</span>
+                        <span className="font-mono font-semibold tabular-nums">
+                          Total: {computeIagarbScoreTotal(woolIagarbScore)} / 100 (Min 80 for Reg)
+                        </span>
+                      </div>
+                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
+                        {IAGARB_JUDGING_POSITIONS.map((pos) => (
+                          <label key={pos.key} className="space-y-0.5">
+                            <span className="text-[11px] text-[var(--barn-muted)] block truncate" title={pos.guidance}>
+                              {pos.label} (/{pos.maxPoints})
+                            </span>
+                            <input
+                              type="number"
+                              min="0"
+                              max={pos.maxPoints}
+                              step="0.5"
+                              value={woolIagarbScore[pos.key] || ''}
+                              onChange={(e) => {
+                                const raw = e.target.value;
+                                const val =
+                                  raw === ''
+                                    ? 0
+                                    : Math.min(pos.maxPoints, Math.max(0, Number(raw) || 0));
+                                setWoolIagarbScore((prev) => ({
+                                  ...prev,
+                                  [pos.key]: val,
+                                }));
+                              }}
+                              className="w-full min-h-[34px] px-2 py-1 rounded-md bg-[var(--barn-canvas)] border border-[var(--barn-border)] font-mono tabular-nums"
+                            />
+                          </label>
+                        ))}
+                      </div>
+                    </div>
+                  )}
+
+                  <input
+                    type="text"
+                    aria-label="Wool harvest notes"
+                    placeholder="Optional fleece quality notes (crimps, web density, matting)..."
+                    value={woolNotes}
+                    onChange={(e) => setWoolNotes(e.target.value)}
+                    className="w-full min-h-[36px] px-2.5 py-1 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)]"
+                  />
+
+                  <div className="flex justify-end gap-2">
+                    <button
+                      type="button"
+                      onClick={() => setShowWoolForm(false)}
+                      className="min-h-[36px] px-3 py-1 rounded-lg border border-[var(--barn-border)] font-medium"
+                    >
+                      Cancel
+                    </button>
+                    <button
+                      type="submit"
+                      disabled={woolSubmitLock.isSubmitting}
+                      aria-busy={woolSubmitLock.isSubmitting}
+                      className="min-h-[36px] px-4 py-1 rounded-lg bg-[var(--barn-sage)] text-[var(--barn-on-sage)] font-semibold disabled:opacity-55 inline-flex items-center gap-1.5"
+                    >
+                      {woolSubmitLock.isSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
+                      Save Harvest
+                    </button>
+                  </div>
+                </form>
+              )}
+
+              {activeAnimalWoolHarvests.length > 0 && (
+                <div className="divide-y divide-[var(--barn-border)] border border-[var(--barn-border)] rounded-xl bg-[var(--barn-surface)]">
+                  {activeAnimalWoolHarvests.map((wh) => {
+                    const total = wh.primeWeightGrams + wh.gradeWeightGrams;
+                    const eq90 = compute90DayEquivalentGrams(total, wh.shearingIntervalDays);
+                    const pts = wh.iagarbScore ? computeIagarbScoreTotal(wh.iagarbScore) : null;
+                    return (
+                      <div key={wh.id} className="px-3 py-2.5 flex items-start justify-between gap-2 text-xs">
+                        <div className="min-w-0 space-y-0.5">
+                          <div className="flex flex-wrap items-center gap-1.5 font-medium">
+                            <span className="font-mono">{formatReadableDate(wh.harvestDateIso)}</span>
+                            <span className="px-1.5 py-0.5 rounded bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-[10.5px]">
+                              {wh.harvestMethod}
+                            </span>
+                            <span className="font-mono tabular-nums font-semibold">
+                              {total} g total ({wh.primeWeightGrams}g Prime / {wh.gradeWeightGrams}g Grade)
+                            </span>
+                            {eq90 !== null && (
+                              <span className="font-mono text-[10.5px] text-[var(--barn-muted)]">
+                                · {eq90} g/90d
+                              </span>
+                            )}
+                            {pts !== null && (
+                              <span
+                                className={`px-1.5 py-0.5 rounded font-mono text-[10.5px] font-semibold ${
+                                  pts >= 80
+                                    ? 'bg-[var(--barn-sage-tint)] text-[var(--barn-sage)]'
+                                    : 'bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-[var(--barn-muted)]'
+                                }`}
+                              >
+                                IAGARB {pts}/100
+                              </span>
+                            )}
+                          </div>
+                          {(wh.stapleLengthMm || wh.witnessedBy || wh.notes) && (
+                            <div className="text-[11px] text-[var(--barn-muted)]">
+                              {wh.stapleLengthMm ? `Staple ${wh.stapleLengthMm} mm` : ''}
+                              {wh.stapleLengthMm && wh.witnessedBy ? ' · ' : ''}
+                              {wh.witnessedBy ? `Witnessed by ${wh.witnessedBy}` : ''}
+                              {(wh.stapleLengthMm || wh.witnessedBy) && wh.notes ? ' · ' : ''}
+                              {wh.notes}
+                            </div>
+                          )}
+                        </div>
+                        {onDeleteWoolHarvest && (
+                          <button
+                            type="button"
+                            onClick={() => onDeleteWoolHarvest(wh.id)}
+                            aria-label="Delete wool harvest"
+                            className="min-h-[32px] min-w-[32px] rounded-lg text-[var(--barn-muted)] hover:text-[var(--barn-danger)] hover:bg-[var(--barn-subtle)] flex items-center justify-center shrink-0"
+                          >
+                            <Trash2 className="w-3.5 h-3.5" />
+                          </button>
+                        )}
+                      </div>
+                    );
+                  })}
+                </div>
+              )}
+            </div>
+
             {activeAnimal.notes && (
               <div className="border-t border-[var(--barn-border)] pt-4 text-xs text-[var(--barn-muted)]">
                 <strong className="text-[var(--barn-ink)]">Notes:</strong> {activeAnimal.notes}
@@ -2490,7 +3122,7 @@
                       const rowIndex = herdVirtual.windowRange.startIndex + localIdx;
                       const isChecked = checkedIdSet.has(a.id);
                       const isArch = isAnimalArchived(a);
-                      const coi = coiByAnimalId.get(a.id);
+                      const coi = visibleCoiByAnimalId.get(a.id);
                       const coverPhoto = primaryPhotoByAnimalId.get(a.id);
                       const photoCount = photosByAnimalId.get(a.id)?.length || 0;
                       const sexColor =
@@ -2618,7 +3250,7 @@
                                   {a.cageLocation ? ` · ${a.cageLocation}` : ''}
                                 </div>
                                 {(() => {
-                                  const rowAnalysis = carrierAnalysisById.get(a.id);
+                                  const rowAnalysis = visibleCarrierAnalysisById.get(a.id);
                                   const parts: string[] = [];
                                   if (a.rufusLevel) parts.push(`Rufus: ${a.rufusLevel} (in dev)`);
                                   if (rowAnalysis?.confirmed.length) {
@@ -2693,83 +3325,98 @@
       )}
 
       {showAnimalModal && (
-        <AnimalEditorModal
-          initialAnimal={editingAnimal}
-          speciesProfile={speciesProfile}
-          speciesAnimals={animals}
-          speciesCages={cages}
-          animalCareLogs={editingAnimalCareLogs}
-          preferredUnit={effectiveWeightUnit}
-          currencyCode={settings.currencyCode}
-          optimizationPresetId={settings.imageOptimizationPreset}
-          defaultBreederName={settings.breederName}
-          defaultOwnerName={settings.barnName}
-          opfsSupported={opfsSupported}
-          autoOffloadRetiredToOpfs={Boolean(settings.autoOffloadRetiredToOpfs)}
-          onSave={onSaveAnimal}
-          onOffloadRetiredAnimal={
-            onOffloadAnimalsToOpfsArchive
-              ? async (animalId) => {
-                  await onOffloadAnimalsToOpfsArchive([animalId]);
-                }
-              : undefined
-          }
-          onSetAutoOffloadRetired={
-            onUpdateSettings
-              ? (enabled) => onUpdateSettings({ autoOffloadRetiredToOpfs: enabled }, { silent: true })
-              : undefined
-          }
-          onDelete={onDeleteAnimal}
-          onClose={() => setShowAnimalModal(false)}
-        />
+        <Suspense fallback={null}>
+          <AnimalEditorModal
+            initialAnimal={editingAnimal}
+            speciesProfile={speciesProfile}
+            speciesAnimals={animals}
+            speciesCages={cages}
+            animalCareLogs={editingAnimalCareLogs}
+            preferredUnit={effectiveWeightUnit}
+            currencyCode={settings.currencyCode}
+            optimizationPresetId={settings.imageOptimizationPreset}
+            defaultBreederName={settings.breederName}
+            defaultOwnerName={settings.barnName}
+            opfsSupported={opfsSupported}
+            autoOffloadRetiredToOpfs={Boolean(settings.autoOffloadRetiredToOpfs)}
+            onSave={onSaveAnimal}
+            onOffloadRetiredAnimal={
+              onOffloadAnimalsToOpfsArchive
+                ? async (animalId) => {
+                    await onOffloadAnimalsToOpfsArchive([animalId]);
+                  }
+                : undefined
+            }
+            onSetAutoOffloadRetired={
+              onUpdateSettings
+                ? (enabled) => onUpdateSettings({ autoOffloadRetiredToOpfs: enabled }, { silent: true })
+                : undefined
+            }
+            onDelete={onDeleteAnimal}
+            onClose={() => setShowAnimalModal(false)}
+          />
+        </Suspense>
       )}
 
-      <ArchivedHerdsModal
-        isOpen={showArchivedHerdsModal}
-        opfsSupported={opfsSupported}
-        archives={archivedHerdBundles}
-        autoOffloadEnabled={Boolean(settings.autoOffloadRetiredToOpfs)}
-        onToggleAutoOffload={(enabled) =>
-          onUpdateSettings?.({ autoOffloadRetiredToOpfs: enabled }, { silent: true })
-        }
-        onRestoreArchive={async (archiveKey, opts) => {
-          if (onRestoreArchivedHerdBundle) {
-            await onRestoreArchivedHerdBundle(archiveKey, opts);
-          }
-        }}
-        onDownloadArchive={async (archiveKey) => {
-          if (onDownloadArchivedHerdBundle) {
-            await onDownloadArchivedHerdBundle(archiveKey);
-          }
-        }}
-        onDeleteArchive={async (archiveKey) => {
-          if (onDeleteArchivedHerdBundle) {
-            await onDeleteArchivedHerdBundle(archiveKey);
-          }
-        }}
-        onClose={() => setShowArchivedHerdsModal(false)}
-      />
+      {showArchivedHerdsModal && (
+        <Suspense fallback={null}>
+          <ArchivedHerdsModal
+            isOpen={showArchivedHerdsModal}
+            opfsSupported={opfsSupported}
+            archives={archivedHerdBundles}
+            autoOffloadEnabled={Boolean(settings.autoOffloadRetiredToOpfs)}
+            onToggleAutoOffload={(enabled) =>
+              onUpdateSettings?.({ autoOffloadRetiredToOpfs: enabled }, { silent: true })
+            }
+            onRestoreArchive={async (archiveKey, opts) => {
+              if (onRestoreArchivedHerdBundle) {
+                await onRestoreArchivedHerdBundle(archiveKey, opts);
+              }
+            }}
+            onDownloadArchive={async (archiveKey) => {
+              if (onDownloadArchivedHerdBundle) {
+                await onDownloadArchivedHerdBundle(archiveKey);
+              }
+            }}
+            onDeleteArchive={async (archiveKey) => {
+              if (onDeleteArchivedHerdBundle) {
+                await onDeleteArchivedHerdBundle(archiveKey);
+              }
+            }}
+            onClose={() => setShowArchivedHerdsModal(false)}
+          />
+        </Suspense>
+      )}
 
       {migrationModalState && (
-        <SpeciesMigrationModal
-          snapshot={snapshot}
-          sourceSpecies={speciesProfile.name}
-          directAnimalIds={migrationModalState.animalIds}
-          mode={migrationModalState.mode}
-          onConfirmMigrate={async (ids, target, options) => {
-            await onMigrateAnimalsSpecies(ids, target, options);
-            setCheckedIds([]);
-          }}
-          onClose={() => setMigrationModalState(null)}
-        />
+        <Suspense fallback={null}>
+          <SpeciesMigrationModal
+            snapshot={snapshot}
+            sourceSpecies={speciesProfile.name}
+            directAnimalIds={migrationModalState.animalIds}
+            mode={migrationModalState.mode}
+            onConfirmMigrate={async (ids, target, options) => {
+              await onMigrateAnimalsSpecies(ids, target, options);
+              setCheckedIds([]);
+            }}
+            onClose={() => setMigrationModalState(null)}
+          />
+        </Suspense>
       )}
 
       {previewDoc && (() => {
         const resolvedPedigreeSubject = previewDoc.pedigreeSubject;
-        const resolvedPedigreePhoto =
-          resolvedPedigreeSubject && settings.includePhotoOnPedigree
+        const resolvedBirthCertSubject = previewDoc.birthCertSubject;
+        const resolvedSubjectForPhoto = resolvedPedigreeSubject ?? resolvedBirthCertSubject;
+        const shouldUseSubjectPhoto = resolvedPedigreeSubject
+          ? Boolean(settings.includePhotoOnPedigree)
+          : resolvedBirthCertSubject
+          ? birthCertOptions.includePrimaryPhoto
+          : false;
+        const resolvedSubjectPhoto =
+          resolvedSubjectForPhoto && shouldUseSubjectPhoto
             ? (() => {
-                const primaryRec = primaryPhotoByAnimalId.get(resolvedPedigreeSubject.id);
+                const primaryRec = primaryPhotoByAnimalId.get(resolvedSubjectForPhoto.id);
                 if (!primaryRec) return undefined;
                 return (
                   primaryRec.dataUrl ||
@@ -2779,10 +3426,22 @@
                 );
               })()
             : undefined;
+        const resolvedPedigreePhoto = resolvedPedigreeSubject ? resolvedSubjectPhoto : undefined;
         const isShareableCard =
           Boolean(resolvedPedigreeSubject) && pedigreeDocMode === 'shareable_card';
+        const effectivePedigreeOptions: PedigreePrintOptions = {
+          ...pedigreePrintOptions,
+          shows,
+          careLogs,
+          woolHarvests,
+          ancestorPhotosByAnimalId:
+            pedigreePrintOptions.layoutPreset === 'family_portrait'
+              ? familyPortraitPhotosByAnimalId
+              : undefined,
+        };
         return (
-          <PrintPreviewModal
+          <Suspense fallback={null}>
+            <PrintPreviewModal
             title={
               isShareableCard && resolvedPedigreeSubject
                 ? `Shareable Pedigree Card — ${resolvedPedigreeSubject.name}`
@@ -2804,9 +3463,7 @@
                       settings.defaultGenerations,
                       resolvedPedigreePhoto,
                       {
-                        ...pedigreePrintOptions,
-                        shows,
-                        careLogs,
+                        ...effectivePedigreeOptions,
                         appBaseUrl,
                         includeQrCode: Boolean(appBaseUrl),
                       }
@@ -2818,10 +3475,18 @@
                       settings,
                       settings.defaultGenerations,
                       resolvedPedigreePhoto,
+                      effectivePedigreeOptions
+                    )
+                : resolvedBirthCertSubject
+                  ? generatePetBirthCertificateHtml(
+                      resolvedBirthCertSubject,
+                      allAnimals,
+                      speciesProfiles,
+                      settings,
                       {
-                        ...pedigreePrintOptions,
-                        shows,
-                        careLogs,
+                        primaryPhotoDataUrl: resolvedSubjectPhoto,
+                        companionFamilyName: birthCertOptions.companionFamilyName,
+                        keepsakeMessage: birthCertOptions.keepsakeMessage,
                       }
                     )
                 : previewDoc.cageCardSubject
@@ -2838,10 +3503,18 @@
                   : previewDoc.html
             }
             includePrimaryPhoto={
-              previewDoc.isPedigree ? settings.includePhotoOnPedigree : undefined
+              previewDoc.isPedigree
+                ? settings.includePhotoOnPedigree
+                : resolvedBirthCertSubject
+                ? birthCertOptions.includePrimaryPhoto
+                : undefined
             }
             onToggleIncludePrimaryPhoto={
-              previewDoc.isPedigree ? onToggleIncludePhotoOnPedigree : undefined
+              previewDoc.isPedigree
+                ? onToggleIncludePhotoOnPedigree
+                : resolvedBirthCertSubject
+                ? (inc) => setBirthCertOptions((prev) => ({ ...prev, includePrimaryPhoto: inc }))
+                : undefined
             }
             includeCageCardQr={
               previewDoc.cageCardSubject ? includeThermalCageCardQr : undefined
@@ -2865,55 +3538,101 @@
             }
             onDownloadPdf={
               resolvedPedigreeSubject && !isShareableCard
-                ? () =>
-                    buildAndDownloadPedigreePdf({
+                ? async () => {
+                    const { buildAndDownloadPedigreePdf } = await import(
+                      '../utils/webPdfActions'
+                    );
+                    return buildAndDownloadPedigreePdf({
                       subject: resolvedPedigreeSubject,
                       allAnimals,
                       speciesProfiles,
                       settings,
                       generations: settings.defaultGenerations,
-                      printOptions: {
-                        ...pedigreePrintOptions,
-                        shows,
-                        careLogs,
-                      },
+                      printOptions: effectivePedigreeOptions,
                       primaryPhotoDataUrl: resolvedPedigreePhoto,
                       pdfFilename: `${previewDoc.filename.replace(/\.html?$/i, '')}.pdf`,
-                    })
+                    });
+                  }
                 : undefined
             }
+            extraToolbarContent={
+              resolvedBirthCertSubject ? (
+                <div className="flex flex-wrap items-center gap-2.5">
+                  <input
+                    type="text"
+                    value={birthCertOptions.companionFamilyName}
+                    onChange={(e) =>
+                      setBirthCertOptions((prev) => ({
+                        ...prev,
+                        companionFamilyName: e.target.value,
+                      }))
+                    }
+                    placeholder="Companion / adopter family name (optional)"
+                    aria-label="Companion or adopter family name"
+                    className="min-h-[30px] min-w-[200px] px-2.5 py-0.5 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] text-xs"
+                  />
+                  <input
+                    type="text"
+                    value={birthCertOptions.keepsakeMessage}
+                    onChange={(e) =>
+                      setBirthCertOptions((prev) => ({
+                        ...prev,
+                        keepsakeMessage: e.target.value,
+                      }))
+                    }
+                    placeholder="Optional keepsake welcome note..."
+                    aria-label="Optional keepsake welcome note"
+                    className="flex-1 min-w-[220px] min-h-[30px] px-2.5 py-0.5 rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] text-xs"
+                  />
+                  <span className="text-[11px] text-[var(--barn-muted)]">
+                    Privacy mode: Breeder contact info &amp; pricing omitted.
+                  </span>
+                </div>
+              ) : undefined
+            }
             headerNotice={
-              previewDoc.hasGenetics ? <ColorGeneticsNotice compact /> : undefined
+              previewDoc.isPedigree ? (
+                <PedigreePrintNotice />
+              ) : previewDoc.hasGenetics ? (
+                <ColorGeneticsNotice compact />
+              ) : undefined
             }
             onClose={() => {
               setPreviewDoc(null);
               setHydratedPedigreePhoto(null);
+              setFamilyPortraitPhotosByAnimalId({});
             }}
           />
+          </Suspense>
         );
       })()}
 
       {batchPrintSubjects && batchPrintSubjects.length > 0 && (
-        <PrintPreviewModal
-          title={`Batch Print — ${getBatchPrintLayoutSpec(batchPrintOptions.layout).label} (${batchPrintSubjects.length} ${speciesProfile.name})`}
-          filename={buildBatchPrintFileName(
-            settings.barnName,
-            speciesProfile.name,
-            batchPrintOptions.layout,
-            batchPrintSubjects.length
-          )}
-          htmlContent={batchPrintHtml}
-          batchPrintOptions={batchPrintOptions}
-          onChangeBatchPrintOptions={setBatchPrintOptions}
-          batchAnimalCount={batchPrintSubjects.length}
-          batchPageCount={batchPrintPageCount}
-          batchPhotoHydrating={batchPhotoHydrating}
-          onClose={() => {
-            setBatchPrintSubjects(null);
-            setBatchHydratedPhotos({});
-            setBatchPhotoHydrating(false);
-          }}
-        />
+        <Suspense fallback={null}>
+          <PrintPreviewModal
+            title={`Batch Print — ${getBatchPrintLayoutSpec(batchPrintOptions.layout).label} (${batchPrintSubjects.length} ${speciesProfile.name})`}
+            filename={buildBatchPrintFileName(
+              settings.barnName,
+              speciesProfile.name,
+              batchPrintOptions.layout,
+              batchPrintSubjects.length
+            )}
+            htmlContent={batchPrintHtml}
+            batchPrintOptions={batchPrintOptions}
+            onChangeBatchPrintOptions={setBatchPrintOptions}
+            batchAnimalCount={batchPrintSubjects.length}
+            batchPageCount={batchPrintPageCount}
+            batchPhotoHydrating={batchPhotoHydrating}
+            headerNotice={
+              batchPrintOptions.layout !== 'cage_cards' ? <PedigreePrintNotice /> : undefined
+            }
+            onClose={() => {
+              setBatchPrintSubjects(null);
+              setBatchHydratedPhotos({});
+              setBatchPhotoHydrating(false);
+            }}
+          />
+        </Suspense>
       )}
 
       {/* E-Leg Certificate Full-Screen Lightbox */}
```

### `src/components/ImportExportHubScreen.tsx` (`+30` / `-50`, source: `part-05_2e3961d6.md`)

```diff
--- working/src/components/ImportExportHubScreen.tsx
+++ import/src/components/ImportExportHubScreen.tsx
@@ -1201,11 +1201,7 @@
           appBaseUrl,
         });
 
-        if (artifact.binaryContent) {
-          await downloadBinaryFile(artifact.filename, artifact.binaryContent, artifact.mimeType);
-        } else {
-          await downloadTextFile(artifact.filename, artifact.content, artifact.mimeType);
-        }
+        await downloadTextFile(artifact.filename, artifact.content, artifact.mimeType);
         setExporterFeedback({
           message: artifact.summary,
           warnings: artifact.warnings,
@@ -1549,9 +1545,11 @@
                     title: 'Community Pedigree Multi-Device Delta Log',
                   });
                   setSyncFeedback(
-                    mode === 'shared'
-                      ? `Shared ${encryptOutgoingSync ? 'encrypted ' : ''}${finalFilename} via native share sheet.`
-                      : `Downloaded ${encryptOutgoingSync ? 'encrypted ' : ''}${finalFilename} for SyncThing or family sharing.`
+                    mode === 'cancelled'
+                      ? 'Share sheet cancelled — no delta file was saved.'
+                      : mode === 'shared'
+                        ? `Shared ${encryptOutgoingSync ? 'encrypted ' : ''}${finalFilename} via native share sheet.`
+                        : `Downloaded ${encryptOutgoingSync ? 'encrypted ' : ''}${finalFilename} for SyncThing or family sharing.`
                   );
                 })
               }
@@ -2424,20 +2422,6 @@
                     </div>
                   </div>
 
-                  {(pendingRestoreInspection.inspection.feedBatchCount > 0 ||
-                    pendingRestoreInspection.inspection.feedAllocationCount > 0 ||
-                    pendingRestoreInspection.inspection.ledgerEntryCount > 0 ||
-                    pendingRestoreInspection.inspection.processingLogCount > 0 ||
-                    pendingRestoreInspection.inspection.youthProjectBookCount > 0) && (
-                    <div className="rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] p-2.5 text-[11px] font-mono tabular-nums text-[var(--barn-muted)] flex flex-wrap gap-x-4 gap-y-1">
-                      <span>Feed Lots: {pendingRestoreInspection.inspection.feedBatchCount}</span>
-                      <span>Feed Logs: {pendingRestoreInspection.inspection.feedAllocationCount}</span>
-                      <span>Ledger: {pendingRestoreInspection.inspection.ledgerEntryCount}</span>
-                      <span>Processing: {pendingRestoreInspection.inspection.processingLogCount}</span>
-                      <span>4-H / FFA: {pendingRestoreInspection.inspection.youthProjectBookCount}</span>
-                    </div>
-                  )}
-
                   {pendingRestoreInspection.inspection.speciesBreakdown.length > 0 && (
                     <div className="rounded-lg bg-[var(--barn-surface)] border border-[var(--barn-border)] p-2.5 space-y-1 text-[11px]">
                       <div className="font-semibold text-[var(--barn-muted)]">
@@ -2809,7 +2793,7 @@
             })}
           </div>
 
-          {/* Extensible External Schema Registry */}
+          {/* Extensible External Schema Roadmap */}
           <div className="border-t border-[var(--barn-border)] pt-4 space-y-3">
             <div className="flex flex-wrap items-center justify-between gap-2">
               <div>
@@ -2823,37 +2807,33 @@
                 </p>
               </div>
               <span className="font-mono text-[11px] text-[var(--barn-muted)]">
-                {BUILTIN_NON_NATIVE_EXPORTERS.length} active
-                {PLANNED_EXTERNAL_SCHEMA_TARGETS.length > 0
-                  ? ` · ${PLANNED_EXTERNAL_SCHEMA_TARGETS.length} reserved schemas`
-                  : ' · All built-in schemas ready'}
+                {BUILTIN_NON_NATIVE_EXPORTERS.length} active ·{' '}
+                {PLANNED_EXTERNAL_SCHEMA_TARGETS.length} reserved schemas
               </span>
             </div>
 
-            {PLANNED_EXTERNAL_SCHEMA_TARGETS.length > 0 && (
-              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
-                {PLANNED_EXTERNAL_SCHEMA_TARGETS.map((target) => (
-                  <div
-                    key={target.id}
-                    className="p-3.5 rounded-xl bg-[var(--barn-canvas)] border border-dashed border-[var(--barn-border)] space-y-1.5"
-                  >
-                    <div className="flex items-center justify-between gap-2">
-                      <span className="font-semibold text-[var(--barn-ink)]">{target.name}</span>
-                      <span className="font-mono text-[10px] text-[var(--barn-muted)]">
-                        {target.formatExtension} · Registered Slot
-                      </span>
-                    </div>
-                    <p className="text-[11px] text-[var(--barn-muted)]">{target.description}</p>
-                    {target.schemaFields && (
-                      <p className="text-[10px] font-mono text-[var(--barn-muted)]">
-                        Columns: {target.schemaFields.join(' · ')}
-                      </p>
-                    )}
-                    <p className="text-[11px] text-[var(--barn-sage)]">{target.compatibilityNote}</p>
+            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
+              {PLANNED_EXTERNAL_SCHEMA_TARGETS.map((target) => (
+                <div
+                  key={target.id}
+                  className="p-3.5 rounded-xl bg-[var(--barn-canvas)] border border-dashed border-[var(--barn-border)] space-y-1.5"
+                >
+                  <div className="flex items-center justify-between gap-2">
+                    <span className="font-semibold text-[var(--barn-ink)]">{target.name}</span>
+                    <span className="font-mono text-[10px] text-[var(--barn-muted)]">
+                      {target.formatExtension} · Registered Slot
+                    </span>
                   </div>
-                ))}
-              </div>
-            )}
+                  <p className="text-[11px] text-[var(--barn-muted)]">{target.description}</p>
+                  {target.schemaFields && (
+                    <p className="text-[10px] font-mono text-[var(--barn-muted)]">
+                      Columns: {target.schemaFields.join(' · ')}
+                    </p>
+                  )}
+                  <p className="text-[11px] text-[var(--barn-sage)]">{target.compatibilityNote}</p>
+                </div>
+              ))}
+            </div>
           </div>
         </section>
       )}
```

### `src/components/PedigreeScreen.tsx` (`+83` / `-0`, source: `part-06_7db922b0.md`)

```diff
--- working/src/components/PedigreeScreen.tsx
+++ import/src/components/PedigreeScreen.tsx
@@ -66,6 +66,7 @@
 import { AnimalEditorModal } from './AnimalEditorModal';
 import { AlleleProvenanceLegend, ColoredGenotypeDisplay } from './ColoredGenotypeDisplay';
 import { ColorGeneticsNotice } from './ColorGeneticsNotice';
+import { PedigreePrintNotice } from './PedigreePrintNotice';
 import { PrintPreviewModal } from './PrintPreviewModal';
 
 interface PedigreeScreenProps {
@@ -87,6 +88,7 @@
   onIgnoreConflicts?: (animalId: string, kinds: AnimalConflictKind[]) => void;
   onRestoreConflictAlert?: (animalId: string, kinds?: AnimalConflictKind[]) => void;
   onLoadFullPhoto?: (photoId: string) => Promise<string | null>;
+  onLoadFullPhotosBatch?: (photoIds: string[]) => Promise<Record<string, string>>;
   onLoadPedigreeNeighborhood?: (rootIds: string[], maxDepth: number) => Promise<Animal[]>;
   onCheckPedigreeBranchesHaveAncestors?: (
     animalIds: string[]
@@ -116,6 +118,7 @@
   onIgnoreConflicts,
   onRestoreConflictAlert,
   onLoadFullPhoto,
+  onLoadFullPhotosBatch,
   onLoadPedigreeNeighborhood,
   onCheckPedigreeBranchesHaveAncestors,
   onUpdateBreederLogo,
@@ -130,6 +133,7 @@
     cages,
     shows,
     careLogs,
+    woolHarvests = [],
   } = activeData;
 
   const [zoom, setZoom] = useState<number>(1);
@@ -152,6 +156,9 @@
     photoId: string;
     dataUrl: string;
   } | null>(null);
+  const [familyPortraitPhotosByAnimalId, setFamilyPortraitPhotosByAnimalId] = useState<
+    Record<string, string>
+  >({});
   const [pedigreePrintOptions, setPedigreePrintOptions] = useState<PedigreePrintOptions>({
     orientation: 'landscape',
     showWeights: true,
@@ -229,6 +236,74 @@
     subjectPrimaryPhoto,
     onLoadFullPhoto,
     hydratedSubjectPhoto,
+  ]);
+
+  useEffect(() => {
+    if (
+      !showPrintModal ||
+      !subject ||
+      pedigreePrintOptions.layoutPreset !== 'family_portrait'
+    ) {
+      setFamilyPortraitPhotosByAnimalId((prev) => (Object.keys(prev).length === 0 ? prev : {}));
+      return;
+    }
+    const animalById = new Map<string, Animal>();
+    for (const a of lazyAncestorsById.values()) animalById.set(a.id, a);
+    for (const a of allAnimals) animalById.set(a.id, a);
+
+    const sire = subject.sireId ? animalById.get(subject.sireId) : undefined;
+    const dam = subject.damId ? animalById.get(subject.damId) : undefined;
+    const familyIds = [
+      subject.id,
+      sire?.id,
+      dam?.id,
+      sire?.sireId,
+      sire?.damId,
+      dam?.sireId,
+      dam?.damId,
+    ].filter((id): id is string => Boolean(id));
+
+    const nextImmediate: Record<string, string> = {};
+    const photoIdsToHydrate: Array<{ animalId: string; photoId: string }> = [];
+    for (const animalId of familyIds) {
+      const rec = primaryPhotoByAnimalId.get(animalId);
+      if (!rec) continue;
+      if (rec.dataUrl) {
+        nextImmediate[animalId] = rec.dataUrl;
+      } else {
+        if (rec.thumbnailDataUrl) nextImmediate[animalId] = rec.thumbnailDataUrl;
+        if (onLoadFullPhotosBatch) {
+          photoIdsToHydrate.push({ animalId, photoId: rec.id });
+        }
+      }
+    }
+    setFamilyPortraitPhotosByAnimalId(nextImmediate);
+
+    if (photoIdsToHydrate.length === 0 || !onLoadFullPhotosBatch) return;
+    let cancelled = false;
+    void onLoadFullPhotosBatch(photoIdsToHydrate.map((x) => x.photoId)).then((loadedMap) => {
+      if (cancelled) return;
+      setFamilyPortraitPhotosByAnimalId((prev) => {
+        const merged = { ...prev };
+        for (const item of photoIdsToHydrate) {
+          if (loadedMap[item.photoId]) {
+            merged[item.animalId] = loadedMap[item.photoId];
+          }
+        }
+        return merged;
+      });
+    });
+    return () => {
+      cancelled = true;
+    };
+  }, [
+    showPrintModal,
+    subject,
+    pedigreePrintOptions.layoutPreset,
+    lazyAncestorsById,
+    allAnimals,
+    primaryPhotoByAnimalId,
+    onLoadFullPhotosBatch,
   ]);
 
   const [historyIds, setHistoryIds] = useState<string[]>(() =>
@@ -1189,6 +1264,7 @@
               <Share2 className="w-3.5 h-3.5" aria-hidden="true" />
               Share Card
             </button>
+            <PedigreePrintNotice compact />
             <ColorGeneticsNotice compact />
           </div>
         </div>
@@ -2122,6 +2198,11 @@
           ...pedigreePrintOptions,
           shows,
           careLogs,
+          woolHarvests,
+          ancestorPhotosByAnimalId:
+            pedigreePrintOptions.layoutPreset === 'family_portrait'
+              ? familyPortraitPhotosByAnimalId
+              : undefined,
         };
         return (
           <PrintPreviewModal
@@ -2183,9 +2264,11 @@
                       pdfFilename: `pedigree-${subject.tattoo || subject.id}-${generations}gen.pdf`,
                     })
             }
+            headerNotice={<PedigreePrintNotice />}
             onClose={() => {
               setShowPrintModal(false);
               setHydratedSubjectPhoto(null);
+              setFamilyPortraitPhotosByAnimalId({});
             }}
           />
         );
```

### `src/components/PrintPreviewModal.tsx` (`+120` / `-183`, source: `part-06_7db922b0.md`)

```diff
--- working/src/components/PrintPreviewModal.tsx
+++ import/src/components/PrintPreviewModal.tsx
@@ -12,9 +12,12 @@
 
 import {
   AlertCircle,
+  Check,
+  Copy,
   Download,
   FileDown,
   Loader2,
+  Mail,
   Printer,
   Share2,
   ShieldAlert,
@@ -50,7 +53,7 @@
 } from '../storage/crashLogger';
 import { optimizeImageFile } from '../storage/webImageOptimizer';
 import { useAccessibleDialog } from '../utils/useAccessibleDialog';
-import { downloadTextFile, shareTextFileOrDownload } from '../utils/webFileActions';
+import { copyTextWithFallback, downloadTextFile, shareTextFileOrDownload } from '../utils/webFileActions';
 import { ColorGeneticsNotice } from './ColorGeneticsNotice';
 
 const MIN_PREVIEW_ZOOM = 0.2;
@@ -58,147 +61,6 @@
 
 function clampPreviewZoom(value: number): number {
   return Math.min(MAX_PREVIEW_ZOOM, Math.max(MIN_PREVIEW_ZOOM, value));
-}
-
-export function canShareHtmlDocument(filename: string, isNativeWrapper: boolean): boolean {
-  if (isNativeWrapper) {
-    return true;
-  }
-  if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') return false;
-  if (typeof navigator.canShare !== 'function') return false;
-  try {
-    const probe = new File(['<html></html>'], filename, { type: 'text/html' });
-    return navigator.canShare({ files: [probe] });
-  } catch {
-    return false;
-  }
-}
-
-export function scopePrintSelectorList(selectorText: string): string {
-  return selectorText
-    .split(',')
-    .map((part) => part.trim())
-    .filter(Boolean)
-    .map((sel) => {
-      if (/^(html|body)$/i.test(sel)) return '#barn-print-stage';
-      if (/^(html|body)\s+/i.test(sel)) {
-        return `#barn-print-stage ${sel.replace(/^(html|body)\s+/i, '')}`;
-      }
-      return `#barn-print-stage ${sel}`;
-    })
-    .join(', ');
-}
-
-export function extractScopedPrintCssFromRules(
-  rules: ArrayLike<CSSRule>,
-  pageRules: string[],
-  scopedRules: string[]
-): void {
-  for (let i = 0; i < rules.length; i++) {
-    const rule = rules[i];
-    if (!rule) continue;
-    const trimmed = typeof rule.cssText === 'string' ? rule.cssText.trimStart() : '';
-    if (rule.type === 6 || trimmed.startsWith('@page')) {
-      pageRules.push(rule.cssText);
-    } else if (rule.type === 1) {
-      const styleRule = rule as CSSStyleRule;
-      const scoped = scopePrintSelectorList(styleRule.selectorText);
-      if (scoped) {
-        scopedRules.push(`${scoped} { ${styleRule.style.cssText} }`);
-      }
-    } else if (rule.type === 4) {
-      const mediaRule = rule as CSSMediaRule;
-      const mediaText = (mediaRule.media?.mediaText || '').trim().toLowerCase();
-      if (mediaText === 'screen' || /\bonly\s+screen\b/.test(mediaText)) {
-        continue;
-      }
-      const childScoped: string[] = [];
-      if (mediaRule.cssRules) {
-        extractScopedPrintCssFromRules(mediaRule.cssRules, pageRules, childScoped);
-      }
-      if (childScoped.length > 0) {
-        if (!mediaText || mediaText === 'print' || mediaText === 'all') {
-          scopedRules.push(...childScoped);
-        } else {
-          const cleanMedia = mediaRule.media.mediaText.replace(/\bscreen\b/gi, 'print');
-          scopedRules.push(`@media ${cleanMedia} {\n${childScoped.join('\n')}\n}`);
-        }
-      }
-    }
-  }
-}
-
-function findMatchingBrace(text: string, openIdx: number): number {
-  let depth = 0;
-  for (let i = openIdx; i < text.length; i++) {
-    const ch = text[i];
-    if (ch === '{') depth++;
-    else if (ch === '}') {
-      depth--;
-      if (depth === 0) return i;
-    }
-  }
-  return -1;
-}
-
-export function extractScopedPrintCssFromRawCss(rawCss: string): {
-  pageRules: string[];
-  scopedRules: string[];
-} {
-  const pageRules: string[] = [];
-  const remainingParts: string[] = [];
-  let cursor = 0;
-  const atRuleRe = /@(page|media)\b([^\{]*)\{/gi;
-
-  while (cursor < rawCss.length) {
-    atRuleRe.lastIndex = cursor;
-    const match = atRuleRe.exec(rawCss);
-    if (!match) {
-      remainingParts.push(rawCss.slice(cursor));
-      break;
-    }
-    if (match.index > cursor) {
-      remainingParts.push(rawCss.slice(cursor, match.index));
-    }
-    const openBrace = match.index + match[0].length - 1;
-    const closeBrace = findMatchingBrace(rawCss, openBrace);
-    if (closeBrace < 0) {
-      remainingParts.push(rawCss.slice(match.index));
-      break;
-    }
-    const kind = match[1].toLowerCase();
-    const prelude = match[2].trim();
-    const inner = rawCss.slice(openBrace + 1, closeBrace);
-    if (kind === 'page') {
-      pageRules.push(rawCss.slice(match.index, closeBrace + 1));
-    } else if (kind === 'media') {
-      const lowerPrelude = prelude.toLowerCase();
-      if (lowerPrelude !== 'screen' && !/\bonly\s+screen\b/.test(lowerPrelude)) {
-        const nested = extractScopedPrintCssFromRawCss(inner);
-        pageRules.push(...nested.pageRules);
-        remainingParts.push(nested.scopedRules.join('\n'));
-      }
-    }
-    cursor = closeBrace + 1;
-  }
-
-  const rewritten = remainingParts
-    .join('\n')
-    .replace(/(^|[\s,}])(html|body)(?=[\s,{])/gi, '$1#barn-print-stage')
-    .trim();
-
-  return {
-    pageRules,
-    scopedRules: rewritten ? [rewritten] : [],
-  };
-}
-
-export function detectDocumentPrintOrientation(
-  pageRules: readonly string[],
-  htmlContent: string
-): 'landscape' | 'portrait' {
-  const combined = `${pageRules.join('\n')}\n${htmlContent}`;
-  return /@page[^}]*\blandscape\b/i.test(combined) ? 'landscape' : 'portrait';
 }
 
 export type PrintPreviewFileActionKind = 'download' | 'share' | 'pdf';
@@ -310,6 +172,9 @@
   batchAnimalCount?: number;
   batchPageCount?: number;
   batchPhotoHydrating?: boolean;
+  extraToolbarContent?: ReactNode;
+  mailtoUrl?: string;
+  plainTextSummary?: string;
   onClose: () => void;
 }
 
@@ -337,6 +202,9 @@
   batchAnimalCount = 0,
   batchPageCount = 0,
   batchPhotoHydrating = false,
+  extraToolbarContent,
+  mailtoUrl,
+  plainTextSummary,
   onClose,
 }: PrintPreviewModalProps) {
   const shareReasonId = useId();
@@ -350,6 +218,7 @@
   const [fileActionBusy, setFileActionBusy] = useState<PrintPreviewFileActionKind | null>(null);
   const [fileActionError, setFileActionError] = useState<PrintPreviewFileError | null>(null);
   const [logoUploading, setLogoUploading] = useState(false);
+  const [copiedSummary, setCopiedSummary] = useState(false);
   const logoInputRef = useRef<HTMLInputElement | null>(null);
   const [docSize, setDocSize] = useState<{ width: number; height: number }>({
     width: 980,
@@ -367,6 +236,7 @@
   const wheelSyncTimerRef = useRef<number | null>(null);
   const printFallbackTimerRef = useRef<number | null>(null);
   const printSafetyTimerRef = useRef<number | null>(null);
+  const copiedSummaryTimerRef = useRef<number | null>(null);
   const cleanupPrintStageRef = useRef<(() => void) | null>(null);
   const cleanupDocListenersRef = useRef<(() => void) | null>(null);
   const dialogRef = useAccessibleDialog({ isOpen: true, onClose });
@@ -383,6 +253,9 @@
       }
       if (printSafetyTimerRef.current !== null) {
         window.clearTimeout(printSafetyTimerRef.current);
+      }
+      if (copiedSummaryTimerRef.current !== null) {
+        window.clearTimeout(copiedSummaryTimerRef.current);
       }
       cleanupPrintStageRef.current?.();
       cleanupPrintStageRef.current = null;
@@ -763,10 +636,16 @@
     }
   };
 
-  const canShareHtml = useMemo(
-    () => canShareHtmlDocument(filename, pedigreeBridge.isNativeWrapper()),
-    [filename]
-  );
+  const canShareHtml = useMemo(() => {
+    if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') return false;
+    if (typeof navigator.canShare !== 'function') return false;
+    try {
+      const probe = new File(['<html></html>'], filename, { type: 'text/html' });
+      return navigator.canShare({ files: [probe] });
+    } catch {
+      return false;
+    }
+  }, [filename]);
 
   const handleShareHtm = () =>
     executeFileAction('share', () =>
@@ -816,9 +695,17 @@
     try {
       const sheets = Array.from(sourceDoc.styleSheets || []);
       for (const sheet of sheets) {
-        const rules = sheet.cssRules;
-        if (rules) {
-          extractScopedPrintCssFromRules(rules, pageRules, scopedRules);
+        const rules = Array.from(sheet.cssRules || []);
+        for (const rule of rules) {
+          if (rule.type === 6 || rule.cssText.trimStart().startsWith('@page')) {
+            pageRules.push(rule.cssText);
+          } else if (rule.type === 1) {
+            const styleRule = rule as CSSStyleRule;
+            const scoped = scopeSelectorList(styleRule.selectorText);
+            if (scoped) {
+              scopedRules.push(`${scoped} { ${styleRule.style.cssText} }`);
+            }
+          }
         }
       }
     } catch {
@@ -829,25 +716,11 @@
       const rawCss = Array.from(parsedFallback.querySelectorAll('style'))
         .map((el) => el.textContent || '')
         .join('\n');
-      const extracted = extractScopedPrintCssFromRawCss(rawCss);
-      pageRules.push(...extracted.pageRules);
-      scopedRules.push(...extracted.scopedRules);
-    }
-
-    const orientation = detectDocumentPrintOrientation(pageRules, htmlContent);
-
-    if (pedigreeBridge.getPlatform() === 'android') {
-      const dispatched = pedigreeBridge.requestPrint({
-        title: docTitle,
-        orientation,
-        htmlContent,
-      });
-      if (!dispatched) {
-        setPrintBlockedMessage(
-          'Native print could not be started on this device. Use Download .HTM (or Share) below to save or export as PDF.'
-        );
-      }
-      return;
+      const extractedPages = rawCss.match(/@page\s*\{[^}]*\}/gi) || [];
+      pageRules.push(...extractedPages);
+      const withoutPage = rawCss.replace(/@page\s*\{[^}]*\}/gi, '');
+      const rewritten = withoutPage.replace(/(^|[\s,}])(html|body)(?=[\s,{])/gi, '$1#barn-print-stage');
+      scopedRules.push(rewritten);
     }
 
     const stageEl = document.createElement('div');
@@ -859,9 +732,6 @@
       sourceDoc.querySelector('meta[name="barn-preserve-accent-ink"][content="true"]') ??
         parsedFallback.querySelector('meta[name="barn-preserve-accent-ink"][content="true"]')
     );
-    if (preserveAccentInk) {
-      stageEl.setAttribute('data-preserve-accent-ink', 'true');
-    }
 
     const styleEl = document.createElement('style');
     styleEl.id = 'barn-print-stage-style';
@@ -890,10 +760,7 @@
           box-sizing: border-box !important;
         }
         ${scopedRules.join('\n')}
-        ${
-          preserveAccentInk
-            ? `#barn-print-stage * { box-shadow: none !important; }`
-            : `#barn-print-stage,
+        #barn-print-stage,
         #barn-print-stage div,
         #barn-print-stage section,
         #barn-print-stage article,
@@ -906,9 +773,8 @@
         #barn-print-stage td {
           background: #ffffff !important;
           background-color: #ffffff !important;
-          color: #000000 !important;
+          ${preserveAccentInk ? '' : 'color: #000000 !important;'}
           box-shadow: none !important;
-        }`
         }
       }
     `;
@@ -954,11 +820,7 @@
     }
 
     if (pedigreeBridge.isNativeWrapper()) {
-      const dispatched = pedigreeBridge.requestPrint({
-        title: docTitle,
-        orientation,
-        htmlContent,
-      });
+      const dispatched = pedigreeBridge.requestPrint();
       if (!dispatched) {
         cleanup();
         setPrintBlockedMessage(
@@ -966,7 +828,7 @@
         );
         return;
       }
-      // Keep #barn-print-stage mounted while non-Android native PrintManager snapshots the WebView DOM.
+      // Keep #barn-print-stage mounted while Android PrintManager snapshots the WebView DOM.
       printSafetyTimerRef.current = window.setTimeout(cleanup, 120000);
       return;
     }
@@ -1155,6 +1017,75 @@
                 {fileActionBusy === 'pdf' ? 'Building PDF...' : 'Download .PDF'}
               </button>
             )}
+            {plainTextSummary && (
+              <button
+                type="button"
+                onClick={async () => {
+                  dismissFileActionError();
+                  try {
+                    const copyMode = await copyTextWithFallback(plainTextSummary);
+                    if (copyMode === 'unsupported') {
+                      if (isMountedRef.current) {
+                        setFileActionError({
+                          action: 'share',
+                          title: 'Could Not Copy Summary',
+                          detail:
+                            'Clipboard access is blocked or unavailable in this browser. Use Download .HTM or Print / Save PDF instead.',
+                        });
+                      }
+                      return;
+                    }
+                    if (isMountedRef.current) {
+                      setCopiedSummary(true);
+                      if (copiedSummaryTimerRef.current !== null) {
+                        window.clearTimeout(copiedSummaryTimerRef.current);
+                      }
+                      copiedSummaryTimerRef.current = window.setTimeout(() => {
+                        copiedSummaryTimerRef.current = null;
+                        if (isMountedRef.current) setCopiedSummary(false);
+                      }, 1800);
+                    }
+                  } catch (err: unknown) {
+                    const detail =
+                      err instanceof Error && err.message.trim()
+                        ? err.message.trim()
+                        : 'Clipboard permission denied.';
+                    logDiagnosticEvent({
+                      level: 'warn',
+                      category: 'storage',
+                      message: `Could not copy print preview summary: ${detail}`,
+                      error: err,
+                    });
+                    if (isMountedRef.current) {
+                      setFileActionError({
+                        action: 'share',
+                        title: 'Could Not Copy Summary',
+                        detail: `${detail} Use Download .HTM or Print / Save PDF instead.`,
+                      });
+                    }
+                  }
+                }}
+                title="Copy plain-text summary for email or messaging"
+                className="min-h-[38px] px-3 py-1.5 rounded-lg border border-[var(--barn-border)] hover:bg-[var(--barn-subtle)] text-xs font-medium transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
+              >
+                {copiedSummary ? (
+                  <Check className="w-4 h-4 text-[var(--barn-sage)]" aria-hidden="true" />
+                ) : (
+                  <Copy className="w-4 h-4" aria-hidden="true" />
+                )}
+                {copiedSummary ? 'Copied Summary' : 'Copy Text'}
+              </button>
+            )}
+            {mailtoUrl && (
+              <a
+                href={mailtoUrl}
+                title="Compose email with pre-filled show entry summary"
+                className="min-h-[38px] px-3 py-1.5 rounded-lg border border-[var(--barn-border)] hover:bg-[var(--barn-subtle)] text-xs font-medium transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
+              >
+                <Mail className="w-4 h-4" aria-hidden="true" />
+                Email Entry
+              </a>
+            )}
             <button
               type="button"
               onClick={handlePrint}
@@ -1922,6 +1853,12 @@
             </div>
           );
         })()}
+
+        {extraToolbarContent && (
+          <div className="px-3 sm:px-5 py-2.5 border-b border-[var(--barn-border)] bg-[var(--barn-canvas)]/75 text-xs">
+            {extraToolbarContent}
+          </div>
+        )}
 
         {(headerNotice ||
           pedigreePrintOptions?.showGenotypes ||
```

### `src/components/SearchableParentPicker.tsx` (`+156` / `-117`, source: `part-06_7db922b0.md`)

```diff
--- working/src/components/SearchableParentPicker.tsx
+++ import/src/components/SearchableParentPicker.tsx
@@ -6,18 +6,26 @@
  *
  * Replaces a static `<select>` dropdown whenever "Include Archived" is enabled
  * during parent selection in Breedings, Pairings, or Animal Pedigree editing.
- * Virtualizes large candidate lists via `useVirtualWindow` so mobile/constrained
- * devices never mount thousands of option nodes at once.
  */
 
 import { Check, Search, X } from 'lucide-react';
-import React, { useEffect, useId, useMemo, useRef, useState } from 'react';
+import React, { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react';
 import { Animal, doesAnimalNeedAttention, isAnimalArchived } from '../core/models';
 import { clampComboboxIndex, stepEnabledComboboxIndex } from '../utils/comboboxNav';
 import { useVirtualWindow } from '../utils/useVirtualWindow';
 
-const OPTION_ROW_ESTIMATE_PX = 36;
-const LISTBOX_MAX_HEIGHT_PX = 208; // max-h-52
+const PICKER_OPTION_ESTIMATE_PX = 38;
+const PICKER_FALLBACK_VIEWPORT_PX = 208;
+
+function matchesParentCandidateQuery(candidate: Animal, q: string): boolean {
+  return (
+    candidate.name.toLowerCase().includes(q) ||
+    candidate.tattoo.toLowerCase().includes(q) ||
+    candidate.breed.toLowerCase().includes(q) ||
+    candidate.variety.toLowerCase().includes(q) ||
+    candidate.registrationNumber.toLowerCase().includes(q)
+  );
+}
 
 interface SearchableParentPickerProps {
   id?: string;
@@ -41,7 +49,8 @@
   onChange,
 }: SearchableParentPickerProps) {
   const containerRef = useRef<HTMLDivElement | null>(null);
-  const listboxRef = useRef<HTMLDivElement | null>(null);
+  const listboxElRef = useRef<HTMLDivElement | null>(null);
+  const optionRefs = useRef<Map<number, HTMLButtonElement>>(new Map());
   const listboxId = useId();
   const [query, setQuery] = useState('');
   const [isOpen, setIsOpen] = useState(false);
@@ -55,12 +64,7 @@
   const filteredCandidates = useMemo(() => {
     const q = query.trim().toLowerCase();
     if (!q) return candidates;
-    return candidates.filter((c) =>
-      [c.name, c.tattoo, c.breed, c.variety, c.registrationNumber]
-        .join(' ')
-        .toLowerCase()
-        .includes(q)
-    );
+    return candidates.filter((c) => matchesParentCandidateQuery(c, q));
   }, [candidates, query]);
 
   const selectableOptions = useMemo(() => {
@@ -77,34 +81,68 @@
     return items;
   }, [unknownLabel, filteredCandidates]);
 
-  const virtualWindow = useVirtualWindow({
+  const pickerVirtual = useVirtualWindow({
     itemCount: isOpen ? selectableOptions.length : 0,
-    estimateSize: OPTION_ROW_ESTIMATE_PX,
+    estimateSize: PICKER_OPTION_ESTIMATE_PX,
     overscan: isConstrained ? 2 : 4,
     initialFallbackCount: isConstrained ? 10 : 16,
-    scrollElementRef: listboxRef,
+    resetKey: `${isOpen}::${query}::${selectableOptions.length}`,
   });
+
+  const { scrollContainerRef: virtualScrollContainerRef, measureRowRef } = pickerVirtual;
+
+  const setListboxRef = useCallback(
+    (node: HTMLDivElement | null) => {
+      listboxElRef.current = node;
+      virtualScrollContainerRef(node);
+    },
+    [virtualScrollContainerRef]
+  );
+
+  const visibleOptions = useMemo(() => {
+    if (!isOpen || selectableOptions.length === 0) return [];
+    const { startIndex, endIndex } = pickerVirtual.windowRange;
+    if (endIndex < startIndex) return [];
+    return selectableOptions.slice(startIndex, endIndex + 1);
+  }, [
+    isOpen,
+    selectableOptions,
+    pickerVirtual.windowRange.startIndex,
+    pickerVirtual.windowRange.endIndex,
+  ]);
 
   useEffect(() => {
     if (!isOpen) {
       setActiveIndex(-1);
+      optionRefs.current.clear();
       return;
     }
     setActiveIndex((prev) => clampComboboxIndex(prev, selectableOptions.length));
   }, [isOpen, selectableOptions.length]);
 
   useEffect(() => {
+    const refs = optionRefs.current;
+    return () => {
+      refs.clear();
+    };
+  }, []);
+
+  useEffect(() => {
     if (!isOpen || activeIndex < 0) return;
-    const el = listboxRef.current;
-    if (!el || typeof el.scrollTo !== 'function') return;
-    const itemTop = activeIndex * OPTION_ROW_ESTIMATE_PX;
-    const itemBottom = itemTop + OPTION_ROW_ESTIMATE_PX;
-    const viewTop = el.scrollTop || 0;
-    const viewHeight = el.clientHeight || LISTBOX_MAX_HEIGHT_PX;
-    if (itemTop < viewTop) {
-      el.scrollTo({ top: itemTop });
-    } else if (itemBottom > viewTop + viewHeight) {
-      el.scrollTo({ top: Math.max(0, itemBottom - viewHeight) });
+    const mountedEl = optionRefs.current.get(activeIndex);
+    if (mountedEl) {
+      mountedEl.scrollIntoView?.({ block: 'nearest' });
+      return;
+    }
+    const container = listboxElRef.current;
+    if (!container) return;
+    const viewportHeight = container.clientHeight || PICKER_FALLBACK_VIEWPORT_PX;
+    const approxTop = activeIndex * PICKER_OPTION_ESTIMATE_PX;
+    const approxBottom = approxTop + PICKER_OPTION_ESTIMATE_PX;
+    if (approxTop < container.scrollTop) {
+      container.scrollTop = approxTop;
+    } else if (approxBottom > container.scrollTop + viewportHeight) {
+      container.scrollTop = Math.max(0, approxBottom - viewportHeight);
     }
   }, [isOpen, activeIndex]);
 
@@ -119,21 +157,6 @@
     isOpen && activeIndex >= 0 && selectableOptions[activeIndex]
       ? `${listboxId}-opt-${activeIndex}`
       : undefined;
-
-  const visibleOptions = useMemo(() => {
-    if (!isOpen || selectableOptions.length === 0) return [];
-    const slice: Array<{
-      index: number;
-      item: (typeof selectableOptions)[number];
-    }> = [];
-    for (let i = virtualWindow.startIndex; i <= virtualWindow.endIndex; i++) {
-      const item = selectableOptions[i];
-      if (item) {
-        slice.push({ index: i, item });
-      }
-    }
-    return slice;
-  }, [isOpen, selectableOptions, virtualWindow.startIndex, virtualWindow.endIndex]);
 
   return (
     <div
@@ -259,103 +282,120 @@
         )}
       </div>
 
-      {/* Searchable Results Dropdown List */}
+      {/* Searchable Results Dropdown List (Virtualized) */}
       {isOpen && (
         <div
-          ref={listboxRef}
+          ref={setListboxRef}
           id={listboxId}
           role="listbox"
           aria-label={`${label} search results`}
-          onScroll={virtualWindow.onScroll}
           className="absolute left-0 right-0 z-30 mt-1 max-h-52 overflow-y-auto rounded-xl border border-[var(--barn-border)] bg-[var(--barn-surface)] shadow-lg"
         >
-          {virtualWindow.paddingTop > 0 && (
-            <div style={{ height: virtualWindow.paddingTop }} aria-hidden="true" />
+          {pickerVirtual.windowRange.paddingTop > 0 && (
+            <div
+              aria-hidden="true"
+              style={{ height: `${pickerVirtual.windowRange.paddingTop}px` }}
+            />
           )}
-
-          {visibleOptions.map(({ index: idx, item }) => {
-            const optionId = `${listboxId}-opt-${idx}`;
-            const isHighlighted = idx === activeIndex;
-
-            if (item.kind === 'unknown') {
+          <div className="divide-y divide-[var(--barn-border)]">
+            {visibleOptions.map((item, localIdx) => {
+              const idx = pickerVirtual.windowRange.startIndex + localIdx;
+              const optionId = `${listboxId}-opt-${idx}`;
+              const isHighlighted = idx === activeIndex;
+              const rowMeasure = measureRowRef(idx);
+
+              if (item.kind === 'unknown') {
+                return (
+                  <button
+                    key="__unknown__"
+                    id={optionId}
+                    ref={(el) => {
+                      rowMeasure(el);
+                      if (el) optionRefs.current.set(idx, el);
+                      else optionRefs.current.delete(idx);
+                    }}
+                    type="button"
+                    role="option"
+                    aria-selected={value === ''}
+                    onMouseDown={(e) => e.preventDefault()}
+                    onMouseEnter={() => setActiveIndex(idx)}
+                    onClick={() => handleSelect('')}
+                    className={`w-full text-left px-3 py-2 text-xs hover:bg-[var(--barn-subtle)] flex items-center justify-between gap-2 ${
+                      value === '' ? 'bg-[var(--barn-sage-tint)] font-semibold' : ''
+                    } ${
+                      isHighlighted ? 'ring-2 ring-inset ring-[var(--barn-sage)] bg-[var(--barn-subtle)]' : ''
+                    }`}
+                  >
+                    <span>{item.label}</span>
+                    {value === '' && (
+                      <Check className="w-3.5 h-3.5 text-[var(--barn-sage)] shrink-0" aria-hidden="true" />
+                    )}
+                  </button>
+                );
+              }
+
+              const cand = item.candidate;
+              const isSelected = cand.id === value;
+              const archived = isAnimalArchived(cand);
+              const needsAttn = doesAnimalNeedAttention(cand);
               return (
                 <button
-                  key="__unknown__"
+                  key={cand.id}
                   id={optionId}
+                  ref={(el) => {
+                    rowMeasure(el);
+                    if (el) optionRefs.current.set(idx, el);
+                    else optionRefs.current.delete(idx);
+                  }}
                   type="button"
                   role="option"
-                  aria-selected={value === ''}
+                  aria-selected={isSelected}
                   onMouseDown={(e) => e.preventDefault()}
                   onMouseEnter={() => setActiveIndex(idx)}
-                  onClick={() => handleSelect('')}
-                  className={`w-full text-left px-3 py-2 text-xs border-b border-[var(--barn-border)] hover:bg-[var(--barn-subtle)] flex items-center justify-between gap-2 ${
-                    value === '' ? 'bg-[var(--barn-sage-tint)] font-semibold' : ''
+                  onClick={() => handleSelect(cand.id)}
+                  className={`w-full text-left px-3 py-2 text-xs hover:bg-[var(--barn-subtle)] flex items-center justify-between gap-2 ${
+                    isSelected ? 'bg-[var(--barn-sage-tint)] font-semibold' : ''
                   } ${
                     isHighlighted ? 'ring-2 ring-inset ring-[var(--barn-sage)] bg-[var(--barn-subtle)]' : ''
                   }`}
                 >
-                  <span>{item.label}</span>
-                  {value === '' && (
-                    <Check className="w-3.5 h-3.5 text-[var(--barn-sage)] shrink-0" aria-hidden="true" />
-                  )}
+                  <span className="min-w-0 truncate">
+                    <span className="text-[var(--barn-ink)]">{cand.name}</span>
+                    {cand.tattoo && (
+                      <span className="font-mono text-[var(--barn-muted)] ml-1.5">
+                        ({cand.tattoo})
+                      </span>
+                    )}
+                    {cand.breed && (
+                      <span className="text-[11px] text-[var(--barn-muted)] ml-1.5">
+                        · {cand.breed}
+                      </span>
+                    )}
+                  </span>
+                  <span className="inline-flex items-center gap-1 shrink-0">
+                    {archived && (
+                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[var(--barn-subtle)] text-[var(--barn-muted)]">
+                        Archived
+                      </span>
+                    )}
+                    {needsAttn && (
+                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[var(--barn-terracotta-tint)] text-[var(--barn-terracotta)]">
+                        Needs Attention
+                      </span>
+                    )}
+                    {isSelected && (
+                      <Check className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                    )}
+                  </span>
                 </button>
               );
-            }
-
-            const cand = item.candidate;
-            const isSelected = cand.id === value;
-            const archived = isAnimalArchived(cand);
-            const needsAttn = doesAnimalNeedAttention(cand);
-            return (
-              <button
-                key={cand.id}
-                id={optionId}
-                type="button"
-                role="option"
-                aria-selected={isSelected}
-                onMouseDown={(e) => e.preventDefault()}
-                onMouseEnter={() => setActiveIndex(idx)}
-                onClick={() => handleSelect(cand.id)}
-                className={`w-full text-left px-3 py-2 text-xs border-b border-[var(--barn-border)] last:border-b-0 hover:bg-[var(--barn-subtle)] flex items-center justify-between gap-2 ${
-                  isSelected ? 'bg-[var(--barn-sage-tint)] font-semibold' : ''
-                } ${
-                  isHighlighted ? 'ring-2 ring-inset ring-[var(--barn-sage)] bg-[var(--barn-subtle)]' : ''
-                }`}
-              >
-                <span className="min-w-0 truncate">
-                  <span className="text-[var(--barn-ink)]">{cand.name}</span>
-                  {cand.tattoo && (
-                    <span className="font-mono text-[var(--barn-muted)] ml-1.5">
-                      ({cand.tattoo})
-                    </span>
-                  )}
-                  {cand.breed && (
-                    <span className="text-[11px] text-[var(--barn-muted)] ml-1.5">
-                      · {cand.breed}
-                    </span>
-                  )}
-                </span>
-                <span className="inline-flex items-center gap-1 shrink-0">
-                  {archived && (
-                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[var(--barn-subtle)] text-[var(--barn-muted)]">
-                      Archived
-                    </span>
-                  )}
-                  {needsAttn && (
-                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[var(--barn-terracotta-tint)] text-[var(--barn-terracotta)]">
-                      Needs Attention
-                    </span>
-                  )}
-                  {isSelected && (
-                    <Check className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
-                  )}
-                </span>
-              </button>
-            );
-          })}
-
-          {virtualWindow.paddingBottom > 0 && (
-            <div style={{ height: virtualWindow.paddingBottom }} aria-hidden="true" />
+            })}
+          </div>
+          {pickerVirtual.windowRange.paddingBottom > 0 && (
+            <div
+              aria-hidden="true"
+              style={{ height: `${pickerVirtual.windowRange.paddingBottom}px` }}
+            />
           )}
 
           {filteredCandidates.length === 0 && (
@@ -368,4 +408,3 @@
     </div>
   );
 }
- 
```

### `src/components/SpeciesDashboardScreen.tsx` (`+426` / `-24`, source: `part-07_f04ec3b8.md`)

```diff
--- working/src/components/SpeciesDashboardScreen.tsx
+++ import/src/components/SpeciesDashboardScreen.tsx
@@ -28,6 +28,7 @@
   DollarSign,
   Download,
   Edit3,
+  FileText,
   GripVertical,
   LayoutGrid,
   Link2,
@@ -37,6 +38,7 @@
   Package,
   Pin,
   Plus,
+  Printer,
   QrCode,
   RefreshCw,
   Settings,
@@ -47,6 +49,7 @@
   StickyNote,
   Trash2,
   UserPlus,
+  Users,
   X,
 } from 'lucide-react';
 import React, { useCallback, useEffect, useId, useMemo, useState } from 'react';
@@ -71,6 +74,7 @@
   generateBatchPrintHtml,
 } from '../core/batchPrint';
 import { formatSystemTaskTitle } from '../core/calendarExport';
+import { evaluateCrmFollowUpReminders } from '../core/clientCrm';
 import { buildFacilityBoardModel } from '../core/facilityBoard';
 import {
   evaluateFeedInventorySummary,
@@ -108,6 +112,15 @@
   mergeEnteredAnimalIdsWithResults,
   normalizeShowResults,
 } from '../core/showResults';
+import {
+  buildShowDocumentFileName,
+  buildShowEntryMailtoUrl,
+  buildShowEntryPlainTextSummary,
+  generateShowEntryFormHtml,
+  generateShowRemarkCardsHtml,
+  RemarkCardLayoutMode,
+  ShowEntryDivision,
+} from '../core/showDocuments';
 import { optimizeImageFile } from '../storage/webImageOptimizer';
 import { countSpeciesNonTestingRecords } from '../core/sampleData';
 import { SpeciesMigrationOptions } from '../core/speciesMigration';
@@ -268,6 +281,23 @@
       }),
     [feedBatches, feedAllocations, speciesProfile.name, settings.feedTagPurgeWindowDays, today]
   );
+  const crmSummary = useMemo(
+    () =>
+      evaluateCrmFollowUpReminders({
+        clients: activeData.clientContacts,
+        waitlistEntries: activeData.waitlistEntries,
+        reservations: activeData.animalReservations,
+        currencyCode: settings.currencyCode,
+        todayIso: today,
+      }),
+    [
+      activeData.clientContacts,
+      activeData.waitlistEntries,
+      activeData.animalReservations,
+      settings.currencyCode,
+      today,
+    ]
+  );
 
   const [taskFilter, setTaskFilter] = useState<'open' | 'completed'>('open');
   const [showNewTaskForm, setShowNewTaskForm] = useState(false);
@@ -437,6 +467,20 @@
   } | null>(null);
   const [pendingShowWithdrawalWarning, setPendingShowWithdrawalWarning] =
     useState<ShowWithdrawalConflictEvaluation | null>(null);
+  const [showDocPreview, setShowDocPreview] = useState<{
+    show: ShowEvent;
+    kind: 'entry_form' | 'remark_cards';
+    division: ShowEntryDivision;
+    exhibitorName: string;
+    exhibitorAddress: string;
+    exhibitorPhone: string;
+    exhibitorEmail: string;
+    exhibitorArbaNumber: string;
+    secretaryEmail: string;
+    entryFeePerAnimal: string;
+    remarkLayout: RemarkCardLayoutMode;
+    includeFurWool: boolean;
+  } | null>(null);
 
   const closeShowEditor = useCallback(() => {
     setPendingShowWithdrawalWarning(null);
@@ -527,6 +571,7 @@
     setActiveBirthCheckoffTaskId(null);
     setShowFullFacilityBoard(false);
     setCageQrPrintState(null);
+    setShowDocPreview(null);
   }, [speciesProfile.name]);
 
   useEffect(() => {
@@ -665,6 +710,93 @@
     snapshot.speciesProfiles,
     photoDataUrlByAnimalId,
   ]);
+
+  const openShowDocumentPreview = (
+    show: ShowEvent,
+    kind: 'entry_form' | 'remark_cards'
+  ) => {
+    setShowDocPreview({
+      show,
+      kind,
+      division: 'Open',
+      exhibitorName: settings.breederName || '',
+      exhibitorAddress: '',
+      exhibitorPhone: '',
+      exhibitorEmail: '',
+      exhibitorArbaNumber: '',
+      secretaryEmail: '',
+      entryFeePerAnimal: '',
+      remarkLayout: '4up',
+      includeFurWool: false,
+    });
+  };
+
+  const renderedShowDocument = useMemo(() => {
+    if (!showDocPreview) return null;
+    const entryOpts = {
+      division: showDocPreview.division,
+      exhibitorName: showDocPreview.exhibitorName,
+      exhibitorBarn: settings.barnName,
+      exhibitorAddress: showDocPreview.exhibitorAddress,
+      exhibitorPhone: showDocPreview.exhibitorPhone,
+      exhibitorEmail: showDocPreview.exhibitorEmail,
+      exhibitorArbaNumber: showDocPreview.exhibitorArbaNumber,
+      secretaryEmail: showDocPreview.secretaryEmail,
+      entryFeePerAnimal: showDocPreview.entryFeePerAnimal,
+      defaultEnterFurWool: showDocPreview.includeFurWool,
+    };
+    if (showDocPreview.kind === 'entry_form') {
+      return {
+        title: `Show Entry Form — ${showDocPreview.show.name}`,
+        filename: buildShowDocumentFileName(showDocPreview.show, 'entry-form'),
+        html: generateShowEntryFormHtml(
+          showDocPreview.show,
+          animals,
+          speciesProfile,
+          settings,
+          entryOpts
+        ),
+        mailtoUrl: buildShowEntryMailtoUrl(
+          showDocPreview.show,
+          animals,
+          speciesProfile,
+          settings,
+          entryOpts
+        ),
+        plainTextSummary: buildShowEntryPlainTextSummary(
+          showDocPreview.show,
+          animals,
+          speciesProfile,
+          settings,
+          entryOpts
+        ),
+      };
+    }
+    return {
+      title: `Show Remark Cards — ${showDocPreview.show.name}`,
+      filename: buildShowDocumentFileName(showDocPreview.show, 'remark-cards'),
+      html: generateShowRemarkCardsHtml(
+        showDocPreview.show,
+        animals,
+        speciesProfile,
+        settings,
+        {
+          layoutMode: showDocPreview.remarkLayout,
+          division: showDocPreview.division,
+          exhibitorName: showDocPreview.exhibitorName || settings.breederName || settings.barnName,
+          includeExistingJudgeNotes: true,
+        }
+      ),
+      mailtoUrl: undefined,
+      plainTextSummary: buildShowEntryPlainTextSummary(
+        showDocPreview.show,
+        animals,
+        speciesProfile,
+        settings,
+        entryOpts
+      ),
+    };
+  }, [showDocPreview, animals, speciesProfile, settings]);
 
   const visibleTasks = tasks.filter((t) => (taskFilter === 'open' ? !t.completed : t.completed));
 
@@ -1429,6 +1561,30 @@
 
             <button
               type="button"
+              onClick={() => onNavigate('crm')}
+              className="bg-[var(--barn-surface)] border border-[var(--barn-border)] hover:border-[var(--barn-sage)] hover:bg-[var(--barn-subtle)] rounded-xl px-4 py-2.5 text-left inline-flex items-center justify-between gap-3 max-w-full transition-colors"
+            >
+              <span className="inline-flex items-center gap-2.5 min-w-0">
+                <span className="w-7 h-7 rounded-lg bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-[var(--barn-sage)] inline-flex items-center justify-center shrink-0">
+                  <Users className="w-4 h-4" aria-hidden="true" />
+                </span>
+                <span className="min-w-0">
+                  <span className="block text-xs font-bold text-[var(--barn-ink)] leading-tight">
+                    Client CRM &amp; Deposits
+                  </span>
+                  <span className="block text-[11px] text-[var(--barn-muted)] leading-tight font-mono tabular-nums">
+                    {crmSummary.activeWaitlistCount} waitlist · {crmSummary.activeReservationsCount} holds
+                    {crmSummary.overdueReminderCount + crmSummary.dueSoonReminderCount > 0
+                      ? ` · ${crmSummary.overdueReminderCount + crmSummary.dueSoonReminderCount} due`
+                      : ''}
+                  </span>
+                </span>
+              </span>
+              <ArrowRight className="w-4 h-4 text-[var(--barn-muted)] shrink-0" aria-hidden="true" />
+            </button>
+
+            <button
+              type="button"
               onClick={openBinderPreview}
               className="bg-[var(--barn-surface)] border border-[var(--barn-border)] hover:border-[var(--barn-sage)] hover:bg-[var(--barn-subtle)] rounded-xl px-4 py-2.5 text-left inline-flex items-center justify-between gap-3 max-w-full transition-colors"
             >
@@ -1508,6 +1664,30 @@
                 </span>
                 <span className="block text-[11px] text-[var(--barn-muted)] leading-tight font-mono tabular-nums">
                   {activeData.ledgerEntries.length} ledger · {activeData.youthProjectBooks.length} 4-H
+                </span>
+              </span>
+            </span>
+            <ArrowRight className="w-4 h-4 text-[var(--barn-muted)] shrink-0" aria-hidden="true" />
+          </button>
+
+          <button
+            type="button"
+            onClick={() => onNavigate('crm')}
+            className="w-full sm:w-auto max-w-full bg-[var(--barn-surface)] border border-[var(--barn-border)] hover:border-[var(--barn-sage)] hover:bg-[var(--barn-subtle)] rounded-xl px-4 py-2.5 text-left inline-flex items-center justify-between gap-3 transition-colors"
+          >
+            <span className="inline-flex items-center gap-2.5 min-w-0">
+              <span className="w-7 h-7 rounded-lg bg-[var(--barn-canvas)] border border-[var(--barn-border)] text-[var(--barn-sage)] inline-flex items-center justify-center shrink-0">
+                <Users className="w-4 h-4" aria-hidden="true" />
+              </span>
+              <span className="min-w-0">
+                <span className="block text-xs font-bold text-[var(--barn-ink)] leading-tight">
+                  Client CRM &amp; Deposits
+                </span>
+                <span className="block text-[11px] text-[var(--barn-muted)] leading-tight font-mono tabular-nums">
+                  {crmSummary.activeWaitlistCount} waitlist · {crmSummary.activeReservationsCount} holds
+                  {crmSummary.overdueReminderCount + crmSummary.dueSoonReminderCount > 0
+                    ? ` · ${crmSummary.overdueReminderCount + crmSummary.dueSoonReminderCount} due`
+                    : ''}
                 </span>
               </span>
             </span>
@@ -3086,7 +3266,25 @@
                                 </p>
                               )}
                             </div>
-                            <div className="flex items-center gap-1 shrink-0">
+                            <div className="flex flex-wrap items-center justify-end gap-1 shrink-0">
+                              <button
+                                type="button"
+                                onClick={() => openShowDocumentPreview(s, 'entry_form')}
+                                title="Preview, print, or email ARBA Show Entry Form"
+                                className="min-h-[34px] px-2.5 py-1 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] hover:bg-[var(--barn-subtle)] text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap"
+                              >
+                                <FileText className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                                <span>Entry Form</span>
+                              </button>
+                              <button
+                                type="button"
+                                onClick={() => openShowDocumentPreview(s, 'remark_cards')}
+                                title="Print 4-up or 1-up Show Remark Cards"
+                                className="min-h-[34px] px-2.5 py-1 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] hover:bg-[var(--barn-subtle)] text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap"
+                              >
+                                <Printer className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                                <span>Remark Cards</span>
+                              </button>
                               <button
                                 type="button"
                                 onClick={() => openEditShowEditor(s)}
@@ -3404,6 +3602,150 @@
         />
       )}
 
+      {/* Show Entry Form & Remark Cards Print / Email Preview */}
+      {showDocPreview && renderedShowDocument && (
+        <PrintPreviewModal
+          title={renderedShowDocument.title}
+          filename={renderedShowDocument.filename}
+          htmlContent={renderedShowDocument.html}
+          mailtoUrl={renderedShowDocument.mailtoUrl}
+          plainTextSummary={renderedShowDocument.plainTextSummary}
+          onClose={() => setShowDocPreview(null)}
+          extraToolbarContent={
+            <div className="w-full flex flex-wrap items-end gap-2 pt-2 border-t border-[var(--barn-border)] text-xs">
+              <label className="flex flex-col gap-0.5">
+                <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                  Document
+                </span>
+                <select
+                  value={showDocPreview.kind}
+                  onChange={(e) =>
+                    setShowDocPreview((prev) =>
+                      prev
+                        ? {
+                            ...prev,
+                            kind: e.target.value === 'remark_cards' ? 'remark_cards' : 'entry_form',
+                          }
+                        : prev
+                    )
+                  }
+                  className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs"
+                >
+                  <option value="entry_form">Show Entry Form</option>
+                  <option value="remark_cards">Show Remark Cards</option>
+                </select>
+              </label>
+
+              <label className="flex flex-col gap-0.5">
+                <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                  Division
+                </span>
+                <select
+                  value={showDocPreview.division}
+                  onChange={(e) =>
+                    setShowDocPreview((prev) =>
+                      prev
+                        ? { ...prev, division: e.target.value === 'Youth' ? 'Youth' : 'Open' }
+                        : prev
+                    )
+                  }
+                  className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs"
+                >
+                  <option value="Open">Open</option>
+                  <option value="Youth">Youth</option>
+                </select>
+              </label>
+
+              <label className="flex flex-col gap-0.5">
+                <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                  Exhibitor
+                </span>
+                <input
+                  type="text"
+                  value={showDocPreview.exhibitorName}
+                  onChange={(e) =>
+                    setShowDocPreview((prev) =>
+                      prev ? { ...prev, exhibitorName: e.target.value } : prev
+                    )
+                  }
+                  placeholder="Exhibitor Name"
+                  className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs w-36"
+                />
+              </label>
+
+              {showDocPreview.kind === 'entry_form' ? (
+                <>
+                  <label className="flex flex-col gap-0.5">
+                    <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                      Secretary Email
+                    </span>
+                    <input
+                      type="email"
+                      value={showDocPreview.secretaryEmail}
+                      onChange={(e) =>
+                        setShowDocPreview((prev) =>
+                          prev ? { ...prev, secretaryEmail: e.target.value } : prev
+                        )
+                      }
+                      placeholder="secretary@club.org"
+                      className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs w-40"
+                    />
+                  </label>
+                  <label className="flex flex-col gap-0.5">
+                    <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                      Fee / Animal ($)
+                    </span>
+                    <input
+                      type="text"
+                      value={showDocPreview.entryFeePerAnimal}
+                      onChange={(e) =>
+                        setShowDocPreview((prev) =>
+                          prev ? { ...prev, entryFeePerAnimal: e.target.value } : prev
+                        )
+                      }
+                      placeholder="e.g. 5.00"
+                      className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs w-20"
+                    />
+                  </label>
+                  <label className="inline-flex items-center gap-1.5 min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] cursor-pointer">
+                    <input
+                      type="checkbox"
+                      checked={showDocPreview.includeFurWool}
+                      onChange={(e) =>
+                        setShowDocPreview((prev) =>
+                          prev ? { ...prev, includeFurWool: e.target.checked } : prev
+                        )
+                      }
+                    />
+                    <span>Enter Fur / Wool</span>
+                  </label>
+                </>
+              ) : (
+                <label className="flex flex-col gap-0.5">
+                  <span className="text-[10px] font-semibold uppercase tracking-wide text-[var(--barn-muted)]">
+                    Card Layout
+                  </span>
+                  <select
+                    value={showDocPreview.remarkLayout}
+                    onChange={(e) =>
+                      setShowDocPreview((prev) =>
+                        prev
+                          ? { ...prev, remarkLayout: e.target.value === '1up' ? '1up' : '4up' }
+                          : prev
+                      )
+                    }
+                    className="min-h-[32px] px-2 rounded-lg border border-[var(--barn-border)] bg-[var(--barn-canvas)] text-xs"
+                  >
+                    <option value="4up">4-Up Letter Sheet</option>
+                    <option value="1up">1-Up (4x6 Index / Thermal)</option>
+                  </select>
+                </label>
+              )}
+            </div>
+          }
+        />
+      )}
+
       {/* Structured Show, Placements, Awards, Judge Notes & E-Leg Vault Editor Modal */}
       {showEditorOpen && (
         <div
@@ -3976,30 +4318,90 @@
               )}
             </div>
 
-            <div className="px-5 py-3.5 border-t border-[var(--barn-border)] bg-[var(--barn-canvas)]/60 flex items-center justify-end gap-2">
-              <button
-                type="button"
-                disabled={showSubmitLock.isSubmitting}
-                onClick={closeShowEditor}
-                className="min-h-[38px] px-4 py-1.5 rounded-xl border border-[var(--barn-border)] bg-[var(--barn-surface)] text-xs font-medium disabled:opacity-50"
-              >
-                Cancel
-              </button>
-              <button
-                type="submit"
-                disabled={showSubmitLock.isSubmitting || Boolean(showPhotoBusyAnimalId)}
-                aria-busy={showSubmitLock.isSubmitting}
-                className="min-h-[38px] px-4 py-1.5 rounded-xl bg-[var(--barn-sage)] text-[var(--barn-on-sage)] text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-65"
-              >
-                {showSubmitLock.isSubmitting && (
-                  <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
+            <div className="px-5 py-3.5 border-t border-[var(--barn-border)] bg-[var(--barn-canvas)]/60 flex flex-wrap items-center justify-between gap-2">
+              <div className="flex flex-wrap items-center gap-1.5">
+                {showAnimalIds.length > 0 && (
+                  <>
+                    <button
+                      type="button"
+                      onClick={() =>
+                        openShowDocumentPreview(
+                          {
+                            id: editingShowId || 'draft-show',
+                            species: speciesProfile.name,
+                            name: showName.trim() || `${speciesProfile.name} Show`,
+                            location: showLocation.trim(),
+                            sanctioningBody: showSanction,
+                            eventDateIso: showDateIso || today,
+                            entryDeadlineIso: showDeadlineIso || '',
+                            enteredAnimalIds: showAnimalIds,
+                            results: Object.values(showResultsByAnimalId),
+                            notes: showNotes.trim(),
+                            createdAt: today,
+                            updatedAt: today,
+                          },
+                          'entry_form'
+                        )
+                      }
+                      className="min-h-[36px] px-3 py-1.5 rounded-xl border border-[var(--barn-border)] bg-[var(--barn-surface)] hover:bg-[var(--barn-subtle)] text-xs font-medium inline-flex items-center gap-1.5"
+                    >
+                      <FileText className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                      Entry Form
+                    </button>
+                    <button
+                      type="button"
+                      onClick={() =>
+                        openShowDocumentPreview(
+                          {
+                            id: editingShowId || 'draft-show',
+                            species: speciesProfile.name,
+                            name: showName.trim() || `${speciesProfile.name} Show`,
+                            location: showLocation.trim(),
+                            sanctioningBody: showSanction,
+                            eventDateIso: showDateIso || today,
+                            entryDeadlineIso: showDeadlineIso || '',
+                            enteredAnimalIds: showAnimalIds,
+                            results: Object.values(showResultsByAnimalId),
+                            notes: showNotes.trim(),
+                            createdAt: today,
+                            updatedAt: today,
+                          },
+                          'remark_cards'
+                        )
+                      }
+                      className="min-h-[36px] px-3 py-1.5 rounded-xl border border-[var(--barn-border)] bg-[var(--barn-surface)] hover:bg-[var(--barn-subtle)] text-xs font-medium inline-flex items-center gap-1.5"
+                    >
+                      <Printer className="w-3.5 h-3.5 text-[var(--barn-sage)]" aria-hidden="true" />
+                      Remark Cards
+                    </button>
+                  </>
                 )}
-                {showSubmitLock.isSubmitting
-                  ? 'Saving...'
-                  : editingShowId
-                    ? 'Save Show & Results'
-                    : 'Save Show'}
-              </button>
+              </div>
+              <div className="flex items-center gap-2 ml-auto">
+                <button
+                  type="button"
+                  disabled={showSubmitLock.isSubmitting}
+                  onClick={closeShowEditor}
+                  className="min-h-[38px] px-4 py-1.5 rounded-xl border border-[var(--barn-border)] bg-[var(--barn-surface)] text-xs font-medium disabled:opacity-50"
+                >
+                  Cancel
+                </button>
+                <button
+                  type="submit"
+                  disabled={showSubmitLock.isSubmitting || Boolean(showPhotoBusyAnimalId)}
+                  aria-busy={showSubmitLock.isSubmitting}
+                  className="min-h-[38px] px-4 py-1.5 rounded-xl bg-[var(--barn-sage)] text-[var(--barn-on-sage)] text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-65"
+                >
+                  {showSubmitLock.isSubmitting && (
+                    <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
+                  )}
+                  {showSubmitLock.isSubmitting
+                    ? 'Saving...'
+                    : editingShowId
+                      ? 'Save Show & Results'
+                      : 'Save Show'}
+                </button>
+              </div>
             </div>
           </form>
         </div>
```

### `src/components/SpeciesMigrationModal.tsx` (`+4` / `-15`, source: `part-07_f04ec3b8.md`)

```diff
--- working/src/components/SpeciesMigrationModal.tsx
+++ import/src/components/SpeciesMigrationModal.tsx
@@ -176,8 +176,8 @@
     try {
       await onConfirmMigrate(effectiveAnimalIds, effectiveTarget, migrationOptions);
       onClose();
-    } catch (err: unknown) {
-      setErrorMsg(err instanceof Error ? err.message : 'Could not migrate selected records.');
+    } catch (err: any) {
+      setErrorMsg(err?.message || 'Could not migrate selected records.');
     } finally {
       setIsMigrating(false);
     }
@@ -389,12 +389,6 @@
                     {previewResult.showsUpdated > 0
                       ? `, ${previewResult.showsUpdated} shows`
                       : ''}
-                    {previewResult.feedBatchesMigrated > 0
-                      ? `, ${previewResult.feedBatchesMigrated} feed batches`
-                      : ''}
-                    {previewResult.feedAllocationsMigrated > 0
-                      ? `, ${previewResult.feedAllocationsMigrated} feed logs`
-                      : ''}
                     .
                   </p>
                   <p className="text-[11px]">
@@ -460,13 +454,8 @@
                       <strong className="text-[var(--barn-ink)]">Linked records moving:</strong>{' '}
                       {previewResult.photosMigrated} photos, {previewResult.careLogsMigrated} care/weight logs,{' '}
                       {previewResult.tasksMigrated} barn chores, {previewResult.breedingsMigrated} breeding
-                      records, {previewResult.cagesMigratedOrAdded} cage/pen locations,{' '}
-                      {previewResult.showsUpdated} show entries
-                      {previewResult.feedBatchesMigrated > 0 ||
-                      previewResult.feedAllocationsMigrated > 0
-                        ? `, ${previewResult.feedBatchesMigrated} feed batches, and ${previewResult.feedAllocationsMigrated} feed allocations`
-                        : ''}
-                      .
+                      records, {previewResult.cagesMigratedOrAdded} cage/pen locations, and{' '}
+                      {previewResult.showsUpdated} show entries.
                     </li>
 
                     {previewResult.createdTargetProfile ? (
```

### `src/core/__tests__/exportersRegistry.test.ts` (`+9` / `-67`, source: `part-12.md`)

```diff
--- working/src/core/__tests__/exportersRegistry.test.ts
+++ import/src/core/__tests__/exportersRegistry.test.ts
@@ -1,4 +1,3 @@
-import { unzipSync, strFromU8 } from 'fflate';
 import { describe, expect, it } from 'vitest';
 import {
   buildExporterCatalog,
@@ -9,11 +8,10 @@
   runExternalExporter,
 } from '../exporters/registry';
 import type { ExternalExporterDescriptor } from '../exporters/exporterTypes';
-import { HerdBossImporter } from '../importers/herdBossImporter';
 import { buildFullPredefinedSampleSnapshot } from '../sampleData';
 
 describe('exporters/registry — extensible non-native format exporters', () => {
-  it('registers all built-in ready exporters and external schemas with unique IDs', () => {
+  it('registers all built-in ready exporters and planned external schema targets with unique IDs', () => {
     const ids = new Set<string>();
     for (const exp of EXTERNAL_EXPORTERS) {
       expect(exp.id.trim().length).toBeGreaterThan(0);
@@ -23,14 +21,12 @@
         expect(typeof exp.exportPayload).toBe('function');
       }
     }
-    expect(BUILTIN_NON_NATIVE_EXPORTERS.length).toBeGreaterThanOrEqual(8);
-    expect(PLANNED_EXTERNAL_SCHEMA_TARGETS).toHaveLength(0);
+    expect(BUILTIN_NON_NATIVE_EXPORTERS.length).toBeGreaterThanOrEqual(5);
+    expect(PLANNED_EXTERNAL_SCHEMA_TARGETS.length).toBeGreaterThanOrEqual(1);
     expect(getExternalExporterById('clean-csv')?.formatExtension).toBe('.CSV');
-    expect(getExternalExporterById('herdboss-transfer-bundle')?.status).toBe('ready');
-    expect(getExternalExporterById('registry-worksheet-csv')?.status).toBe('ready');
   });
 
-  it('executes CSV, Evans .HTM, Barn Binder .HTM, Report DTO .JSON, .ICS, HerdBoss .ZIP, and Registry Worksheet .CSV in pure TS', () => {
+  it('executes CSV, Evans .HTM, Barn Binder .HTM, Report DTO .JSON, and .ICS exporters in pure TS', () => {
     const snapshot = buildFullPredefinedSampleSnapshot();
     const rabbit = snapshot.animals.find((a) => a.species === 'Rabbit')!;
 
@@ -106,51 +102,9 @@
     expect(ics.filename.endsWith('.ics')).toBe(true);
     expect(ics.content).toContain('BEGIN:VCALENDAR');
     expect(ics.content).toContain('Kindling Nestbox Check');
-
-    const hbZip = runExternalExporter('herdboss-transfer-bundle', {
-      snapshot,
-      speciesName: 'Rabbit',
-    });
-    expect(hbZip.filename.endsWith('.zip')).toBe(true);
-    expect(hbZip.mimeType).toBe('application/zip');
-    expect(hbZip.binaryContent).toBeInstanceOf(Uint8Array);
-    const unpacked = unzipSync(hbZip.binaryContent!);
-    expect(Object.keys(unpacked).sort()).toEqual([
-      'animals.csv',
-      'breedings.csv',
-      'pedigree_links.csv',
-      'weights.csv',
-    ]);
-    const animalsCsvBytes = unpacked['animals.csv'];
-    expect(Array.from(animalsCsvBytes.slice(0, 3))).toEqual([0xef, 0xbb, 0xbf]);
-    const animalsCsvText = strFromU8(animalsCsvBytes);
-    expect(animalsCsvText).toContain(rabbit.name);
-
-    // Round-trip verification back through HerdBossImporter into a clean snapshot
-    const emptySnapshot = {
-      ...snapshot,
-      animals: [],
-      breedings: [],
-      careLogs: [],
-    };
-    const reimportPreview = HerdBossImporter.parse(
-      [{ fileName: hbZip.filename, bytes: hbZip.binaryContent! }],
-      emptySnapshot,
-      { fallbackSpeciesName: 'Rabbit' }
-    );
-    expect(reimportPreview.animals.some((a) => a.name === rabbit.name)).toBe(true);
-
-    const worksheet = runExternalExporter('registry-worksheet-csv', {
-      snapshot,
-      speciesName: 'Rabbit',
-    });
-    expect(worksheet.filename.endsWith('.csv')).toBe(true);
-    expect(worksheet.content.charCodeAt(0)).toBe(0xfeff);
-    expect(worksheet.content).toContain('Gen3_Pat_Grandsire');
-    expect(worksheet.content).toContain(rabbit.name);
   });
 
-  it('supports extending or overriding catalog entries and rejects unknown or planned IDs', () => {
+  it('supports extending or overriding catalog entries cleanly without UI code changes', () => {
     const customSchema: ExternalExporterDescriptor = {
       id: 'kintracs-custom-csv',
       name: 'Kintracs Transfer CSV',
@@ -172,27 +126,15 @@
         warnings: [],
       }),
     };
-    const plannedSchema: ExternalExporterDescriptor = {
-      id: 'future-planned-schema',
-      name: 'Future Planned Format',
-      formatExtension: '.CSV',
-      category: 'external_schema',
-      targetPlatform: 'Future',
-      scopeMode: 'all_or_species',
-      supportsSpeciesFilter: true,
-      status: 'planned',
-      description: 'Reserved slot.',
-      compatibilityNote: 'Planned.',
-    };
 
-    const extendedCatalog = buildExporterCatalog([customSchema, plannedSchema]);
+    const extendedCatalog = buildExporterCatalog([customSchema]);
     const snapshot = buildFullPredefinedSampleSnapshot();
     const res = runExternalExporter('kintracs-custom-csv', { snapshot }, extendedCatalog);
     expect(res.filename).toBe('kintracs-export.csv');
     expect(res.recordCount).toBe(snapshot.animals.length);
 
-    expect(() =>
-      runExternalExporter('future-planned-schema', { snapshot }, extendedCatalog)
-    ).toThrow(/planned external schema target/i);
+    expect(() => runExternalExporter('herdboss-transfer-bundle', { snapshot })).toThrow(
+      /planned external schema target/i
+    );
   });
 });
```

### `src/core/__tests__/reportCatalog.test.ts` (`+3` / `-1`, source: `part-12.md`)

```diff
--- working/src/core/__tests__/reportCatalog.test.ts
+++ import/src/core/__tests__/reportCatalog.test.ts
@@ -53,10 +53,12 @@
       offspringLabel: 'Chick',
     };
     const quailCatalog = buildReportCatalogForSpecies(customProfile);
-    expect(quailCatalog).toHaveLength(26);
+    expect(quailCatalog).toHaveLength(28);
     expect(quailCatalog.map((r) => r.id)).toContain('barn-economics-report');
     expect(quailCatalog.map((r) => r.id)).toContain('meat-pelt-yield-report');
     expect(quailCatalog.map((r) => r.id)).toContain('youth-project-report');
+    expect(quailCatalog.map((r) => r.id)).toContain('crm-waitlist-report');
+    expect(quailCatalog.map((r) => r.id)).toContain('crm-reservations-deposits-report');
     expect(quailCatalog[0].title).toBe('Hatching Calendar (By ID)');
     expect(quailCatalog.every((e) => e.scopeLabel === 'Quail Only')).toBe(true);
   });
```

### `src/core/__tests__/reportGenerators.test.ts` (`+2` / `-2`, source: `part-12.md`)

```diff
--- working/src/core/__tests__/reportGenerators.test.ts
+++ import/src/core/__tests__/reportGenerators.test.ts
@@ -391,12 +391,12 @@
 }
 
 describe('reportGenerators (Phase 3)', () => {
-  it('generates every single one of the 26 catalog reports for an added species without errors', () => {
+  it('generates every single one of the 28 catalog reports for an added species without errors', () => {
     const snapshot = buildMultiSpeciesTestSnapshot();
     const rabbitProfile = snapshot.speciesProfiles[0];
     const catalog = buildReportCatalogForSpecies(rabbitProfile);
 
-    expect(catalog).toHaveLength(26);
+    expect(catalog).toHaveLength(28);
 
     for (const entry of catalog) {
       const rep = generateSpeciesReport(snapshot, 'Rabbit', entry.id, {
```

### `src/core/__tests__/speciesMigration.test.ts` (`+0` / `-65`, source: `part-13.md`)

```diff
--- working/src/core/__tests__/speciesMigration.test.ts
+++ import/src/core/__tests__/speciesMigration.test.ts
@@ -167,69 +167,4 @@
     // Unrelated Sheep remains untouched
     expect(result.snapshot.animals.find((a) => a.id === 'sb')?.species).toBe('Sheep');
   });
-
-  it('migrates linked feedBatches and feedAllocations and clears remainingSourceRecordsCount', () => {
-    const doe = makeAnimal('d1', { species: 'Rabbit', sex: 'Female' });
-    const buck = makeAnimal('b1', { species: 'Rabbit', sex: 'Male' });
-    const snap = makeEmptySnapshot({
-      speciesProfiles: [makeSpeciesProfile('Rabbit'), makeSpeciesProfile('Goat')],
-      animals: [doe, buck],
-      feedBatches: [
-        {
-          id: 'fb1',
-          species: 'Rabbit',
-          brand: 'Mana Pro',
-          productName: '16% Pelleted',
-          lotNumber: 'LOT-99',
-          millCode: 'MILL-1',
-          manufactureDateIso: '2026-01-15',
-          purchaseDateIso: '2026-02-01',
-          bagCount: 2,
-          bagWeightValue: 50,
-          bagWeightUnit: 'lbs',
-          totalQuantity: 100,
-          remainingQuantity: 80,
-          lowStockThreshold: 15,
-          totalCostCents: 4200,
-          supplierName: 'Local Feed Co',
-          notes: '',
-          _rev: 1,
-          createdAt: '2026-02-01T00:00:00.000Z',
-          updatedAt: '2026-02-01T00:00:00.000Z',
-        },
-      ],
-      feedAllocations: [
-        {
-          id: 'fa1',
-          species: 'Rabbit',
-          feedBatchId: 'fb1',
-          targetType: 'animal',
-          targetId: 'd1',
-          targetLabel: doe.name,
-          dateIso: '2026-02-02',
-          quantity: 0.5,
-          unit: 'lbs',
-          notes: '',
-          _rev: 1,
-          createdAt: '2026-02-02T00:00:00.000Z',
-          updatedAt: '2026-02-02T00:00:00.000Z',
-        },
-      ],
-    });
-
-    const partial = migrateAnimalsToSpecies(snap, ['d1'], 'Goat');
-    expect(partial.feedBatchesMigrated).toBe(0);
-    expect(partial.feedAllocationsMigrated).toBe(1);
-    expect(partial.snapshot.feedAllocations?.[0].species).toBe('Goat');
-    expect(partial.snapshot.feedAllocations?.[0]._rev).toBe(2);
-
-    const bulk = migrateAnimalsToSpecies(partial.snapshot, [], 'Goat', {
-      migrateEntireSpecies: true,
-      sourceSpeciesName: 'Rabbit',
-    });
-    expect(bulk.feedBatchesMigrated).toBe(1);
-    expect(bulk.snapshot.feedBatches?.[0].species).toBe('Goat');
-    expect(bulk.snapshot.feedBatches?.[0]._rev).toBe(2);
-    expect(bulk.remainingSourceRecordsCount).toBe(0);
-  });
 });
```

### `src/core/__tests__/stageBResilience.test.ts` (`+2` / `-47`, source: `part-13.md`)

```diff
--- working/src/core/__tests__/stageBResilience.test.ts
+++ import/src/core/__tests__/stageBResilience.test.ts
@@ -213,60 +213,15 @@
       });
     });
 
-    it('summarizes snapshots directly for SQLite pre-restore dry-run inspection including v3/v4 records', () => {
+    it('summarizes snapshots directly for SQLite pre-restore dry-run inspection', () => {
       const a1 = makeAnimal('a1', { tattoo: 'T1', sex: 'Male' });
-      const snap = makeEmptySnapshot({
-        animals: [a1],
-        feedBatches: [
-          {
-            id: 'fb-1',
-            species: 'Rabbit',
-            brand: 'Brand',
-            productName: 'Pellet',
-            lotNumber: 'L1',
-            millCode: '',
-            manufactureDateIso: '',
-            purchaseDateIso: '2026-03-01',
-            bagCount: 1,
-            bagWeightValue: 50,
-            bagWeightUnit: 'lbs',
-            totalQuantity: 50,
-            remainingQuantity: 50,
-            lowStockThreshold: 10,
-            totalCostCents: 2000,
-            supplierName: 'Supply Co',
-            notes: '',
-            createdAt: '2026-03-01T00:00:00.000Z',
-            updatedAt: '2026-03-01T00:00:00.000Z',
-          },
-        ],
-        ledgerEntries: [
-          {
-            id: 'le-1',
-            species: 'Rabbit',
-            dateIso: '2026-03-01',
-            entryType: 'expense',
-            category: 'supplies',
-            amountCents: 1500,
-            title: 'Water crocks',
-            vendorOrParty: 'Supply Co',
-            notes: '',
-            createdAt: '2026-03-01T00:00:00.000Z',
-            updatedAt: '2026-03-01T00:00:00.000Z',
-          },
-        ],
-      });
+      const snap = makeEmptySnapshot({ animals: [a1] });
       const insp = inspectSnapshotBeforeRestorePure(snap, null, {
         fileName: 'barn.sqlite',
         sourceFormat: 'sqlite',
       });
       expect(insp.sourceFormat).toBe('sqlite');
       expect(insp.animalCount).toBe(1);
-      expect(insp.feedBatchCount).toBe(1);
-      expect(insp.feedAllocationCount).toBe(0);
-      expect(insp.ledgerEntryCount).toBe(1);
-      expect(insp.processingLogCount).toBe(0);
-      expect(insp.youthProjectBookCount).toBe(0);
       expect(insp.replaceImpact).toBeNull();
       expect(insp.mergeImpact).toBeNull();
     });
```

### `src/core/__tests__/suggestionsBacklog.test.ts` (`+3` / `-3`, source: `part-13.md`)

```diff
--- working/src/core/__tests__/suggestionsBacklog.test.ts
+++ import/src/core/__tests__/suggestionsBacklog.test.ts
@@ -26,15 +26,15 @@
 
     expect(SUGGESTIONS_BACKLOG_PATH).toBe('/docs/plans/suggestions-backlog.md');
     expect(parsed.isEmpty).toBe(false);
-    expect(parsed.totalItems).toBe(8);
+    expect(parsed.totalItems).toBe(6);
     expect(parsed.sections).toHaveLength(1);
     expect(parsed.sections[0].title).toContain('Priority 4');
-    expect(parsed.sections[0].items).toHaveLength(8);
+    expect(parsed.sections[0].items).toHaveLength(6);
 
     const firstItem = parsed.sections[0].items[0];
     expect(firstItem.number).toBe(1);
     expect(firstItem.title).toBe(
-      'Client CRM, Buyer Waitlist, Reservations & Deposit Reminders'
+      'Founder Loss / Heritability Analytics & Interactive Barn Scheduler Gantt'
     );
     expect(firstItem.codeTag).toBeNull();
     expect(firstItem.details.length).toBeGreaterThan(0);
```

### `src/core/__tests__/syncAndExports.test.ts` (`+99` / `-0`, source: `part-13.md`)

```diff
--- working/src/core/__tests__/syncAndExports.test.ts
+++ import/src/core/__tests__/syncAndExports.test.ts
@@ -637,4 +637,103 @@
     expect(mergedRabbit?.targetWeightCurve).toHaveLength(2);
     expect(merged.snapshot.breedings[0].litterWeightMilestones?.[0].totalWeightGrams).toBe(3180);
   });
+
+  it('renders family_portrait multi-photo pedigrees, iagarb_angora 7-position scorecards, and persists woolHarvests in backups', () => {
+    const sire = makeAnimal('s1', {
+      name: 'Boreal King',
+      sex: 'Male',
+      breed: 'German Angora',
+      variety: 'White',
+    });
+    const dam = makeAnimal('d1', {
+      name: 'Cloud Silk',
+      sex: 'Female',
+      breed: 'German Angora',
+      variety: 'White',
+    });
+    const subject = makeAnimal('a1', {
+      name: 'Snowdrift',
+      tattoo: 'ANG01',
+      sex: 'Female',
+      breed: 'German Angora',
+      variety: 'White',
+      sireId: 's1',
+      damId: 'd1',
+    });
+    const harvest = {
+      id: 'wh-test-1',
+      species: 'Rabbit',
+      animalId: 'a1',
+      harvestDateIso: '2026-06-01',
+      shearingIntervalDays: 90,
+      primeWeightGrams: 280,
+      gradeWeightGrams: 80,
+      harvestMethod: 'Shear' as const,
+      stapleLengthMm: 78,
+      iagarbScore: {
+        weightPts: 19,
+        bodyTypePts: 18,
+        densityLengthPts: 13.5,
+        uniformityPts: 13,
+        texturePts: 14,
+        furnishingsPts: 8.5,
+        conditionPts: 4.5,
+        totalPts: 90.5,
+        evaluatorName: 'E. Registrar',
+        evaluationDateIso: '2026-06-01',
+      },
+      notes: 'Clean uniform staple',
+      createdAt: '2026-06-01T10:00:00.000Z',
+      updatedAt: '2026-06-01T10:00:00.000Z',
+    };
+
+    const samplePng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
+
+    const familyHtml = generateEvansHtmPedigree(
+      subject,
+      [subject, sire, dam],
+      [makeSpeciesProfile('Rabbit')],
+      makeSettings(),
+      3,
+      samplePng,
+      {
+        layoutPreset: 'family_portrait',
+        ancestorPhotosByAnimalId: {
+          s1: samplePng,
+          d1: samplePng,
+        },
+        woolHarvests: [harvest],
+      }
+    );
+    expect(familyHtml).toContain('Boreal King');
+    expect(familyHtml).toContain('360g total');
+    expect(familyHtml).toContain('family-strip');
+    expect(familyHtml).toContain('anc-photo');
+
+    const iagarbHtml = generateEvansHtmPedigree(
+      subject,
+      [subject, sire, dam],
+      [makeSpeciesProfile('Rabbit')],
+      makeSettings(),
+      3,
+      samplePng,
+      {
+        layoutPreset: 'iagarb_angora',
+        woolHarvests: [harvest],
+      }
+    );
+    expect(iagarbHtml).toContain('IAGARB German Angora Wool &amp; Evaluation Standard');
+    expect(iagarbHtml).toContain('90.5 / 100 pts');
+    expect(iagarbHtml).toContain('360g/90d');
+    expect(iagarbHtml).toContain('90.5/100');
+
+    const snap = makeEmptySnapshot({
+      animals: [subject, sire, dam],
+      woolHarvests: [harvest],
+    });
+    const parsed = parseBarnBackupJson(exportBarnBackupJson(snap), makeSettings());
+    expect(parsed.woolHarvests).toHaveLength(1);
+    expect(parsed.woolHarvests?.[0].primeWeightGrams).toBe(280);
+    expect(parsed.woolHarvests?.[0].iagarbScore?.totalPts).toBe(90.5);
+  });
 });
```

### `src/core/__tests__/testFixtures.ts` (`+4` / `-0`, source: `part-13.md`)

```diff
--- working/src/core/__tests__/testFixtures.ts
+++ import/src/core/__tests__/testFixtures.ts
@@ -95,6 +95,10 @@
     ledgerEntries: [],
     processingLogs: [],
     youthProjectBooks: [],
+    clientContacts: [],
+    waitlistEntries: [],
+    animalReservations: [],
+    woolHarvests: [],
     ...overrides,
   };
 }
```

### `src/core/archiveInspector.ts` (`+0` / `-15`, source: `part-08.md`)

```diff
--- working/src/core/archiveInspector.ts
+++ import/src/core/archiveInspector.ts
@@ -43,11 +43,6 @@
   cageCount: number;
   careLogCount: number;
   showCount: number;
-  feedBatchCount: number;
-  feedAllocationCount: number;
-  ledgerEntryCount: number;
-  processingLogCount: number;
-  youthProjectBookCount: number;
   photoCount: number;
   photoBytes: number;
   speciesBreakdown: ArchiveSpeciesSummaryItem[];
@@ -211,11 +206,6 @@
     cageCount: incoming.cages.length,
     careLogCount: incoming.careLogs.length,
     showCount: incoming.shows.length,
-    feedBatchCount: (incoming.feedBatches ?? []).length,
-    feedAllocationCount: (incoming.feedAllocations ?? []).length,
-    ledgerEntryCount: (incoming.ledgerEntries ?? []).length,
-    processingLogCount: (incoming.processingLogs ?? []).length,
-    youthProjectBookCount: (incoming.youthProjectBooks ?? []).length,
     photoCount: photos.length,
     photoBytes,
     speciesBreakdown,
@@ -299,11 +289,6 @@
     cageCount: 0,
     careLogCount: 0,
     showCount: 0,
-    feedBatchCount: 0,
-    feedAllocationCount: 0,
-    ledgerEntryCount: 0,
-    processingLogCount: 0,
-    youthProjectBookCount: 0,
     photoCount: photos.length,
     photoBytes,
     speciesBreakdown: Array.from(speciesMap.values()).sort(
```

### `src/core/backupArchive.ts` (`+24` / `-0`, source: `part-08.md`)

```diff
--- working/src/core/backupArchive.ts
+++ import/src/core/backupArchive.ts
@@ -429,6 +429,18 @@
         youthProjectBooks: (snapshot.youthProjectBooks ?? []).filter((y) =>
           isSameSpecies(y.species, filterSpecies)
         ),
+        clientContacts: (snapshot.clientContacts ?? []).filter((c) =>
+          isSameSpecies(c.species, filterSpecies)
+        ),
+        waitlistEntries: (snapshot.waitlistEntries ?? []).filter((w) =>
+          isSameSpecies(w.species, filterSpecies)
+        ),
+        animalReservations: (snapshot.animalReservations ?? []).filter((r) =>
+          isSameSpecies(r.species, filterSpecies)
+        ),
+        woolHarvests: (snapshot.woolHarvests ?? []).filter((w) =>
+          isSameSpecies(w.species, filterSpecies)
+        ),
       }
     : {
         ...snapshot,
@@ -914,6 +926,18 @@
           ),
           youthProjectBooks: (snapshot.youthProjectBooks ?? []).filter((y) =>
             isSameSpecies(y.species, filterSpecies)
+          ),
+          clientContacts: (snapshot.clientContacts ?? []).filter((c) =>
+            isSameSpecies(c.species, filterSpecies)
+          ),
+          waitlistEntries: (snapshot.waitlistEntries ?? []).filter((w) =>
+            isSameSpecies(w.species, filterSpecies)
+          ),
+          animalReservations: (snapshot.animalReservations ?? []).filter((r) =>
+            isSameSpecies(r.species, filterSpecies)
+          ),
+          woolHarvests: (snapshot.woolHarvests ?? []).filter((w) =>
+            isSameSpecies(w.species, filterSpecies)
           ),
         }
       : {
```

### `src/core/backupStatus.ts` (`+12` / `-0`, source: `part-08.md`)

```diff
--- working/src/core/backupStatus.ts
+++ import/src/core/backupStatus.ts
@@ -103,6 +103,10 @@
   checkItems(snapshot.ledgerEntries);
   checkItems(snapshot.processingLogs);
   checkItems(snapshot.youthProjectBooks);
+  checkItems(snapshot.clientContacts);
+  checkItems(snapshot.waitlistEntries);
+  checkItems(snapshot.animalReservations);
+  checkItems(snapshot.woolHarvests);
   return latest;
 }
 
@@ -123,6 +127,10 @@
   const hasRealLedgerEntries = (snapshot.ledgerEntries ?? []).some((e) => !isSampleTestingId(e.id));
   const hasRealProcessingLogs = (snapshot.processingLogs ?? []).some((p) => !isSampleTestingId(p.id));
   const hasRealYouthBooks = (snapshot.youthProjectBooks ?? []).some((y) => !isSampleTestingId(y.id));
+  const hasRealClients = (snapshot.clientContacts ?? []).some((c) => !isSampleTestingId(c.id));
+  const hasRealWaitlist = (snapshot.waitlistEntries ?? []).some((w) => !isSampleTestingId(w.id));
+  const hasRealReservations = (snapshot.animalReservations ?? []).some((r) => !isSampleTestingId(r.id));
+  const hasRealWoolHarvests = (snapshot.woolHarvests ?? []).some((w) => !isSampleTestingId(w.id));
   const hasCustomSpecies = snapshot.speciesProfiles.some(
     (sp) => !PREDEFINED_SPECIES_LOWER.has(sp.name.trim().toLowerCase())
   );
@@ -143,6 +151,10 @@
     hasRealLedgerEntries ||
     hasRealProcessingLogs ||
     hasRealYouthBooks ||
+    hasRealClients ||
+    hasRealWaitlist ||
+    hasRealReservations ||
+    hasRealWoolHarvests ||
     hasCustomSpecies ||
     hasSpeciesMemo
   );
```

### `src/core/backupVault.ts` (`+12` / `-0`, source: `part-08.md`)

```diff
--- working/src/core/backupVault.ts
+++ import/src/core/backupVault.ts
@@ -331,6 +331,10 @@
     ledgerEntries: [],
     processingLogs: [],
     youthProjectBooks: [],
+    clientContacts: [],
+    waitlistEntries: [],
+    animalReservations: [],
+    woolHarvests: [],
   };
 }
 
@@ -1097,6 +1101,10 @@
       ledgerEntries: [],
       processingLogs: [],
       youthProjectBooks: [],
+      clientContacts: [],
+      waitlistEntries: [],
+      animalReservations: [],
+      woolHarvests: [],
     }),
     fallback
   );
@@ -1206,6 +1214,10 @@
       ledgerEntries: [],
       processingLogs: [],
       youthProjectBooks: [],
+      clientContacts: [],
+      waitlistEntries: [],
+      animalReservations: [],
+      woolHarvests: [],
     }),
     fallbackSettings
   );
```

### `src/core/dataHealthCheck.ts` (`+77` / `-0`, source: `part-09.md`)

```diff
--- working/src/core/dataHealthCheck.ts
+++ import/src/core/dataHealthCheck.ts
@@ -21,8 +21,10 @@
 import {
   Animal,
   AnimalPhoto,
+  AnimalReservation,
   BarnDatabaseSnapshot,
   BarnSettings,
+  ClientContact,
   FeedAllocation,
   FeedBatch,
   isSameSpecies,
@@ -32,6 +34,7 @@
   ProcessingLog,
   resolveSpeciesProfile,
   SpeciesProfile,
+  WaitlistEntry,
   YouthProjectBook,
 } from './models';
 import { buildSpeciesHerdMap, wouldCreateCycle } from './pedigreeCalculator';
@@ -127,6 +130,18 @@
   }
   for (const yp of Array.isArray(snapshot.youthProjectBooks) ? snapshot.youthProjectBooks : []) {
     if (isPlainObject(yp)) add(yp.species);
+  }
+  for (const cc of Array.isArray(snapshot.clientContacts) ? snapshot.clientContacts : []) {
+    if (isPlainObject(cc)) add(cc.species);
+  }
+  for (const wl of Array.isArray(snapshot.waitlistEntries) ? snapshot.waitlistEntries : []) {
+    if (isPlainObject(wl)) add(wl.species);
+  }
+  for (const ar of Array.isArray(snapshot.animalReservations) ? snapshot.animalReservations : []) {
+    if (isPlainObject(ar)) add(ar.species);
+  }
+  for (const wh of Array.isArray(snapshot.woolHarvests) ? snapshot.woolHarvests : []) {
+    if (isPlainObject(wh)) add(wh.species);
   }
 
   return Array.from(seen.values());
@@ -723,6 +738,64 @@
       feedLogs: normalizeYouthProjectFeedLogs(yp.feedLogs),
     }));
 
+  const workingClientContacts: ClientContact[] = (Array.isArray(snapshot.clientContacts) ? snapshot.clientContacts : [])
+    .filter((cc): cc is ClientContact => isPlainObject(cc) && typeof cc.id === 'string' && cc.id.trim().length > 0)
+    .map((cc) => ({
+      ...cc,
+      tags: Array.isArray(cc.tags) ? cc.tags.filter((t): t is string => typeof t === 'string') : [],
+    }));
+
+  const workingWaitlistEntries: WaitlistEntry[] = (Array.isArray(snapshot.waitlistEntries) ? snapshot.waitlistEntries : [])
+    .filter((wl): wl is WaitlistEntry => isPlainObject(wl) && typeof wl.id === 'string' && wl.id.trim().length > 0)
+    .map((wl) => {
+      const rank = Number(wl.priorityRank);
+      if (!Number.isFinite(rank) || rank < 1) {
+        repairsApplied.push(`Normalized waitlist priority rank for "${wl.clientName || wl.id}" to 1.`);
+        return { ...wl, priorityRank: 1, updatedAt: ts };
+      }
+      return { ...wl };
+    });
+
+  const workingReservations: AnimalReservation[] = (Array.isArray(snapshot.animalReservations) ? snapshot.animalReservations : [])
+    .filter((ar): ar is AnimalReservation => isPlainObject(ar) && typeof ar.id === 'string' && ar.id.trim().length > 0)
+    .map((ar) => {
+      const next = { ...ar };
+      let changed = false;
+      for (const key of ['totalPriceCents', 'depositRequiredCents', 'depositPaidCents'] as const) {
+        const val = Number(next[key]);
+        if (!Number.isFinite(val) || val < 0) {
+          next[key] = 0;
+          changed = true;
+        }
+      }
+      if (changed) {
+        next.updatedAt = ts;
+        repairsApplied.push(`Reset negative/invalid price or deposit field on reservation "${next.agreementNumber || next.id}".`);
+      }
+      return next;
+    });
+
+  const workingWoolHarvests = (Array.isArray(snapshot.woolHarvests) ? snapshot.woolHarvests : [])
+    .filter((wh) => isPlainObject(wh) && typeof wh.id === 'string' && wh.id.trim().length > 0)
+    .map((wh) => {
+      const next = { ...wh };
+      let changed = false;
+      for (const key of ['primeWeightGrams', 'gradeWeightGrams', 'shearingIntervalDays', 'stapleLengthMm'] as const) {
+        if (next[key] !== undefined) {
+          const val = Number(next[key]);
+          if (!Number.isFinite(val) || val < 0) {
+            next[key] = 0;
+            changed = true;
+          }
+        }
+      }
+      if (changed) {
+        next.updatedAt = ts;
+        repairsApplied.push(`Reset negative/invalid fiber measurement on wool harvest "${next.id}".`);
+      }
+      return next;
+    });
+
   const nextSnapshot: BarnDatabaseSnapshot = {
     ...snapshot,
     settings: nextSettings,
@@ -734,6 +807,10 @@
     ledgerEntries: workingLedgerEntries,
     processingLogs: workingProcessingLogs,
     youthProjectBooks: workingYouthBooks,
+    clientContacts: workingClientContacts,
+    waitlistEntries: workingWaitlistEntries,
+    animalReservations: workingReservations,
+    woolHarvests: workingWoolHarvests,
   };
 
   const reportAfter = analyzeBarnDataHealth(nextSnapshot);
```

### `src/core/exporters/exporterTypes.ts` (`+0` / `-1`, source: `part-13.md`)

```diff
--- working/src/core/exporters/exporterTypes.ts
+++ import/src/core/exporters/exporterTypes.ts
@@ -46,7 +46,6 @@
   filename: string;
   mimeType: string;
   content: string;
-  binaryContent?: Uint8Array;
   recordCount: number;
   summary: string;
   warnings: string[];
```

### `src/core/exporters/registry.ts` (`+16` / `-407`, source: `part-13.md`)

```diff
--- working/src/core/exporters/registry.ts
+++ import/src/core/exporters/registry.ts
@@ -13,38 +13,19 @@
  * 100% pure TypeScript with zero browser DOM (`window`, `document`, `File`, `Blob`) dependencies.
  */
 
-import { strToU8, zipSync } from 'fflate';
 import {
   buildBarnBinderFileName,
   buildDefaultBarnBinderOptions,
   generateSpeciesBarnBinderHtml,
 } from '../barnBinder';
 import { buildIcsCalendarForTasks } from '../calendarExport';
+import { buildCleanCsvExportFileName, exportAnimalsCsv } from '../csvExport';
 import {
-  analyzeAnimalCarrierLineage,
-  formatClearedProofBadge,
-  getAnimalCarrierDisclosures,
-} from '../carrierGenetics';
-import {
-  buildCleanCsvExportFileName,
-  escapeCsvCell,
-  exportAnimalsCsv,
-  UTF8_BOM,
-} from '../csvExport';
-import { formatGenotypeArray } from '../geneticsEngine';
-import {
-  Animal,
-  formatSexForSpecies,
-  formatWeight,
-  isAnimalArchived,
   isSameSpecies,
   normalizeDefaultPedigreeGenerations,
   normalizePedigreeGenerationDepth,
   nowIsoUtc,
-  resolveSpeciesProfile,
-  resolveSpeciesWeightUnit,
 } from '../models';
-import { buildSpeciesHerdMap } from '../pedigreeCalculator';
 import {
   buildShareablePedigreeCardFileName,
   generateShareablePedigreeCardHtml,
@@ -70,14 +51,6 @@
 
 function getLocalDateSlug(): string {
   return nowIsoUtc().slice(0, 10);
-}
-
-function buildCsvDocument(headers: readonly string[], rows: readonly (readonly unknown[])[]): string {
-  const lines = [headers.join(',')];
-  for (const row of rows) {
-    lines.push(row.map(escapeCsvCell).join(','));
-  }
-  return `${UTF8_BOM}${lines.join('\r\n')}`;
 }
 
 export const BUILTIN_NON_NATIVE_EXPORTERS: readonly ExternalExporterDescriptor[] = [
@@ -431,247 +404,23 @@
       };
     },
   },
+];
+
+export const PLANNED_EXTERNAL_SCHEMA_TARGETS: readonly ExternalExporterDescriptor[] = [
   {
     id: 'herdboss-transfer-bundle',
     name: 'HerdBoss Transfer Tables',
-    formatExtension: '.ZIP',
+    formatExtension: '.CSV / .ZIP',
     category: 'external_schema',
-    targetPlatform: 'HerdBoss / Relational Herd CSV Archive',
+    targetPlatform: 'HerdBoss Schema Target',
     scopeMode: 'all_or_species',
     supportsSpeciesFilter: true,
-    status: 'ready',
-    description:
-      'Relational 4-table .ZIP bundle (animals.csv, breedings.csv, weights.csv, pedigree_links.csv) using HerdBoss-compatible columns for multi-table portability.',
-    compatibilityNote:
-      'Sanitizes spreadsheet formulas and re-imports cleanly through Section 2 HerdBoss importer with multi-gen ancestor linking.',
+    status: 'planned',
+    description:
+      'Relational CSV bundle mapping animals, breedings, litters, and weight logs back into HerdBoss column conventions.',
+    compatibilityNote:
+      'Extensible schema slot reserved; HerdBoss multi-ZIP/CSV import is already active in Section 2.',
     schemaFields: ['animals.csv', 'breedings.csv', 'weights.csv', 'pedigree_links.csv'],
-    exportPayload(context: ExporterExecutionContext): ExportedArtifactPayload {
-      const { snapshot, speciesName } = context;
-      const scopedSpecies = speciesName?.trim() || undefined;
-
-      const animalById = new Map<string, Animal>();
-      for (const a of snapshot.animals) {
-        if (a.id) animalById.set(a.id, a);
-      }
-
-      const scopedAnimals = (
-        scopedSpecies
-          ? snapshot.animals.filter((a) => isSameSpecies(a.species, scopedSpecies))
-          : snapshot.animals
-      )
-        .slice()
-        .sort((a, b) => a.species.localeCompare(b.species) || a.name.localeCompare(b.name));
-
-      const animalHeaders = [
-        'Animal_ID',
-        'Species',
-        'Primary_Tag',
-        'Tattoo',
-        'Name',
-        'Breed',
-        'Variety',
-        'Sex',
-        'Birth_Date',
-        'Status',
-        'Sire_ID',
-        'Sire',
-        'Dam_ID',
-        'Dam',
-        'Weight',
-        'Weight_Unit',
-        'Genotype',
-        'Rufus_Level',
-        'Registration_Number',
-        'Grand_Champion_Number',
-        'Legs_Count',
-        'Group_Location',
-        'Breeder_Name',
-        'Owner_Name',
-        'Sold_Date',
-        'Death_Date',
-        'Notes',
-      ];
-      const animalRows = scopedAnimals.map((a) => {
-        const sire = a.sireId ? animalById.get(a.sireId) : undefined;
-        const dam = a.damId ? animalById.get(a.damId) : undefined;
-        return [
-          a.id,
-          a.species,
-          a.tattoo || a.id,
-          a.tattoo,
-          a.name,
-          a.breed,
-          a.variety,
-          a.sex,
-          a.birthDateIso,
-          a.status,
-          sire?.id || a.sireId || '',
-          sire?.name || '',
-          dam?.id || a.damId || '',
-          dam?.name || '',
-          a.weightGrams > 0 ? String(a.weightGrams) : '',
-          a.weightGrams > 0 ? 'g' : '',
-          a.genotypeRaw || formatGenotypeArray(a.genotype),
-          a.rufusLevel || '',
-          a.registrationNumber,
-          a.grandChampionNumber,
-          a.legsCount,
-          a.cageLocation,
-          a.breederName,
-          a.ownerName,
-          a.soldDateIso || '',
-          a.deceasedDateIso || '',
-          a.notes,
-        ];
-      });
-      const animalsCsv = buildCsvDocument(animalHeaders, animalRows);
-
-      const scopedBreedings = snapshot.breedings.filter(
-        (b) => !scopedSpecies || isSameSpecies(b.species, scopedSpecies)
-      );
-      const breedingHeaders = [
-        'Breeding_ID',
-        'Species',
-        'Sire_ID',
-        'Sire',
-        'Dam_ID',
-        'Dam',
-        'Bred_Date',
-        'Expected_Due_Date',
-        'Actual_Birth_Date',
-        'Status',
-        'Live_Count',
-        'Stillborn_Count',
-        'Weaned_Count',
-        'Notes',
-      ];
-      const breedingRows = scopedBreedings.map((b) => {
-        const sire = b.sireId ? animalById.get(b.sireId) : undefined;
-        const dam = b.damId ? animalById.get(b.damId) : undefined;
-        return [
-          b.id,
-          b.species,
-          b.sireId,
-          sire?.name || b.sireName,
-          b.damId,
-          dam?.name || b.damName,
-          b.bredDateIso,
-          b.expectedDueDateIso,
-          b.actualBirthDateIso,
-          b.status,
-          b.liveCount,
-          b.stillbornCount,
-          b.weanedCount,
-          b.notes,
-        ];
-      });
-      const breedingsCsv = buildCsvDocument(breedingHeaders, breedingRows);
-
-      const weightLogs = snapshot.careLogs.filter(
-        (l) =>
-          (l.type === 'Weight Check' || l.weightGrams > 0) &&
-          (!scopedSpecies || isSameSpecies(l.species, scopedSpecies))
-      );
-      const weightHeaders = [
-        'Species',
-        'Animal_ID',
-        'Primary_Tag',
-        'Name',
-        'Weigh_Date',
-        'Weight',
-        'Weight_Unit',
-        'Stage',
-        'Notes',
-      ];
-      const weightRows = weightLogs.map((l) => {
-        const animal = animalById.get(l.animalId);
-        return [
-          l.species,
-          l.animalId,
-          animal?.tattoo || l.animalId,
-          animal?.name || '',
-          l.dateIso,
-          l.weightGrams > 0 ? String(l.weightGrams) : '',
-          l.weightGrams > 0 ? 'g' : '',
-          l.title || 'Weight Check',
-          l.notes,
-        ];
-      });
-      const weightsCsv = buildCsvDocument(weightHeaders, weightRows);
-
-      const pedigreeHeaders = [
-        'Species',
-        'Animal_ID',
-        'Primary_Tag',
-        'Name',
-        'Sire_ID',
-        'Sire_Tag',
-        'Sire_Name',
-        'Dam_ID',
-        'Dam_Tag',
-        'Dam_Name',
-        'Paternal_Grandsire',
-        'Paternal_Granddam',
-        'Maternal_Grandsire',
-        'Maternal_Granddam',
-      ];
-      const pedigreeRows = scopedAnimals
-        .filter((a) => Boolean(a.sireId || a.damId))
-        .map((a) => {
-          const sire = a.sireId ? animalById.get(a.sireId) : undefined;
-          const dam = a.damId ? animalById.get(a.damId) : undefined;
-          const pgs = sire?.sireId ? animalById.get(sire.sireId) : undefined;
-          const pgd = sire?.damId ? animalById.get(sire.damId) : undefined;
-          const mgs = dam?.sireId ? animalById.get(dam.sireId) : undefined;
-          const mgd = dam?.damId ? animalById.get(dam.damId) : undefined;
-          return [
-            a.species,
-            a.id,
-            a.tattoo || a.id,
-            a.name,
-            sire?.id || a.sireId || '',
-            sire?.tattoo || '',
-            sire?.name || '',
-            dam?.id || a.damId || '',
-            dam?.tattoo || '',
-            dam?.name || '',
-            pgs?.name || pgs?.tattoo || '',
-            pgd?.name || pgd?.tattoo || '',
-            mgs?.name || mgs?.tattoo || '',
-            mgd?.name || mgd?.tattoo || '',
-          ];
-        });
-      const pedigreeLinksCsv = buildCsvDocument(pedigreeHeaders, pedigreeRows);
-
-      const zipBytes = zipSync(
-        {
-          'animals.csv': strToU8(animalsCsv),
-          'breedings.csv': strToU8(breedingsCsv),
-          'weights.csv': strToU8(weightsCsv),
-          'pedigree_links.csv': strToU8(pedigreeLinksCsv),
-        },
-        { level: 6 }
-      );
-
-      const barnSlug = sanitizeFileSlug(snapshot.settings.barnName, 'pedigree');
-      const scopeSlug = scopedSpecies ? `-${sanitizeFileSlug(scopedSpecies, 'species')}` : '';
-      const filename = `${barnSlug}${scopeSlug}-herdboss-transfer-${getLocalDateSlug()}.zip`;
-      const totalRecords = scopedAnimals.length + scopedBreedings.length + weightLogs.length;
-
-      return {
-        exporterId: 'herdboss-transfer-bundle',
-        filename,
-        mimeType: 'application/zip',
-        content: '',
-        binaryContent: zipBytes,
-        recordCount: totalRecords,
-        summary: `Exported HerdBoss 4-table .ZIP bundle (${filename}): ${scopedAnimals.length} animals, ${scopedBreedings.length} breedings, ${weightLogs.length} weight logs, and ${pedigreeRows.length} pedigree link rows.`,
-        warnings:
-          scopedAnimals.length === 0
-            ? ['Archive built cleanly with headers only because zero animals matched the active scope.']
-            : [],
-      };
-    },
   },
   {
     id: 'registry-worksheet-csv',
@@ -681,154 +430,14 @@
     targetPlatform: 'ARBA / ADGA / Custom Registry Forms',
     scopeMode: 'species_required',
     supportsSpeciesFilter: true,
-    status: 'ready',
-    description:
-      'Targeted per-species worksheet columns tailored for registration applications, show entry secretaries, and 3-generation ancestor transfers.',
-    compatibilityNote:
-      'Exports RFC-4180 UTF-8 BOM CSV scoped to one livestock species with ear tattoo, Reg #, GC #, Legs, 3-gen ancestor Reg #s, and breeder contact.',
+    status: 'planned',
+    description:
+      'Targeted per-species worksheet columns tailored for registration applications, show entry secretaries, and external pedigree transfers.',
+    compatibilityNote:
+      'Use Herd Roster Spreadsheet (.CSV) or Printable Barn Binder (.HTM) today for full registration details.',
     schemaFields: ['Reg #', 'Ear Tattoo', '3-Gen Ancestor Reg #s', 'Legs / GC', 'Breeder Contact'],
-    exportPayload(context: ExporterExecutionContext): ExportedArtifactPayload {
-      const { snapshot, speciesName } = context;
-      const targetSpecies =
-        speciesName?.trim() ||
-        snapshot.settings.defaultSpecies ||
-        snapshot.speciesProfiles[0]?.name ||
-        'Rabbit';
-
-      const sp = resolveSpeciesProfile(targetSpecies, snapshot.speciesProfiles);
-      const unit = resolveSpeciesWeightUnit(sp, snapshot.settings);
-      const herdMap = buildSpeciesHerdMap(snapshot.animals, targetSpecies);
-
-      const animalById = new Map<string, Animal>();
-      for (const a of snapshot.animals) {
-        if (a.id) animalById.set(a.id, a);
-      }
-
-      const scopedAnimals = snapshot.animals
-        .filter((a) => isSameSpecies(a.species, targetSpecies))
-        .slice()
-        .sort((a, b) => {
-          const archDiff = (isAnimalArchived(a) ? 1 : 0) - (isAnimalArchived(b) ? 1 : 0);
-          if (archDiff !== 0) return archDiff;
-          return a.name.localeCompare(b.name) || a.tattoo.localeCompare(b.tattoo);
-        });
-
-      const formatAncestorSummary = (anc: Animal | undefined): string => {
-        if (!anc) return '';
-        const parts: string[] = [];
-        if (anc.name) parts.push(anc.name);
-        if (anc.tattoo) parts.push(`Ear: ${anc.tattoo}`);
-        if (anc.registrationNumber) parts.push(`Reg: ${anc.registrationNumber}`);
-        return parts.join(' | ');
-      };
-
-      const headers = [
-        'Species',
-        'Ear_Tattoo',
-        'Name',
-        'Breed',
-        'Variety',
-        'Sex',
-        'Birth_Date',
-        'Weight',
-        'Registration_No',
-        'Grand_Champion_No',
-        'Legs_Earned',
-        'Sire_Name',
-        'Sire_Tattoo',
-        'Sire_Reg_No',
-        'Dam_Name',
-        'Dam_Tattoo',
-        'Dam_Reg_No',
-        'Gen3_Pat_Grandsire',
-        'Gen3_Pat_Granddam',
-        'Gen3_Mat_Grandsire',
-        'Gen3_Mat_Granddam',
-        'Genotype',
-        'Carrier_Disclosures',
-        'Breeder_Contact',
-        'Owner_Name',
-        'Status',
-      ];
-
-      const rows = scopedAnimals.map((a) => {
-        const sire = a.sireId ? animalById.get(a.sireId) : undefined;
-        const dam = a.damId ? animalById.get(a.damId) : undefined;
-        const pgs = sire?.sireId ? animalById.get(sire.sireId) : undefined;
-        const pgd = sire?.damId ? animalById.get(sire.damId) : undefined;
-        const mgs = dam?.sireId ? animalById.get(dam.sireId) : undefined;
-        const mgd = dam?.damId ? animalById.get(dam.damId) : undefined;
-
-        const carriers = getAnimalCarrierDisclosures(a);
-        const lineage = analyzeAnimalCarrierLineage(a, herdMap);
-        const carrierNotes = [
-          ...carriers.confirmed.map((t) => `Confirmed: ${t}`),
-          ...carriers.suspected.map((t) => `Suspected: ${t}`),
-          ...carriers.cleared.map((c) => `Cleared: ${c.trait} (${formatClearedProofBadge(c)})`),
-          ...lineage.lineagePotential.map(
-            (l) => `Lineage Potential: ${l.trait} (${l.viaBranches.join('/')})`
-          ),
-        ].join('; ');
-
-        const breederContact = [
-          a.breederName || snapshot.settings.breederName || '',
-          snapshot.settings.barnName || '',
-        ]
-          .filter(Boolean)
-          .join(' — ');
-
-        return [
-          a.species,
-          a.tattoo,
-          a.name,
-          a.breed,
-          a.variety,
-          formatSexForSpecies(a.sex, sp),
-          a.birthDateIso,
-          formatWeight(a.weightGrams, unit),
-          a.registrationNumber,
-          a.grandChampionNumber,
-          a.legsCount,
-          sire?.name || '',
-          sire?.tattoo || '',
-          sire?.registrationNumber || '',
-          dam?.name || '',
-          dam?.tattoo || '',
-          dam?.registrationNumber || '',
-          formatAncestorSummary(pgs),
-          formatAncestorSummary(pgd),
-          formatAncestorSummary(mgs),
-          formatAncestorSummary(mgd),
-          a.genotypeRaw || formatGenotypeArray(a.genotype),
-          carrierNotes,
-          breederContact,
-          a.ownerName,
-          a.status,
-        ];
-      });
-
-      const content = buildCsvDocument(headers, rows);
-      const barnSlug = sanitizeFileSlug(snapshot.settings.barnName, 'pedigree');
-      const spSlug = sanitizeFileSlug(targetSpecies, 'species');
-      const filename = `${barnSlug}-${spSlug}-registry-worksheet-${getLocalDateSlug()}.csv`;
-
-      return {
-        exporterId: 'registry-worksheet-csv',
-        filename,
-        mimeType: 'text/csv;charset=utf-8',
-        content,
-        recordCount: scopedAnimals.length,
-        summary: `Exported ${scopedAnimals.length} ${targetSpecies} registration/show worksheet row(s) to ${filename}.`,
-        warnings:
-          scopedAnimals.length === 0
-            ? [`Zero ${targetSpecies} records found — exported header template only.`]
-            : [],
-      };
-    },
   },
 ];
-
-export const PLANNED_EXTERNAL_SCHEMA_TARGETS: readonly ExternalExporterDescriptor[] = [];
 
 export function buildExporterCatalog(
   additionalExporters: readonly ExternalExporterDescriptor[] = []
```

### `src/core/imageOptimizationSpec.ts` (`+80` / `-13`, source: `part-09.md`)

```diff
--- working/src/core/imageOptimizationSpec.ts
+++ import/src/core/imageOptimizationSpec.ts
@@ -70,6 +70,65 @@
 
 export const DEFAULT_IMAGE_OPTIMIZATION_PRESET: ImageOptimizationPresetId = 'balanced';
 
+/** Hard single-canvas backing store area ceiling (16M px) to avoid WebKit/mobile OOM crashes. */
+export const MAX_CANVAS_AREA_PX = 16_000_000;
+/** Tighter single-canvas area ceiling (3M px) for Low-Memory / constrained tier devices. */
+export const MAX_CONSTRAINED_CANVAS_AREA_PX = 3_000_000;
+
+export function getCanvasAreaCeiling(isConstrained: boolean): number {
+  return isConstrained ? MAX_CONSTRAINED_CANVAS_AREA_PX : MAX_CANVAS_AREA_PX;
+}
+
+/**
+ * Proportionally clamps canvas dimensions so `width * height <= maxAreaPx` (never returning < 1px).
+ */
+export function clampCanvasDimensionsToAreaCeiling(
+  width: number,
+  height: number,
+  maxAreaPx: number = MAX_CANVAS_AREA_PX
+): { width: number; height: number; wasClamped: boolean } {
+  const safeW = Number.isFinite(width) ? Math.max(1, Math.round(width)) : 1;
+  const safeH = Number.isFinite(height) ? Math.max(1, Math.round(height)) : 1;
+  const ceiling = Number.isFinite(maxAreaPx)
+    ? Math.max(1, Math.floor(maxAreaPx))
+    : MAX_CANVAS_AREA_PX;
+
+  if (safeW * safeH <= ceiling) {
+    return { width: safeW, height: safeH, wasClamped: false };
+  }
+
+  const scale = Math.sqrt(ceiling / (safeW * safeH));
+  let outW = Math.max(1, Math.floor(safeW * scale));
+  let outH = Math.max(1, Math.floor(safeH * scale));
+  while (outW * outH > ceiling && (outW > 1 || outH > 1)) {
+    if (outW >= outH && outW > 1) {
+      outW -= 1;
+    } else if (outH > 1) {
+      outH -= 1;
+    } else {
+      break;
+    }
+  }
+  return { width: outW, height: outH, wasClamped: true };
+}
+
+/**
+ * Caps canvas backing-store DPR at `Math.min(2, dpr || 1)`, or `1` in Low-Memory / constrained mode.
+ */
+export function capCanvasDevicePixelRatio(
+  rawDevicePixelRatio: number | null | undefined,
+  isConstrained: boolean
+): number {
+  if (isConstrained) return 1;
+  const dpr =
+    typeof rawDevicePixelRatio === 'number' &&
+    Number.isFinite(rawDevicePixelRatio) &&
+    rawDevicePixelRatio > 0
+      ? rawDevicePixelRatio
+      : 1;
+  return Math.min(2, dpr);
+}
+
 export function resolveImageOptimizationPreset(
   presetId?: string | null
 ): ImageOptimizationPreset {
@@ -80,27 +139,35 @@
 }
 
 /**
- * Computes proportional output dimensions capped to `maxDimension` on the longest edge.
- * Never upscales images that are already smaller than `maxDimension`.
+ * Computes proportional output dimensions capped to `maxDimension` on the longest edge
+ * and clamped to `maxAreaPx` total canvas pixels. Never upscales images that are smaller.
  */
 export function computeScaledDimensions(
   sourceWidth: number,
   sourceHeight: number,
-  maxDimension: number
+  maxDimension: number,
+  maxAreaPx: number = MAX_CANVAS_AREA_PX
 ): { width: number; height: number; wasResized: boolean } {
-  const safeW = Math.max(1, Math.round(sourceWidth));
-  const safeH = Math.max(1, Math.round(sourceHeight));
+  const safeW = Number.isFinite(sourceWidth) ? Math.max(1, Math.round(sourceWidth)) : 1;
+  const safeH = Number.isFinite(sourceHeight) ? Math.max(1, Math.round(sourceHeight)) : 1;
   const longest = Math.max(safeW, safeH);
 
-  if (longest <= maxDimension) {
-    return { width: safeW, height: safeH, wasResized: false };
-  }
-
-  const scale = maxDimension / longest;
+  let targetW = safeW;
+  let targetH = safeH;
+  let wasResized = false;
+
+  if (longest > maxDimension) {
+    const scale = maxDimension / longest;
+    targetW = Math.max(1, Math.round(safeW * scale));
+    targetH = Math.max(1, Math.round(safeH * scale));
+    wasResized = true;
+  }
+
+  const clamped = clampCanvasDimensionsToAreaCeiling(targetW, targetH, maxAreaPx);
   return {
-    width: Math.max(1, Math.round(safeW * scale)),
-    height: Math.max(1, Math.round(safeH * scale)),
-    wasResized: true,
+    width: clamped.width,
+    height: clamped.height,
+    wasResized: wasResized || clamped.wasClamped,
   };
 }
 
```

### `src/core/improvementRegistry.ts` (`+211` / `-71`, source: `part-10.md`)

```diff
--- working/src/core/improvementRegistry.ts
+++ import/src/core/improvementRegistry.ts
@@ -3183,78 +3183,218 @@
   },
   {
     id: 'IMP-047',
-    title: 'Post-Crash Alignment, Ready External Exporters, Feed/Archive Parity & Android WebView Print/Share',
-    category: 'stability-pwa',
-    source: 'session',
-    summary:
-      'Enforces the React PWA preservation rule in `AGENTS.md` and `prompts/master_system_prompt.md`; aligns PWA/Android versions to `0.1.0-alpha.2`; migrates `feedBatches` and `feedAllocations` during cross-species moves; surfaces v3/v4 feed, ledger, processing, and 4-H/FFA counts in `archiveInspector.ts`; implements `herdboss-transfer-bundle` (.ZIP) and `registry-worksheet-csv` (.CSV) as ready exporters; and fixes `@media print` extraction, accent-ink preservation, native wrapper Share .HTM enablement, and Android `PrintBridge.kt` offscreen HTML + landscape/portrait printing while removing the stale `PedigreePrintNotice` banner.',
-    userIntent:
-      'Realign the entire codebase after build-crash drift, keep the PWA locked to React + Vite + TypeScript, complete half-done exporters and migration/inspector coverage, and make pedigree/binder print & share work seamlessly on desktop, mobile web, and the Android WebView APK.',
-    files: [
-      'AGENTS.md',
-      '.env.example',
-      'package.json',
-      'public/version.json',
-      'src/core/upgradeGate.ts',
-      'src/core/speciesMigration.ts',
-      'src/core/archiveInspector.ts',
-      'src/core/exporters/exporterTypes.ts',
-      'src/core/exporters/registry.ts',
-      'src/native/pedigreeBridge.ts',
+    title: 'Client CRM, Buyer Waitlist, Reservations & Deposit Reminders',
+    category: 'species-ux',
+    source: 'session',
+    summary:
+      'Adds species-isolated local-first breeder CRM tracking buyer contacts (`ClientContact`), ranked waitlist inquiries (`WaitlistEntry`) with live unreserved animal/pairing match scoring (`findWaitlistMatches`), animal/litter-pick reservations (`AnimalReservation`) with sequential agreement numbering and deposit/balance progress (`evaluateReservationFinancials`), automated overdue/due/upcoming follow-up reminders (`evaluateCrmFollowUpReminders`) with 1-click Master Task creation, XSS-safe printable Sales Agreements with optional breeder logo and active withdrawal disclosures (`generateSalesAgreementHtml`), SQLite v5 persistence, sync outbox deltas, 2 CRM report presets, and `ClientCrmScreen.tsx` accessible from Species Dashboard & `C` shortcut.',
+    userIntent:
+      'Track buyer contacts, waitlist queues, animal/litter reservations, deposit due reminders, and printable sales agreements offline without cloud dependencies.',
+    files: [
+      'src/core/models.ts',
+      'src/core/clientCrm.ts',
+      'src/core/__tests__/clientCrm.test.ts',
+      'src/core/reportCatalog.ts',
+      'src/core/reportGenerators.ts',
+      'src/core/syncOutbox.ts',
+      'src/storage/webSqliteAdapter.ts',
+      'src/hooks/useBarnStore.ts',
+      'src/components/ClientCrmScreen.tsx',
+      'src/components/SpeciesDashboardScreen.tsx',
+      'src/App.tsx',
+    ],
+    invariants: [
+      {
+        filePath: 'src/core/models.ts',
+        requiredSubstrings: [
+          'ClientContact',
+          'WaitlistEntry',
+          'AnimalReservation',
+          'RESERVATION_STATUSES',
+          'WAITLIST_STATUSES',
+        ],
+        rationale:
+          'ClientContact, WaitlistEntry, and AnimalReservation domain models and normalizers must remain intact.',
+      },
+      {
+        filePath: 'src/core/clientCrm.ts',
+        requiredSubstrings: [
+          'evaluateReservationFinancials',
+          'evaluateCrmFollowUpReminders',
+          'findWaitlistMatches',
+          'generateSalesAgreementHtml',
+          'formatReservationsCsv',
+        ],
+        rationale:
+          'Pure TS CRM financial evaluation, automated follow-up reminders, waitlist matching, CSV export, and printable Sales Agreement generator must stay zero-DOM.',
+      },
+      {
+        filePath: 'src/storage/webSqliteAdapter.ts',
+        requiredSubstrings: [
+          'client_contacts',
+          'waitlist_entries',
+          'animal_reservations',
+          'saveClientContact',
+          'saveWaitlistEntry',
+          'saveAnimalReservation',
+        ],
+        rationale:
+          'SQLite schema v5 and adapter CRUD methods must store and hydrate CRM contacts, waitlist entries, and reservations.',
+      },
+      {
+        filePath: 'src/hooks/useBarnStore.ts',
+        requiredSubstrings: [
+          'saveClientContact',
+          'saveWaitlistEntry',
+          'saveAnimalReservation',
+          'completeReservationSale',
+          'createCrmReminderTask',
+        ],
+        rationale:
+          'Store must expose species-isolated CRM mutations, atomic sale completion, and reminder task creation with delta outbox sync.',
+      },
+      {
+        filePath: 'src/components/ClientCrmScreen.tsx',
+        requiredSubstrings: [
+          'ClientCrmScreen',
+          'generateSalesAgreementHtml',
+          'evaluateCrmFollowUpReminders',
+          'findWaitlistMatches',
+        ],
+        rationale:
+          'ClientCrmScreen must render reminders, reservation/deposit tracking, ranked waitlist matching, client directory, and printable sales agreements.',
+      },
+      {
+        filePath: 'src/App.tsx',
+        requiredSubstrings: ['ClientCrmScreen', "route === 'crm'"],
+        rationale: 'Root router must lazy-load and mount ClientCrmScreen on route crm.',
+      },
+    ],
+    restorePlaybook: [
+      'Keep `ClientContact`, `WaitlistEntry`, and `AnimalReservation` interfaces and normalizers in `src/core/models.ts` plus SQLite v5 tables in `src/storage/webSqliteAdapter.ts`.',
+      'Restore `src/core/clientCrm.ts` and `src/core/__tests__/clientCrm.test.ts` along with the 2 CRM presets in `reportCatalog.ts` and `reportGenerators.ts`.',
+      'Keep CRM mutations in `src/hooks/useBarnStore.ts` and wire `ClientCrmScreen.tsx` into `SpeciesDashboardScreen.tsx` and `App.tsx`.',
+    ],
+  },
+  {
+    id: 'IMP-048',
+    title: 'Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking',
+    category: 'species-ux',
+    source: 'session',
+    summary:
+      'Adds privacy-scoped Pet-Sale Birth Certificates (omitting breeder contact info & pricing), official Breeding/Service Certificates, ARBA-style Show Entry Forms (`mailto:` + plain-text copy + Open/Youth/fees) & 4-up/1-up Show Remark Cards from ShowEvent rosters, Gen 0–2 multi-photo Family Portrait and IAGARB German Angora pedigree layouts, and SQLite v6 `wool_harvests` tracking with 7-position 100-pt IAGARB scoring and 90-day 325g shearing yield calculations.',
+    userIntent:
+      'Support alternative companion birth/breeding certificates, printable/emailable show documents directly from show rosters, family portrait & IAGARB Angora pedigree templates, and wool/fiber harvest logging.',
+    files: [
+      'src/core/models.ts',
+      'src/core/woolFiber.ts',
+      'src/core/alternativeCertificates.ts',
+      'src/core/showDocuments.ts',
+      'src/core/pedigreePrintStyles.ts',
+      'src/core/syncAndExports.ts',
+      'src/core/pdfExporter.ts',
+      'src/storage/webSqliteAdapter.ts',
+      'src/hooks/useBarnStore.ts',
       'src/components/PrintPreviewModal.tsx',
-      'src/components/ImportExportHubScreen.tsx',
-      'src/index.css',
-      'android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/MainActivity.kt',
-      'android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt',
-      '.github/structure.txt',
-    ],
-    invariants: [
-      {
-        filePath: 'AGENTS.md',
-        requiredSubstrings: ['Never Convert PWA Away From React'],
-        rationale: 'Workspace agent rules must lock the PWA against non-React rewrites.',
-      },
-      {
-        filePath: 'src/core/speciesMigration.ts',
-        requiredSubstrings: ['feedBatchesMigrated', 'feedAllocationsMigrated'],
-        rationale: 'Cross-species migrations must move linked feedBatches and feedAllocations.',
-      },
-      {
-        filePath: 'src/core/archiveInspector.ts',
-        requiredSubstrings: [
-          'feedBatchCount',
-          'feedAllocationCount',
-          'ledgerEntryCount',
-          'processingLogCount',
-          'youthProjectBookCount',
-        ],
-        rationale: 'Pre-restore dry-run inspection must count v3/v4 feed, ledger, processing, and youth records.',
-      },
-      {
-        filePath: 'src/core/exporters/registry.ts',
-        requiredSubstrings: ['herdboss-transfer-bundle', 'registry-worksheet-csv', 'binaryContent'],
-        rationale: 'HerdBoss Transfer Tables (.ZIP) and Breed Registry & Show Worksheets (.CSV) must stay active ready exporters.',
-      },
-      {
-        filePath: 'src/components/PrintPreviewModal.tsx',
-        requiredSubstrings: [
-          'canShareHtmlDocument',
-          'extractScopedPrintCssFromRules',
-          'detectDocumentPrintOrientation',
-        ],
-        rationale: 'PrintPreviewModal must enable Share .HTM on native wrappers, extract @media print rules, and forward orientation/HTML to native print.',
-      },
-      {
-        filePath: 'android-wrapper/app/src/main/java/org/askkim/pedigree/wrapper/PrintBridge.kt',
-        requiredSubstrings: ['printFromBridge', 'printHtmlDocument', 'buildPrintAttributes'],
-        rationale: 'Android PrintBridge must render self-contained HTML in a hardened offscreen WebView with landscape/portrait PrintAttributes.',
-      },
-    ],
-    restorePlaybook: [
-      'Verify `AGENTS.md` and `prompts/master_system_prompt.md` keep the React PWA lock rule intact.',
-      'Ensure `package.json`, `public/version.json`, and `src/core/upgradeGate.ts` match `android-wrapper/app/build.gradle.kts` (`0.1.0-alpha.2`).',
-      'Keep `herdboss-transfer-bundle` and `registry-worksheet-csv` in `src/core/exporters/registry.ts` with `binaryContent` download dispatch in `ImportExportHubScreen.tsx`.',
-      'Keep `@media print` extraction, native Share .HTM support, and Android `PrintBridge.kt` offscreen HTML rendering intact and do not reintroduce `PedigreePrintNotice`.',
+      'src/components/HerdScreen.tsx',
+      'src/components/PedigreeScreen.tsx',
+      'src/components/BreedingScreen.tsx',
+      'src/components/SpeciesDashboardScreen.tsx',
+      'src/App.tsx',
+      'src/core/__tests__/woolFiber.test.ts',
+      'src/core/__tests__/alternativeCertificates.test.ts',
+      'src/core/__tests__/showDocuments.test.ts',
+    ],
+    invariants: [
+      {
+        filePath: 'src/core/models.ts',
+        requiredSubstrings: [
+          'WoolHarvest',
+          'IagarbScorecard',
+          'WOOL_HARVEST_METHODS',
+          'normalizeWoolHarvestMethod',
+        ],
+        rationale: 'WoolHarvest and IagarbScorecard domain models and normalizers must remain intact.',
+      },
+      {
+        filePath: 'src/core/woolFiber.ts',
+        requiredSubstrings: [
+          'IAGARB_JUDGING_POSITIONS',
+          'computeIagarbScoreTotal',
+          'evaluateIagarbEligibility',
+          'compute90DayEquivalentGrams',
+          'summarizeAnimalWoolHarvests',
+        ],
+        rationale:
+          'Pure TS IAGARB 100-point rubric, 325g/90-day performance yield normalization, and harvest summary calculators must stay zero-DOM.',
+      },
+      {
+        filePath: 'src/core/alternativeCertificates.ts',
+        requiredSubstrings: [
+          'generatePetBirthCertificateHtml',
+          'generateBreedingCertificateHtml',
+          'buildPetBirthCertificateFileName',
+          'buildBreedingCertificateFileName',
+        ],
+        rationale:
+          'Pure TS Pet-Sale Birth Certificate (no breeder contact/pricing) and Breeding Certificate generators must remain zero-DOM and XSS-safe.',
+      },
+      {
+        filePath: 'src/core/showDocuments.ts',
+        requiredSubstrings: [
+          'generateShowEntryFormHtml',
+          'generateShowRemarkCardsHtml',
+          'buildShowEntryMailtoUrl',
+          'buildShowEntryPlainTextSummary',
+        ],
+        rationale:
+          'Pure TS ARBA Show Entry Form, emailable plain-text/mailto dispatchers, and 4-up/1-up Remark Card generators must remain zero-DOM.',
+      },
+      {
+        filePath: 'src/core/pedigreePrintStyles.ts',
+        requiredSubstrings: ['family_portrait', 'iagarb_angora'],
+        rationale: 'Family Portrait and IAGARB German Angora pedigree presets must stay registered.',
+      },
+      {
+        filePath: 'src/storage/webSqliteAdapter.ts',
+        requiredSubstrings: ['wool_harvests', 'saveWoolHarvest', 'deleteWoolHarvest'],
+        rationale: 'SQLite schema v6 must store and hydrate wool_harvests cleanly.',
+      },
+      {
+        filePath: 'src/hooks/useBarnStore.ts',
+        requiredSubstrings: ['saveWoolHarvest', 'deleteWoolHarvest'],
+        rationale: 'Store must expose species-isolated wool harvest mutations with delta outbox sync.',
+      },
+      {
+        filePath: 'src/components/HerdScreen.tsx',
+        requiredSubstrings: [
+          'generatePetBirthCertificateHtml',
+          'onSaveWoolHarvest',
+          'IAGARB_JUDGING_POSITIONS',
+        ],
+        rationale:
+          'HerdScreen must provide Pet-Sale Birth Certificate previews and Wool / Fiber + IAGARB scoring.',
+      },
+      {
+        filePath: 'src/components/BreedingScreen.tsx',
+        requiredSubstrings: ['generateBreedingCertificateHtml', 'Breeding Cert'],
+        rationale: 'BreedingScreen must expose Breeding Certificate preview controls.',
+      },
+      {
+        filePath: 'src/components/SpeciesDashboardScreen.tsx',
+        requiredSubstrings: [
+          'generateShowEntryFormHtml',
+          'generateShowRemarkCardsHtml',
+          'buildShowEntryMailtoUrl',
+        ],
+        rationale:
+          'SpeciesDashboardScreen must expose Show Entry Form and Remark Cards print/email previews directly from ShowEvents.',
+      },
+    ],
+    restorePlaybook: [
+      'Keep `WoolHarvest` and `IagarbScorecard` models in `src/core/models.ts` and `wool_harvests` SQLite v6 schema in `src/storage/webSqliteAdapter.ts`.',
+      'Restore pure modules `src/core/woolFiber.ts`, `src/core/alternativeCertificates.ts`, and `src/core/showDocuments.ts` with their unit tests.',
+      'Keep `family_portrait` & `iagarb_angora` rendering in `pedigreePrintStyles.ts`, `syncAndExports.ts`, and `pdfExporter.ts`, plus UI wiring in `HerdScreen.tsx`, `PedigreeScreen.tsx`, `BreedingScreen.tsx`, `SpeciesDashboardScreen.tsx`, and `App.tsx`.',
     ],
   },
 ];
```

### `src/core/inputSanitization.ts` (`+79` / `-0`, source: `part-10.md`)

```diff
--- working/src/core/inputSanitization.ts
+++ import/src/core/inputSanitization.ts
@@ -449,6 +449,10 @@
   'ledgerEntry',
   'processingLog',
   'youthProjectBook',
+  'clientContact',
+  'waitlistEntry',
+  'animalReservation',
+  'woolHarvest',
 ]);
 
 export const ALLOWED_SYNC_FIELDS_BY_ENTITY: Record<SyncEntityType, ReadonlySet<string>> = {
@@ -724,6 +728,81 @@
     'notes',
     '_rev',
   ]),
+  clientContact: new Set([
+    'species',
+    'fullName',
+    'ranchOrHerdName',
+    'email',
+    'phone',
+    'preferredContact',
+    'clientKind',
+    'cityState',
+    'shippingAddress',
+    'tags',
+    'notes',
+    '_rev',
+  ]),
+  waitlistEntry: new Set([
+    'species',
+    'clientId',
+    'clientName',
+    'priorityRank',
+    'status',
+    'intent',
+    'desiredBreed',
+    'desiredVariety',
+    'preferredSex',
+    'preferredBreedingId',
+    'requestedByDateIso',
+    'inquiryDateIso',
+    'followUpDateIso',
+    'lastContactedDateIso',
+    'maxBudgetCents',
+    'notes',
+    '_rev',
+  ]),
+  animalReservation: new Set([
+    'species',
+    'agreementNumber',
+    'clientId',
+    'clientName',
+    'waitlistEntryId',
+    'animalId',
+    'breedingId',
+    'pickOrder',
+    'itemLabel',
+    'status',
+    'reservedDateIso',
+    'holdExpiresDateIso',
+    'totalPriceCents',
+    'depositRequiredCents',
+    'depositPaidCents',
+    'depositDueDateIso',
+    'depositPaidDateIso',
+    'pickupScheduledDateIso',
+    'completedDateIso',
+    'balanceReminderDateIso',
+    'paymentMethod',
+    'ledgerEntryId',
+    'termsSummary',
+    'healthGuaranteeNotes',
+    'notes',
+    '_rev',
+  ]),
+  woolHarvest: new Set([
+    'species',
+    'animalId',
+    'harvestDateIso',
+    'shearingIntervalDays',
+    'primeWeightGrams',
+    'gradeWeightGrams',
+    'harvestMethod',
+    'stapleLengthMm',
+    'iagarbScore',
+    'witnessedBy',
+    'notes',
+    '_rev',
+  ]),
 };
 
 /**
```

### `src/core/models.ts` (`+327` / `-0`, source: `part-10.md`)

```diff
--- working/src/core/models.ts
+++ import/src/core/models.ts
@@ -758,6 +758,7 @@
   title: string;
   category: TaskCategory;
   priority: TaskPriority;
+  startDateIso?: string; // YYYY-MM-DD or ""
   dueDateIso: string; // YYYY-MM-DD or ""
   linkedAnimalId: string;
   linkedAnimalName: string;
@@ -1237,6 +1238,328 @@
   updatedAt: string;
 }
 
+export type PreferredContactMethod = 'email' | 'phone' | 'sms' | 'in_person' | 'other';
+
+export const PREFERRED_CONTACT_METHODS: ReadonlyArray<{
+  value: PreferredContactMethod;
+  label: string;
+}> = [
+  { value: 'sms', label: 'Text / SMS' },
+  { value: 'phone', label: 'Phone Call' },
+  { value: 'email', label: 'Email' },
+  { value: 'in_person', label: 'In Person / Barn Visit' },
+  { value: 'other', label: 'Other' },
+];
+
+export function normalizePreferredContactMethod(
+  raw: unknown,
+  fallback: PreferredContactMethod = 'sms'
+): PreferredContactMethod {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  if (clean === 'email' || clean === 'mail') return 'email';
+  if (clean === 'phone' || clean === 'call') return 'phone';
+  if (clean === 'sms' || clean === 'text') return 'sms';
+  if (clean === 'in_person' || clean === 'in person' || clean === 'barn') return 'in_person';
+  if (clean === 'other') return 'other';
+  return fallback;
+}
+
+export type ClientKind =
+  | 'pet_buyer'
+  | 'show_breeder'
+  | 'commercial_meat'
+  | 'youth_4h_ffa'
+  | 'rescue_partner'
+  | 'other';
+
+export const CLIENT_KINDS: ReadonlyArray<{
+  value: ClientKind;
+  label: string;
+}> = [
+  { value: 'pet_buyer', label: 'Pet / Companion Buyer' },
+  { value: 'show_breeder', label: 'Show & Breeding Program' },
+  { value: 'youth_4h_ffa', label: '4-H / FFA Youth Buyer' },
+  { value: 'commercial_meat', label: 'Commercial / Meat / Homestead' },
+  { value: 'rescue_partner', label: 'Partner / Exchange' },
+  { value: 'other', label: 'Other Client' },
+];
+
+export function normalizeClientKind(
+  raw: unknown,
+  fallback: ClientKind = 'pet_buyer'
+): ClientKind {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  const valid = new Set<ClientKind>(CLIENT_KINDS.map((o) => o.value));
+  if (valid.has(clean as ClientKind)) return clean as ClientKind;
+  if (clean.includes('show') || clean.includes('breed')) return 'show_breeder';
+  if (clean.includes('4-h') || clean.includes('4h') || clean.includes('ffa') || clean.includes('youth')) {
+    return 'youth_4h_ffa';
+  }
+  if (clean.includes('meat') || clean.includes('commercial') || clean.includes('homestead')) {
+    return 'commercial_meat';
+  }
+  if (clean.includes('rescue') || clean.includes('partner')) return 'rescue_partner';
+  if (clean.includes('pet') || clean.includes('companion')) return 'pet_buyer';
+  return fallback;
+}
+
+/**
+ * Local-first breeder CRM client contact record, scoped to a `species`.
+ */
+export interface ClientContact {
+  id: string;
+  species: string;
+  fullName: string;
+  ranchOrHerdName: string;
+  email: string;
+  phone: string;
+  preferredContact: PreferredContactMethod;
+  clientKind: ClientKind;
+  cityState: string;
+  shippingAddress: string;
+  tags: string[];
+  notes: string;
+  _rev?: number;
+  createdAt: string;
+  updatedAt: string;
+}
+
+export type WaitlistStatus =
+  | 'Active'
+  | 'Matched'
+  | 'Deposited'
+  | 'Fulfilled'
+  | 'Paused'
+  | 'Cancelled';
+
+export const WAITLIST_STATUSES: ReadonlyArray<WaitlistStatus> = [
+  'Active',
+  'Matched',
+  'Deposited',
+  'Fulfilled',
+  'Paused',
+  'Cancelled',
+];
+
+export function normalizeWaitlistStatus(
+  raw: unknown,
+  fallback: WaitlistStatus = 'Active'
+): WaitlistStatus {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  if (clean === 'active' || clean === 'waiting' || clean === 'open') return 'Active';
+  if (clean === 'matched') return 'Matched';
+  if (clean === 'deposited' || clean === 'reserved') return 'Deposited';
+  if (clean === 'fulfilled' || clean === 'completed' || clean === 'sold') return 'Fulfilled';
+  if (clean === 'paused' || clean === 'hold') return 'Paused';
+  if (clean === 'cancelled' || clean === 'canceled') return 'Cancelled';
+  return fallback;
+}
+
+export type WaitlistIntent =
+  | 'Show / Breeding'
+  | 'Pet / Companion'
+  | '4-H / FFA Youth'
+  | 'Meat / Commercial'
+  | 'Any';
+
+export const WAITLIST_INTENTS: ReadonlyArray<WaitlistIntent> = [
+  'Show / Breeding',
+  'Pet / Companion',
+  '4-H / FFA Youth',
+  'Meat / Commercial',
+  'Any',
+];
+
+export function normalizeWaitlistIntent(
+  raw: unknown,
+  fallback: WaitlistIntent = 'Show / Breeding'
+): WaitlistIntent {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  if (clean.includes('show') || clean.includes('breed')) return 'Show / Breeding';
+  if (clean.includes('pet') || clean.includes('companion')) return 'Pet / Companion';
+  if (clean.includes('4-h') || clean.includes('4h') || clean.includes('ffa') || clean.includes('youth')) {
+    return '4-H / FFA Youth';
+  }
+  if (clean.includes('meat') || clean.includes('commercial')) return 'Meat / Commercial';
+  if (clean === 'any') return 'Any';
+  return fallback;
+}
+
+/**
+ * Buyer waitlist inquiry & preference record, scoped to a `species`.
+ */
+export interface WaitlistEntry {
+  id: string;
+  species: string;
+  clientId: string;
+  clientName: string;
+  priorityRank: number;
+  status: WaitlistStatus;
+  intent: WaitlistIntent;
+  desiredBreed: string;
+  desiredVariety: string;
+  preferredSex: 'Any' | 'Male' | 'Female';
+  preferredBreedingId?: string;
+  requestedByDateIso: string; // YYYY-MM-DD or ""
+  inquiryDateIso: string; // YYYY-MM-DD
+  followUpDateIso: string; // YYYY-MM-DD or ""
+  lastContactedDateIso: string; // YYYY-MM-DD or ""
+  maxBudgetCents?: number;
+  notes: string;
+  _rev?: number;
+  createdAt: string;
+  updatedAt: string;
+}
+
+export type ReservationStatus =
+  | 'Inquiry Hold'
+  | 'Pending Deposit'
+  | 'Deposit Paid'
+  | 'Paid in Full'
+  | 'Ready for Pickup'
+  | 'Picked Up / Completed'
+  | 'Cancelled';
+
+export const RESERVATION_STATUSES: ReadonlyArray<ReservationStatus> = [
+  'Inquiry Hold',
+  'Pending Deposit',
+  'Deposit Paid',
+  'Paid in Full',
+  'Ready for Pickup',
+  'Picked Up / Completed',
+  'Cancelled',
+];
+
+export function normalizeReservationStatus(
+  raw: unknown,
+  fallback: ReservationStatus = 'Pending Deposit'
+): ReservationStatus {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  if (clean === 'inquiry hold' || clean === 'hold') return 'Inquiry Hold';
+  if (clean === 'pending deposit' || clean === 'pending') return 'Pending Deposit';
+  if (clean === 'deposit paid' || clean === 'deposited') return 'Deposit Paid';
+  if (clean === 'paid in full' || clean === 'paid') return 'Paid in Full';
+  if (clean === 'ready for pickup' || clean === 'ready') return 'Ready for Pickup';
+  if (
+    clean === 'picked up / completed' ||
+    clean === 'completed' ||
+    clean === 'picked up' ||
+    clean === 'sold'
+  ) {
+    return 'Picked Up / Completed';
+  }
+  if (clean === 'cancelled' || clean === 'canceled') return 'Cancelled';
+  return fallback;
+}
+
+/**
+ * Animal or litter-pick reservation with deposit schedule, hold expiration,
+ * follow-up reminders, and printable sales agreement metadata, scoped to a `species`.
+ */
+export interface AnimalReservation {
+  id: string;
+  species: string;
+  agreementNumber: string;
+  clientId: string;
+  clientName: string;
+  waitlistEntryId?: string;
+  animalId?: string;
+  breedingId?: string;
+  pickOrder?: number;
+  itemLabel: string;
+  status: ReservationStatus;
+  reservedDateIso: string; // YYYY-MM-DD
+  holdExpiresDateIso: string; // YYYY-MM-DD or ""
+  totalPriceCents: number;
+  depositRequiredCents: number;
+  depositPaidCents: number;
+  depositDueDateIso: string; // YYYY-MM-DD or ""
+  depositPaidDateIso: string; // YYYY-MM-DD or ""
+  pickupScheduledDateIso: string; // YYYY-MM-DD or ""
+  completedDateIso: string; // YYYY-MM-DD or ""
+  balanceReminderDateIso: string; // YYYY-MM-DD or ""
+  paymentMethod: string;
+  ledgerEntryId?: string;
+  termsSummary: string;
+  healthGuaranteeNotes: string;
+  notes: string;
+  _rev?: number;
+  createdAt: string;
+  updatedAt: string;
+}
+
+export type WoolHarvestMethod = 'Shear' | 'Pluck' | 'Brush / Comb' | 'Other';
+
+export const WOOL_HARVEST_METHODS: ReadonlyArray<WoolHarvestMethod> = [
+  'Shear',
+  'Pluck',
+  'Brush / Comb',
+  'Other',
+];
+
+export function normalizeWoolHarvestMethod(
+  raw: unknown,
+  fallback: WoolHarvestMethod = 'Shear'
+): WoolHarvestMethod {
+  if (typeof raw !== 'string') return fallback;
+  const clean = raw.trim().toLowerCase();
+  if (clean === 'shear' || clean === 'clipped' || clean === 'clip' || clean === 'sheared') {
+    return 'Shear';
+  }
+  if (clean === 'pluck' || clean === 'plucked') return 'Pluck';
+  if (clean === 'brush / comb' || clean === 'brush' || clean === 'comb' || clean === 'combed') {
+    return 'Brush / Comb';
+  }
+  if (clean === 'other') return 'Other';
+  return fallback;
+}
+
+/**
+ * Official 100-point 7-position IAGARB German Angora evaluation breakdown:
+ * Weight (20), Body Type (20), Wool Density & Length (15), Wool Uniformity (15),
+ * Wool Texture (15), Furnishings (10), Condition (5).
+ */
+export interface IagarbScorecard {
+  weightPts: number;
+  bodyTypePts: number;
+  densityLengthPts: number;
+  uniformityPts: number;
+  texturePts: number;
+  furnishingsPts: number;
+  conditionPts: number;
+  totalPts: number;
+  evaluatorName: string;
+  evaluationDateIso: string; // YYYY-MM-DD or ""
+}
+
+/**
+ * Per-animal wool/fiber harvest record supporting prime vs. grade yields,
+ * shearing cycle interval tracking (e.g., 90-day IAGARB performance test),
+ * and optional IAGARB German Angora 7-position judging scorecard.
+ */
+export interface WoolHarvest {
+  id: string;
+  species: string;
+  animalId: string;
+  harvestDateIso: string; // YYYY-MM-DD
+  shearingIntervalDays?: number;
+  primeWeightGrams: number;
+  gradeWeightGrams: number;
+  harvestMethod: WoolHarvestMethod;
+  stapleLengthMm?: number;
+  iagarbScore?: IagarbScorecard;
+  witnessedBy?: string;
+  notes: string;
+  _rev?: number;
+  createdAt: string;
+  updatedAt: string;
+}
+
 /**
  * Complete in-memory snapshot of the unencrypted local database.
  */
@@ -1255,6 +1578,10 @@
   ledgerEntries?: LedgerEntry[];
   processingLogs?: ProcessingLog[];
   youthProjectBooks?: YouthProjectBook[];
+  clientContacts?: ClientContact[];
+  waitlistEntries?: WaitlistEntry[];
+  animalReservations?: AnimalReservation[];
+  woolHarvests?: WoolHarvest[];
 }
 
 export const ANIMAL_STATUSES: AnimalStatus[] = [
```

### `src/core/pdfExporter.ts` (`+33` / `-3`, source: `part-10.md`)

```diff
--- working/src/core/pdfExporter.ts
+++ import/src/core/pdfExporter.ts
@@ -38,6 +38,12 @@
 import { hexToPdfRgb, resolvePedigreePrintTheme } from './pedigreePrintStyles';
 import { computeAnimalShowSummary } from './showResults';
 import type { PedigreePrintOrientation, PedigreePrintOptions } from './syncAndExports';
+import {
+  AnimalWoolSummary,
+  buildWoolHarvestSummaryByAnimalId,
+  formatWoolWeightSummary,
+  summarizeAnimalWoolHarvests,
+} from './woolFiber';
 
 export interface PdfRasterImage {
   /** Raw JPEG bytes (`FF D8 ... FF D9`) for native PDF `/DCTDecode` embedding. */
@@ -292,6 +298,15 @@
     subjectFields.push(`Show Points: ${subjShow.totalPoints}`);
   }
   if (subject.rufusLevel) subjectFields.push(`Rufus: ${subject.rufusLevel}`);
+  const woolHarvestList = printOptions?.woolHarvests ?? [];
+  const woolSummaryByAnimalId =
+    woolHarvestList.length > 0
+      ? buildWoolHarvestSummaryByAnimalId(woolHarvestList)
+      : new Map<string, AnimalWoolSummary>();
+  const subjectWool =
+    woolHarvestList.length > 0 ? summarizeAnimalWoolHarvests(woolHarvestList, subject.id) : null;
+  const subjectWoolLine = subjectWool ? formatWoolWeightSummary(subjectWool) : '';
+  if (subjectWoolLine) subjectFields.push(`Wool / Fiber: ${subjectWoolLine}`);
   if (showGenotypes && subjectGeno) subjectFields.push(`Genotype: ${subjectGeno}`);
   if (subjectCarriers) subjectFields.push(`Carriers: ${subjectCarriers}`);
 
@@ -466,9 +481,13 @@
     const headerHeight = isCompactLedger ? (hasLogo ? 32 : 26) : hasLogo ? 40 : 32;
     const barnTitle = settings.barnName || 'Community Pedigree';
     const pageSuffix = slice.totalPages > 1 ? ` | Page ${slice.pageNumber}/${slice.totalPages}` : '';
-    const subLeft = `Official ${depth}-Generation ${subject.species} Pedigree Certificate${
-      settings.breederName ? ` | Breeder: ${settings.breederName}` : ''
-    }`;
+    const subLeft = `${
+      theme.layoutPreset === 'iagarb_angora'
+        ? `IAGARB German Angora ${depth}-Generation Wool Pedigree`
+        : theme.layoutPreset === 'family_portrait'
+        ? `Family Portrait ${depth}-Generation ${subject.species} Pedigree`
+        : `Official ${depth}-Generation ${subject.species} Pedigree Certificate`
+    }${settings.breederName ? ` | Breeder: ${settings.breederName}` : ''}`;
     const rightMeta = `Generated ${formatReadableDate(nowIsoUtc().slice(0, 10))} | Wright COI: ${coi.coiPercent.toFixed(2)}% (${coi.risk.label})${pageSuffix}`;
 
     if (isShowCert && !hasLogo) {
@@ -736,6 +755,17 @@
           ancLegs > 0 ? `Legs: ${ancLegs}` : '',
           ancShowSummary?.awardsSummaryText ? ancShowSummary.awardsSummaryText : '',
         ].filter(Boolean);
+        const ancWool = woolSummaryByAnimalId.get(animal.id);
+        const ancWoolText =
+          ancWool && (ancWool.harvestCount > 0 || ancWool.highestIagarbScore)
+            ? formatWoolWeightSummary(ancWool, { compact: true })
+            : '';
+        if (!compactMode && ancWoolText && cellH >= 40) {
+          const woolWrapped = wrapPdfLines(ancWoolText, innerCellW, metaSize, 1);
+          for (const wl of woolWrapped) {
+            linesToRender.push({ text: wl, font: 'F3', size: metaSize, rgb: primaryRgb });
+          }
+        }
         if (!compactMode && regParts.length > 0 && cellH >= 36) {
           const regWrapped = wrapPdfLines(regParts.join(' | '), innerCellW, metaSize, 1);
           for (const rl of regWrapped) {
```

### `src/core/pedigreePrintStyles.ts` (`+32` / `-2`, source: `part-10.md`)

```diff
--- working/src/core/pedigreePrintStyles.ts
+++ import/src/core/pedigreePrintStyles.ts
@@ -33,7 +33,9 @@
 export type PedigreeLayoutPresetId =
   | 'evans_standard'
   | 'show_certificate'
-  | 'compact_ledger';
+  | 'compact_ledger'
+  | 'family_portrait'
+  | 'iagarb_angora';
 
 export interface PedigreeColorPresetSpec {
   id: PedigreeColorPresetId;
@@ -181,6 +183,16 @@
     label: 'Compact Ledger',
     description: 'Tighter header & subject summary leaving maximum vertical space for deep trees.',
   },
+  {
+    id: 'family_portrait',
+    label: 'Family Portrait (Photos)',
+    description: 'Multi-photo pedigree displaying portrait thumbnails for subject, parents & grandparents.',
+  },
+  {
+    id: 'iagarb_angora',
+    label: 'IAGARB German Angora',
+    description: 'Official 100-point wool judging breakdown, 325g/90d yield stats & ancestor fiber table.',
+  },
 ];
 
 export const PEDIGREE_QUICK_STYLE_PRESETS: readonly PedigreeQuickPresetSpec[] = [
@@ -199,6 +211,22 @@
     colorPreset: 'royal_navy',
     borderStyle: 'double_frame',
     layoutPreset: 'show_certificate',
+  },
+  {
+    id: 'family-portrait',
+    label: 'Family Photo Keepsake',
+    description: 'Barn Sage · Double Frame · Multi-Photo Portrait',
+    colorPreset: 'classic_sage',
+    borderStyle: 'double_frame',
+    layoutPreset: 'family_portrait',
+  },
+  {
+    id: 'iagarb-german-angora',
+    label: 'IAGARB German Angora',
+    description: 'Heritage Burgundy · Classic Rule · Wool Yield & 100-pt Scale',
+    colorPreset: 'heritage_burgundy',
+    borderStyle: 'classic_rule',
+    layoutPreset: 'iagarb_angora',
   },
   {
     id: 'deep-archival',
@@ -272,7 +300,9 @@
   if (
     raw === 'evans_standard' ||
     raw === 'show_certificate' ||
-    raw === 'compact_ledger'
+    raw === 'compact_ledger' ||
+    raw === 'family_portrait' ||
+    raw === 'iagarb_angora'
   ) {
     return raw;
   }
```

### `src/core/reportCatalog.ts` (`+16` / `-0`, source: `part-11.md`)

```diff
--- working/src/core/reportCatalog.ts
+++ import/src/core/reportCatalog.ts
@@ -262,5 +262,21 @@
       scopeLabel,
       iconKey: 'roster',
     },
+    {
+      id: 'crm-waitlist-report',
+      title: `Buyer Waitlist Queue (${spName})`,
+      category: 'Sales & CRM',
+      description: `Prioritized buyer waitlist inquiries, desired breeds/varieties, follow-up dates, and contact methods for ${spLower}`,
+      scopeLabel,
+      iconKey: 'users',
+    },
+    {
+      id: 'crm-reservations-deposits-report',
+      title: `Reservations & Deposit Tracking (${spName})`,
+      category: 'Sales & CRM',
+      description: `Active holds, deposits collected, remaining balances, and scheduled pickup dates for ${spLower}`,
+      scopeLabel,
+      iconKey: 'income',
+    },
   ];
 }
```

### `src/core/reportGenerators.ts` (`+181` / `-0`, source: `part-11.md`)

```diff
--- working/src/core/reportGenerators.ts
+++ import/src/core/reportGenerators.ts
@@ -56,6 +56,7 @@
 } from './economicsLedger';
 import { buildReportCatalogForSpecies, ReportCatalogEntrySpec } from './reportCatalog';
 import { computeAnimalShowSummary } from './showResults';
+import { evaluateReservationFinancials, formatPreferredContactLabel } from './clientCrm';
 
 export type ReportAudienceFilter =
   | 'All'
@@ -2695,6 +2696,186 @@
       };
     }
 
+    // 26. CRM Buyer Waitlist Queue Report
+    case 'crm-waitlist-report': {
+      const speciesClients = (ctx.snapshot.clientContacts ?? []).filter((cc) =>
+        isSameSpecies(cc.species, speciesProfile.name)
+      );
+      const clientMap = new Map(speciesClients.map((c) => [c.id, c]));
+      const speciesWaitlist = (ctx.snapshot.waitlistEntries ?? [])
+        .filter((wl) => {
+          if (!isSameSpecies(wl.species, speciesProfile.name)) return false;
+          if (!isIsoWithinRange(wl.inquiryDateIso, dateFromIso, dateToIso)) return false;
+          return true;
+        })
+        .sort(
+          (a, b) =>
+            (a.priorityRank || 9999) - (b.priorityRank || 9999) ||
+            a.inquiryDateIso.localeCompare(b.inquiryDateIso)
+        );
+
+      const activeCount = speciesWaitlist.filter(
+        (w) => w.status === 'Active' || w.status === 'Matched'
+      ).length;
+      const overdueFollowUps = speciesWaitlist.filter(
+        (w) =>
+          (w.status === 'Active' || w.status === 'Matched') &&
+          Boolean(w.followUpDateIso) &&
+          w.followUpDateIso < referenceDateIso
+      ).length;
+
+      const rows: ReportRow[] = speciesWaitlist.map((w) => {
+        const client = clientMap.get(w.clientId);
+        const contactInfo = client
+          ? `${formatPreferredContactLabel(client.preferredContact)}: ${client.phone || client.email || '—'}`
+          : '—';
+        return {
+          id: w.id,
+          highlightTone:
+            (w.status === 'Active' || w.status === 'Matched') &&
+            Boolean(w.followUpDateIso) &&
+            w.followUpDateIso < referenceDateIso
+              ? 'warning'
+              : w.status === 'Deposited' || w.status === 'Fulfilled'
+                ? 'success'
+                : 'normal',
+          cells: {
+            rank: `#${w.priorityRank || 1}`,
+            buyer: client?.fullName || w.clientName || 'Buyer',
+            status: w.status,
+            intent: w.intent,
+            preferences:
+              [w.desiredBreed, w.desiredVariety, w.preferredSex !== 'Any' ? w.preferredSex : '']
+                .filter(Boolean)
+                .join(' · ') || 'Any',
+            inquiryDate: formatReadableDate(w.inquiryDateIso),
+            followUp: w.followUpDateIso ? formatReadableDate(w.followUpDateIso) : '—',
+            budget:
+              w.maxBudgetCents && w.maxBudgetCents > 0
+                ? formatCurrencyCents(w.maxBudgetCents, currencyCode)
+                : '—',
+            contact: contactInfo,
+          },
+        };
+      });
+
+      return {
+        columns: [
+          { key: 'rank', label: 'Rank', align: 'right' },
+          { key: 'buyer', label: 'Buyer' },
+          { key: 'status', label: 'Status' },
+          { key: 'intent', label: 'Intent' },
+          { key: 'preferences', label: 'Desired Stock' },
+          { key: 'inquiryDate', label: 'Inquiry Date' },
+          { key: 'followUp', label: 'Follow-Up' },
+          { key: 'budget', label: 'Max Budget', align: 'right' },
+          { key: 'contact', label: 'Contact' },
+        ],
+        rows,
+        summaryMetrics: [
+          { label: 'Waitlist Entries', value: String(rows.length) },
+          { label: 'Active / Matched', value: String(activeCount), tone: activeCount > 0 ? 'positive' : 'neutral' },
+          {
+            label: 'Overdue Follow-Ups',
+            value: String(overdueFollowUps),
+            tone: overdueFollowUps > 0 ? 'danger' : 'neutral',
+          },
+        ],
+      };
+    }
+
+    // 27. CRM Reservations & Deposit Tracking Report
+    case 'crm-reservations-deposits-report': {
+      const speciesReservations = (ctx.snapshot.animalReservations ?? [])
+        .filter((ar) => {
+          if (!isSameSpecies(ar.species, speciesProfile.name)) return false;
+          if (!isIsoWithinRange(ar.reservedDateIso, dateFromIso, dateToIso)) return false;
+          if (filter !== 'All' && ar.animalId) {
+            return matchesFilter(animalById.get(ar.animalId));
+          }
+          return true;
+        })
+        .sort((a, b) => (b.reservedDateIso || '').localeCompare(a.reservedDateIso || ''));
+
+      let totalAgreedCents = 0;
+      let totalPaidCents = 0;
+      let totalRemainingCents = 0;
+      let overdueDepositsCount = 0;
+
+      const rows: ReportRow[] = speciesReservations.map((r) => {
+        const fin = evaluateReservationFinancials(r);
+        if (r.status !== 'Cancelled') {
+          totalAgreedCents += fin.totalPriceCents;
+          totalPaidCents += fin.depositPaidCents;
+          if (r.status !== 'Picked Up / Completed') {
+            totalRemainingCents += fin.balanceRemainingCents;
+          }
+        }
+        const depositOverdue =
+          r.status !== 'Cancelled' &&
+          r.status !== 'Picked Up / Completed' &&
+          fin.depositRemainingCents > 0 &&
+          Boolean(r.depositDueDateIso) &&
+          r.depositDueDateIso < referenceDateIso;
+        if (depositOverdue) overdueDepositsCount += 1;
+        return {
+          id: r.id,
+          animalId: r.animalId,
+          highlightTone: depositOverdue
+            ? 'danger'
+            : r.status === 'Picked Up / Completed' || fin.isPaidInFull
+              ? 'success'
+              : 'normal',
+          cells: {
+            agreement: r.agreementNumber || '—',
+            buyer: r.clientName || 'Buyer',
+            item: r.itemLabel || 'Reserved Stock',
+            status: r.status,
+            reservedDate: formatReadableDate(r.reservedDateIso),
+            totalPrice: formatCurrencyCents(fin.totalPriceCents, currencyCode),
+            depositReq: formatCurrencyCents(fin.depositRequiredCents, currencyCode),
+            paid: formatCurrencyCents(fin.depositPaidCents, currencyCode),
+            balanceDue: formatCurrencyCents(fin.balanceRemainingCents, currencyCode),
+            pickupDate: r.pickupScheduledDateIso ? formatReadableDate(r.pickupScheduledDateIso) : '—',
+          },
+        };
+      });
+
+      return {
+        columns: [
+          { key: 'agreement', label: 'Agreement #' },
+          { key: 'buyer', label: 'Buyer' },
+          { key: 'item', label: 'Animal / Pick' },
+          { key: 'status', label: 'Status' },
+          { key: 'reservedDate', label: 'Reserved' },
+          { key: 'totalPrice', label: 'Price', align: 'right' },
+          { key: 'depositReq', label: 'Deposit Req', align: 'right' },
+          { key: 'paid', label: 'Paid', align: 'right' },
+          { key: 'balanceDue', label: 'Balance Due', align: 'right' },
+          { key: 'pickupDate', label: 'Pickup Date' },
+        ],
+        rows,
+        summaryMetrics: [
+          { label: 'Reservations', value: String(rows.length) },
+          { label: 'Total Price Value', value: formatCurrencyCents(totalAgreedCents, currencyCode) },
+          {
+            label: 'Deposits / Payments Collected',
+            value: formatCurrencyCents(totalPaidCents, currencyCode),
+            tone: totalPaidCents > 0 ? 'positive' : 'neutral',
+          },
+          {
+            label: 'Open Balance Due',
+            value: formatCurrencyCents(totalRemainingCents, currencyCode),
+          },
+          {
+            label: 'Overdue Deposits',
+            value: String(overdueDepositsCount),
+            tone: overdueDepositsCount > 0 ? 'danger' : 'neutral',
+          },
+        ],
+      };
+    }
+
     default: {
       return {
         columns: [{ key: 'notice', label: 'Notice' }],
```

### `src/core/sampleData.ts` (`+134` / `-2`, source: `part-11.md`)

```diff
--- working/src/core/sampleData.ts
+++ import/src/core/sampleData.ts
@@ -430,6 +430,18 @@
   const youthProjectBooks = (snapshot.youthProjectBooks ?? []).filter(
     (yp) => isSameSpecies(yp.species, speciesName) && isSampleTestingId(yp.id)
   ).length;
+  const clientContacts = (snapshot.clientContacts ?? []).filter(
+    (cc) => isSameSpecies(cc.species, speciesName) && isSampleTestingId(cc.id)
+  ).length;
+  const waitlistEntries = (snapshot.waitlistEntries ?? []).filter(
+    (wl) => isSameSpecies(wl.species, speciesName) && isSampleTestingId(wl.id)
+  ).length;
+  const animalReservations = (snapshot.animalReservations ?? []).filter(
+    (ar) => isSameSpecies(ar.species, speciesName) && isSampleTestingId(ar.id)
+  ).length;
+  const woolHarvests = (snapshot.woolHarvests ?? []).filter(
+    (wh) => isSameSpecies(wh.species, speciesName) && isSampleTestingId(wh.id)
+  ).length;
 
   return (
     seedAnimalIds.size +
@@ -443,7 +455,11 @@
     feedAllocations +
     ledgerEntries +
     processingLogs +
-    youthProjectBooks
+    youthProjectBooks +
+    clientContacts +
+    waitlistEntries +
+    animalReservations +
+    woolHarvests
   );
 }
 
@@ -477,6 +493,18 @@
   ).length;
   const youthProjectBooks = (snapshot.youthProjectBooks ?? []).filter((yp) =>
     isSameSpecies(yp.species, speciesName)
+  ).length;
+  const clientContacts = (snapshot.clientContacts ?? []).filter((cc) =>
+    isSameSpecies(cc.species, speciesName)
+  ).length;
+  const waitlistEntries = (snapshot.waitlistEntries ?? []).filter((wl) =>
+    isSameSpecies(wl.species, speciesName)
+  ).length;
+  const animalReservations = (snapshot.animalReservations ?? []).filter((ar) =>
+    isSameSpecies(ar.species, speciesName)
+  ).length;
+  const woolHarvests = (snapshot.woolHarvests ?? []).filter((wh) =>
+    isSameSpecies(wh.species, speciesName)
   ).length;
 
   return (
@@ -491,7 +519,11 @@
     feedAllocations +
     ledgerEntries +
     processingLogs +
-    youthProjectBooks
+    youthProjectBooks +
+    clientContacts +
+    waitlistEntries +
+    animalReservations +
+    woolHarvests
   );
 }
 
@@ -649,6 +681,32 @@
     return !remove;
   });
 
+  const nextClientContacts = (snapshot.clientContacts ?? []).filter((cc) => {
+    const remove = isSameSpecies(cc.species, speciesName) && isSampleTestingId(cc.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextWaitlistEntries = (snapshot.waitlistEntries ?? []).filter((wl) => {
+    const remove = isSameSpecies(wl.species, speciesName) && isSampleTestingId(wl.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextAnimalReservations = (snapshot.animalReservations ?? []).filter((ar) => {
+    const remove = isSameSpecies(ar.species, speciesName) && isSampleTestingId(ar.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextWoolHarvests = (snapshot.woolHarvests ?? []).filter((wh) => {
+    const remove =
+      (isSameSpecies(wh.species, speciesName) && isSampleTestingId(wh.id)) ||
+      removedAnimalIds.has(wh.animalId);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
   return {
     nextSnapshot: {
       ...snapshot,
@@ -664,6 +722,10 @@
       ledgerEntries: nextLedgerEntries,
       processingLogs: nextProcessingLogs,
       youthProjectBooks: nextYouthProjectBooks,
+      clientContacts: nextClientContacts,
+      waitlistEntries: nextWaitlistEntries,
+      animalReservations: nextAnimalReservations,
+      woolHarvests: nextWoolHarvests,
     },
     removedAnimals: removedAnimalIds.size,
     removedTotalRecords,
@@ -810,6 +872,32 @@
     return !remove;
   });
 
+  const nextClientContacts = (snapshot.clientContacts ?? []).filter((cc) => {
+    const remove = isSameSpecies(cc.species, speciesName) && !isSampleTestingId(cc.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextWaitlistEntries = (snapshot.waitlistEntries ?? []).filter((wl) => {
+    const remove = isSameSpecies(wl.species, speciesName) && !isSampleTestingId(wl.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextAnimalReservations = (snapshot.animalReservations ?? []).filter((ar) => {
+    const remove = isSameSpecies(ar.species, speciesName) && !isSampleTestingId(ar.id);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
+  const nextWoolHarvests = (snapshot.woolHarvests ?? []).filter((wh) => {
+    const remove =
+      (isSameSpecies(wh.species, speciesName) && !isSampleTestingId(wh.id)) ||
+      removedAnimalIds.has(wh.animalId);
+    if (remove) removedTotalRecords++;
+    return !remove;
+  });
+
   return {
     nextSnapshot: {
       ...snapshot,
@@ -825,6 +913,10 @@
       ledgerEntries: nextLedgerEntries,
       processingLogs: nextProcessingLogs,
       youthProjectBooks: nextYouthProjectBooks,
+      clientContacts: nextClientContacts,
+      waitlistEntries: nextWaitlistEntries,
+      animalReservations: nextAnimalReservations,
+      woolHarvests: nextWoolHarvests,
     },
     removedAnimals: removedAnimalIds.size,
     removedTotalRecords,
@@ -945,6 +1037,38 @@
     return true;
   });
 
+  const nextClientContacts = (snapshot.clientContacts ?? []).filter((cc) => {
+    if (isSameSpecies(cc.species, speciesName)) {
+      removedTotalRecords++;
+      return false;
+    }
+    return true;
+  });
+
+  const nextWaitlistEntries = (snapshot.waitlistEntries ?? []).filter((wl) => {
+    if (isSameSpecies(wl.species, speciesName)) {
+      removedTotalRecords++;
+      return false;
+    }
+    return true;
+  });
+
+  const nextAnimalReservations = (snapshot.animalReservations ?? []).filter((ar) => {
+    if (isSameSpecies(ar.species, speciesName)) {
+      removedTotalRecords++;
+      return false;
+    }
+    return true;
+  });
+
+  const nextWoolHarvests = (snapshot.woolHarvests ?? []).filter((wh) => {
+    if (isSameSpecies(wh.species, speciesName) || removedAnimalIds.has(wh.animalId)) {
+      removedTotalRecords++;
+      return false;
+    }
+    return true;
+  });
+
   return {
     nextSnapshot: {
       ...snapshot,
@@ -960,6 +1084,10 @@
       ledgerEntries: nextLedgerEntries,
       processingLogs: nextProcessingLogs,
       youthProjectBooks: nextYouthProjectBooks,
+      clientContacts: nextClientContacts,
+      waitlistEntries: nextWaitlistEntries,
+      animalReservations: nextAnimalReservations,
+      woolHarvests: nextWoolHarvests,
     },
     removedAnimals: removedAnimalIds.size,
     removedTotalRecords,
@@ -1623,5 +1751,9 @@
     ledgerEntries: [],
     processingLogs: [],
     youthProjectBooks: [],
+    clientContacts: [],
+    waitlistEntries: [],
+    animalReservations: [],
+    woolHarvests: [],
   };
 }
```

### `src/core/shareablePedigreeCard.ts` (`+22` / `-0`, source: `part-11.md`)

```diff
--- working/src/core/shareablePedigreeCard.ts
+++ import/src/core/shareablePedigreeCard.ts
@@ -38,6 +38,12 @@
 import { buildAnimalProfileDeepLink, renderQrSvg } from './qrCode';
 import { computeAnimalShowSummary } from './showResults';
 import type { PedigreePrintOptions } from './syncAndExports';
+import {
+  AnimalWoolSummary,
+  buildWoolHarvestSummaryByAnimalId,
+  formatWoolWeightSummary,
+  summarizeAnimalWoolHarvests,
+} from './woolFiber';
 
 export interface ShareablePedigreeCardOptions extends PedigreePrintOptions {
   /** Optional PWA base URL used to embed a scannable QR profile link when desired. */
@@ -116,6 +122,15 @@
         className: 'qr-svg',
       })
     : '';
+
+  const woolHarvestList = options?.woolHarvests ?? [];
+  const woolByAnimalId =
+    woolHarvestList.length > 0
+      ? buildWoolHarvestSummaryByAnimalId(woolHarvestList)
+      : new Map<string, AnimalWoolSummary>();
+  const subjectWool =
+    woolHarvestList.length > 0 ? summarizeAnimalWoolHarvests(woolHarvestList, subject.id) : null;
+  const subjectWoolLine = subjectWool ? formatWoolWeightSummary(subjectWool) : '';
 
   const renderNodeHtml = (gen: number, idx: number, compact = false): string => {
     const slot = slotMap.get(`${gen}:${idx}`);
@@ -140,11 +155,17 @@
         ? computeAnimalShowSummary(a, options?.shows ?? [], options?.careLogs ?? [])
         : null;
     const ancLegs = ancShow ? ancShow.effectiveLegs : a.legsCount;
+    const ancWool = woolByAnimalId.get(a.id);
+    const ancWoolCompact =
+      ancWool && (ancWool.harvestCount > 0 || ancWool.highestIagarbScore)
+        ? formatWoolWeightSummary(ancWool, { compact: true })
+        : '';
     const honors = [
       a.registrationNumber ? `Reg ${escapeSafeHtml(a.registrationNumber)}` : '',
       a.grandChampionNumber ? `GC ${escapeSafeHtml(a.grandChampionNumber)}` : '',
       ancLegs > 0 ? `${ancLegs} Leg${ancLegs === 1 ? '' : 's'}` : '',
       ancShow?.awardsSummaryText ? escapeSafeHtml(ancShow.awardsSummaryText) : '',
+      !compact && ancWoolCompact ? escapeSafeHtml(ancWoolCompact) : '',
     ].filter(Boolean);
 
     return `<div class="node ${isSire ? 'sire' : 'dam'}">
@@ -307,6 +328,7 @@
         <div class="facts">
           ${subject.birthDateIso ? `<span><strong>DOB:</strong> ${escapeSafeHtml(formatReadableDate(subject.birthDateIso))}</span>` : ''}
           ${showWeights ? `<span>${subject.birthDateIso ? ' &middot; ' : ''}<strong>Weight:</strong> ${escapeSafeHtml(formatPedigreeWeight(subject.weightGrams, effectiveWeightUnit, arbaLbsOzDotNotation))}</span>` : ''}
+          ${subjectWoolLine ? `<div><strong>Wool / Fiber:</strong> ${escapeSafeHtml(subjectWoolLine)}</div>` : ''}
           ${showGenotypes && subjectGeno ? `<div><strong>Genotype:</strong> <code>${escapeSafeHtml(subjectGeno)}</code></div>` : ''}
         </div>
       </div>
```

### `src/core/speciesMigration.ts` (`+39` / `-35`, source: `part-11.md`)

```diff
--- working/src/core/speciesMigration.ts
+++ import/src/core/speciesMigration.ts
@@ -45,8 +45,6 @@
   breedingsMigrated: number;
   cagesMigratedOrAdded: number;
   showsUpdated: number;
-  feedBatchesMigrated: number;
-  feedAllocationsMigrated: number;
   createdTargetProfile: boolean;
   /** Migrated animals that still reference a sire/dam staying in another species (will reconnect if those parents are migrated too). */
   splitParentLinksCount: number;
@@ -580,36 +578,42 @@
     return yp;
   });
 
-  let feedBatchesMigrated = 0;
-  const migratedFeedBatchIds = new Set<string>();
-  const nextFeedBatches = (snapshot.feedBatches ?? []).map((fb) => {
-    const fullSpecies = isFullSpeciesFromSource(fb.species);
-    if (fullSpecies && !isSameSpecies(fb.species, targetName)) {
-      feedBatchesMigrated++;
-      migratedFeedBatchIds.add(fb.id);
-      return { ...fb, species: targetName, _rev: bumpRecordRevision(fb), updatedAt: ts };
-    }
-    return fb;
-  });
-
-  let feedAllocationsMigrated = 0;
-  const nextFeedAllocations = (snapshot.feedAllocations ?? []).map((fa) => {
-    const linkedBatchMoved = Boolean(fa.feedBatchId && migratedFeedBatchIds.has(fa.feedBatchId));
-    const linkedAnimalMoved = Boolean(
-      fa.targetType === 'animal' && fa.targetId && actuallyMovingIds.has(fa.targetId)
+  const nextClientContacts = (snapshot.clientContacts ?? []).map((cc) => {
+    const fullSpecies = isFullSpeciesFromSource(cc.species);
+    if (fullSpecies && !isSameSpecies(cc.species, targetName)) {
+      return { ...cc, species: targetName, _rev: bumpRecordRevision(cc), updatedAt: ts };
+    }
+    return cc;
+  });
+
+  const nextWaitlistEntries = (snapshot.waitlistEntries ?? []).map((wl) => {
+    const linkedBreedingMoved = Boolean(
+      wl.preferredBreedingId && migratedBreedingIds.has(wl.preferredBreedingId)
     );
-    const linkedBreedingMoved = Boolean(
-      fa.targetType === 'litter' && fa.targetId && migratedBreedingIds.has(fa.targetId)
-    );
-    const fullSpecies = isFullSpeciesFromSource(fa.species);
-    if (
-      (linkedBatchMoved || linkedAnimalMoved || linkedBreedingMoved || fullSpecies) &&
-      !isSameSpecies(fa.species, targetName)
-    ) {
-      feedAllocationsMigrated++;
-      return { ...fa, species: targetName, _rev: bumpRecordRevision(fa), updatedAt: ts };
-    }
-    return fa;
+    const fullSpecies = isFullSpeciesFromSource(wl.species);
+    if ((linkedBreedingMoved || fullSpecies) && !isSameSpecies(wl.species, targetName)) {
+      return { ...wl, species: targetName, _rev: bumpRecordRevision(wl), updatedAt: ts };
+    }
+    return wl;
+  });
+
+  const nextAnimalReservations = (snapshot.animalReservations ?? []).map((ar) => {
+    const linkedAnimalMoved = Boolean(ar.animalId && actuallyMovingIds.has(ar.animalId));
+    const linkedBreedingMoved = Boolean(ar.breedingId && migratedBreedingIds.has(ar.breedingId));
+    const fullSpecies = isFullSpeciesFromSource(ar.species);
+    if ((linkedAnimalMoved || linkedBreedingMoved || fullSpecies) && !isSameSpecies(ar.species, targetName)) {
+      return { ...ar, species: targetName, _rev: bumpRecordRevision(ar), updatedAt: ts };
+    }
+    return ar;
+  });
+
+  const nextWoolHarvests = (snapshot.woolHarvests ?? []).map((wh) => {
+    const linkedAnimalMoved = Boolean(wh.animalId && actuallyMovingIds.has(wh.animalId));
+    const fullSpecies = isFullSpeciesFromSource(wh.species);
+    if ((linkedAnimalMoved || fullSpecies) && !isSameSpecies(wh.species, targetName)) {
+      return { ...wh, species: targetName, _rev: bumpRecordRevision(wh), updatedAt: ts };
+    }
+    return wh;
   });
 
   const nextSnapshot: BarnDatabaseSnapshot = {
@@ -622,11 +626,13 @@
     tasks: nextTasks,
     careLogs: nextCareLogs,
     shows: [...nextShows, ...showsToAppend],
-    feedBatches: nextFeedBatches,
-    feedAllocations: nextFeedAllocations,
     ledgerEntries: nextLedgerEntries,
     processingLogs: nextProcessingLogs,
     youthProjectBooks: nextYouthBooks,
+    clientContacts: nextClientContacts,
+    waitlistEntries: nextWaitlistEntries,
+    animalReservations: nextAnimalReservations,
+    woolHarvests: nextWoolHarvests,
   };
 
   let remainingSourceRecordsCount = 0;
@@ -647,8 +653,6 @@
     breedingsMigrated,
     cagesMigratedOrAdded,
     showsUpdated,
-    feedBatchesMigrated,
-    feedAllocationsMigrated,
     createdTargetProfile,
     splitParentLinksCount,
     splitBreedingsCount,
```

### `src/core/syncAndExports.ts` (`+348` / `-3`, source: `part-11.md`)

```diff
--- working/src/core/syncAndExports.ts
+++ import/src/core/syncAndExports.ts
@@ -18,6 +18,7 @@
 import {
   Animal,
   AnimalPhoto,
+  AnimalReservation,
   BarnDatabaseSnapshot,
   BarnSettings,
   BarnTask,
@@ -26,6 +27,7 @@
   CageLocation,
   CareLog,
   CareLogType,
+  ClientContact,
   FeedAllocation,
   FeedAllocationTargetType,
   FeedBatch,
@@ -42,6 +44,7 @@
   normalizeBiologicalSex,
   normalizeBreedScheduleOverrides,
   normalizeCalendarSyncSettings,
+  normalizeClientKind,
   normalizeCurrencyCode,
   normalizeFeedPurgeWindowDays,
   normalizeHousingUnitType,
@@ -52,11 +55,15 @@
   normalizeOwnershipType,
   normalizePedigreeGenerationDepth,
   normalizePeltGrade,
+  normalizePreferredContactMethod,
   normalizeProcessingStatus,
+  normalizeReservationStatus,
   normalizeRufusLevel,
   normalizeServiceFeeDirection,
   normalizeTargetWeightCurve,
   normalizeUltrasoundResult,
+  normalizeWaitlistIntent,
+  normalizeWaitlistStatus,
   normalizeWeightUnit,
   normalizeYouthOrgType,
   normalizeYouthProjectFeedLogs,
@@ -73,7 +80,19 @@
   TaskCategory,
   TaskPriority,
   todayDateIso,
+  WaitlistEntry,
+  WoolHarvest,
 } from './models';
+import {
+  AnimalWoolSummary,
+  buildWoolHarvestSummaryByAnimalId,
+  formatWoolWeightSummary,
+  IAGARB_JUDGING_POSITIONS,
+  IAGARB_MIN_90_DAY_WOOL_GRAMS,
+  IAGARB_REGISTRATION_MIN_POINTS,
+  normalizeWoolHarvest,
+  summarizeAnimalWoolHarvests,
+} from './woolFiber';
 import {
   buildPedigreeSlots,
   buildSpeciesHerdMap,
@@ -308,6 +327,22 @@
     local.youthProjectBooks ?? [],
     incoming.youthProjectBooks ?? []
   );
+  const clientContactsRes = mergeByIdAndTimestamp(
+    local.clientContacts ?? [],
+    incoming.clientContacts ?? []
+  );
+  const waitlistEntriesRes = mergeByIdAndTimestamp(
+    local.waitlistEntries ?? [],
+    incoming.waitlistEntries ?? []
+  );
+  const animalReservationsRes = mergeByIdAndTimestamp(
+    local.animalReservations ?? [],
+    incoming.animalReservations ?? []
+  );
+  const woolHarvestsRes = mergeByIdAndTimestamp(
+    local.woolHarvests ?? [],
+    incoming.woolHarvests ?? []
+  );
 
   const sortedSpecies = Array.from(speciesByName.values())
     .sort((a, b) => (a.sortOrder ?? 9999) - (b.sortOrder ?? 9999) || a.name.localeCompare(b.name))
@@ -329,6 +364,10 @@
       ledgerEntries: ledgerEntriesRes.merged,
       processingLogs: processingLogsRes.merged,
       youthProjectBooks: youthBooksRes.merged,
+      clientContacts: clientContactsRes.merged,
+      waitlistEntries: waitlistEntriesRes.merged,
+      animalReservations: animalReservationsRes.merged,
+      woolHarvests: woolHarvestsRes.merged,
     },
     animalsAdded: animalsRes.added,
     animalsUpdated: animalsRes.updated,
@@ -496,6 +535,10 @@
         ledgerEntries: (snapshot.ledgerEntries ?? []).length,
         processingLogs: (snapshot.processingLogs ?? []).length,
         youthProjectBooks: (snapshot.youthProjectBooks ?? []).length,
+        clientContacts: (snapshot.clientContacts ?? []).length,
+        waitlistEntries: (snapshot.waitlistEntries ?? []).length,
+        animalReservations: (snapshot.animalReservations ?? []).length,
+        woolHarvests: (snapshot.woolHarvests ?? []).length,
       },
       bySpecies: Array.from(bySpeciesMap.values()),
     },
@@ -539,6 +582,10 @@
     ledgerEntries: snapshot.ledgerEntries ?? [],
     processingLogs: snapshot.processingLogs ?? [],
     youthProjectBooks: snapshot.youthProjectBooks ?? [],
+    clientContacts: snapshot.clientContacts ?? [],
+    waitlistEntries: snapshot.waitlistEntries ?? [],
+    animalReservations: snapshot.animalReservations ?? [],
+    woolHarvests: snapshot.woolHarvests ?? [],
   };
   return JSON.stringify(payload, null, 2);
 }
@@ -577,6 +624,10 @@
     { key: 'ledgerEntries', items: snapshot.ledgerEntries ?? [] },
     { key: 'processingLogs', items: snapshot.processingLogs ?? [] },
     { key: 'youthProjectBooks', items: snapshot.youthProjectBooks ?? [] },
+    { key: 'clientContacts', items: snapshot.clientContacts ?? [] },
+    { key: 'waitlistEntries', items: snapshot.waitlistEntries ?? [] },
+    { key: 'animalReservations', items: snapshot.animalReservations ?? [] },
+    { key: 'woolHarvests', items: snapshot.woolHarvests ?? [] },
   ];
 
   for (let sIdx = 0; sIdx < sections.length; sIdx++) {
@@ -1373,6 +1424,129 @@
       } satisfies YouthProjectBook;
     });
 
+  const clientContacts: ClientContact[] = (
+    Array.isArray(raw.clientContacts) ? raw.clientContacts : []
+  )
+    .filter(isObj)
+    .map((cc: any) => ({
+      id: safeId(cc.id),
+      species: sanitizeSingleLineText(cc.species, 100) || 'Rabbit',
+      fullName: sanitizeSingleLineText(cc.fullName || 'Buyer', 140) || 'Buyer',
+      ranchOrHerdName: sanitizeSingleLineText(cc.ranchOrHerdName || '', 160),
+      email: sanitizeSingleLineText(cc.email || '', 160),
+      phone: sanitizeSingleLineText(cc.phone || '', 60),
+      preferredContact: normalizePreferredContactMethod(cc.preferredContact, 'sms'),
+      clientKind: normalizeClientKind(cc.clientKind, 'pet_buyer'),
+      cityState: sanitizeSingleLineText(cc.cityState || '', 120),
+      shippingAddress: sanitizePlainText(cc.shippingAddress || '', 400),
+      tags: Array.isArray(cc.tags)
+        ? cc.tags
+            .filter((t: unknown): t is string => typeof t === 'string' && t.trim().length > 0)
+            .map((t: string) => sanitizeSingleLineText(t, 60))
+            .filter(Boolean)
+        : [],
+      notes: sanitizePlainText(cc.notes || '', 5000),
+      ...(typeof cc._rev === 'number' && Number.isFinite(cc._rev) ? { _rev: Math.floor(cc._rev) } : {}),
+      createdAt: typeof cc.createdAt === 'string' && cc.createdAt ? cc.createdAt : ts,
+      updatedAt: typeof cc.updatedAt === 'string' && cc.updatedAt ? cc.updatedAt : ts,
+    }));
+
+  const waitlistEntries: WaitlistEntry[] = (
+    Array.isArray(raw.waitlistEntries) ? raw.waitlistEntries : []
+  )
+    .filter(isObj)
+    .map((wl: any) => {
+      const reqDate = typeof wl.requestedByDateIso === 'string' ? wl.requestedByDateIso.trim() : '';
+      const inqDate = typeof wl.inquiryDateIso === 'string' ? wl.inquiryDateIso.trim() : '';
+      const fuDate = typeof wl.followUpDateIso === 'string' ? wl.followUpDateIso.trim() : '';
+      const lcDate = typeof wl.lastContactedDateIso === 'string' ? wl.lastContactedDateIso.trim() : '';
+      const rawSex = String(wl.preferredSex || 'Any');
+      const preferredSex: WaitlistEntry['preferredSex'] =
+        rawSex === 'Male' || rawSex === 'Female' ? rawSex : 'Any';
+      return {
+        id: safeId(wl.id),
+        species: sanitizeSingleLineText(wl.species, 100) || 'Rabbit',
+        clientId: typeof wl.clientId === 'string' && isSafeRecordKey(wl.clientId) ? wl.clientId : '',
+        clientName: sanitizeSingleLineText(wl.clientName || 'Buyer', 140),
+        priorityRank: Math.max(1, Math.round(finiteNonNeg(wl.priorityRank, 1))),
+        status: normalizeWaitlistStatus(wl.status, 'Active'),
+        intent: normalizeWaitlistIntent(wl.intent, 'Show / Breeding'),
+        desiredBreed: sanitizeSingleLineText(wl.desiredBreed || '', 120),
+        desiredVariety: sanitizeSingleLineText(wl.desiredVariety || '', 120),
+        preferredSex,
+        ...(typeof wl.preferredBreedingId === 'string' && isSafeRecordKey(wl.preferredBreedingId)
+          ? { preferredBreedingId: wl.preferredBreedingId }
+          : {}),
+        requestedByDateIso: /^\d{4}-\d{2}-\d{2}$/.test(reqDate) ? reqDate : '',
+        inquiryDateIso: /^\d{4}-\d{2}-\d{2}$/.test(inqDate) ? inqDate : todayDateIso(),
+        followUpDateIso: /^\d{4}-\d{2}-\d{2}$/.test(fuDate) ? fuDate : '',
+        lastContactedDateIso: /^\d{4}-\d{2}-\d{2}$/.test(lcDate) ? lcDate : '',
+        ...(wl.maxBudgetCents !== undefined && Number(wl.maxBudgetCents) > 0
+          ? { maxBudgetCents: Math.round(finiteNonNeg(wl.maxBudgetCents, 0)) }
+          : {}),
+        notes: sanitizePlainText(wl.notes || '', 5000),
+        ...(typeof wl._rev === 'number' && Number.isFinite(wl._rev) ? { _rev: Math.floor(wl._rev) } : {}),
+        createdAt: typeof wl.createdAt === 'string' && wl.createdAt ? wl.createdAt : ts,
+        updatedAt: typeof wl.updatedAt === 'string' && wl.updatedAt ? wl.updatedAt : ts,
+      };
+    });
+
+  const animalReservations: AnimalReservation[] = (
+    Array.isArray(raw.animalReservations) ? raw.animalReservations : []
+  )
+    .filter(isObj)
+    .map((ar: any) => {
+      const isoOrEmpty = (val: unknown) =>
+        typeof val === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(val.trim()) ? val.trim() : '';
+      return {
+        id: safeId(ar.id),
+        species: sanitizeSingleLineText(ar.species, 100) || 'Rabbit',
+        agreementNumber: sanitizeSingleLineText(ar.agreementNumber || '', 60),
+        clientId: typeof ar.clientId === 'string' && isSafeRecordKey(ar.clientId) ? ar.clientId : '',
+        clientName: sanitizeSingleLineText(ar.clientName || 'Buyer', 140),
+        ...(typeof ar.waitlistEntryId === 'string' && isSafeRecordKey(ar.waitlistEntryId)
+          ? { waitlistEntryId: ar.waitlistEntryId }
+          : {}),
+        ...(typeof ar.animalId === 'string' && isSafeRecordKey(ar.animalId)
+          ? { animalId: ar.animalId }
+          : {}),
+        ...(typeof ar.breedingId === 'string' && isSafeRecordKey(ar.breedingId)
+          ? { breedingId: ar.breedingId }
+          : {}),
+        ...(ar.pickOrder !== undefined && Number(ar.pickOrder) > 0
+          ? { pickOrder: Math.round(finiteNonNeg(ar.pickOrder, 1)) }
+          : {}),
+        itemLabel: sanitizeSingleLineText(ar.itemLabel || '', 180),
+        status: normalizeReservationStatus(ar.status, 'Pending Deposit'),
+        reservedDateIso: isoOrEmpty(ar.reservedDateIso) || todayDateIso(),
+        holdExpiresDateIso: isoOrEmpty(ar.holdExpiresDateIso),
+        totalPriceCents: Math.round(finiteNonNeg(ar.totalPriceCents, 0)),
+        depositRequiredCents: Math.round(finiteNonNeg(ar.depositRequiredCents, 0)),
+        depositPaidCents: Math.round(finiteNonNeg(ar.depositPaidCents, 0)),
+        depositDueDateIso: isoOrEmpty(ar.depositDueDateIso),
+        depositPaidDateIso: isoOrEmpty(ar.depositPaidDateIso),
+        pickupScheduledDateIso: isoOrEmpty(ar.pickupScheduledDateIso),
+        completedDateIso: isoOrEmpty(ar.completedDateIso),
+        balanceReminderDateIso: isoOrEmpty(ar.balanceReminderDateIso),
+        paymentMethod: sanitizeSingleLineText(ar.paymentMethod || '', 80),
+        ...(typeof ar.ledgerEntryId === 'string' && isSafeRecordKey(ar.ledgerEntryId)
+          ? { ledgerEntryId: ar.ledgerEntryId }
+          : {}),
+        termsSummary: sanitizePlainText(ar.termsSummary || '', 5000),
+        healthGuaranteeNotes: sanitizePlainText(ar.healthGuaranteeNotes || '', 5000),
+        notes: sanitizePlainText(ar.notes || '', 5000),
+        ...(typeof ar._rev === 'number' && Number.isFinite(ar._rev) ? { _rev: Math.floor(ar._rev) } : {}),
+        createdAt: typeof ar.createdAt === 'string' && ar.createdAt ? ar.createdAt : ts,
+        updatedAt: typeof ar.updatedAt === 'string' && ar.updatedAt ? ar.updatedAt : ts,
+      };
+    });
+
+  const woolHarvests: WoolHarvest[] = (
+    Array.isArray(raw.woolHarvests) ? raw.woolHarvests : []
+  )
+    .map((wh: unknown) => normalizeWoolHarvest(wh, settings.defaultSpecies || 'Rabbit'))
+    .filter((wh: WoolHarvest | null): wh is WoolHarvest => Boolean(wh));
+
   return {
     settings,
     speciesProfiles,
@@ -1388,6 +1562,10 @@
     ledgerEntries,
     processingLogs,
     youthProjectBooks,
+    clientContacts,
+    waitlistEntries,
+    animalReservations,
+    woolHarvests,
   };
 }
 
@@ -1446,6 +1624,10 @@
   /** Optional species shows & careLogs so pedigree certificates auto-surface show honors & GC progress. */
   shows?: ShowEvent[];
   careLogs?: CareLog[];
+  /** Optional wool/fiber harvests to summarize fiber yields & IAGARB scores onto pedigrees. */
+  woolHarvests?: WoolHarvest[];
+  /** Optional map of ancestor animalId -> portrait data URL used by `family_portrait` layout. */
+  ancestorPhotosByAnimalId?: Record<string, string>;
 }
 
 /**
@@ -1453,7 +1635,7 @@
  * with Evans Rabbit Register / ARBA breeder sharing conventions and direct PDF printing.
  * Supports 3 through 8 generations, Landscape/Portrait 8.5"x11" sizing, customizable print
  * border/color/layout presets, optional breeder logo, ARBA `lbs.oz` dot weight notation,
- * and embedded primary portrait photo.
+ * multi-photo Family Portrait mode, IAGARB German Angora template, and fiber harvest totals.
  */
 export function generateEvansHtmPedigree(
   subject: Animal,
@@ -1492,6 +1674,17 @@
     slotMap.set(`${sl.generation}:${sl.slotIndex}`, sl);
   }
 
+  const woolHarvestList = printOptions?.woolHarvests ?? [];
+  const woolSummaryByAnimalId =
+    woolHarvestList.length > 0
+      ? buildWoolHarvestSummaryByAnimalId(woolHarvestList)
+      : new Map<string, AnimalWoolSummary>();
+  const subjectWoolSummary =
+    woolHarvestList.length > 0 ? summarizeAnimalWoolHarvests(woolHarvestList, subject.id) : null;
+  const subjectWoolLine = subjectWoolSummary ? formatWoolWeightSummary(subjectWoolSummary) : '';
+
+  const isFamilyPortrait = theme.layoutPreset === 'family_portrait';
+  const isIagarbAngora = theme.layoutPreset === 'iagarb_angora';
   const ultraCompactMode = depth >= 7;
   const compactMode = depth >= 5 || theme.layoutPreset === 'compact_ledger';
   const tightMode = compactMode || (isPortrait && depth >= 4);
@@ -1546,6 +1739,17 @@
       ancShowSummary?.awardsSummaryText ? escapeHtml(ancShowSummary.awardsSummaryText) : '',
     ].filter(Boolean);
 
+    const ancWool = woolSummaryByAnimalId.get(a.id);
+    const ancWoolText =
+      ancWool && (ancWool.harvestCount > 0 || ancWool.highestIagarbScore)
+        ? formatWoolWeightSummary(ancWool, { compact: true })
+        : '';
+
+    const ancSafePhoto =
+      isFamilyPortrait && !compactMode && gen <= 2
+        ? sanitizeSafeRasterImageDataUrl(printOptions?.ancestorPhotosByAnimalId?.[a.id])
+        : '';
+
     if (isTinyLeaf) {
       return `<td rowspan="${rowspan}" class="cell leaf ${idx % 2 === 0 ? 'sire' : 'dam'}">
       <div class="name">${escapeHtml(a.name)}${a.tattoo ? ` <span class="meta">(${escapeHtml(a.tattoo)})</span>` : ''}</div>
@@ -1553,12 +1757,15 @@
     }
 
     return `<td rowspan="${rowspan}" class="cell ${idx % 2 === 0 ? 'sire' : 'dam'}">
+      ${ancSafePhoto ? `<div class="anc-photo-row"><img class="anc-photo" src="${ancSafePhoto}" alt="${escapeHtml(a.name)}" /><div>` : ''}
       <div class="name">${escapeHtml(a.name)}</div>
       ${metaParts.length ? `<div class="meta">${metaParts.join(' &middot; ')}</div>` : ''}
       ${!compactMode && a.birthDateIso ? `<div class="meta">DOB: ${escapeHtml(formatReadableDate(a.birthDateIso))}</div>` : ''}
       ${!compactMode && regParts.length ? `<div class="meta">${regParts.join(' &middot; ')}</div>` : ''}
+      ${!compactMode && ancWoolText ? `<div class="wool-line">${escapeHtml(ancWoolText)}</div>` : ''}
       ${showGenotypes && !compactMode && geno ? `<div class="geno">${escapeHtml(geno)}</div>` : ''}
       ${carrierText ? `<div class="carrier" title="${escapeHtml(fullCarrierText)}">${escapeHtml(carrierText)}</div>` : ''}
+      ${ancSafePhoto ? `</div></div>` : ''}
     </td>`;
   };
 
@@ -1586,6 +1793,97 @@
     includeCleared: true,
   });
   const safePhoto = sanitizeSafeRasterImageDataUrl(primaryPhotoDataUrl);
+
+  const familyPortraitStripHtml = (() => {
+    if (!isFamilyPortrait) return '';
+    const cards: Array<{ label: string; name: string; sub: string; photo: string; role: 'subj' | 'sire' | 'dam' }> = [];
+    cards.push({
+      label: 'Subject',
+      name: subject.name,
+      sub: subject.tattoo || subject.variety || '',
+      photo: safePhoto || sanitizeSafeRasterImageDataUrl(printOptions?.ancestorPhotosByAnimalId?.[subject.id]),
+      role: 'subj',
+    });
+    const gen1Slots: Array<{ idx: number; label: string; role: 'sire' | 'dam' }> = [
+      { idx: 0, label: `Sire (${sp.maleLabel})`, role: 'sire' },
+      { idx: 1, label: `Dam (${sp.femaleLabel})`, role: 'dam' },
+    ];
+    for (const entry of gen1Slots) {
+      const anc = slotMap.get(`1:${entry.idx}`)?.animal;
+      if (anc) {
+        cards.push({
+          label: entry.label,
+          name: anc.name,
+          sub: anc.tattoo || anc.variety || '',
+          photo: sanitizeSafeRasterImageDataUrl(printOptions?.ancestorPhotosByAnimalId?.[anc.id]),
+          role: entry.role,
+        });
+      }
+    }
+    const gen2Labels = ['Pat. Grandsire', 'Pat. Granddam', 'Mat. Grandsire', 'Mat. Granddam'];
+    for (let i = 0; i < 4; i += 1) {
+      const anc = slotMap.get(`2:${i}`)?.animal;
+      if (!anc) continue;
+      const ancPhoto = sanitizeSafeRasterImageDataUrl(printOptions?.ancestorPhotosByAnimalId?.[anc.id]);
+      if (ancPhoto) {
+        cards.push({
+          label: gen2Labels[i],
+          name: anc.name,
+          sub: anc.tattoo || anc.variety || '',
+          photo: ancPhoto,
+          role: i % 2 === 0 ? 'sire' : 'dam',
+        });
+      }
+    }
+    if (cards.length <= 1 && !cards[0]?.photo) return '';
+    return `<div class="family-strip" aria-label="Family Portrait Gallery">
+      ${cards
+        .map(
+          (c) => `<div class="fp-card fp-${c.role}">
+            ${
+              c.photo
+                ? `<img class="fp-img" src="${c.photo}" alt="${escapeHtml(c.name)}" />`
+                : `<div class="fp-placeholder">${escapeHtml((c.name || '?').slice(0, 2).toUpperCase())}</div>`
+            }
+            <div class="fp-role">${escapeHtml(c.label)}</div>
+            <div class="fp-name">${escapeHtml(c.name)}</div>
+            ${c.sub ? `<div class="fp-sub">${escapeHtml(c.sub)}</div>` : ''}
+          </div>`
+        )
+        .join('')}
+    </div>`;
+  })();
+
+  const iagarbSectionHtml = (() => {
+    if (!isIagarbAngora) return '';
+    const bestScore = subjectWoolSummary?.highestIagarbScore ?? subjectWoolSummary?.latestIagarbScore ?? null;
+    const totalPrime = subjectWoolSummary?.primeGrams ?? 0;
+    const totalGrade = subjectWoolSummary?.gradeGrams ?? 0;
+    const avg90 = subjectWoolSummary?.average90DayRateGrams;
+    const eligText = subjectWoolSummary?.eligibility.statusLabel || 'Log wool harvests & IAGARB score to verify qualification';
+    const scoreCells = IAGARB_JUDGING_POSITIONS.map((pos) => {
+      const val = bestScore ? bestScore[pos.key] : null;
+      return `<div class="iag-pos">
+        <div class="iag-lbl">${escapeHtml(pos.label)}</div>
+        <div class="iag-val">${val !== null ? `${val} / ${pos.maxPoints}` : `&mdash; / ${pos.maxPoints}`}</div>
+      </div>`;
+    }).join('');
+    return `<div class="iagarb-panel">
+      <div class="iag-head">
+        <div><strong>IAGARB German Angora Wool &amp; Evaluation Standard</strong> (Reg min: ${IAGARB_REGISTRATION_MIN_POINTS}/100 pts &middot; 90-day yield min: ${IAGARB_MIN_90_DAY_WOOL_GRAMS}g)</div>
+        <div class="iag-status">${escapeHtml(eligText)}</div>
+      </div>
+      <div class="iag-stats">
+        <div><strong>Logged Harvests:</strong> ${subjectWoolSummary?.harvestCount ?? 0}</div>
+        <div><strong>Prime Fiber:</strong> ${totalPrime}g</div>
+        <div><strong>Grade Fiber:</strong> ${totalGrade}g</div>
+        <div><strong>Total Yield:</strong> ${subjectWoolSummary?.totalGrams ?? 0}g</div>
+        <div><strong>90-Day Rate:</strong> ${avg90 !== null && avg90 !== undefined ? `${avg90}g` : 'N/A'}</div>
+        <div><strong>Total IAGARB Score:</strong> ${bestScore ? `${bestScore.totalPts} / 100 pts` : 'Not Scored'}</div>
+      </div>
+      <div class="iag-grid">${scoreCells}</div>
+    </div>`;
+  })();
 
   const genHeaders: string[] = [
     '<th>Parents (Gen 1)</th>',
@@ -1615,6 +1913,12 @@
     theme.borderStyle === 'minimal_lines'
       ? `0.75px solid ${theme.cellBorderHex}`
       : `1px solid ${theme.cellBorderHex}`;
+
+  const certSubtitle = isIagarbAngora
+    ? `IAGARB German Angora ${depth}-Generation Wool &amp; Evaluation Pedigree`
+    : isFamilyPortrait
+    ? `Family Portrait ${depth}-Generation ${escapeHtml(subject.species)} Pedigree`
+    : `Official ${depth}-Generation ${escapeHtml(subject.species)} Pedigree Certificate`;
 
   return `<!DOCTYPE html>
 <html lang="en">
@@ -1637,6 +1941,27 @@
   .subject-wrap { ${subjectBorderCss} padding: ${theme.layoutPreset === 'compact_ledger' ? '5px 9px' : isPortrait ? '8px 11px' : '10px 14px'}; margin-bottom: ${theme.layoutPreset === 'compact_ledger' ? '6px' : '10px'}; background: #ffffff; display: flex; align-items: center; gap: ${isPortrait ? '12px' : '16px'}; }
   .subject-photo { width: ${theme.layoutPreset === 'compact_ledger' ? '58px' : isPortrait ? '72px' : '84px'}; height: ${theme.layoutPreset === 'compact_ledger' ? '58px' : isPortrait ? '72px' : '84px'}; object-fit: cover; border-radius: 6px; border: 1px solid ${theme.cellBorderHex}; flex-shrink: 0; }
   .subject-box { display: flex; flex-wrap: wrap; gap: ${theme.layoutPreset === 'compact_ledger' ? '4px 12px' : isPortrait ? '6px 14px' : '8px 18px'}; font-size: ${theme.layoutPreset === 'compact_ledger' ? '10.5px' : isPortrait ? '11.5px' : '12.5px'}; flex: 1; }
+  .family-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(105px, 1fr)); gap: 8px; margin-bottom: 10px; }
+  .fp-card { border: 1px solid ${theme.cellBorderHex}; border-radius: 6px; padding: 6px; text-align: center; background: #ffffff; }
+  .fp-card.fp-subj { border-top: 3px solid ${theme.primaryHex}; }
+  .fp-card.fp-sire { border-top: 3px solid ${theme.sireHex}; }
+  .fp-card.fp-dam { border-top: 3px solid ${theme.damHex}; }
+  .fp-img { width: 58px; height: 58px; object-fit: cover; border-radius: 6px; border: 1px solid ${theme.cellBorderHex}; display: block; margin: 0 auto 4px auto; }
+  .fp-placeholder { width: 58px; height: 58px; border-radius: 6px; border: 1px dashed ${theme.cellBorderHex}; display: flex; align-items: center; justify-content: center; margin: 0 auto 4px auto; font-weight: bold; font-size: 16px; color: ${theme.mutedInkHex}; }
+  .fp-role { font-family: Arial, Helvetica, sans-serif; font-size: 8.5px; text-transform: uppercase; color: ${theme.mutedInkHex}; }
+  .fp-name { font-size: 10.5px; font-weight: bold; color: ${theme.inkHex}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
+  .fp-sub { font-size: 9px; color: ${theme.mutedInkHex}; }
+  .iagarb-panel { border: 1.5px solid ${theme.borderHex}; border-radius: 6px; padding: 7px 10px; margin-bottom: 10px; font-family: Arial, Helvetica, sans-serif; background: #ffffff; }
+  .iag-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px; font-size: 10.5px; border-bottom: 1px solid ${theme.cellBorderHex}; padding-bottom: 4px; margin-bottom: 5px; }
+  .iag-status { font-weight: bold; color: ${theme.primaryHex}; }
+  .iag-stats { display: flex; flex-wrap: wrap; gap: 4px 14px; font-size: 10px; margin-bottom: 6px; }
+  .iag-grid { display: grid; grid-template-columns: repeat(7, minmax(0, 1fr)); gap: 4px; }
+  .iag-pos { border: 1px solid ${theme.cellBorderHex}; border-radius: 4px; padding: 3px 5px; text-align: center; }
+  .iag-lbl { font-size: 8.5px; color: ${theme.mutedInkHex}; }
+  .iag-val { font-size: 10.5px; font-weight: bold; color: ${theme.inkHex}; margin-top: 1px; }
+  .anc-photo-row { display: flex; align-items: flex-start; gap: 6px; }
+  .anc-photo { width: 34px; height: 34px; object-fit: cover; border-radius: 4px; border: 1px solid ${theme.cellBorderHex}; flex-shrink: 0; }
+  .wool-line { color: ${theme.primaryHex}; font-family: Arial, Helvetica, sans-serif; font-size: 9px; font-weight: bold; margin-top: 1px; }
   table.pedigree { width: 100%; border-collapse: collapse; table-layout: fixed; background: #ffffff; }
   table.pedigree thead { display: table-header-group; }
   table.pedigree tr { break-inside: avoid; page-break-inside: avoid; }
@@ -1656,7 +1981,7 @@
   .footer-contact { width: 100%; font-size: 10.5px; color: ${theme.primaryHex}; font-weight: bold; }
   @media print {
     body { max-width: none; margin: 0; }
-    :root, html, body, .pedigree-frame, .header, .subject-wrap, table.pedigree, table.pedigree th, td.cell, td.sire, td.dam, td.empty, .genetics-notice, .footer {
+    :root, html, body, .pedigree-frame, .header, .subject-wrap, .family-strip, .fp-card, .iagarb-panel, .iag-pos, table.pedigree, table.pedigree th, td.cell, td.sire, td.dam, td.empty, .genetics-notice, .footer {
       color-scheme: light only !important;
       background: #ffffff !important;
       background-color: #ffffff !important;
@@ -1676,7 +2001,7 @@
         ${safeLogo ? `<img class="barn-logo" src="${safeLogo}" alt="${escapeHtml(settings.barnName || 'Barn Logo')}" />` : ''}
         <div>
           <div class="barn-title">${escapeHtml(settings.barnName || 'Community Pedigree')}</div>
-          <div class="sub-title">Official ${depth}-Generation ${escapeHtml(subject.species)} Pedigree Certificate${settings.breederName ? ` &middot; Breeder: ${escapeHtml(settings.breederName)}` : ''}</div>
+          <div class="sub-title">${certSubtitle}${settings.breederName ? ` &middot; Breeder: ${escapeHtml(settings.breederName)}` : ''}</div>
         </div>
       </div>
       <div class="sub-title">Generated ${escapeHtml(formatReadableDate(nowIsoUtc().slice(0, 10)))} &middot; Wright COI: ${coi.coiPercent.toFixed(2)}% (${escapeHtml(coi.risk.label)})</div>
@@ -1712,11 +2037,15 @@
           }
           return parts.join('\n        ');
         })()}
+        ${subjectWoolLine ? `<div><strong>Wool / Fiber:</strong> ${escapeHtml(subjectWoolLine)}</div>` : ''}
         ${subject.rufusLevel ? `<div><strong>Rufus Intensity:</strong> ${escapeHtml(subject.rufusLevel)}</div>` : ''}
         ${showGenotypes && subjectGeno ? `<div><strong>Genotype:</strong> <code>${escapeHtml(subjectGeno)}</code></div>` : ''}
         ${subjectCarriers ? `<div><strong>Carrier Disclosures:</strong> ${escapeHtml(subjectCarriers)}</div>` : ''}
       </div>
     </div>
+
+    ${familyPortraitStripHtml}
+    ${iagarbSectionHtml}
 
     <table class="pedigree">
       <thead>
@@ -1794,6 +2123,18 @@
   );
   const youthProjectBooks = (snapshot.youthProjectBooks ?? []).filter((yp) =>
     isSameSpecies(yp.species, speciesName)
+  );
+  const clientContacts = (snapshot.clientContacts ?? []).filter((cc) =>
+    isSameSpecies(cc.species, speciesName)
+  );
+  const waitlistEntries = (snapshot.waitlistEntries ?? []).filter((wl) =>
+    isSameSpecies(wl.species, speciesName)
+  );
+  const animalReservations = (snapshot.animalReservations ?? []).filter((ar) =>
+    isSameSpecies(ar.species, speciesName)
+  );
+  const woolHarvests = (snapshot.woolHarvests ?? []).filter(
+    (wh) => isSameSpecies(wh.species, speciesName) || animalIds.has(wh.animalId)
   );
 
   return exportBarnBackupJson(
@@ -1812,6 +2153,10 @@
       ledgerEntries,
       processingLogs,
       youthProjectBooks,
+      clientContacts,
+      waitlistEntries,
+      animalReservations,
+      woolHarvests,
     },
     {
       backupScope: 'species',
```

### `src/core/syncOutbox.ts` (`+49` / `-1`, source: `part-11.md`)

```diff
--- working/src/core/syncOutbox.ts
+++ import/src/core/syncOutbox.ts
@@ -18,12 +18,14 @@
 import {
   Animal,
   AnimalPhoto,
+  AnimalReservation,
   BarnDatabaseSnapshot,
   BarnSettings,
   BarnTask,
   BreedingRecord,
   CageLocation,
   CareLog,
+  ClientContact,
   FeedAllocation,
   FeedBatch,
   generateUuid,
@@ -33,6 +35,8 @@
   ProcessingLog,
   ShowEvent,
   SpeciesProfile,
+  WaitlistEntry,
+  WoolHarvest,
   YouthProjectBook,
 } from './models';
 import { normalizeShowResults, mergeEnteredAnimalIdsWithResults } from './showResults';
@@ -58,7 +62,11 @@
   | 'feedAllocation'
   | 'ledgerEntry'
   | 'processingLog'
-  | 'youthProjectBook';
+  | 'youthProjectBook'
+  | 'clientContact'
+  | 'waitlistEntry'
+  | 'animalReservation'
+  | 'woolHarvest';
 
 export interface SyncOperation {
   op_id: string;
@@ -336,6 +344,10 @@
   diffCollection('ledgerEntry', params.previous.ledgerEntries ?? [], params.next.ledgerEntries ?? []);
   diffCollection('processingLog', params.previous.processingLogs ?? [], params.next.processingLogs ?? []);
   diffCollection('youthProjectBook', params.previous.youthProjectBooks ?? [], params.next.youthProjectBooks ?? []);
+  diffCollection('clientContact', params.previous.clientContacts ?? [], params.next.clientContacts ?? []);
+  diffCollection('waitlistEntry', params.previous.waitlistEntries ?? [], params.next.waitlistEntries ?? []);
+  diffCollection('animalReservation', params.previous.animalReservations ?? [], params.next.animalReservations ?? []);
+  diffCollection('woolHarvest', params.previous.woolHarvests ?? [], params.next.woolHarvests ?? []);
 
   if (params.includeSettings) {
     ops.push(
@@ -407,6 +419,22 @@
     const yp = (snapshot.youthProjectBooks ?? []).find((x) => x.id === uuid);
     return yp ? yp.projectTitle : uuid;
   }
+  if (type === 'clientContact') {
+    const cc = (snapshot.clientContacts ?? []).find((x) => x.id === uuid);
+    return cc ? cc.fullName : uuid;
+  }
+  if (type === 'waitlistEntry') {
+    const wl = (snapshot.waitlistEntries ?? []).find((x) => x.id === uuid);
+    return wl ? `${wl.clientName || 'Waitlist'} (#${wl.priorityRank})` : uuid;
+  }
+  if (type === 'animalReservation') {
+    const ar = (snapshot.animalReservations ?? []).find((x) => x.id === uuid);
+    return ar ? `${ar.agreementNumber || ar.clientName || uuid}` : uuid;
+  }
+  if (type === 'woolHarvest') {
+    const wh = (snapshot.woolHarvests ?? []).find((x) => x.id === uuid);
+    return wh ? `Wool Harvest (${wh.harvestDateIso})` : uuid;
+  }
   if (type === 'settings') return 'Barn Settings';
   return uuid;
 }
@@ -470,6 +498,10 @@
   const ledgerEntries = getCollectionMap<LedgerEntry>(localSnapshot.ledgerEntries ?? []);
   const processingLogs = getCollectionMap<ProcessingLog>(localSnapshot.processingLogs ?? []);
   const youthProjectBooks = getCollectionMap<YouthProjectBook>(localSnapshot.youthProjectBooks ?? []);
+  const clientContacts = getCollectionMap<ClientContact>(localSnapshot.clientContacts ?? []);
+  const waitlistEntries = getCollectionMap<WaitlistEntry>(localSnapshot.waitlistEntries ?? []);
+  const animalReservations = getCollectionMap<AnimalReservation>(localSnapshot.animalReservations ?? []);
+  const woolHarvests = getCollectionMap<WoolHarvest>(localSnapshot.woolHarvests ?? []);
   const speciesProfiles = getCollectionMap<SpeciesProfile>(localSnapshot.speciesProfiles);
   let settings: BarnSettings = { ...localSnapshot.settings };
 
@@ -641,6 +673,18 @@
       case 'youthProjectBook':
         applyToMap(youthProjectBooks);
         break;
+      case 'clientContact':
+        applyToMap(clientContacts);
+        break;
+      case 'waitlistEntry':
+        applyToMap(waitlistEntries);
+        break;
+      case 'animalReservation':
+        applyToMap(animalReservations);
+        break;
+      case 'woolHarvest':
+        applyToMap(woolHarvests);
+        break;
       case 'species':
         applyToMap(speciesProfiles);
         break;
@@ -685,6 +729,10 @@
       ledgerEntries: Array.from(ledgerEntries.values()),
       processingLogs: Array.from(processingLogs.values()),
       youthProjectBooks: Array.from(youthProjectBooks.values()),
+      clientContacts: Array.from(clientContacts.values()),
+      waitlistEntries: Array.from(waitlistEntries.values()),
+      animalReservations: Array.from(animalReservations.values()),
+      woolHarvests: Array.from(woolHarvests.values()),
     },
     mergedOperations: allOpsSorted,
     newConflicts,
```

### `src/core/upgradeGate.ts` (`+1` / `-1`, source: `part-12.md`)

```diff
--- working/src/core/upgradeGate.ts
+++ import/src/core/upgradeGate.ts
@@ -12,7 +12,7 @@
 import { CURRENT_BACKUP_SCHEMA_VERSION } from './backupVault';
 import { nowEpochMs } from './models';
 
-export const CURRENT_APP_VERSION = '0.1.0-alpha.2';
+export const CURRENT_APP_VERSION = '0.1.0-prealpha.1';
 
 export interface VersionManifest {
   appVersion: string;
```

### `src/hooks/useBarnStore.ts` (`+929` / `-31`, source: `part-14.md`)

```diff
--- working/src/hooks/useBarnStore.ts
+++ import/src/hooks/useBarnStore.ts
@@ -47,6 +47,7 @@
   Animal,
   AnimalConflictKind,
   AnimalPhoto,
+  AnimalReservation,
   applyAnimalNamePrefix,
   BarnDatabaseSnapshot,
   BarnSettings,
@@ -54,6 +55,7 @@
   BreedingRecord,
   CageLocation,
   CareLog,
+  ClientContact,
   FeedAllocation,
   FeedBatch,
   FeedPurgeWindowDays,
@@ -64,6 +66,7 @@
   LitterWeightMilestone,
   normalizeBreedScheduleOverrides,
   normalizeCalendarSyncSettings,
+  normalizeClientKind,
   normalizeDefaultPedigreeGenerations,
   normalizeFeedPurgeWindowDays,
   normalizeIgnoredConflicts,
@@ -71,12 +74,16 @@
   normalizeLedgerEntryType,
   normalizeLitterWeightMilestones,
   normalizePeltGrade,
+  normalizePreferredContactMethod,
   normalizeProcessingStatus,
+  normalizeReservationStatus,
   normalizeRufusLevel,
   normalizeServiceFeeDirection,
   normalizeSpeciesHubBlockOrder,
   normalizeTargetWeightCurve,
   normalizeUltrasoundResult,
+  normalizeWaitlistIntent,
+  normalizeWaitlistStatus,
   normalizeYouthOrgType,
   normalizeYouthProjectFeedLogs,
   PedigreeGenerationDepth,
@@ -90,8 +97,16 @@
   TargetWeightPoint,
   todayDateIso,
   UltrasoundResult,
+  WaitlistEntry,
+  WoolHarvest,
   YouthProjectBook,
 } from '../core/models';
+import { normalizeWoolHarvest } from '../core/woolFiber';
+import {
+  buildSuggestedAgreementNumber,
+  CrmFollowUpReminder,
+  evaluateReservationFinancials,
+} from '../core/clientCrm';
 import { calculateDressOutPercent } from '../core/economicsLedger';
 import {
   applyFeedAllocationToBatch,
@@ -305,6 +320,7 @@
   | 'pedigree'
   | 'feed'
   | 'economics'
+  | 'crm'
   | 'reports'
   | 'memo'
   | 'importExport'
@@ -312,6 +328,15 @@
   | 'techyStuff'
   | 'prompts'
   | 'suggestions';
+
+const NON_SPECIES_ROUTES: ReadonlySet<WorkspaceRoute> = new Set([
+  'home',
+  'settings',
+  'importExport',
+  'techyStuff',
+  'prompts',
+  'suggestions',
+]);
 
 export type BreedingTaskCheckoffAction =
   | { kind: 'palpated_positive' }
@@ -349,6 +374,10 @@
   ledgerEntries: LedgerEntry[];
   processingLogs: ProcessingLog[];
   youthProjectBooks: YouthProjectBook[];
+  clientContacts: ClientContact[];
+  waitlistEntries: WaitlistEntry[];
+  animalReservations: AnimalReservation[];
+  woolHarvests: WoolHarvest[];
   testingRecordCount: number;
   nonTestingRecordCount: number;
   totalRecordCount: number;
@@ -444,14 +473,27 @@
     readOpfsPruneSyncWarning()
   );
 
+  const maxRevByEntityRef = useRef<Map<string, number>>(new Map());
+
+  const rebuildMaxRevIndex = useCallback((ops: SyncOperation[]) => {
+    const next = new Map<string, number>();
+    for (const op of ops) {
+      if (typeof op.record_rev === 'number' && Number.isFinite(op.record_rev)) {
+        const prev = next.get(op.entity_uuid) ?? 0;
+        if (op.record_rev > prev) {
+          next.set(op.entity_uuid, op.record_rev);
+        }
+      }
+    }
+    maxRevByEntityRef.current = next;
+  }, []);
+
   const nextEntityRev = useCallback((entityUuid: string, currentRev?: number): number => {
-    let maxSeen = typeof currentRev === 'number' && Number.isFinite(currentRev) ? currentRev : 0;
-    for (const op of syncOperationsRef.current) {
-      if (op.entity_uuid === entityUuid && typeof op.record_rev === 'number' && op.record_rev > maxSeen) {
-        maxSeen = op.record_rev;
-      }
-    }
-    return bumpRecordRevision({ _rev: maxSeen });
+    const current = typeof currentRev === 'number' && Number.isFinite(currentRev) ? currentRev : 0;
+    const indexed = maxRevByEntityRef.current.get(entityUuid) ?? 0;
+    const nextRev = bumpRecordRevision({ _rev: Math.max(current, indexed) });
+    maxRevByEntityRef.current.set(entityUuid, nextRev);
+    return nextRev;
   }, []);
 
   const enqueueStoreMutation = useCallback(<T,>(task: () => Promise<T>): Promise<T> => {
@@ -538,6 +580,14 @@
   const recordOutboxOps = useCallback(async (ops: SyncOperation[]) => {
     if (ops.length === 0) return;
     const writtenOps = await appendSyncOperationsToIdb(ops);
+    for (const op of writtenOps) {
+      if (typeof op.record_rev === 'number' && Number.isFinite(op.record_rev)) {
+        const prev = maxRevByEntityRef.current.get(op.entity_uuid) ?? 0;
+        if (op.record_rev > prev) {
+          maxRevByEntityRef.current.set(op.entity_uuid, op.record_rev);
+        }
+      }
+    }
     const nextOps = [...syncOperationsRef.current, ...writtenOps];
     syncOperationsRef.current = nextOps;
     setSyncOperations(nextOps);
@@ -546,6 +596,7 @@
   const clearLocalSyncAndBackupReminderState = useCallback(async () => {
     await clearAllSyncStateInIdb();
     clearPausedBackgroundJob('directory_sync');
+    maxRevByEntityRef.current.clear();
     syncOperationsRef.current = [];
     setSyncOperations([]);
     syncConflictsRef.current = [];
@@ -725,8 +776,13 @@
     }, 0);
   }, [route]);
 
-  // Monitor Google Calendar auth state (access token is kept strictly in memory)
+  const calendarDeliveryMode = snapshot?.settings.calendarSync?.deliveryMode;
+
+  // Monitor Google Calendar auth state lazily only when Google Calendar delivery is enabled
   useEffect(() => {
+    if (calendarDeliveryMode !== 'google_calendar') {
+      return undefined;
+    }
     return initGoogleCalendarAuth(
       (user) => {
         setGoogleAuthConnected(true);
@@ -737,7 +793,7 @@
         setGoogleUserEmail(user?.email || null);
       }
     );
-  }, []);
+  }, [calendarDeliveryMode]);
 
   // Initialize local SQLite / IndexedDB store + request persistent storage lock + load outbox
   useEffect(() => {
@@ -842,6 +898,8 @@
         setWipedRecoveryContext(detectedWiped && detectedWiped.detected ? detectedWiped : null);
         setPedigreeGenerations(initial.settings.defaultGenerations);
         setStorageStatus(persistedStatus);
+        rebuildMaxRevIndex(ops);
+        syncOperationsRef.current = ops;
         setSyncOperations(ops);
         setSyncConflicts(conflicts);
         void refreshVaultAndArchives();
@@ -1031,6 +1089,10 @@
    */
   const selectSpeciesWorkspace = useCallback(
     (speciesName: string, targetRoute: WorkspaceRoute = 'dashboard') => {
+      if (!isSameSpecies(speciesName, activeSpeciesName)) {
+        pedigreeAncestorCacheRef.current.clear();
+        loadedPedigreeArchiveKeysRef.current.clear();
+      }
       setActiveSpeciesName(speciesName);
       setSelectedAnimalId(null);
       setPedigreeAnimalId(null);
@@ -1040,16 +1102,48 @@
         window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
       }
     },
-    []
-  );
+    [activeSpeciesName]
+  );
+
+  const isNonSpeciesRoute = NON_SPECIES_ROUTES.has(route);
 
   /**
    * Strictly species-isolated slice of all records for `activeSpeciesName`.
-   * Decoupled from `route` so navigating between screens never re-filters/re-sorts herd records.
+   * Skips heavy filtering/sorting when on non-species routes (`home`, `settings`, etc.)
+   * and avoids re-evaluating across species-tab switches.
    */
   const baseSpeciesData = useMemo(() => {
     if (!snapshot) return null;
     const speciesProfile = resolveSpeciesProfile(activeSpeciesName, snapshot.speciesProfiles);
+    if (isNonSpeciesRoute) {
+      return {
+        speciesProfile,
+        animals: [],
+        activeAnimals: [],
+        archivedAnimals: [],
+        animalPhotos: [],
+        photosByAnimalId: new Map<string, AnimalPhoto[]>(),
+        primaryPhotoByAnimalId: new Map<string, AnimalPhoto>(),
+        herdById: new Map<string, Animal>(),
+        cages: [],
+        breedings: [],
+        tasks: [],
+        careLogs: [],
+        shows: [],
+        feedBatches: [],
+        feedAllocations: [],
+        ledgerEntries: [],
+        processingLogs: [],
+        youthProjectBooks: [],
+        clientContacts: [],
+        waitlistEntries: [],
+        animalReservations: [],
+        woolHarvests: [],
+        testingRecordCount: 0,
+        nonTestingRecordCount: 0,
+        totalRecordCount: 0,
+      };
+    }
     const animals = snapshot.animals
       .filter((a) => isSameSpecies(a.species, speciesProfile.name))
       .sort((a, b) => a.name.localeCompare(b.name));
@@ -1144,6 +1238,35 @@
         (b.projectYear || '').localeCompare(a.projectYear || '') ||
         (b.startDateIso || '').localeCompare(a.startDateIso || '') ||
         b.createdAt.localeCompare(a.createdAt)
+      );
+
+    const clientContacts = (snapshot.clientContacts ?? [])
+      .filter((c) => isSameSpecies(c.species, speciesProfile.name))
+      .sort((a, b) => a.fullName.localeCompare(b.fullName));
+
+    const waitlistEntries = (snapshot.waitlistEntries ?? [])
+      .filter((w) => isSameSpecies(w.species, speciesProfile.name))
+      .sort(
+        (a, b) =>
+          (a.priorityRank || 9999) - (b.priorityRank || 9999) ||
+          (a.inquiryDateIso || '').localeCompare(b.inquiryDateIso || '') ||
+          a.createdAt.localeCompare(b.createdAt)
+      );
+
+    const animalReservations = (snapshot.animalReservations ?? [])
+      .filter((r) => isSameSpecies(r.species, speciesProfile.name))
+      .sort(
+        (a, b) =>
+          (b.reservedDateIso || '').localeCompare(a.reservedDateIso || '') ||
+          b.createdAt.localeCompare(a.createdAt)
+      );
+
+    const woolHarvests = (snapshot.woolHarvests ?? [])
+      .filter((w) => isSameSpecies(w.species, speciesProfile.name))
+      .sort(
+        (a, b) =>
+          (b.harvestDateIso || '').localeCompare(a.harvestDateIso || '') ||
+          b.createdAt.localeCompare(a.createdAt)
       );
 
     const testingRecordCount = countSpeciesTestingRecords(snapshot, speciesProfile.name);
@@ -1169,14 +1292,18 @@
       ledgerEntries,
       processingLogs,
       youthProjectBooks,
+      clientContacts,
+      waitlistEntries,
+      animalReservations,
+      woolHarvests,
       testingRecordCount,
       nonTestingRecordCount,
       totalRecordCount,
     };
-  }, [snapshot, activeSpeciesName]);
+  }, [snapshot, activeSpeciesName, isNonSpeciesRoute]);
 
   const conflictsBySpeciesAnimalId = useMemo(() => {
-    if (!baseSpeciesData) {
+    if (!baseSpeciesData || baseSpeciesData.animals.length === 0) {
       return {
         map: new Map<string, AnimalConflictSummary>(),
         conflictedAnimalCount: 0,
@@ -1195,15 +1322,24 @@
 
   const coiByAnimalId = useMemo(() => {
     const map = new Map<string, CoiAnalysis>();
-    if (!baseSpeciesData) return map;
-    if (route === 'herd' || route === 'pedigree' || route === 'breeding') {
-      const evaluator = createSpeciesCoiEvaluator(baseSpeciesData.herdById);
-      for (const animal of baseSpeciesData.animals) {
-        map.set(animal.id, evaluator.calculateAnimalCoi(animal));
+    if (!baseSpeciesData || baseSpeciesData.animals.length === 0) return map;
+    if (route === 'pedigree') {
+      const target =
+        (pedigreeAnimalId ? baseSpeciesData.herdById.get(pedigreeAnimalId) : undefined) ??
+        baseSpeciesData.animals[0];
+      if (target) {
+        const evaluator = createSpeciesCoiEvaluator(baseSpeciesData.herdById);
+        map.set(target.id, evaluator.calculateAnimalCoi(target));
+      }
+    } else if (route === 'herd' && selectedAnimalId) {
+      const target = baseSpeciesData.herdById.get(selectedAnimalId);
+      if (target) {
+        const evaluator = createSpeciesCoiEvaluator(baseSpeciesData.herdById);
+        map.set(target.id, evaluator.calculateAnimalCoi(target));
       }
     }
     return map;
-  }, [baseSpeciesData, route]);
+  }, [baseSpeciesData, route, pedigreeAnimalId, selectedAnimalId]);
 
   const activeSpeciesData: ActiveSpeciesData | null = useMemo(() => {
     if (!baseSpeciesData) return null;
@@ -1567,6 +1703,7 @@
     snapshotRef.current = fresh;
     setSnapshot(fresh);
     setPedigreeGenerations(fresh.settings.defaultGenerations);
+    rebuildMaxRevIndex(freshOps);
     syncOperationsRef.current = freshOps;
     setSyncOperations(freshOps);
     syncConflictsRef.current = freshConflicts;
@@ -1610,6 +1747,8 @@
       id: 'barn-store-photo-cache-trim',
       onHidden: () => {
         photoCacheRef.current?.clear();
+        pedigreeAncestorCacheRef.current.clear();
+        loadedPedigreeArchiveKeysRef.current.clear();
       },
       onVisible: () => {
         if (isLoading) return;
@@ -2001,6 +2140,33 @@
                 ),
                 shows: currentSnapshot.shows.map((s) =>
                   isSameSpecies(s.species, oldName) ? { ...s, species: newName, updatedAt: ts } : s
+                ),
+                feedBatches: (currentSnapshot.feedBatches ?? []).map((fb) =>
+                  isSameSpecies(fb.species, oldName) ? { ...fb, species: newName, updatedAt: ts } : fb
+                ),
+                feedAllocations: (currentSnapshot.feedAllocations ?? []).map((fa) =>
+                  isSameSpecies(fa.species, oldName) ? { ...fa, species: newName, updatedAt: ts } : fa
+                ),
+                ledgerEntries: (currentSnapshot.ledgerEntries ?? []).map((le) =>
+                  isSameSpecies(le.species, oldName) ? { ...le, species: newName, updatedAt: ts } : le
+                ),
+                processingLogs: (currentSnapshot.processingLogs ?? []).map((pl) =>
+                  isSameSpecies(pl.species, oldName) ? { ...pl, species: newName, updatedAt: ts } : pl
+                ),
+                youthProjectBooks: (currentSnapshot.youthProjectBooks ?? []).map((yp) =>
+                  isSameSpecies(yp.species, oldName) ? { ...yp, species: newName, updatedAt: ts } : yp
+                ),
+                clientContacts: (currentSnapshot.clientContacts ?? []).map((c) =>
+                  isSameSpecies(c.species, oldName) ? { ...c, species: newName, updatedAt: ts } : c
+                ),
+                waitlistEntries: (currentSnapshot.waitlistEntries ?? []).map((w) =>
+                  isSameSpecies(w.species, oldName) ? { ...w, species: newName, updatedAt: ts } : w
+                ),
+                animalReservations: (currentSnapshot.animalReservations ?? []).map((r) =>
+                  isSameSpecies(r.species, oldName) ? { ...r, species: newName, updatedAt: ts } : r
+                ),
+                woolHarvests: (currentSnapshot.woolHarvests ?? []).map((w) =>
+                  isSameSpecies(w.species, oldName) ? { ...w, species: newName, updatedAt: ts } : w
                 ),
               };
               await adapterRef.current!.replaceSnapshot(renamedSnapshot);
@@ -4244,17 +4410,25 @@
           mimeType: 'text/calendar',
           title: filenameHint || `${snapshot.settings.barnName} Barn Chores`,
           text: 'Import barn chore into your calendar app',
-        }).then((outcome) => {
-          notify(
-            outcome === 'shared'
-              ? `Opened external calendar handoff for ${ics.eventCount} event${
-                  ics.eventCount === 1 ? '' : 's'
-                }.`
-              : `Saved ${ics.eventCount} event${
-                  ics.eventCount === 1 ? '' : 's'
-                } (.ICS) — open file to add to Outlook, Apple, or system calendar.`
-          );
-        });
+        })
+          .then((outcome) => {
+            if (outcome === 'cancelled') {
+              notify('Calendar share cancelled.');
+              return;
+            }
+            notify(
+              outcome === 'shared'
+                ? `Opened external calendar handoff for ${ics.eventCount} event${
+                    ics.eventCount === 1 ? '' : 's'
+                  }.`
+                : `Saved ${ics.eventCount} event${
+                    ics.eventCount === 1 ? '' : 's'
+                  } (.ICS) — open file to add to Outlook, Apple, or system calendar.`
+            );
+          })
+          .catch((err) => {
+            reportPersistenceFailure('share .ICS calendar file', err);
+          });
         return ics.eventCount;
       }
 
@@ -5624,6 +5798,706 @@
     ]
   );
 
+  const saveClientContact = useCallback(
+    async (
+      draft: Omit<ClientContact, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
+    ): Promise<string | null> => {
+      return enqueueStoreMutation(async () => {
+        const latestSnapshot = snapshotRef.current ?? snapshot;
+        const ts = getAdjustedNowIsoUtc();
+        const prev = draft.id
+          ? (latestSnapshot?.clientContacts ?? []).find((x) => x.id === draft.id)
+          : undefined;
+        const id = draft.id || generateUuid();
+        const rev = nextEntityRev(id, prev?._rev);
+        const cleanTags = Array.isArray(draft.tags)
+          ? Array.from(new Set(draft.tags.map((t) => t.trim()).filter(Boolean)))
+          : [];
+        const contact: ClientContact = {
+          ...draft,
+          id,
+          fullName: (draft.fullName || '').trim() || 'Buyer',
+          ranchOrHerdName: (draft.ranchOrHerdName || '').trim(),
+          email: (draft.email || '').trim(),
+          phone: (draft.phone || '').trim(),
+          preferredContact: normalizePreferredContactMethod(draft.preferredContact, 'sms'),
+          clientKind: normalizeClientKind(draft.clientKind, 'pet_buyer'),
+          cityState: (draft.cityState || '').trim(),
+          shippingAddress: (draft.shippingAddress || '').trim(),
+          tags: cleanTags,
+          notes: (draft.notes || '').trim(),
+          _rev: rev,
+          createdAt: prev?.createdAt || ts,
+          updatedAt: ts,
+        };
+        try {
+          await adapterRef.current!.saveClientContact(contact);
+          await recordOutboxOps(
+            diffEntityFieldsToOperations({
+              entityType: 'clientContact',
+              previous: prev,
+              next: contact,
+              deviceId,
+              nextCounter: allocateNextLogicalCounter,
+              timestamp: ts,
+              recordRev: rev,
+            })
+          );
+          await reloadFromAdapter();
+          notify(`Saved client contact: ${contact.fullName}.`);
+          return id;
+        } catch (err) {
+          reportPersistenceFailure(`save client contact ${contact.fullName}`, err);
+          return null;
+        }
+      });
+    },
+    [
+      snapshot,
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const deleteClientContact = useCallback(
+    async (id: string) => {
+      return enqueueStoreMutation(async () => {
+        const currentSnapshot = snapshotRef.current;
+        const target = (currentSnapshot?.clientContacts ?? []).find((x) => x.id === id);
+        const ts = getAdjustedNowIsoUtc();
+        try {
+          await adapterRef.current!.deleteClientContact(id);
+          await recordOutboxOps([
+            createOutboxOperation({
+              entityType: 'clientContact',
+              entityUuid: id,
+              deviceId,
+              logicalCounter: allocateNextLogicalCounter(),
+              fieldName: '__delete__',
+              newValue: true,
+              timestamp: ts,
+              recordRev: nextEntityRev(id, target?._rev),
+            }),
+          ]);
+          await reloadFromAdapter();
+          notify('Client contact deleted.');
+        } catch (err) {
+          reportPersistenceFailure('delete client contact', err);
+        }
+      });
+    },
+    [
+      enqueueStoreMutation,
+      deviceId,
+      nextEntityRev,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const saveWaitlistEntry = useCallback(
+    async (
+      draft: Omit<WaitlistEntry, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
+    ): Promise<string | null> => {
+      return enqueueStoreMutation(async () => {
+        const latestSnapshot = snapshotRef.current ?? snapshot;
+        const ts = getAdjustedNowIsoUtc();
+        const prev = draft.id
+          ? (latestSnapshot?.waitlistEntries ?? []).find((x) => x.id === draft.id)
+          : undefined;
+        const id = draft.id || generateUuid();
+        const rev = nextEntityRev(id, prev?._rev);
+        const linkedClient = draft.clientId
+          ? (latestSnapshot?.clientContacts ?? []).find((c) => c.id === draft.clientId)
+          : undefined;
+        const maxBudgetNum =
+          draft.maxBudgetCents !== undefined && Number.isFinite(Number(draft.maxBudgetCents))
+            ? Math.max(0, Math.round(Number(draft.maxBudgetCents)))
+            : undefined;
+        const entry: WaitlistEntry = {
+          ...draft,
+          id,
+          clientName: linkedClient?.fullName || (draft.clientName || '').trim() || 'Buyer',
+          priorityRank: Math.max(1, Math.round(Number(draft.priorityRank) || 1)),
+          status: normalizeWaitlistStatus(draft.status, 'Active'),
+          intent: normalizeWaitlistIntent(draft.intent, 'Show / Breeding'),
+          desiredBreed: (draft.desiredBreed || '').trim(),
+          desiredVariety: (draft.desiredVariety || '').trim(),
+          preferredSex:
+            draft.preferredSex === 'Male' || draft.preferredSex === 'Female'
+              ? draft.preferredSex
+              : 'Any',
+          preferredBreedingId: draft.preferredBreedingId || undefined,
+          requestedByDateIso: (draft.requestedByDateIso || '').trim(),
+          inquiryDateIso: (draft.inquiryDateIso || '').trim() || todayDateIso(),
+          followUpDateIso: (draft.followUpDateIso || '').trim(),
+          lastContactedDateIso: (draft.lastContactedDateIso || '').trim(),
+          maxBudgetCents: maxBudgetNum && maxBudgetNum > 0 ? maxBudgetNum : undefined,
+          notes: (draft.notes || '').trim(),
+          _rev: rev,
+          createdAt: prev?.createdAt || ts,
+          updatedAt: ts,
+        };
+        try {
+          await adapterRef.current!.saveWaitlistEntry(entry);
+          await recordOutboxOps(
+            diffEntityFieldsToOperations({
+              entityType: 'waitlistEntry',
+              previous: prev,
+              next: entry,
+              deviceId,
+              nextCounter: allocateNextLogicalCounter,
+              timestamp: ts,
+              recordRev: rev,
+            })
+          );
+          await reloadFromAdapter();
+          notify(`Saved waitlist entry #${entry.priorityRank} for ${entry.clientName}.`);
+          return id;
+        } catch (err) {
+          reportPersistenceFailure(`save waitlist entry for ${entry.clientName}`, err);
+          return null;
+        }
+      });
+    },
+    [
+      snapshot,
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const deleteWaitlistEntry = useCallback(
+    async (id: string) => {
+      return enqueueStoreMutation(async () => {
+        const currentSnapshot = snapshotRef.current;
+        const target = (currentSnapshot?.waitlistEntries ?? []).find((x) => x.id === id);
+        const ts = getAdjustedNowIsoUtc();
+        try {
+          await adapterRef.current!.deleteWaitlistEntry(id);
+          await recordOutboxOps([
+            createOutboxOperation({
+              entityType: 'waitlistEntry',
+              entityUuid: id,
+              deviceId,
+              logicalCounter: allocateNextLogicalCounter(),
+              fieldName: '__delete__',
+              newValue: true,
+              timestamp: ts,
+              recordRev: nextEntityRev(id, target?._rev),
+            }),
+          ]);
+          await reloadFromAdapter();
+          notify('Waitlist entry deleted.');
+        } catch (err) {
+          reportPersistenceFailure('delete waitlist entry', err);
+        }
+      });
+    },
+    [
+      enqueueStoreMutation,
+      deviceId,
+      nextEntityRev,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const saveAnimalReservation = useCallback(
+    async (
+      draft: Omit<AnimalReservation, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
+    ): Promise<string | null> => {
+      return enqueueStoreMutation(async () => {
+        const latestSnapshot = snapshotRef.current ?? snapshot;
+        const ts = getAdjustedNowIsoUtc();
+        const prev = draft.id
+          ? (latestSnapshot?.animalReservations ?? []).find((x) => x.id === draft.id)
+          : undefined;
+        const id = draft.id || generateUuid();
+        const rev = nextEntityRev(id, prev?._rev);
+        const linkedClient = draft.clientId
+          ? (latestSnapshot?.clientContacts ?? []).find((c) => c.id === draft.clientId)
+          : undefined;
+        const speciesReservations = (latestSnapshot?.animalReservations ?? []).filter((r) =>
+          isSameSpecies(r.species, draft.species)
+        );
+        const agreementNumber =
+          (draft.agreementNumber || '').trim() ||
+          prev?.agreementNumber ||
+          buildSuggestedAgreementNumber(speciesReservations);
+        const status = normalizeReservationStatus(draft.status, 'Pending Deposit');
+        const totalPriceCents = Math.max(0, Math.round(Number(draft.totalPriceCents) || 0));
+        const depositRequiredCents = Math.max(
+          0,
+          Math.round(Number(draft.depositRequiredCents) || 0)
+        );
+        const depositPaidCents = Math.max(0, Math.round(Number(draft.depositPaidCents) || 0));
+        const fin = evaluateReservationFinancials({
+          status,
+          totalPriceCents,
+          depositRequiredCents,
+          depositPaidCents,
+        });
+        const reservation: AnimalReservation = {
+          ...draft,
+          id,
+          agreementNumber,
+          clientName: linkedClient?.fullName || (draft.clientName || '').trim() || 'Buyer',
+          waitlistEntryId: draft.waitlistEntryId || undefined,
+          animalId: draft.animalId || undefined,
+          breedingId: draft.breedingId || undefined,
+          pickOrder:
+            draft.pickOrder !== undefined && Number(draft.pickOrder) > 0
+              ? Math.round(Number(draft.pickOrder))
+              : undefined,
+          itemLabel: (draft.itemLabel || '').trim() || 'Reserved Animal / Pick',
+          status: draft.id ? status : fin.suggestedStatus,
+          reservedDateIso: (draft.reservedDateIso || '').trim() || todayDateIso(),
+          holdExpiresDateIso: (draft.holdExpiresDateIso || '').trim(),
+          totalPriceCents,
+          depositRequiredCents,
+          depositPaidCents,
+          depositDueDateIso: (draft.depositDueDateIso || '').trim(),
+          depositPaidDateIso: (draft.depositPaidDateIso || '').trim(),
+          pickupScheduledDateIso: (draft.pickupScheduledDateIso || '').trim(),
+          completedDateIso: (draft.completedDateIso || '').trim(),
+          balanceReminderDateIso: (draft.balanceReminderDateIso || '').trim(),
+          paymentMethod: (draft.paymentMethod || '').trim(),
+          ledgerEntryId: draft.ledgerEntryId || undefined,
+          termsSummary: (draft.termsSummary || '').trim(),
+          healthGuaranteeNotes: (draft.healthGuaranteeNotes || '').trim(),
+          notes: (draft.notes || '').trim(),
+          _rev: rev,
+          createdAt: prev?.createdAt || ts,
+          updatedAt: ts,
+        };
+        try {
+          await adapterRef.current!.saveAnimalReservation(reservation);
+          const outboxOps = diffEntityFieldsToOperations({
+            entityType: 'animalReservation',
+            previous: prev,
+            next: reservation,
+            deviceId,
+            nextCounter: allocateNextLogicalCounter,
+            timestamp: ts,
+            recordRev: rev,
+          });
+          if (
+            reservation.waitlistEntryId &&
+            reservation.status !== 'Cancelled' &&
+            reservation.status !== 'Inquiry Hold'
+          ) {
+            const linkedWait = (latestSnapshot?.waitlistEntries ?? []).find(
+              (w) => w.id === reservation.waitlistEntryId
+            );
+            if (linkedWait && (linkedWait.status === 'Active' || linkedWait.status === 'Matched')) {
+              const nextWaitStatus =
+                reservation.status === 'Picked Up / Completed' ? 'Fulfilled' : 'Deposited';
+              const waitRev = nextEntityRev(linkedWait.id, linkedWait._rev);
+              const updatedWait: WaitlistEntry = {
+                ...linkedWait,
+                status: nextWaitStatus,
+                _rev: waitRev,
+                updatedAt: ts,
+              };
+              await adapterRef.current!.saveWaitlistEntry(updatedWait);
+              outboxOps.push(
+                ...diffEntityFieldsToOperations({
+                  entityType: 'waitlistEntry',
+                  previous: linkedWait,
+                  next: updatedWait,
+                  deviceId,
+                  nextCounter: allocateNextLogicalCounter,
+                  timestamp: ts,
+                  recordRev: waitRev,
+                })
+              );
+            }
+          }
+          await recordOutboxOps(outboxOps);
+          await reloadFromAdapter();
+          notify(`Saved reservation ${reservation.agreementNumber} (${reservation.clientName}).`);
+          return id;
+        } catch (err) {
+          reportPersistenceFailure(`save reservation ${reservation.agreementNumber}`, err);
+          return null;
+        }
+      });
+    },
+    [
+      snapshot,
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const deleteAnimalReservation = useCallback(
+    async (id: string) => {
+      return enqueueStoreMutation(async () => {
+        const currentSnapshot = snapshotRef.current;
+        const target = (currentSnapshot?.animalReservations ?? []).find((x) => x.id === id);
+        const ts = getAdjustedNowIsoUtc();
+        try {
+          await adapterRef.current!.deleteAnimalReservation(id);
+          await recordOutboxOps([
+            createOutboxOperation({
+              entityType: 'animalReservation',
+              entityUuid: id,
+              deviceId,
+              logicalCounter: allocateNextLogicalCounter(),
+              fieldName: '__delete__',
+              newValue: true,
+              timestamp: ts,
+              recordRev: nextEntityRev(id, target?._rev),
+            }),
+          ]);
+          await reloadFromAdapter();
+          notify('Reservation deleted.');
+        } catch (err) {
+          reportPersistenceFailure('delete reservation', err);
+        }
+      });
+    },
+    [
+      enqueueStoreMutation,
+      deviceId,
+      nextEntityRev,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const saveWoolHarvest = useCallback(
+    async (
+      draft: Omit<WoolHarvest, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
+    ): Promise<string | null> => {
+      return enqueueStoreMutation(async () => {
+        const latestSnapshot = snapshotRef.current ?? snapshot;
+        const ts = getAdjustedNowIsoUtc();
+        const prev = draft.id
+          ? (latestSnapshot?.woolHarvests ?? []).find((x) => x.id === draft.id)
+          : undefined;
+        const id = draft.id || generateUuid();
+        const rev = nextEntityRev(id, prev?._rev);
+        const normalized = normalizeWoolHarvest(
+          {
+            ...draft,
+            id,
+            _rev: rev,
+            createdAt: prev?.createdAt || ts,
+            updatedAt: ts,
+          },
+          draft.species || activeSpeciesName || 'Rabbit'
+        );
+        if (!normalized) return null;
+        try {
+          await adapterRef.current!.saveWoolHarvest(normalized);
+          const outboxOps = diffEntityFieldsToOperations({
+            entityType: 'woolHarvest',
+            previous: prev,
+            next: normalized,
+            deviceId,
+            nextCounter: allocateNextLogicalCounter,
+            timestamp: ts,
+            recordRev: rev,
+          });
+          await recordOutboxOps(outboxOps);
+          await reloadFromAdapter();
+          const totalG = normalized.primeWeightGrams + normalized.gradeWeightGrams;
+          notify(`Saved wool harvest (${totalG} g on ${normalized.harvestDateIso}).`);
+          return id;
+        } catch (err) {
+          reportPersistenceFailure('save wool harvest', err);
+          return null;
+        }
+      });
+    },
+    [
+      snapshot,
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const deleteWoolHarvest = useCallback(
+    async (id: string) => {
+      return enqueueStoreMutation(async () => {
+        const currentSnapshot = snapshotRef.current;
+        const target = (currentSnapshot?.woolHarvests ?? []).find((x) => x.id === id);
+        const ts = getAdjustedNowIsoUtc();
+        try {
+          await adapterRef.current!.deleteWoolHarvest(id);
+          await recordOutboxOps([
+            createOutboxOperation({
+              entityType: 'woolHarvest',
+              entityUuid: id,
+              deviceId,
+              logicalCounter: allocateNextLogicalCounter(),
+              fieldName: '__delete__',
+              newValue: true,
+              timestamp: ts,
+              recordRev: nextEntityRev(id, target?._rev),
+            }),
+          ]);
+          await reloadFromAdapter();
+          notify('Wool harvest record deleted.');
+        } catch (err) {
+          reportPersistenceFailure('delete wool harvest', err);
+        }
+      });
+    },
+    [
+      enqueueStoreMutation,
+      deviceId,
+      nextEntityRev,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const completeReservationSale = useCallback(
+    async (params: {
+      reservationId: string;
+      completedDateIso?: string;
+      markAnimalSold?: boolean;
+      recordLedgerIncome?: boolean;
+    }): Promise<boolean> => {
+      return enqueueStoreMutation(async () => {
+        const latestSnapshot = snapshotRef.current ?? snapshot;
+        if (!latestSnapshot) return false;
+        const target = (latestSnapshot.animalReservations ?? []).find(
+          (r) => r.id === params.reservationId
+        );
+        if (!target) return false;
+
+        const ts = getAdjustedNowIsoUtc();
+        const completedDateIso = (params.completedDateIso || '').trim() || todayDateIso();
+        const finalPaidCents = Math.max(target.totalPriceCents, target.depositPaidCents);
+        let ledgerEntryId = target.ledgerEntryId;
+        const outboxOps: SyncOperation[] = [];
+
+        try {
+          if (params.recordLedgerIncome && finalPaidCents > 0 && !ledgerEntryId) {
+            const newLedgerId = generateUuid();
+            const ledgerRev = nextEntityRev(newLedgerId);
+            const ledgerEntry: LedgerEntry = {
+              id: newLedgerId,
+              species: target.species,
+              dateIso: completedDateIso,
+              entryType: 'income',
+              category: 'animal_sale',
+              amountCents: finalPaidCents,
+              title: `${target.agreementNumber || 'Sale'} — ${target.itemLabel}`,
+              vendorOrParty: target.clientName,
+              linkedAnimalId: target.animalId,
+              linkedBreedingId: target.breedingId,
+              notes: `Completed reservation ${target.agreementNumber || target.id}`,
+              _rev: ledgerRev,
+              createdAt: ts,
+              updatedAt: ts,
+            };
+            await adapterRef.current!.saveLedgerEntry(ledgerEntry);
+            outboxOps.push(
+              ...diffEntityFieldsToOperations({
+                entityType: 'ledgerEntry',
+                previous: undefined,
+                next: ledgerEntry,
+                deviceId,
+                nextCounter: allocateNextLogicalCounter,
+                timestamp: ts,
+                recordRev: ledgerRev,
+              })
+            );
+            ledgerEntryId = newLedgerId;
+          }
+
+          if (params.markAnimalSold !== false && target.animalId) {
+            const animalPrev = latestSnapshot.animals.find((a) => a.id === target.animalId);
+            if (animalPrev) {
+              const animalRev = nextEntityRev(animalPrev.id, animalPrev._rev);
+              const updatedAnimal: Animal = {
+                ...animalPrev,
+                status: 'Sold',
+                soldDateIso: animalPrev.soldDateIso || completedDateIso,
+                salePriceCents: finalPaidCents > 0 ? finalPaidCents : animalPrev.salePriceCents,
+                buyerName: target.clientName || animalPrev.buyerName,
+                _rev: animalRev,
+                updatedAt: ts,
+              };
+              await adapterRef.current!.saveAnimal(updatedAnimal);
+              outboxOps.push(
+                ...diffEntityFieldsToOperations({
+                  entityType: 'animal',
+                  previous: animalPrev,
+                  next: updatedAnimal,
+                  deviceId,
+                  nextCounter: allocateNextLogicalCounter,
+                  timestamp: ts,
+                  recordRev: animalRev,
+                })
+              );
+            }
+          }
+
+          if (target.waitlistEntryId) {
+            const waitPrev = (latestSnapshot.waitlistEntries ?? []).find(
+              (w) => w.id === target.waitlistEntryId
+            );
+            if (waitPrev && waitPrev.status !== 'Fulfilled') {
+              const waitRev = nextEntityRev(waitPrev.id, waitPrev._rev);
+              const updatedWait: WaitlistEntry = {
+                ...waitPrev,
+                status: 'Fulfilled',
+                _rev: waitRev,
+                updatedAt: ts,
+              };
+              await adapterRef.current!.saveWaitlistEntry(updatedWait);
+              outboxOps.push(
+                ...diffEntityFieldsToOperations({
+                  entityType: 'waitlistEntry',
+                  previous: waitPrev,
+                  next: updatedWait,
+                  deviceId,
+                  nextCounter: allocateNextLogicalCounter,
+                  timestamp: ts,
+                  recordRev: waitRev,
+                })
+              );
+            }
+          }
+
+          const resRev = nextEntityRev(target.id, target._rev);
+          const updatedRes: AnimalReservation = {
+            ...target,
+            status: 'Picked Up / Completed',
+            depositPaidCents: finalPaidCents,
+            depositPaidDateIso: target.depositPaidDateIso || completedDateIso,
+            completedDateIso,
+            ledgerEntryId,
+            _rev: resRev,
+            updatedAt: ts,
+          };
+          await adapterRef.current!.saveAnimalReservation(updatedRes);
+          outboxOps.push(
+            ...diffEntityFieldsToOperations({
+              entityType: 'animalReservation',
+              previous: target,
+              next: updatedRes,
+              deviceId,
+              nextCounter: allocateNextLogicalCounter,
+              timestamp: ts,
+              recordRev: resRev,
+            })
+          );
+
+          await recordOutboxOps(outboxOps);
+          await reloadFromAdapter();
+          notify(`Completed sale for ${target.agreementNumber} (${target.clientName}).`);
+          return true;
+        } catch (err) {
+          reportPersistenceFailure(`complete sale ${target.agreementNumber}`, err);
+          return false;
+        }
+      });
+    },
+    [
+      snapshot,
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
+  const createCrmReminderTask = useCallback(
+    async (speciesName: string, reminder: CrmFollowUpReminder): Promise<boolean> => {
+      return enqueueStoreMutation(async () => {
+        const currentSnapshot = snapshotRef.current;
+        const ts = getAdjustedNowIsoUtc();
+        const taskId = generateUuid();
+        const taskRev = nextEntityRev(taskId);
+        const linkedAnimal = reminder.linkedAnimalId
+          ? currentSnapshot?.animals.find((a) => a.id === reminder.linkedAnimalId)
+          : undefined;
+        const task: BarnTask = {
+          id: taskId,
+          species: speciesName,
+          title: reminder.suggestedTaskTitle,
+          category: reminder.suggestedTaskCategory,
+          priority: reminder.suggestedTaskPriority,
+          dueDateIso: reminder.targetDateIso || todayDateIso(),
+          completed: false,
+          linkedBreedingId: reminder.linkedBreedingId || '',
+          linkedAnimalId: reminder.linkedAnimalId || '',
+          linkedAnimalName: linkedAnimal?.name || reminder.clientName || '',
+          _rev: taskRev,
+          createdAt: ts,
+          updatedAt: ts,
+        };
+        try {
+          await adapterRef.current!.saveTask(task);
+          await recordOutboxOps(
+            diffEntityFieldsToOperations({
+              entityType: 'task',
+              previous: undefined,
+              next: task,
+              deviceId,
+              nextCounter: allocateNextLogicalCounter,
+              timestamp: ts,
+              recordRev: taskRev,
+            })
+          );
+          await reloadFromAdapter();
+          notify(`Added Master Task: ${task.title}`);
+          return true;
+        } catch (err) {
+          reportPersistenceFailure(`create CRM task ${task.title}`, err);
+          return false;
+        }
+      });
+    },
+    [
+      deviceId,
+      nextEntityRev,
+      enqueueStoreMutation,
+      recordOutboxOps,
+      reloadFromAdapter,
+      notify,
+      reportPersistenceFailure,
+    ]
+  );
+
   const seedSpeciesSampleData = useCallback(
     async (speciesName: string) => {
       return enqueueStoreMutation(async () => {
@@ -5668,6 +6542,10 @@
               ledgerEntries: [],
               processingLogs: [],
               youthProjectBooks: [],
+              clientContacts: [],
+              waitlistEntries: [],
+              animalReservations: [],
+              woolHarvests: [],
             }
           );
           await adapterRef.current!.replaceSnapshot(report.snapshot);
@@ -5861,6 +6739,10 @@
           ledgerEntries: [],
           processingLogs: [],
           youthProjectBooks: [],
+          clientContacts: [],
+          waitlistEntries: [],
+          animalReservations: [],
+          woolHarvests: [],
         };
         await adapterRef.current!.replaceSnapshot(empty);
         photoCacheRef.current.clear();
@@ -6174,6 +7056,7 @@
           }
           await adapterRef.current!.replaceSnapshot(result.nextSnapshot);
           await replaceSyncOperationsInIdb(result.mergedOperations);
+          rebuildMaxRevIndex(result.mergedOperations);
           syncOperationsRef.current = result.mergedOperations;
           setSyncOperations(result.mergedOperations);
           if (result.newConflicts.length > 0) {
@@ -6224,6 +7107,7 @@
           );
           await adapterRef.current!.replaceSnapshot(applied.nextSnapshot);
           await replaceSyncOperationsInIdb(applied.mergedOperations);
+          rebuildMaxRevIndex(applied.mergedOperations);
           syncOperationsRef.current = applied.mergedOperations;
           setSyncOperations(applied.mergedOperations);
 
@@ -6815,6 +7699,10 @@
             ledgerEntries: [],
             processingLogs: [],
             youthProjectBooks: [],
+            clientContacts: [],
+            waitlistEntries: [],
+            animalReservations: [],
+            woolHarvests: [],
           };
           const merged = mergeBarnSnapshots(localAdjustedSnapshot, incoming);
           const importedIds = new Set(resolvedAnimals.map((a) => a.id));
@@ -7393,6 +8281,16 @@
     deleteProcessingLog,
     saveYouthProjectBook,
     deleteYouthProjectBook,
+    saveClientContact,
+    deleteClientContact,
+    saveWaitlistEntry,
+    deleteWaitlistEntry,
+    saveAnimalReservation,
+    deleteAnimalReservation,
+    completeReservationSale,
+    createCrmReminderTask,
+    saveWoolHarvest,
+    deleteWoolHarvest,
     seedSpeciesSampleData,
     seedAllPredefinedSpecies,
     deleteSpeciesTestingData,
```

### `src/index.css` (`+0` / `-6`, source: `part-02_8cc4d2d8.md`)

```diff
--- working/src/index.css
+++ import/src/index.css
@@ -128,10 +128,4 @@
     -webkit-print-color-adjust: economy !important;
     print-color-adjust: economy !important;
   }
-
-  #barn-print-stage[data-preserve-accent-ink="true"],
-  #barn-print-stage[data-preserve-accent-ink="true"] * {
-    -webkit-print-color-adjust: exact !important;
-    print-color-adjust: exact !important;
-  }
 }
```

### `src/native/pedigreeBridge.test.ts` (`+0` / `-21`, source: `part-14.md`)

```diff
--- working/src/native/pedigreeBridge.test.ts
+++ import/src/native/pedigreeBridge.test.ts
@@ -440,27 +440,6 @@
       expect(envelope.type).toBe('OPEN_DEV_PANEL');
       expect(typeof envelope.requestId).toBe('string');
     });
-
-    it('serializes sanitized title, orientation, and htmlContent on REQUEST_PRINT in Android mode', () => {
-      const { posted } = setupAndroidMock();
-      bridge = createPedigreeBridge();
-
-      expect(
-        bridge.requestPrint({
-          title: 'Pedigree\nChart\tCC-12',
-          orientation: 'landscape',
-          htmlContent: '<html><body><h1>Chart</h1></body></html>',
-        })
-      ).toBe(true);
-      expect(posted).toHaveLength(1);
-      const envelope = JSON.parse(posted[0] as string);
-      expect(envelope.type).toBe('REQUEST_PRINT');
-      expect(envelope.payload).toEqual({
-        title: 'Pedigree Chart CC-12',
-        orientation: 'landscape',
-        htmlContent: '<html><body><h1>Chart</h1></body></html>',
-      });
-    });
   });
 
   describe('iOS WKScriptMessageHandler serialization', () => {
```

### `src/native/pedigreeBridge.ts` (`+5` / `-29`, source: `part-14.md`)

```diff
--- working/src/native/pedigreeBridge.ts
+++ import/src/native/pedigreeBridge.ts
@@ -38,12 +38,6 @@
   ok: boolean;
   handledBy: 'android' | 'ios' | 'web-share' | 'web-download' | 'error';
   error?: string;
-}
-
-export interface NativePrintOptions {
-  title?: string;
-  orientation?: 'landscape' | 'portrait';
-  htmlContent?: string;
 }
 
 export interface BackupSnapshotInput {
@@ -381,34 +375,16 @@
     return this.triggerBrowserDownload(slicedBuffer, options.filename, options.mimeType);
   }
 
-  public requestPrint(options?: NativePrintOptions): boolean {
+  public requestPrint(): boolean {
     this.ensureListenersAttached();
     const platform = this.getPlatform();
     const requestId = createRequestId('print');
 
     if (platform !== 'web') {
-      const payload: Record<string, unknown> = {};
-      if (options?.title && options.title.trim()) {
-        payload.title = options.title.replace(/[\r\n\t]+/g, ' ').trim().slice(0, 160);
-      }
-      if (options?.orientation === 'landscape' || options?.orientation === 'portrait') {
-        payload.orientation = options.orientation;
-      }
-      if (typeof options?.htmlContent === 'string' && options.htmlContent.trim()) {
-        payload.htmlContent = options.htmlContent;
-      }
-      return this.postControlEnvelope(
-        Object.keys(payload).length > 0
-          ? {
-              type: 'REQUEST_PRINT',
-              requestId: requestId,
-              payload: payload,
-            }
-          : {
-              type: 'REQUEST_PRINT',
-              requestId: requestId,
-            }
-      );
+      return this.postControlEnvelope({
+        type: 'REQUEST_PRINT',
+        requestId: requestId,
+      });
     }
 
     const win = getWindowRef();
```

### `src/storage/__tests__/es2018AndPwaUpdate.test.ts` (`+50` / `-1`, source: `part-16.md`)

```diff
--- working/src/storage/__tests__/es2018AndPwaUpdate.test.ts
+++ import/src/storage/__tests__/es2018AndPwaUpdate.test.ts
@@ -120,6 +120,55 @@
       vi.unstubAllGlobals();
     }
   });
+
+  it('prefers native blob.text()/arrayBuffer() over FileReader and degrades cleanly if FileReader throws SecurityError', async () => {
+    const fileReaderSpy = vi.fn(function () {
+      throw new DOMException('FileReader blocked', 'SecurityError');
+    });
+    vi.stubGlobal('FileReader', fileReaderSpy);
+    try {
+      const nativeBlob = new Blob(['Hello Pedigree'], { type: 'text/plain' });
+      expect(await readBlobAsText(nativeBlob)).toBe('Hello Pedigree');
+      expect(new TextDecoder().decode(await readBlobAsArrayBuffer(nativeBlob))).toBe(
+        'Hello Pedigree'
+      );
+      expect(fileReaderSpy).not.toHaveBeenCalled();
+
+      // Legacy blob without .text()/.arrayBuffer() when FileReader is blocked -> Response fallback
+      const rawBytes = new TextEncoder().encode('ResponseFallback');
+      const noMethodBlob = {
+        size: rawBytes.byteLength,
+        type: 'text/plain',
+        slice() {
+          return new Blob([rawBytes]);
+        },
+      } as unknown as Blob;
+      const origResponse = globalThis.Response;
+      vi.stubGlobal(
+        'Response',
+        class FakeResponse {
+          constructor(private readonly body: unknown) {}
+          async arrayBuffer() {
+            void this.body;
+            return rawBytes.buffer.slice(0);
+          }
+          async text() {
+            return 'ResponseFallback';
+          }
+        }
+      );
+      try {
+        expect(await readBlobAsText(noMethodBlob)).toBe('ResponseFallback');
+        expect(new TextDecoder().decode(await readBlobAsArrayBuffer(noMethodBlob))).toBe(
+          'ResponseFallback'
+        );
+      } finally {
+        vi.stubGlobal('Response', origResponse);
+      }
+    } finally {
+      vi.unstubAllGlobals();
+    }
+  });
 });
 
 describe('pwaUpdateManager (manual prompt gate & controllerchange handshake)', () => {
@@ -255,7 +304,7 @@
 
     // Valid live version.json clears captive failure and captures Date clock skew
     const liveJsonFetch = vi.fn(async () => {
-      return new Response(JSON.stringify({ appVersion: '0.1.0-alpha.2' }), {
+      return new Response(JSON.stringify({ appVersion: '0.1.0-prealpha.1' }), {
         status: 200,
         headers: {
           'content-type': 'application/json',
```

### `src/storage/__tests__/opfsStorage.test.ts` (`+125` / `-0`, source: `part-16.md`)

```diff
--- working/src/storage/__tests__/opfsStorage.test.ts
+++ import/src/storage/__tests__/opfsStorage.test.ts
@@ -35,11 +35,18 @@
   MONTHLY_BACKUP_INTERVAL_MS,
   OpfsDirectoryHandle,
   OpfsFileHandle,
+  OpfsSyncAccessHandle,
   OpfsWritableStream,
+  probeOpfsRuntime,
   readOpfsHerdArchiveBlob,
   readOpfsPruneSyncWarning,
   readOpfsVaultBackupBlob,
+  resetOpfsProbesForTests,
   runOpfsExportCanary,
+  safeAwaitOpfsClose,
+  safeAwaitOpfsFlush,
+  safeAwaitOpfsGetSize,
+  safeAwaitOpfsTruncate,
   saveOpfsHerdArchive,
   saveOpfsVaultBackup,
   setOpfsRootResolverForTest,
@@ -50,6 +57,7 @@
   writeTempOpfsFile,
   writeTempOpfsFileStreamed,
 } from '../opfsStorage';
+import { getOpfsRoot, writeFileToOpfsDir } from '../opfsTempStream';
 
 interface MockFileEntry {
   kind: 'file';
@@ -218,6 +226,7 @@
   setBackupSyncHandleForTest(null);
   clearOpfsPruneSyncWarning();
   clearPriorUseSentinel();
+  resetOpfsProbesForTests();
   vi.unstubAllGlobals();
   vi.restoreAllMocks();
 });
@@ -860,3 +869,119 @@
   });
 });
 
+describe('opfsTempStream Safari 15.2–16.3 handle compatibility, SyncAccessHandle fallback & restricted probes', () => {
+  it('safely awaits close(), flush(), getSize(), and truncate() across both sync void/number and Promise returns, and skips double-close', async () => {
+    const syncHandle: OpfsSyncAccessHandle = {
+      write: () => 4,
+      flush: vi.fn<() => void>(),
+      getSize: vi.fn<() => number>(() => 42),
+      truncate: vi.fn<() => void>(),
+      close: vi.fn<() => void>(),
+    };
+
+    await safeAwaitOpfsTruncate(syncHandle, 0);
+    await safeAwaitOpfsFlush(syncHandle);
+    expect(await safeAwaitOpfsGetSize(syncHandle)).toBe(42);
+    await safeAwaitOpfsClose(syncHandle);
+    await safeAwaitOpfsClose(syncHandle); // double-close must be a no-op
+    expect(syncHandle.close).toHaveBeenCalledTimes(1);
+
+    const asyncHandle: OpfsSyncAccessHandle = {
+      write: () => 4,
+      flush: vi.fn(async () => {}),
+      getSize: vi.fn(async () => 128),
+      truncate: vi.fn(async () => {}),
+      close: vi.fn(async () => {}),
+    };
+
+    await safeAwaitOpfsTruncate(asyncHandle, 0);
+    await safeAwaitOpfsFlush(asyncHandle);
+    expect(await safeAwaitOpfsGetSize(asyncHandle)).toBe(128);
+    await safeAwaitOpfsClose(asyncHandle);
+    await safeAwaitOpfsClose(asyncHandle);
+    expect(asyncHandle.close).toHaveBeenCalledTimes(1);
+  });
+
+  it('writes via worker createSyncAccessHandle() with 0 args (never readwrite-unsafe) when createWritable is unavailable', async () => {
+    let storedBytes = new Uint8Array(0);
+    const createSyncSpy = vi.fn(async (): Promise<OpfsSyncAccessHandle> => {
+      return {
+        write(buf: ArrayBuffer | ArrayBufferView, opts?: { at?: number }) {
+          const view =
+            buf instanceof ArrayBuffer
+              ? new Uint8Array(buf)
+              : new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
+          const at = opts?.at ?? 0;
+          const next = new Uint8Array(Math.max(storedBytes.byteLength, at + view.byteLength));
+          next.set(storedBytes);
+          next.set(view, at);
+          storedBytes = next;
+          return view.byteLength;
+        },
+        async truncate(newSize: number) {
+          storedBytes = storedBytes.slice(0, newSize);
+        },
+        async flush() {},
+        async getSize() {
+          return storedBytes.byteLength;
+        },
+        async close() {},
+      };
+    });
+
+    const syncOnlyDir: OpfsDirectoryHandle = {
+      kind: 'directory',
+      name: 'tmp',
+      async getDirectoryHandle() {
+        throw new Error('unexpected subdir');
+      },
+      async getFileHandle(name: string) {
+        return {
+          kind: 'file',
+          name,
+          async getFile() {
+            return new Blob([storedBytes]);
+          },
+          createSyncAccessHandle: createSyncSpy,
+        };
+      },
+      async removeEntry() {},
+    };
+
+    await writeFileToOpfsDir(syncOnlyDir, 'worker-sync.json', '{"ok":true}');
+    expect(createSyncSpy).toHaveBeenCalledTimes(1);
+    expect(createSyncSpy).toHaveBeenCalledWith();
+    expect(new TextDecoder().decode(storedBytes)).toBe('{"ok":true}');
+  });
+
+  it('degrades cleanly without throwing when navigator.storage getter or getDirectory() throws SecurityError', async () => {
+    setOpfsRootResolverForTest(null);
+    resetOpfsProbesForTests();
+
+    const throwingNav = {
+      get storage() {
+        throw new DOMException('Blocked in Lockdown Mode', 'SecurityError');
+      },
+    };
+    vi.stubGlobal('navigator', throwingNav);
+
+    expect(isOpfsSupported()).toBe(false);
+    const probeA = await probeOpfsRuntime();
+    expect(probeA.supported).toBe(false);
+    expect(await getOpfsRoot()).toBeNull();
+
+    // Now simulate navigator.storage present, but getDirectory() rejects with SecurityError
+    resetOpfsProbesForTests();
+    vi.stubGlobal('navigator', {
+      storage: {
+        getDirectory: vi.fn(async () => {
+          throw new DOMException('OPFS unavailable in Private Browsing', 'SecurityError');
+        }),
+      },
+    });
+    const probeB = await probeOpfsRuntime();
+    expect(probeB.supported).toBe(false);
+    expect(isOpfsSupported()).toBe(false);
+    expect(await getOpfsRoot()).toBeNull();
+  });
+});
```

### `src/storage/__tests__/passphraseAndClockSkew.test.ts` (`+1` / `-1`, source: `part-16.md`)

```diff
--- working/src/storage/__tests__/passphraseAndClockSkew.test.ts
+++ import/src/storage/__tests__/passphraseAndClockSkew.test.ts
@@ -75,7 +75,7 @@
             if (url.includes('version.json')) {
               return new Response(
                 JSON.stringify({
-                  appVersion: '0.1.0-alpha.2',
+                  appVersion: '0.1.0-prealpha.1',
                   schemaVersion: 6,
                   minDirectUpgradeSchema: 1,
                 }),
```

### `src/storage/__tests__/photoHydrationAndWorker.test.ts` (`+309` / `-0`, source: `part-16.md`)

```diff
--- working/src/storage/__tests__/photoHydrationAndWorker.test.ts
+++ import/src/storage/__tests__/photoHydrationAndWorker.test.ts
@@ -788,3 +788,312 @@
   });
 });
 
+describe('Canvas memory guardrails, OffscreenCanvas probe, sequential hydration & iOS PWA shares', () => {
+  it('probes OffscreenCanvas 2D context before worker usage and releases probe backing store', async () => {
+    const { probeOffscreenCanvas2dSupport, releaseCanvas } = await import('../webImageOptimizer');
+
+    vi.stubGlobal('OffscreenCanvas', undefined);
+    expect(probeOffscreenCanvas2dSupport()).toBe(false);
+
+    const widthHistory: number[] = [];
+    const heightHistory: number[] = [];
+    const clearRect = vi.fn();
+
+    class NullCtxOffscreenCanvas {
+      private _w: number;
+      private _h: number;
+      constructor(w: number, h: number) {
+        this._w = w;
+        this._h = h;
+      }
+      get width() {
+        return this._w;
+      }
+      set width(v: number) {
+        widthHistory.push(v);
+        this._w = v;
+      }
+      get height() {
+        return this._h;
+      }
+      set height(v: number) {
+        heightHistory.push(v);
+        this._h = v;
+      }
+      getContext() {
+        return null;
+      }
+    }
+    vi.stubGlobal('OffscreenCanvas', NullCtxOffscreenCanvas);
+    expect(probeOffscreenCanvas2dSupport()).toBe(false);
+    expect(widthHistory).toEqual([1, 0]);
+    expect(heightHistory).toEqual([1, 0]);
+
+    class ThrowingCtxOffscreenCanvas {
+      width = 1;
+      height = 1;
+      getContext() {
+        throw new Error('2D unavailable in worker');
+      }
+    }
+    vi.stubGlobal('OffscreenCanvas', ThrowingCtxOffscreenCanvas);
+    expect(probeOffscreenCanvas2dSupport()).toBe(false);
+
+    const sequence: string[] = [];
+    class WorkingOffscreenCanvas {
+      private _w: number;
+      private _h: number;
+      constructor(w: number, h: number) {
+        this._w = w;
+        this._h = h;
+      }
+      get width() {
+        return this._w;
+      }
+      set width(v: number) {
+        sequence.push(`w:${v}`);
+        this._w = v;
+      }
+      get height() {
+        return this._h;
+      }
+      set height(v: number) {
+        sequence.push(`h:${v}`);
+        this._h = v;
+      }
+      getContext(type: string) {
+        if (type !== '2d') return null;
+        return {
+          clearRect: (...args: number[]) => {
+            clearRect(...args);
+            sequence.push('clear');
+          },
+        };
+      }
+    }
+    vi.stubGlobal('OffscreenCanvas', WorkingOffscreenCanvas);
+    expect(probeOffscreenCanvas2dSupport()).toBe(true);
+    expect(clearRect).toHaveBeenCalledWith(0, 0, 1, 1);
+    expect(sequence).toEqual(['w:1', 'h:1', 'clear', 'w:0', 'h:0']);
+
+    sequence.length = 0;
+    const standaloneCanvas = new WorkingOffscreenCanvas(800, 600) as unknown as OffscreenCanvas;
+    releaseCanvas(standaloneCanvas);
+    expect(sequence).toEqual(['w:1', 'h:1', 'clear', 'w:0', 'h:0']);
+    expect(standaloneCanvas.width).toBe(0);
+    expect(standaloneCanvas.height).toBe(0);
+  });
+
+  it('caps DPR via getEffectiveCanvasDevicePixelRatio and enforces constrained area ceiling', async () => {
+    const { enforceCanvasDimensions, getEffectiveCanvasDevicePixelRatio } = await import(
+      '../webImageOptimizer'
+    );
+
+    vi.stubGlobal('window', { devicePixelRatio: 3 });
+    expect(getEffectiveCanvasDevicePixelRatio(false)).toBe(2);
+    expect(getEffectiveCanvasDevicePixelRatio(true)).toBe(1);
+
+    vi.stubGlobal('window', { devicePixelRatio: 0 });
+    expect(getEffectiveCanvasDevicePixelRatio(false)).toBe(1);
+
+    const standardCap = enforceCanvasDimensions(5000, 5000, false);
+    expect(standardCap.wasClamped).toBe(true);
+    expect(standardCap.width * standardCap.height).toBeLessThanOrEqual(16_000_000);
+
+    const constrainedCap = enforceCanvasDimensions(3000, 2000, true);
+    expect(constrainedCap.wasClamped).toBe(true);
+    expect(constrainedCap.width * constrainedCap.height).toBeLessThanOrEqual(3_000_000);
+  });
+
+  it('hydrates photos sequentially in bounded batches and safely revokes only blob: URLs', async () => {
+    const { revokeBlobUrlIfNeeded } = await import('../photoHydration');
+    const revoked: string[] = [];
+    const origRevoke = URL.revokeObjectURL;
+    URL.revokeObjectURL = vi.fn((u: string) => {
+      revoked.push(u);
+    });
+
+    try {
+      revokeBlobUrlIfNeeded('data:image/webp;base64,AAAA');
+      revokeBlobUrlIfNeeded('https://example.com/photo.jpg');
+      revokeBlobUrlIfNeeded('');
+      revokeBlobUrlIfNeeded(null);
+      expect(revoked).toHaveLength(0);
+
+      revokeBlobUrlIfNeeded('blob:https://example.test/123');
+      expect(revoked).toEqual(['blob:https://example.test/123']);
+    } finally {
+      URL.revokeObjectURL = origRevoke;
+    }
+
+    const baseSnap = makeTestSnapshot();
+    const extraPhotos: AnimalPhoto[] = Array.from({ length: 5 }, (_, idx) => ({
+      ...baseSnap.animalPhotos![0],
+      id: `photo-seq-${idx}`,
+      dataUrl: '',
+    }));
+    const snap: BarnDatabaseSnapshot = {
+      ...baseSnap,
+      animalPhotos: extraPhotos,
+    };
+
+    let activeFetches = 0;
+    let peakConcurrentFetches = 0;
+    const chunkCalls: string[][] = [];
+
+    const hydrated = await hydrateSnapshotWithPhotoDataUrls(
+      snap,
+      async (ids) => {
+        activeFetches += 1;
+        peakConcurrentFetches = Math.max(peakConcurrentFetches, activeFetches);
+        chunkCalls.push(ids);
+        await Promise.resolve();
+        activeFetches -= 1;
+        return Object.fromEntries(ids.map((id) => [id, `data:image/png;base64,${id}`]));
+      },
+      undefined,
+      undefined,
+      { batchSize: 2 }
+    );
+
+    expect(peakConcurrentFetches).toBe(1);
+    expect(chunkCalls).toEqual([
+      ['photo-seq-0', 'photo-seq-1'],
+      ['photo-seq-2', 'photo-seq-3'],
+      ['photo-seq-4'],
+    ]);
+    expect(hydrated.animalPhotos!.every((p) => p.dataUrl.startsWith('data:image/png;base64,'))).toBe(
+      true
+    );
+  });
+
+  it('uses files-only navigator.canShare/share for iOS standalone PWA, ignores AbortError cleanly, and surfaces non-abort errors', async () => {
+    const {
+      downloadTextFile,
+      isFileShareAbortError,
+      isInstalledIosPwa,
+      shareTextFileOrDownload,
+    } = await import('../../utils/webFileActions');
+
+    const abortErr = new Error('User cancelled');
+    abortErr.name = 'AbortError';
+    expect(isFileShareAbortError(abortErr)).toBe(true);
+    expect(isFileShareAbortError(new Error('Other'))).toBe(false);
+
+    const anchorClickSpy = vi.fn();
+    const revokeSpy = vi.fn();
+    const origCreateObjectURL = URL.createObjectURL;
+    const origRevokeObjectURL = URL.revokeObjectURL;
+    URL.createObjectURL = vi.fn(() => 'blob:ios-fallback');
+    URL.revokeObjectURL = revokeSpy;
+
+    const fakeBody = { appendChild: vi.fn(), removeChild: vi.fn() };
+    vi.stubGlobal('document', {
+      createElement: vi.fn(() => ({
+        href: '',
+        download: '',
+        parentNode: fakeBody,
+        click: anchorClickSpy,
+      })),
+      body: fakeBody,
+    });
+
+    try {
+      const shareCalls: ShareData[] = [];
+      const canShareCalls: ShareData[] = [];
+
+      vi.stubGlobal('navigator', {
+        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15',
+        platform: 'iPhone',
+        maxTouchPoints: 5,
+        standalone: true,
+        canShare: vi.fn((data: ShareData) => {
+          canShareCalls.push(data);
+          return Boolean(data.files && data.files.length === 1);
+        }),
+        share: vi.fn(async (data: ShareData) => {
+          shareCalls.push(data);
+        }),
+      });
+
+      expect(isInstalledIosPwa()).toBe(true);
+
+      // 1. Passes ONLY `{ files: [file] }` with no extra title/text/url keys
+      const sharedOutcome = await shareTextFileOrDownload({
+        filename: 'pedigree.htm',
+        content: '<html><body>Test</body></html>',
+        mimeType: 'text/html',
+        title: 'Pedigree Certificate',
+        text: 'Ignored on iOS standalone',
+      });
+      expect(sharedOutcome).toBe('shared');
+      expect(canShareCalls).toHaveLength(1);
+      expect(shareCalls).toHaveLength(1);
+      expect(Object.keys(shareCalls[0])).toEqual(['files']);
+      expect(shareCalls[0].title).toBeUndefined();
+      expect(shareCalls[0].text).toBeUndefined();
+      expect(shareCalls[0].url).toBeUndefined();
+      expect(anchorClickSpy).not.toHaveBeenCalled();
+
+      // 2. AbortError returns 'cancelled' cleanly without falling back to <a download> or throwing
+      vi.stubGlobal('navigator', {
+        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15',
+        platform: 'iPhone',
+        maxTouchPoints: 5,
+        standalone: true,
+        canShare: vi.fn(() => true),
+        share: vi.fn(async () => {
+          throw abortErr;
+        }),
+      });
+
+      const cancelledOutcome = await shareTextFileOrDownload({
+        filename: 'pedigree.htm',
+        content: '<html></html>',
+        mimeType: 'text/html',
+        title: 'Pedigree',
+      });
+      expect(cancelledOutcome).toBe('cancelled');
+      expect(anchorClickSpy).not.toHaveBeenCalled();
+
+      // 3. When canShare rejects files on iOS standalone PWA, surfaces visible error instead of silent swallow or broken anchor
+      vi.stubGlobal('navigator', {
+        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15',
+        platform: 'iPhone',
+        maxTouchPoints: 5,
+        standalone: true,
+        canShare: vi.fn(() => false),
+        share: vi.fn(async () => {}),
+      });
+
+      await expect(
+        shareTextFileOrDownload({
+          filename: 'pedigree.htm',
+          content: '<html></html>',
+          mimeType: 'text/html',
+          title: 'Pedigree',
+        })
+      ).rejects.toThrow(/iOS Home Screen/i);
+      expect(anchorClickSpy).not.toHaveBeenCalled();
+
+      // 4. Desktop/non-iOS anchor download fallback revokes blob: immediately if click() fails
+      vi.stubGlobal('navigator', {
+        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/125.0.0.0',
+        platform: 'Win32',
+        maxTouchPoints: 0,
+      });
+      anchorClickSpy.mockImplementationOnce(() => {
+        throw new Error('Blocked popup');
+      });
+      await expect(downloadTextFile('test.txt', 'hello', 'text/plain')).rejects.toThrow(
+        'Blocked popup'
+      );
+      expect(revokeSpy).toHaveBeenCalledWith('blob:ios-fallback');
+    } finally {
+      URL.createObjectURL = origCreateObjectURL;
+      URL.revokeObjectURL = origRevokeObjectURL;
+    }
+  });
+});
+
+
```

### `src/storage/backgroundFreezeCoordinator.ts` (`+86` / `-11`, source: `part-14.md`)

```diff
--- working/src/storage/backgroundFreezeCoordinator.ts
+++ import/src/storage/backgroundFreezeCoordinator.ts
@@ -12,6 +12,13 @@
  *   storage quota, partial I/O failure) to a sticky user-acknowledged prompt.
  */
 
+import { releaseActiveOpfsHandles } from './opfsTempStream';
+import {
+  abortPendingWebLocks,
+  releaseOpenBroadcastChannels,
+  releaseOpenIdbResources,
+} from './storageProbes';
+
 export class BackgroundPausedError extends Error {
   readonly taskName: string;
   readonly severityIssue: string | null;
@@ -42,6 +49,7 @@
   id: string;
   onHidden?: () => void | Promise<void>;
   onVisible?: () => void | Promise<void>;
+  onReleaseResources?: (reason: 'hidden' | 'pagehide') => void | Promise<void>;
 }
 
 export interface PausedBackgroundJob {
@@ -59,8 +67,17 @@
 const pausedJobs = new Map<string, PausedBackgroundJob>();
 const pausedJobSubscribers = new Set<PausedJobsSubscriber>();
 
-let lastVisibilityState: 'visible' | 'hidden' =
-  typeof document !== 'undefined' && document.visibilityState === 'hidden' ? 'hidden' : 'visible';
+function readInitialVisibilityState(): 'visible' | 'hidden' {
+  try {
+    return typeof document !== 'undefined' && document.visibilityState === 'hidden'
+      ? 'hidden'
+      : 'visible';
+  } catch {
+    return 'visible';
+  }
+}
+
+let lastVisibilityState: 'visible' | 'hidden' = readInitialVisibilityState();
 
 function emitPausedJobs(): void {
   const snapshot = Array.from(pausedJobs.values());
@@ -74,8 +91,12 @@
 }
 
 export function isDocumentHidden(docOverride?: { visibilityState?: string }): boolean {
-  const target = docOverride ?? (typeof document !== 'undefined' ? document : undefined);
-  return Boolean(target && target.visibilityState === 'hidden');
+  try {
+    const target = docOverride ?? (typeof document !== 'undefined' ? document : undefined);
+    return Boolean(target && target.visibilityState === 'hidden');
+  } catch {
+    return false;
+  }
 }
 
 export function assertForegroundOrPause(
@@ -151,13 +172,48 @@
   return true;
 }
 
-/**
- * Called from `crashLogger`'s single `visibilitychange` / `pagehide` dispatcher.
- * - On `'hidden'`: notifies all registered jobs/flushes to checkpoint & pause cleanly.
- * - On `'visible'`: auto-resumes clean minor paused jobs immediately (zero tap friction),
- *   while leaving `'severity'` paused jobs intact until acknowledged by the user.
- */
-export function notifyBackgroundTransition(nextState: 'hidden' | 'visible'): void {
+function emitReleaseResources(reason: 'hidden' | 'pagehide'): void {
+  try {
+    abortPendingWebLocks();
+  } catch {
+    // Non-fatal
+  }
+  try {
+    releaseOpenIdbResources();
+  } catch {
+    // Non-fatal
+  }
+  try {
+    releaseOpenBroadcastChannels();
+  } catch {
+    // Non-fatal
+  }
+  try {
+    void releaseActiveOpfsHandles().catch(() => {});
+  } catch {
+    // Non-fatal
+  }
+
+  const listeners = Array.from(lifecycleListeners.values());
+  for (const listener of listeners) {
+    if (typeof listener.onReleaseResources === 'function') {
+      try {
+        void Promise.resolve(listener.onReleaseResources(reason)).catch(() => {});
+      } catch {
+        // Non-fatal resource release failure
+      }
+    }
+  }
+}
+
+function applyBackgroundTransition(
+  nextState: 'hidden' | 'visible',
+  releaseReason: 'hidden' | 'pagehide'
+): void {
+  if (nextState === 'hidden') {
+    emitReleaseResources(releaseReason);
+  }
+
   if (nextState === lastVisibilityState && nextState === 'hidden') {
     return;
   }
@@ -206,6 +262,25 @@
   }
 }
 
+/**
+ * Called from `crashLogger`'s single `visibilitychange` / `pagehide` dispatcher.
+ * - On `'hidden'`: releases OPFS/IDB/channel handles and notifies registered jobs to checkpoint & pause cleanly.
+ * - On `'visible'`: auto-resumes clean minor paused jobs immediately (zero tap friction),
+ *   while leaving `'severity'` paused jobs intact until acknowledged by the user.
+ */
+export function notifyBackgroundTransition(nextState: 'hidden' | 'visible'): void {
+  applyBackgroundTransition(nextState, 'hidden');
+}
+
+/**
+ * Called on `pagehide` (including bfcache transitions) to release active OPFS handles,
+ * open IDB transactions/connections, and BroadcastChannels even if `visibilitychange`
+ * already transitioned to `'hidden'`.
+ */
+export function notifyPageHide(): void {
+  applyBackgroundTransition('hidden', 'pagehide');
+}
+
 export function resetBackgroundFreezeCoordinatorForTests(): void {
   lifecycleListeners.clear();
   pausedJobs.clear();
```

### `src/storage/capturedIdeasStore.ts` (`+111` / `-50`, source: `part-14.md`)

```diff
--- working/src/storage/capturedIdeasStore.ts
+++ import/src/storage/capturedIdeasStore.ts
@@ -23,7 +23,18 @@
 } from '../core/suggestionsBacklog';
 import { logDiagnosticEvent } from './crashLogger';
 import { isOpfsSupported, purgeOpfsTmp } from './opfsStorage';
+import {
+  getOpfsRoot,
+  writeFileToOpfsDir,
+} from './opfsTempStream';
+import {
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+} from './storageProbes';
 import { isQuotaExceededError } from './storageProtection';
+import { readBlobAsText } from '../utils/es2018Shims';
 
 const IDEAS_IDB_NAME = 'community_pedigree_ideas_v1';
 const IDEAS_IDB_VERSION = 1;
@@ -54,9 +65,10 @@
 }
 
 function readLocalFallback(): CapturedIdeaEntry[] {
-  if (typeof localStorage === 'undefined') return [];
-  try {
-    const raw = localStorage.getItem(IDEAS_LOCAL_STORAGE_KEY);
+  const ls = getSafeLocalStorage();
+  if (!ls) return [];
+  try {
+    const raw = ls.getItem(IDEAS_LOCAL_STORAGE_KEY);
     if (!raw) return [];
     return parseIdeaList(JSON.parse(raw));
   } catch {
@@ -65,9 +77,10 @@
 }
 
 function writeLocalFallback(ideas: readonly CapturedIdeaEntry[]): boolean {
-  if (typeof localStorage === 'undefined') return false;
-  try {
-    localStorage.setItem(IDEAS_LOCAL_STORAGE_KEY, JSON.stringify(ideas));
+  const ls = getSafeLocalStorage();
+  if (!ls) return false;
+  try {
+    ls.setItem(IDEAS_LOCAL_STORAGE_KEY, JSON.stringify(ideas));
     return true;
   } catch (err) {
     if (isQuotaExceededError(err)) {
@@ -78,7 +91,8 @@
 }
 
 async function openIdeasIndexedDb(): Promise<IDBDatabase | null> {
-  if (typeof indexedDB === 'undefined') return null;
+  const idb = getSafeIndexedDb();
+  if (!idb) return null;
   try {
     return await new Promise<IDBDatabase | null>((resolve) => {
       let settled = false;
@@ -89,7 +103,7 @@
         }
       };
       try {
-        const req = indexedDB.open(IDEAS_IDB_NAME, IDEAS_IDB_VERSION);
+        const req = idb.open(IDEAS_IDB_NAME, IDEAS_IDB_VERSION);
         req.onupgradeneeded = () => {
           try {
             const db = req.result;
@@ -115,13 +129,25 @@
 async function readAllFromIdb(): Promise<CapturedIdeaEntry[] | null> {
   const db = await openIdeasIndexedDb();
   if (!db) return null;
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     const rows = await new Promise<unknown[]>((resolve, reject) => {
       const tx = db.transaction(IDEAS_STORE_NAME, 'readonly');
+      const untrackTx = trackActiveIdbTransaction(tx);
       const store = tx.objectStore(IDEAS_STORE_NAME);
       const req = store.getAll();
-      req.onsuccess = () => resolve(Array.isArray(req.result) ? req.result : []);
-      req.onerror = () => reject(req.error || new Error('IndexedDB read failed.'));
+      req.onsuccess = () => {
+        untrackTx();
+        resolve(Array.isArray(req.result) ? req.result : []);
+      };
+      req.onerror = () => {
+        untrackTx();
+        reject(req.error || new Error('IndexedDB read failed.'));
+      };
+      tx.onabort = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB read aborted.'));
+      };
     });
     return parseIdeaList(rows);
   } catch (err) {
@@ -133,99 +159,134 @@
     });
     return null;
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
 async function putEntryInIdb(entry: CapturedIdeaEntry): Promise<boolean> {
   const db = await openIdeasIndexedDb();
   if (!db) return false;
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     await new Promise<void>((resolve, reject) => {
       const tx = db.transaction(IDEAS_STORE_NAME, 'readwrite');
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => reject(tx.error || new Error('IndexedDB write failed.'));
-      tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted.'));
+      const untrackTx = trackActiveIdbTransaction(tx);
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB write failed.'));
+      };
+      tx.onabort = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB write aborted.'));
+      };
       tx.objectStore(IDEAS_STORE_NAME).put(entry);
     });
     return true;
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
 async function deleteEntryInIdb(id: string): Promise<boolean> {
   const db = await openIdeasIndexedDb();
   if (!db) return false;
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     await new Promise<void>((resolve, reject) => {
       const tx = db.transaction(IDEAS_STORE_NAME, 'readwrite');
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => reject(tx.error || new Error('IndexedDB delete failed.'));
-      tx.onabort = () => reject(tx.error || new Error('IndexedDB delete aborted.'));
+      const untrackTx = trackActiveIdbTransaction(tx);
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB delete failed.'));
+      };
+      tx.onabort = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB delete aborted.'));
+      };
       tx.objectStore(IDEAS_STORE_NAME).delete(id);
     });
     return true;
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
 async function clearAllInIdb(): Promise<boolean> {
   const db = await openIdeasIndexedDb();
   if (!db) return false;
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     await new Promise<void>((resolve, reject) => {
       const tx = db.transaction(IDEAS_STORE_NAME, 'readwrite');
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => reject(tx.error || new Error('IndexedDB clear failed.'));
-      tx.onabort = () => reject(tx.error || new Error('IndexedDB clear aborted.'));
+      const untrackTx = trackActiveIdbTransaction(tx);
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB clear failed.'));
+      };
+      tx.onabort = () => {
+        untrackTx();
+        reject(tx.error || new Error('IndexedDB clear aborted.'));
+      };
       tx.objectStore(IDEAS_STORE_NAME).clear();
     });
     return true;
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
 async function writeIdeasToOpfs(ideas: readonly CapturedIdeaEntry[]): Promise<boolean> {
   if (!isOpfsSupported()) return false;
-  const storage =
-    typeof navigator !== 'undefined'
-      ? (navigator.storage as (StorageManager & {
-          getDirectory?: () => Promise<FileSystemDirectoryHandle>;
-        }) | undefined)
-      : undefined;
-  if (!storage || typeof storage.getDirectory !== 'function') return false;
-
-  const root = await storage.getDirectory();
+  const root = await getOpfsRoot();
+  if (!root) return false;
+
   const ideasDir = await root.getDirectoryHandle(IDEAS_OPFS_DIR, { create: true });
-  const fileHandle = await ideasDir.getFileHandle(IDEAS_OPFS_FILE, { create: true });
-  const writable = await fileHandle.createWritable();
-  try {
-    await writable.write(JSON.stringify(ideas, null, 2));
-  } finally {
-    await writable.close();
-  }
+  await writeFileToOpfsDir(ideasDir, IDEAS_OPFS_FILE, JSON.stringify(ideas, null, 2));
   return true;
 }
 
 async function readIdeasFromOpfs(): Promise<CapturedIdeaEntry[] | null> {
   if (!isOpfsSupported()) return null;
-  const storage =
-    typeof navigator !== 'undefined'
-      ? (navigator.storage as (StorageManager & {
-          getDirectory?: () => Promise<FileSystemDirectoryHandle>;
-        }) | undefined)
-      : undefined;
-  if (!storage || typeof storage.getDirectory !== 'function') return null;
-
-  try {
-    const root = await storage.getDirectory();
+  const root = await getOpfsRoot();
+  if (!root) return null;
+
+  try {
     const ideasDir = await root.getDirectoryHandle(IDEAS_OPFS_DIR, { create: false });
     const fileHandle = await ideasDir.getFileHandle(IDEAS_OPFS_FILE, { create: false });
     const file = await fileHandle.getFile();
-    const text = await file.text();
+    const text = await readBlobAsText(file);
     if (!text.trim()) return [];
     return parseIdeaList(JSON.parse(text));
   } catch {
```

### `src/storage/crashLogger.ts` (`+123` / `-56`, source: `part-14.md`)

```diff
--- working/src/storage/crashLogger.ts
+++ import/src/storage/crashLogger.ts
@@ -31,7 +31,16 @@
 import {
   BackgroundPausedError,
   notifyBackgroundTransition,
+  notifyPageHide,
 } from './backgroundFreezeCoordinator';
+import {
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  getSafeSessionStorage,
+  getSafeStorageManager,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+} from './storageProbes';
 
 export type {
   DiagnosticCategory,
@@ -256,9 +265,10 @@
 }
 
 export function getDiagnosticConfig(): DiagnosticConfig {
-  if (typeof localStorage === 'undefined') return { ...DEFAULT_CONFIG };
+  const ls = getSafeLocalStorage();
+  if (!ls) return { ...DEFAULT_CONFIG };
   try {
-    const raw = localStorage.getItem(CONFIG_STORAGE_KEY);
+    const raw = ls.getItem(CONFIG_STORAGE_KEY);
     if (!raw) return { ...DEFAULT_CONFIG };
     const parsed = JSON.parse(raw) as Partial<DiagnosticConfig>;
     const days = parsed.retentionDays === 3 || parsed.retentionDays === 7 || parsed.retentionDays === 14
@@ -283,9 +293,10 @@
   if (next.retentionDays !== 3 && next.retentionDays !== 7 && next.retentionDays !== 14) {
     next.retentionDays = 7;
   }
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
-      localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(next));
+      ls.setItem(CONFIG_STORAGE_KEY, JSON.stringify(next));
     } catch {
       // Ignore quota issue while saving config
     }
@@ -356,9 +367,10 @@
 
 export async function captureMemoryAndStorageSample(): Promise<MemorySample> {
   const base = captureMemorySample();
-  if (typeof navigator !== 'undefined' && navigator.storage?.estimate) {
+  const storage = getSafeStorageManager();
+  if (storage && typeof storage.estimate === 'function') {
     try {
-      const est = await navigator.storage.estimate();
+      const est = await storage.estimate();
       base.storageUsageBytes = Number(est.usage) || 0;
       base.storageQuotaBytes = Number(est.quota) || 0;
     } catch {
@@ -435,9 +447,10 @@
 }
 
 function readRingBuffer(): DiagnosticLogEntry[] {
-  if (typeof localStorage === 'undefined') return [];
+  const ls = getSafeLocalStorage();
+  if (!ls) return [];
   try {
-    const raw = localStorage.getItem(RING_STORAGE_KEY);
+    const raw = ls.getItem(RING_STORAGE_KEY);
     if (!raw) return [];
     const parsed = JSON.parse(raw);
     if (!Array.isArray(parsed)) return [];
@@ -456,8 +469,7 @@
 }
 
 export function readEmergencySessionTrace(
-  sessionStore: Pick<Storage, 'getItem'> | null | undefined =
-    typeof sessionStorage !== 'undefined' ? sessionStorage : null
+  sessionStore: Pick<Storage, 'getItem'> | null | undefined = getSafeSessionStorage()
 ): DiagnosticLogEntry[] {
   if (!sessionStore) return [];
   try {
@@ -466,11 +478,7 @@
     const parsed = JSON.parse(raw);
     if (!Array.isArray(parsed)) return [];
     return parsed.filter(
-      (item: unknown): item is DiagnosticLogEntry =>
-        typeof item === 'object' &&
-        item !== null &&
-        typeof (item as { id?: unknown }).id === 'string' &&
-        typeof (item as { timestampMs?: unknown }).timestampMs === 'number'
+      (item: any) => item && typeof item.id === 'string' && typeof item.timestampMs === 'number'
     );
   } catch {
     return [];
@@ -478,8 +486,7 @@
 }
 
 export function clearEmergencySessionTrace(
-  sessionStore: Pick<Storage, 'removeItem'> | null | undefined =
-    typeof sessionStorage !== 'undefined' ? sessionStorage : null
+  sessionStore: Pick<Storage, 'removeItem'> | null | undefined = getSafeSessionStorage()
 ): void {
   if (!sessionStore) return;
   try {
@@ -491,8 +498,7 @@
 
 export function writeEmergencySessionTraceSync(
   entry: DiagnosticLogEntry,
-  sessionStore: Pick<Storage, 'getItem' | 'setItem'> | null | undefined =
-    typeof sessionStorage !== 'undefined' ? sessionStorage : null
+  sessionStore: Pick<Storage, 'getItem' | 'setItem'> | null | undefined = getSafeSessionStorage()
 ): boolean {
   if (!sessionStore) return false;
   const compactEntry: DiagnosticLogEntry = {
@@ -523,7 +529,8 @@
 
 function writeRingBufferSync(entry: DiagnosticLogEntry): void {
   let localWriteOk = false;
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
       const existing = readRingBuffer();
       const cutoff = getCutoffTimestampMs(getDiagnosticConfig().retentionDays);
@@ -531,12 +538,12 @@
         ...existing.filter((e) => e.id !== entry.id && e.timestampMs >= cutoff),
         entry,
       ].slice(-MAX_RING_ENTRIES);
-      localStorage.setItem(RING_STORAGE_KEY, JSON.stringify(filtered));
+      ls.setItem(RING_STORAGE_KEY, JSON.stringify(filtered));
       localWriteOk = true;
     } catch {
       // If localStorage is completely full, trim aggressively and retry once
       try {
-        localStorage.setItem(RING_STORAGE_KEY, JSON.stringify([entry]));
+        ls.setItem(RING_STORAGE_KEY, JSON.stringify([entry]));
         localWriteOk = true;
       } catch {
         localWriteOk = false;
@@ -550,7 +557,8 @@
 
 function openLogsIdb(): Promise<IDBDatabase> {
   return new Promise((resolve, reject) => {
-    if (typeof indexedDB === 'undefined') {
+    const idb = getSafeIndexedDb();
+    if (!idb) {
       reject(new Error('IndexedDB unavailable'));
       return;
     }
@@ -562,7 +570,7 @@
     }, 6000);
 
     try {
-      const req = indexedDB.open(LOG_IDB_NAME, 1);
+      const req = idb.open(LOG_IDB_NAME, 1);
       req.onupgradeneeded = () => {
         try {
           const db = req.result;
@@ -630,21 +638,34 @@
 }
 
 async function persistEntryToIdb(entry: DiagnosticLogEntry): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   let db: IDBDatabase | null = null;
+  let untrackDb: (() => void) | null = null;
   try {
     db = await openLogsIdb();
+    untrackDb = trackActiveIdbConnection(db);
     await new Promise<void>((resolve) => {
       const tx = db!.transaction(LOG_STORE_NAME, 'readwrite');
+      const untrackTx = trackActiveIdbTransaction(tx);
       const store = tx.objectStore(LOG_STORE_NAME);
       store.put(entry);
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => resolve();
-      tx.onabort = () => resolve();
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onabort = () => {
+        untrackTx();
+        resolve();
+      };
     });
   } catch {
     // Ring buffer already persisted critical entries synchronously
   } finally {
+    untrackDb?.();
     db?.close();
   }
 }
@@ -653,21 +674,25 @@
   const cfg = getDiagnosticConfig();
   const cutoff = getCutoffTimestampMs(cfg.retentionDays);
 
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
       const ring = readRingBuffer().filter((e) => e.timestampMs >= cutoff);
-      localStorage.setItem(RING_STORAGE_KEY, JSON.stringify(ring));
+      ls.setItem(RING_STORAGE_KEY, JSON.stringify(ring));
     } catch {
       // Ignore
     }
   }
 
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   let db: IDBDatabase | null = null;
+  let untrackDb: (() => void) | null = null;
   try {
     db = await openLogsIdb();
+    untrackDb = trackActiveIdbConnection(db);
     await new Promise<void>((resolve) => {
       const tx = db!.transaction(LOG_STORE_NAME, 'readwrite');
+      const untrackTx = trackActiveIdbTransaction(tx);
       const store = tx.objectStore(LOG_STORE_NAME);
       const req = store.getAll();
       req.onsuccess = () => {
@@ -679,13 +704,23 @@
           }
         });
       };
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => resolve();
-      tx.onabort = () => resolve();
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onabort = () => {
+        untrackTx();
+        resolve();
+      };
     });
   } catch {
     // Ignore
   } finally {
+    untrackDb?.();
     db?.close();
   }
 }
@@ -699,16 +734,28 @@
     if (e.timestampMs >= cutoff) byId.set(e.id, e);
   }
 
-  if (typeof indexedDB !== 'undefined') {
+  if (getSafeIndexedDb()) {
     let db: IDBDatabase | null = null;
+    let untrackDb: (() => void) | null = null;
     try {
       db = await openLogsIdb();
+      untrackDb = trackActiveIdbConnection(db);
       const idbItems = await new Promise<DiagnosticLogEntry[]>((resolve) => {
         const tx = db!.transaction(LOG_STORE_NAME, 'readonly');
+        const untrackTx = trackActiveIdbTransaction(tx);
         const req = tx.objectStore(LOG_STORE_NAME).getAll();
-        req.onsuccess = () => resolve((req.result as DiagnosticLogEntry[]) || []);
-        req.onerror = () => resolve([]);
-        tx.onabort = () => resolve([]);
+        req.onsuccess = () => {
+          untrackTx();
+          resolve((req.result as DiagnosticLogEntry[]) || []);
+        };
+        req.onerror = () => {
+          untrackTx();
+          resolve([]);
+        };
+        tx.onabort = () => {
+          untrackTx();
+          resolve([]);
+        };
       });
       for (const e of idbItems) {
         const clean = normalizeStoredDiagnosticEntry(e);
@@ -719,6 +766,7 @@
     } catch {
       // Fall back to ring buffer entries
     } finally {
+      untrackDb?.();
       db?.close();
     }
   }
@@ -735,27 +783,41 @@
 
 export async function clearAllDiagnosticLogs(): Promise<void> {
   clearEmergencySessionTrace();
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
-      localStorage.removeItem(RING_STORAGE_KEY);
+      ls.removeItem(RING_STORAGE_KEY);
     } catch {
       // Ignore
     }
   }
-  if (typeof indexedDB !== 'undefined') {
+  if (getSafeIndexedDb()) {
     let db: IDBDatabase | null = null;
+    let untrackDb: (() => void) | null = null;
     try {
       db = await openLogsIdb();
+      untrackDb = trackActiveIdbConnection(db);
       await new Promise<void>((resolve) => {
         const tx = db!.transaction(LOG_STORE_NAME, 'readwrite');
+        const untrackTx = trackActiveIdbTransaction(tx);
         tx.objectStore(LOG_STORE_NAME).clear();
-        tx.oncomplete = () => resolve();
-        tx.onerror = () => resolve();
-        tx.onabort = () => resolve();
+        tx.oncomplete = () => {
+          untrackTx();
+          resolve();
+        };
+        tx.onerror = () => {
+          untrackTx();
+          resolve();
+        };
+        tx.onabort = () => {
+          untrackTx();
+          resolve();
+        };
       });
     } catch {
       // Ignore
     } finally {
+      untrackDb?.();
       db?.close();
     }
   }
@@ -880,7 +942,8 @@
 }
 
 function updateSessionHeartbeat(active: boolean): void {
-  if (typeof localStorage === 'undefined') return;
+  const ls = getSafeLocalStorage();
+  if (!ls) return;
   try {
     const mem = captureMemorySample();
     const hb: SessionHeartbeat = {
@@ -892,7 +955,7 @@
       lastHeapPercent: mem.heapPercent,
       lastHeapBytes: mem.usedHeapBytes,
     };
-    localStorage.setItem(SESSION_HEARTBEAT_KEY, JSON.stringify(hb));
+    ls.setItem(SESSION_HEARTBEAT_KEY, JSON.stringify(hb));
   } catch {
     // Ignore heartbeat write failures
   }
@@ -911,9 +974,10 @@
 }
 
 export function inspectPreviousSessionUncleanExit(): DiagnosticLogEntry | null {
-  if (typeof localStorage === 'undefined') return null;
+  const ls = getSafeLocalStorage();
+  if (!ls) return null;
   try {
-    const raw = localStorage.getItem(SESSION_HEARTBEAT_KEY);
+    const raw = ls.getItem(SESSION_HEARTBEAT_KEY);
     if (!raw) return null;
     const prev = JSON.parse(raw) as Partial<SessionHeartbeat>;
     if (prev.active && prev.sessionId && prev.sessionId !== SESSION_ID) {
@@ -1210,17 +1274,20 @@
     }
   };
 
-  const handleCleanBackgroundOrExit = () => {
+  const handleCleanBackgroundHide = () => {
     markCleanSessionExit();
     notifyBackgroundTransition('hidden');
   };
 
-  // 4. Clean exit & visibility lifecycle hooks (shared dispatcher to BackgroundFreezeCoordinator)
-  window.addEventListener('pagehide', handleCleanBackgroundOrExit);
-
-  window.addEventListener('beforeunload', handleCleanBackgroundOrExit);
-
-  document.addEventListener('freeze', handleCleanBackgroundOrExit);
+  const handleCleanPageHide = () => {
+    markCleanSessionExit();
+    notifyPageHide();
+  };
+
+  // 4. bfcache-safe pagehide / freeze / visibilitychange lifecycle hooks (avoid beforeunload)
+  window.addEventListener('pagehide', handleCleanPageHide);
+
+  document.addEventListener('freeze', handleCleanPageHide);
 
   document.addEventListener('resume', () => {
     updateSessionHeartbeat(true);
@@ -1231,7 +1298,7 @@
 
   document.addEventListener('visibilitychange', () => {
     if (document.visibilityState === 'hidden') {
-      handleCleanBackgroundOrExit();
+      handleCleanBackgroundHide();
     } else {
       updateSessionHeartbeat(true);
       void sampleMemoryPressure();
```

### `src/storage/deviceCapabilityDetector.ts` (`+35` / `-20`, source: `part-14.md`)

```diff
--- working/src/storage/deviceCapabilityDetector.ts
+++ import/src/storage/deviceCapabilityDetector.ts
@@ -21,6 +21,11 @@
 } from '../core/deviceCapability';
 import { logDiagnosticEvent } from './crashLogger';
 import { isArchiveWorkerDisabled } from './offThreadWorkerClient';
+import {
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  getSafeStorageManager,
+} from './storageProbes';
 
 const HOME_DISMISSED_KEY = 'pedigree.deviceCapability.homeDismissed.v1';
 const SETTINGS_DISMISSED_KEY = 'pedigree.deviceCapability.settingsDismissed.v1';
@@ -44,8 +49,9 @@
   if (typeof document === 'undefined') {
     return true;
   }
-  try {
-    const canvas = document.createElement('canvas');
+  let canvas: HTMLCanvasElement | null = null;
+  try {
+    canvas = document.createElement('canvas');
     canvas.width = 1;
     canvas.height = 1;
     if (typeof canvas.toDataURL !== 'function') {
@@ -56,6 +62,22 @@
     cachedWebpEncodeSupported = typeof url === 'string' && url.indexOf('data:image/webp') === 0;
   } catch {
     cachedWebpEncodeSupported = false;
+  } finally {
+    if (canvas) {
+      try {
+        canvas.width = 1;
+        canvas.height = 1;
+        const ctx = canvas.getContext('2d');
+        if (ctx && typeof ctx.clearRect === 'function') {
+          ctx.clearRect(0, 0, 1, 1);
+        }
+      } catch {
+        // Ignore teardown error
+      } finally {
+        canvas.width = 0;
+        canvas.height = 0;
+      }
+    }
   }
   return cachedWebpEncodeSupported;
 }
@@ -173,12 +195,7 @@
     };
   }
 
-  let indexedDbSupported = false;
-  try {
-    indexedDbSupported = 'indexedDB' in window && Boolean(window.indexedDB);
-  } catch {
-    indexedDbSupported = false;
-  }
+  const indexedDbSupported = getSafeIndexedDb() !== null;
 
   let wasmSupported = false;
   try {
@@ -190,17 +207,13 @@
     wasmSupported = false;
   }
 
-  const storageObj = (navigator as Navigator & { storage?: StorageManager }).storage;
+  const storageObj = getSafeStorageManager();
 
   const opfsSupported =
-    typeof storageObj !== 'undefined' &&
-    storageObj !== null &&
-    typeof storageObj.getDirectory === 'function';
+    storageObj !== null && typeof storageObj.getDirectory === 'function';
 
   const persistStorageSupported =
-    typeof storageObj !== 'undefined' &&
-    storageObj !== null &&
-    typeof storageObj.persist === 'function';
+    storageObj !== null && typeof storageObj.persist === 'function';
 
   let directoryPickerSupported = false;
   try {
@@ -252,8 +265,9 @@
 
 function readLocalFlag(key: string): boolean {
   try {
-    if (typeof localStorage === 'undefined') return false;
-    return localStorage.getItem(key) === '1';
+    const ls = getSafeLocalStorage();
+    if (!ls) return false;
+    return ls.getItem(key) === '1';
   } catch {
     return false;
   }
@@ -261,11 +275,12 @@
 
 function writeLocalFlag(key: string, value: boolean): void {
   try {
-    if (typeof localStorage === 'undefined') return;
+    const ls = getSafeLocalStorage();
+    if (!ls) return;
     if (value) {
-      localStorage.setItem(key, '1');
+      ls.setItem(key, '1');
     } else {
-      localStorage.removeItem(key);
+      ls.removeItem(key);
     }
   } catch {
     // Ignore quota or private-browsing storage restrictions
```

### `src/storage/feedTagOcr.ts` (`+26` / `-10`, source: `part-14.md`)

```diff
--- working/src/storage/feedTagOcr.ts
+++ import/src/storage/feedTagOcr.ts
@@ -21,7 +21,11 @@
 } from '../core/feedInventory';
 import { OptimizedImagePayload } from '../core/imageOptimizationSpec';
 import { todayDateIso } from '../core/models';
-import { optimizeImageBlob } from './webImageOptimizer';
+import {
+  enforceCanvasDimensions,
+  optimizeImageBlob,
+  releaseCanvas,
+} from './webImageOptimizer';
 
 export type FeedTagOcrStatus =
   | 'detected'
@@ -76,16 +80,26 @@
     const objectUrl = URL.createObjectURL(file);
     const img = new Image();
     img.decoding = 'async';
+    const releaseImageObjectUrl = () => {
+      img.onload = null;
+      img.onerror = null;
+      try {
+        img.src = '';
+      } catch {
+        // Ignore readonly src teardown
+      }
+      URL.revokeObjectURL(objectUrl);
+    };
     img.onload = () => {
       resolve({
         source: img,
         width: img.naturalWidth || img.width || 1,
         height: img.naturalHeight || img.height || 1,
-        cleanup: () => URL.revokeObjectURL(objectUrl),
+        cleanup: releaseImageObjectUrl,
       });
     };
     img.onerror = () => {
-      URL.revokeObjectURL(objectUrl);
+      releaseImageObjectUrl();
       reject(new Error('Could not decode image file for feed tag OCR.'));
     };
     img.src = objectUrl;
@@ -99,14 +113,19 @@
 ): HTMLCanvasElement {
   const longest = Math.max(srcWidth, srcHeight, 1);
   const scale = longest > OCR_MAX_DIMENSION_PX ? OCR_MAX_DIMENSION_PX / longest : 1;
-  const targetWidth = Math.max(1, Math.round(srcWidth * scale));
-  const targetHeight = Math.max(1, Math.round(srcHeight * scale));
+  const safeDims = enforceCanvasDimensions(
+    Math.max(1, Math.round(srcWidth * scale)),
+    Math.max(1, Math.round(srcHeight * scale))
+  );
+  const targetWidth = safeDims.width;
+  const targetHeight = safeDims.height;
 
   const canvas = document.createElement('canvas');
   canvas.width = targetWidth;
   canvas.height = targetHeight;
   const ctx = canvas.getContext('2d');
   if (!ctx) {
+    releaseCanvas(canvas);
     throw new Error('2D Canvas context unavailable for feed tag OCR.');
   }
   ctx.fillStyle = '#FFFFFF';
@@ -252,11 +271,8 @@
       }
     }
   } finally {
-    if (ocrCanvas) {
-      ocrCanvas.width = 0;
-      ocrCanvas.height = 0;
-      ocrCanvas = null;
-    }
+    releaseCanvas(ocrCanvas);
+    ocrCanvas = null;
     decoded.cleanup();
   }
 
```

### `src/storage/localSyncChannels.ts` (`+411` / `-119`, source: `part-15.md`)

```diff
--- working/src/storage/localSyncChannels.ts
+++ import/src/storage/localSyncChannels.ts
@@ -29,17 +29,29 @@
   SyncConflictEntry,
   SyncOperation,
 } from '../core/syncOutbox';
-import { downloadTextFile } from '../utils/webFileActions';
+import { FileShareOutcome, shareTextFileOrDownload } from '../utils/webFileActions';
 import { readBlobAsText } from '../utils/es2018Shims';
 import {
   BackgroundPausedError,
   isDocumentHidden,
+  registerFreezeLifecycleListener,
 } from './backgroundFreezeCoordinator';
 import { logDiagnosticEvent } from './crashLogger';
+import { safeAwaitOpfsClose, safeAwaitOpfsFlush } from './opfsTempStream';
 import {
   decryptTextWithPassphrase,
   encryptTextWithPassphrase,
 } from './passphraseCrypto';
+import {
+  getSafeBroadcastChannelCtor,
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  getSafeWebLocks,
+  registerPendingWebLockAbort,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+  trackBroadcastChannel,
+} from './storageProbes';
 import { getAdjustedNowIsoUtc } from './storageProtection';
 
 const SYNC_IDB_NAME = 'community_pedigree_sync_v1';
@@ -56,6 +68,7 @@
 const DEVICE_ID_LS_KEY = 'pedigree_device_id_v1';
 const LOGICAL_COUNTER_LS_KEY = 'pedigree_logical_counter_v1';
 const SYNC_IDB_TIMEOUT_MS = 7000;
+const DEFAULT_WEB_LOCK_TIMEOUT_MS = 5000;
 const SYNC_OUTBOX_LOCK_NAME = 'community_pedigree_sync_outbox_v1';
 const LOGICAL_COUNTER_LOCK_NAME = 'community_pedigree_logical_counter_v1';
 export const TAB_SYNC_CHANNEL_NAME = 'community_pedigree_tab_sync_v1';
@@ -70,29 +83,145 @@
 
 /**
  * Serializes critical storage/outbox mutations both within the current tab (FIFO queue)
- * and across parallel browser tabs via `navigator.locks` when supported (ES2018 fallback: in-tab FIFO).
+ * and across parallel browser tabs via `navigator.locks` when supported, with a bounded
+ * acquisition timeout, `AbortController` release on `pagehide`/`hidden`, and safe in-tab FIFO
+ * fallback when Web Locks are blocked (Safari Lockdown Mode / Private Browsing) or unsupported.
  * Never nest calls with the same `lockName`.
  */
-export function withCrossTabLock<T>(lockName: string, task: () => Promise<T>): Promise<T> {
+export function withCrossTabLock<T>(
+  lockName: string,
+  task: () => Promise<T>,
+  options?: { timeoutMs?: number }
+): Promise<T> {
   const prev = inTabLockQueues.get(lockName) ?? Promise.resolve();
+  const lockTimeoutMs = Math.max(10, options?.timeoutMs ?? DEFAULT_WEB_LOCK_TIMEOUT_MS);
+
   const executeWithWebLock = async (): Promise<T> => {
-    const nav =
-      typeof navigator !== 'undefined'
-        ? (navigator as unknown as {
-            locks?: {
-              request?: <R>(
-                name: string,
-                options: { mode?: 'exclusive' | 'shared' },
-                callback: () => Promise<R>
-              ) => Promise<R>;
-            };
-          })
-        : undefined;
-    if (nav?.locks && typeof nav.locks.request === 'function') {
-      return nav.locks.request(lockName, { mode: 'exclusive' }, () => task());
-    }
-    return task();
+    const locks = getSafeWebLocks();
+    if (!locks) {
+      return task();
+    }
+
+    let callbackEntered = false;
+    let timedOutFallback = false;
+    let timer: ReturnType<typeof setTimeout> | null = null;
+    let graceTimer: ReturnType<typeof setTimeout> | null = null;
+    const controller = typeof AbortController === 'function' ? new AbortController() : null;
+
+    const cleanupTimers = () => {
+      if (timer !== null) {
+        clearTimeout(timer);
+        timer = null;
+      }
+      if (graceTimer !== null) {
+        clearTimeout(graceTimer);
+        graceTimer = null;
+      }
+    };
+
+    const runWithRequest = async (useSignal: boolean): Promise<T> => {
+      return new Promise<T>((resolve, reject) => {
+        let settled = false;
+        const finishResolve = (val: T) => {
+          if (settled) return;
+          settled = true;
+          cleanupTimers();
+          untrackPending();
+          resolve(val);
+        };
+        const finishReject = (err: unknown) => {
+          if (settled) return;
+          settled = true;
+          cleanupTimers();
+          untrackPending();
+          reject(err);
+        };
+
+        const triggerFallback = () => {
+          if (settled || callbackEntered) return;
+          timedOutFallback = true;
+          if (controller && !controller.signal.aborted) {
+            try {
+              controller.abort();
+            } catch {
+              // Ignore abort failure
+            }
+          }
+          task().then(finishResolve, finishReject);
+        };
+
+        const untrackPending = registerPendingWebLockAbort(() => {
+          if (callbackEntered || settled) return;
+          if (controller && !controller.signal.aborted) {
+            try {
+              controller.abort();
+            } catch {
+              // Ignore abort failure
+            }
+          }
+          graceTimer = setTimeout(triggerFallback, 25);
+        });
+
+        timer = setTimeout(triggerFallback, lockTimeoutMs);
+
+        const reqOpts: { mode?: 'exclusive' | 'shared'; signal?: AbortSignal } =
+          useSignal && controller
+            ? { mode: 'exclusive', signal: controller.signal }
+            : { mode: 'exclusive' };
+
+        try {
+          const reqPromise = locks.request(lockName, reqOpts, async () => {
+            if (timedOutFallback || settled) {
+              return undefined as unknown as T;
+            }
+            callbackEntered = true;
+            cleanupTimers();
+            untrackPending();
+            return await task();
+          });
+
+          Promise.resolve(reqPromise).then(
+            (val) => {
+              if (!timedOutFallback) {
+                finishResolve(val);
+              }
+            },
+            (err) => {
+              if (timedOutFallback || settled) return;
+              if (callbackEntered) {
+                finishReject(err);
+                return;
+              }
+              if (useSignal && controller && err instanceof TypeError) {
+                cleanupTimers();
+                untrackPending();
+                runWithRequest(false).then(finishResolve, finishReject);
+                return;
+              }
+              timedOutFallback = true;
+              task().then(finishResolve, finishReject);
+            }
+          );
+        } catch (syncErr) {
+          if (callbackEntered || timedOutFallback) {
+            finishReject(syncErr);
+            return;
+          }
+          if (useSignal && controller && syncErr instanceof TypeError) {
+            cleanupTimers();
+            untrackPending();
+            runWithRequest(false).then(finishResolve, finishReject);
+            return;
+          }
+          timedOutFallback = true;
+          task().then(finishResolve, finishReject);
+        }
+      });
+    };
+
+    return runWithRequest(Boolean(controller));
   };
+
   const run = prev.catch(() => undefined).then(executeWithWebLock);
   const settled = run.then(
     () => undefined,
@@ -114,12 +243,21 @@
 }
 
 let sharedTabSyncChannel: BroadcastChannel | null = null;
+let untrackSharedTabSyncChannel: (() => void) | null = null;
 
 function getSharedTabSyncChannel(): BroadcastChannel | null {
-  if (typeof BroadcastChannel !== 'function') return null;
+  const Ctor = getSafeBroadcastChannelCtor();
+  if (!Ctor) return null;
   if (!sharedTabSyncChannel) {
     try {
-      sharedTabSyncChannel = new BroadcastChannel(TAB_SYNC_CHANNEL_NAME);
+      const ch = new Ctor(TAB_SYNC_CHANNEL_NAME);
+      sharedTabSyncChannel = ch;
+      untrackSharedTabSyncChannel = trackBroadcastChannel(ch, () => {
+        if (sharedTabSyncChannel === ch) {
+          sharedTabSyncChannel = null;
+          untrackSharedTabSyncChannel = null;
+        }
+      });
     } catch {
       return null;
     }
@@ -138,9 +276,10 @@
     committedAtIso: getAdjustedNowIsoUtc(),
     reason: params.reason,
   };
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
-      localStorage.setItem(DB_WRITE_EPOCH_LS_KEY, JSON.stringify(payload));
+      ls.setItem(DB_WRITE_EPOCH_LS_KEY, JSON.stringify(payload));
     } catch {
       // Non-fatal
     }
@@ -151,6 +290,9 @@
       ch.postMessage(payload);
     } catch {
       // Non-fatal (channel closed/restricted)
+      untrackSharedTabSyncChannel?.();
+      untrackSharedTabSyncChannel = null;
+      sharedTabSyncChannel = null;
     }
   }
   return payload;
@@ -162,6 +304,7 @@
 ): () => void {
   const selfId = options?.selfTabId || CURRENT_TAB_ID;
   let lastDeliveredEpoch = 0;
+  let disposed = false;
 
   const handleCandidate = (raw: unknown) => {
     if (!raw || typeof raw !== 'object') return;
@@ -182,17 +325,43 @@
   };
 
   let bc: BroadcastChannel | null = null;
+  let untrackBc: (() => void) | null = null;
   const onBcMessage = (ev: MessageEvent) => {
     handleCandidate(ev.data);
   };
-  if (typeof BroadcastChannel === 'function') {
+
+  const openBcChannel = () => {
+    if (disposed || bc) return;
+    const Ctor = getSafeBroadcastChannelCtor();
+    if (!Ctor) return;
     try {
-      bc = new BroadcastChannel(TAB_SYNC_CHANNEL_NAME);
-      bc.addEventListener('message', onBcMessage);
+      const channel = new Ctor(TAB_SYNC_CHANNEL_NAME);
+      channel.addEventListener('message', onBcMessage);
+      bc = channel;
+      untrackBc = trackBroadcastChannel(channel, () => {
+        try {
+          channel.removeEventListener('message', onBcMessage);
+        } catch {
+          // Ignore
+        }
+        if (bc === channel) {
+          bc = null;
+          untrackBc = null;
+        }
+      });
     } catch {
       bc = null;
     }
-  }
+  };
+
+  openBcChannel();
+
+  const unregisterLifecycle = registerFreezeLifecycleListener({
+    id: `tab-sync-sub-${generateUuid()}`,
+    onVisible: () => {
+      openBcChannel();
+    },
+  });
 
   const onStorage = (ev: StorageEvent) => {
     if (ev.key !== DB_WRITE_EPOCH_LS_KEY || !ev.newValue) return;
@@ -207,6 +376,10 @@
   }
 
   return () => {
+    disposed = true;
+    unregisterLifecycle();
+    untrackBc?.();
+    untrackBc = null;
     if (bc) {
       try {
         bc.removeEventListener('message', onBcMessage);
@@ -214,6 +387,7 @@
       } catch {
         // Ignore
       }
+      bc = null;
     }
     if (typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
       window.removeEventListener('storage', onStorage);
@@ -262,11 +436,13 @@
 }
 
 export function getOrCreateLocalDeviceId(): string {
+  const ls = getSafeLocalStorage();
+  if (!ls) return `dev-${generateUuid().slice(0, 8)}`;
   try {
-    const existing = localStorage.getItem(DEVICE_ID_LS_KEY);
+    const existing = ls.getItem(DEVICE_ID_LS_KEY);
     if (existing && existing.trim()) return existing.trim();
     const shortId = `dev-${generateUuid().slice(0, 8)}`;
-    localStorage.setItem(DEVICE_ID_LS_KEY, shortId);
+    ls.setItem(DEVICE_ID_LS_KEY, shortId);
     return shortId;
   } catch {
     return `dev-${generateUuid().slice(0, 8)}`;
@@ -274,10 +450,12 @@
 }
 
 export function allocateNextLogicalCounter(): number {
+  const ls = getSafeLocalStorage();
+  if (!ls) return Date.now();
   try {
-    const curr = Number(localStorage.getItem(LOGICAL_COUNTER_LS_KEY) || '0') || 0;
+    const curr = Number(ls.getItem(LOGICAL_COUNTER_LS_KEY) || '0') || 0;
     const next = curr + 1;
-    localStorage.setItem(LOGICAL_COUNTER_LS_KEY, String(next));
+    ls.setItem(LOGICAL_COUNTER_LS_KEY, String(next));
     return next;
   } catch {
     return Date.now();
@@ -290,6 +468,11 @@
 
 function openSyncIdb(): Promise<IDBDatabase> {
   return new Promise((resolve, reject) => {
+    const idb = getSafeIndexedDb();
+    if (!idb) {
+      reject(new Error('Sync IndexedDB is unavailable in this browser context.'));
+      return;
+    }
     let settled = false;
     const timer = setTimeout(() => {
       if (settled) return;
@@ -310,7 +493,7 @@
     };
 
     try {
-      const req = indexedDB.open(SYNC_IDB_NAME, SYNC_IDB_VERSION);
+      const req = idb.open(SYNC_IDB_NAME, SYNC_IDB_VERSION);
       req.onupgradeneeded = () => {
         try {
           const db = req.result;
@@ -379,10 +562,12 @@
   run: (db: IDBDatabase) => Promise<T>
 ): Promise<T> {
   const db = await openSyncIdb();
+  const untrackDb = trackActiveIdbConnection(db);
   let closed = false;
   const safeClose = () => {
     if (closed) return;
     closed = true;
+    untrackDb();
     try {
       db.close();
     } catch {
@@ -399,16 +584,26 @@
 export async function saveSyncCheckpointToIdb(
   checkpoint: SyncCheckpointRecord
 ): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   try {
     await withSyncIdb(
       (db) =>
         new Promise<void>((resolve, reject) => {
           const tx = db.transaction(STORE_CHECKPOINTS, 'readwrite');
+          const untrackTx = trackActiveIdbTransaction(tx);
           tx.objectStore(STORE_CHECKPOINTS).put(checkpoint);
-          tx.oncomplete = () => resolve();
-          tx.onerror = () => reject(tx.error);
-          tx.onabort = () => reject(tx.error || new Error('Sync checkpoint aborted'));
+          tx.oncomplete = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onerror = () => {
+            untrackTx();
+            reject(tx.error);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            reject(tx.error || new Error('Sync checkpoint aborted'));
+          };
         })
     );
   } catch {
@@ -419,16 +614,26 @@
 export async function loadSyncCheckpointFromIdb(
   taskId: string
 ): Promise<SyncCheckpointRecord | null> {
-  if (typeof indexedDB === 'undefined') return null;
+  if (!getSafeIndexedDb()) return null;
   try {
     return await withSyncIdb(
       (db) =>
         new Promise<SyncCheckpointRecord | null>((resolve) => {
           const tx = db.transaction(STORE_CHECKPOINTS, 'readonly');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const req = tx.objectStore(STORE_CHECKPOINTS).get(taskId);
-          req.onsuccess = () => resolve((req.result as SyncCheckpointRecord) || null);
-          req.onerror = () => resolve(null);
-          tx.onabort = () => resolve(null);
+          req.onsuccess = () => {
+            untrackTx();
+            resolve((req.result as SyncCheckpointRecord) || null);
+          };
+          req.onerror = () => {
+            untrackTx();
+            resolve(null);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            resolve(null);
+          };
         })
     );
   } catch {
@@ -437,16 +642,26 @@
 }
 
 export async function clearSyncCheckpointFromIdb(taskId: string): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   try {
     await withSyncIdb(
       (db) =>
         new Promise<void>((resolve) => {
           const tx = db.transaction(STORE_CHECKPOINTS, 'readwrite');
+          const untrackTx = trackActiveIdbTransaction(tx);
           tx.objectStore(STORE_CHECKPOINTS).delete(taskId);
-          tx.oncomplete = () => resolve();
-          tx.onerror = () => resolve();
-          tx.onabort = () => resolve();
+          tx.oncomplete = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onerror = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onabort = () => {
+            untrackTx();
+            resolve();
+          };
         })
     );
   } catch {
@@ -457,13 +672,14 @@
 export async function appendSyncOperationsToIdb(
   ops: SyncOperation[]
 ): Promise<SyncOperation[]> {
-  if (ops.length === 0 || typeof indexedDB === 'undefined') return ops;
+  if (ops.length === 0 || !getSafeIndexedDb()) return ops;
   return withCrossTabLock(SYNC_OUTBOX_LOCK_NAME, async () => {
     try {
       return await withSyncIdb(
         (db) =>
           new Promise<SyncOperation[]>((resolve, reject) => {
             const tx = db.transaction(STORE_OUTBOX, 'readwrite');
+            const untrackTx = trackActiveIdbTransaction(tx);
             const store = tx.objectStore(STORE_OUTBOX);
             let writtenOps: SyncOperation[] = ops;
 
@@ -491,6 +707,7 @@
                   }
                 }
 
+                const ls = getSafeLocalStorage();
                 writtenOps = ops.map((op) => {
                   let used = usedByDevice.get(op.device_id);
                   if (!used) {
@@ -502,13 +719,13 @@
                   if (used.has(counter)) {
                     let lsMax = 0;
                     try {
-                      lsMax = Number(localStorage.getItem(LOGICAL_COUNTER_LS_KEY) || '0') || 0;
+                      lsMax = ls ? Number(ls.getItem(LOGICAL_COUNTER_LS_KEY) || '0') || 0 : 0;
                     } catch {
                       lsMax = 0;
                     }
                     counter = Math.max(currentMax, lsMax) + 1;
                     try {
-                      localStorage.setItem(LOGICAL_COUNTER_LS_KEY, String(counter));
+                      ls?.setItem(LOGICAL_COUNTER_LS_KEY, String(counter));
                     } catch {
                       // Non-fatal
                     }
@@ -529,9 +746,18 @@
             } else {
               for (const op of ops) store.put(op);
             }
-            tx.oncomplete = () => resolve(writtenOps);
-            tx.onerror = () => reject(tx.error);
-            tx.onabort = () => reject(tx.error || new Error('Sync outbox write aborted'));
+            tx.oncomplete = () => {
+              untrackTx();
+              resolve(writtenOps);
+            };
+            tx.onerror = () => {
+              untrackTx();
+              reject(tx.error);
+            };
+            tx.onabort = () => {
+              untrackTx();
+              reject(tx.error || new Error('Sync outbox write aborted'));
+            };
           })
       );
     } catch {
@@ -541,16 +767,26 @@
 }
 
 export async function loadAllSyncOperationsFromIdb(): Promise<SyncOperation[]> {
-  if (typeof indexedDB === 'undefined') return [];
+  if (!getSafeIndexedDb()) return [];
   try {
     return await withSyncIdb(
       (db) =>
         new Promise<SyncOperation[]>((resolve, reject) => {
           const tx = db.transaction(STORE_OUTBOX, 'readonly');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const req = tx.objectStore(STORE_OUTBOX).getAll();
-          req.onsuccess = () => resolve((req.result as SyncOperation[]) || []);
-          req.onerror = () => reject(req.error);
-          tx.onabort = () => reject(tx.error || new Error('Sync outbox read aborted'));
+          req.onsuccess = () => {
+            untrackTx();
+            resolve((req.result as SyncOperation[]) || []);
+          };
+          req.onerror = () => {
+            untrackTx();
+            reject(req.error);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            reject(tx.error || new Error('Sync outbox read aborted'));
+          };
         })
     );
   } catch {
@@ -559,19 +795,29 @@
 }
 
 export async function replaceSyncOperationsInIdb(ops: SyncOperation[]): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   await withCrossTabLock(SYNC_OUTBOX_LOCK_NAME, async () => {
     try {
       await withSyncIdb(
         (db) =>
           new Promise<void>((resolve, reject) => {
             const tx = db.transaction(STORE_OUTBOX, 'readwrite');
+            const untrackTx = trackActiveIdbTransaction(tx);
             const store = tx.objectStore(STORE_OUTBOX);
             store.clear();
             for (const op of ops) store.put(op);
-            tx.oncomplete = () => resolve();
-            tx.onerror = () => reject(tx.error);
-            tx.onabort = () => reject(tx.error || new Error('Sync outbox replace aborted'));
+            tx.oncomplete = () => {
+              untrackTx();
+              resolve();
+            };
+            tx.onerror = () => {
+              untrackTx();
+              reject(tx.error);
+            };
+            tx.onabort = () => {
+              untrackTx();
+              reject(tx.error || new Error('Sync outbox replace aborted'));
+            };
           })
       );
     } catch {
@@ -581,17 +827,27 @@
 }
 
 export async function appendSyncConflictsToIdb(conflicts: SyncConflictEntry[]): Promise<void> {
-  if (conflicts.length === 0 || typeof indexedDB === 'undefined') return;
+  if (conflicts.length === 0 || !getSafeIndexedDb()) return;
   try {
     await withSyncIdb(
       (db) =>
         new Promise<void>((resolve, reject) => {
           const tx = db.transaction(STORE_CONFLICTS, 'readwrite');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const store = tx.objectStore(STORE_CONFLICTS);
           for (const c of conflicts) store.put(c);
-          tx.oncomplete = () => resolve();
-          tx.onerror = () => reject(tx.error);
-          tx.onabort = () => reject(tx.error || new Error('Sync conflicts write aborted'));
+          tx.oncomplete = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onerror = () => {
+            untrackTx();
+            reject(tx.error);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            reject(tx.error || new Error('Sync conflicts write aborted'));
+          };
         })
     );
   } catch {
@@ -600,21 +856,30 @@
 }
 
 export async function loadAllSyncConflictsFromIdb(): Promise<SyncConflictEntry[]> {
-  if (typeof indexedDB === 'undefined') return [];
+  if (!getSafeIndexedDb()) return [];
   try {
     return await withSyncIdb(
       (db) =>
         new Promise<SyncConflictEntry[]>((resolve, reject) => {
           const tx = db.transaction(STORE_CONFLICTS, 'readonly');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const req = tx.objectStore(STORE_CONFLICTS).getAll();
-          req.onsuccess = () =>
+          req.onsuccess = () => {
+            untrackTx();
             resolve(
               ((req.result as SyncConflictEntry[]) || []).sort((a, b) =>
                 b.detected_at.localeCompare(a.detected_at)
               )
             );
-          req.onerror = () => reject(req.error);
-          tx.onabort = () => reject(tx.error || new Error('Sync conflicts read aborted'));
+          };
+          req.onerror = () => {
+            untrackTx();
+            reject(req.error);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            reject(tx.error || new Error('Sync conflicts read aborted'));
+          };
         })
     );
   } catch {
@@ -627,21 +892,31 @@
 }
 
 export async function clearAllSyncStateInIdb(): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   await withCrossTabLock(SYNC_OUTBOX_LOCK_NAME, async () => {
     try {
       await withSyncIdb(
         (db) =>
           new Promise<void>((resolve, reject) => {
             const tx = db.transaction([STORE_OUTBOX, STORE_CONFLICTS, STORE_CHECKPOINTS], 'readwrite');
+            const untrackTx = trackActiveIdbTransaction(tx);
             tx.objectStore(STORE_OUTBOX).clear();
             tx.objectStore(STORE_CONFLICTS).clear();
             if (db.objectStoreNames.contains(STORE_CHECKPOINTS)) {
               tx.objectStore(STORE_CHECKPOINTS).clear();
             }
-            tx.oncomplete = () => resolve();
-            tx.onerror = () => reject(tx.error);
-            tx.onabort = () => reject(tx.error || new Error('Sync state clear aborted'));
+            tx.oncomplete = () => {
+              untrackTx();
+              resolve();
+            };
+            tx.onerror = () => {
+              untrackTx();
+              reject(tx.error);
+            };
+            tx.onabort = () => {
+              untrackTx();
+              reject(tx.error || new Error('Sync state clear aborted'));
+            };
           })
       );
     } catch {
@@ -746,15 +1021,16 @@
 
 function readLocalSyncMeta(): StoredSyncMeta | null {
   try {
-    if (typeof localStorage === 'undefined') return null;
-    let raw = localStorage.getItem(BACKUP_SYNC_META_LS_KEY);
+    const ls = getSafeLocalStorage();
+    if (!ls) return null;
+    let raw = ls.getItem(BACKUP_SYNC_META_LS_KEY);
     if (!raw) {
-      const legacyRaw = localStorage.getItem(LEGACY_BACKUP_SINK_META_LS_KEY);
+      const legacyRaw = ls.getItem(LEGACY_BACKUP_SINK_META_LS_KEY);
       if (legacyRaw) {
         raw = legacyRaw;
         try {
-          localStorage.setItem(BACKUP_SYNC_META_LS_KEY, legacyRaw);
-          localStorage.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
+          ls.setItem(BACKUP_SYNC_META_LS_KEY, legacyRaw);
+          ls.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
         } catch {
           // Ignore migration write failure
         }
@@ -777,13 +1053,14 @@
 
 function writeLocalSyncMeta(meta: StoredSyncMeta | null): void {
   try {
-    if (typeof localStorage === 'undefined') return;
+    const ls = getSafeLocalStorage();
+    if (!ls) return;
     if (!meta) {
-      localStorage.removeItem(BACKUP_SYNC_META_LS_KEY);
-      localStorage.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
+      ls.removeItem(BACKUP_SYNC_META_LS_KEY);
+      ls.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
     } else {
-      localStorage.setItem(BACKUP_SYNC_META_LS_KEY, JSON.stringify(meta));
-      localStorage.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
+      ls.setItem(BACKUP_SYNC_META_LS_KEY, JSON.stringify(meta));
+      ls.removeItem(LEGACY_BACKUP_SINK_META_LS_KEY);
     }
   } catch {
     // Non-fatal
@@ -798,12 +1075,13 @@
     configuredAtIso,
     lastPushError: null,
   });
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   try {
     await withSyncIdb(
       (db) =>
         new Promise<void>((resolve, reject) => {
           const tx = db.transaction(STORE_HANDLES, 'readwrite');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const store = tx.objectStore(STORE_HANDLES);
           const rec: StoredHandleRecord = {
             key: BACKUP_SYNC_HANDLE_KEY,
@@ -813,9 +1091,18 @@
           };
           store.put(rec);
           store.delete(LEGACY_BACKUP_SINK_HANDLE_KEY);
-          tx.oncomplete = () => resolve();
-          tx.onerror = () => reject(tx.error);
-          tx.onabort = () => reject(tx.error || new Error('Sync handle write aborted'));
+          tx.oncomplete = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onerror = () => {
+            untrackTx();
+            reject(tx.error);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            reject(tx.error || new Error('Sync handle write aborted'));
+          };
         })
     );
   } catch {
@@ -832,17 +1119,19 @@
       configuredAtIso: getAdjustedNowIsoUtc(),
     };
   }
-  if (typeof indexedDB === 'undefined') return null;
+  if (!getSafeIndexedDb()) return null;
   try {
     return await withSyncIdb(
       (db) =>
         new Promise<StoredHandleRecord | null>((resolve) => {
           const tx = db.transaction(STORE_HANDLES, 'readonly');
+          const untrackTx = trackActiveIdbTransaction(tx);
           const store = tx.objectStore(STORE_HANDLES);
           const req = store.get(BACKUP_SYNC_HANDLE_KEY);
           req.onsuccess = () => {
             const res = req.result as StoredHandleRecord | undefined;
             if (res?.handle) {
+              untrackTx();
               resolve(res);
               return;
             }
@@ -850,12 +1139,22 @@
             const legacyReq = store.get(LEGACY_BACKUP_SINK_HANDLE_KEY);
             legacyReq.onsuccess = () => {
               const legacyRes = legacyReq.result as StoredHandleRecord | undefined;
+              untrackTx();
               resolve(legacyRes?.handle ? legacyRes : null);
             };
-            legacyReq.onerror = () => resolve(null);
-          };
-          req.onerror = () => resolve(null);
-          tx.onabort = () => resolve(null);
+            legacyReq.onerror = () => {
+              untrackTx();
+              resolve(null);
+            };
+          };
+          req.onerror = () => {
+            untrackTx();
+            resolve(null);
+          };
+          tx.onabort = () => {
+            untrackTx();
+            resolve(null);
+          };
         })
     );
   } catch {
@@ -956,18 +1255,28 @@
 
 export async function disconnectBackupSyncFolder(): Promise<BackupSyncStatus> {
   writeLocalSyncMeta(null);
-  if (typeof indexedDB !== 'undefined') {
+  if (getSafeIndexedDb()) {
     try {
       await withSyncIdb(
         (db) =>
           new Promise<void>((resolve) => {
             const tx = db.transaction(STORE_HANDLES, 'readwrite');
+            const untrackTx = trackActiveIdbTransaction(tx);
             const store = tx.objectStore(STORE_HANDLES);
             store.delete(BACKUP_SYNC_HANDLE_KEY);
             store.delete(LEGACY_BACKUP_SINK_HANDLE_KEY);
-            tx.oncomplete = () => resolve();
-            tx.onerror = () => resolve();
-            tx.onabort = () => resolve();
+            tx.oncomplete = () => {
+              untrackTx();
+              resolve();
+            };
+            tx.onerror = () => {
+              untrackTx();
+              resolve();
+            };
+            tx.onabort = () => {
+              untrackTx();
+              resolve();
+            };
           })
       );
     } catch {
@@ -1019,8 +1328,9 @@
     const writable = await fh.createWritable();
     try {
       await writable.write(data);
+      await safeAwaitOpfsFlush(writable);
     } finally {
-      await writable.close();
+      await safeAwaitOpfsClose(writable);
     }
     const prev = readLocalSyncMeta();
     writeLocalSyncMeta({
@@ -1158,8 +1468,9 @@
   const deltaWritable = await deltaHandle.createWritable();
   try {
     await deltaWritable.write(deltaPayload);
+    await safeAwaitOpfsFlush(deltaWritable);
   } finally {
-    await deltaWritable.close();
+    await safeAwaitOpfsClose(deltaWritable);
   }
 
   if (isDocumentHidden(params.visibilityDoc)) {
@@ -1188,8 +1499,9 @@
   const masterWritable = await masterHandle.createWritable();
   try {
     await masterWritable.write(masterPayload);
+    await safeAwaitOpfsFlush(masterWritable);
   } finally {
-    await masterWritable.close();
+    await safeAwaitOpfsClose(masterWritable);
   }
 
   await clearSyncCheckpointFromIdb('directory_sync');
@@ -1304,26 +1616,6 @@
   content: string;
   mimeType: string;
   title: string;
-}): Promise<'shared' | 'downloaded'> {
-  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
-    try {
-      const file = new File([params.content], params.filename, {
-        type: params.mimeType,
-      });
-      if (navigator.canShare && navigator.canShare({ files: [file] })) {
-        await navigator.share({
-          title: params.title,
-          files: [file],
-        });
-        return 'shared';
-      }
-    } catch (err) {
-      if ((err as { name?: string })?.name === 'AbortError') {
-        return 'shared';
-      }
-      // Fall back to direct file download
-    }
-  }
-  await downloadTextFile(params.filename, params.content, params.mimeType);
-  return 'downloaded';
-}
+}): Promise<FileShareOutcome> {
+  return shareTextFileOrDownload(params);
+}
```

### `src/storage/offThreadWorkerClient.ts` (`+15` / `-13`, source: `part-15.md`)

```diff
--- working/src/storage/offThreadWorkerClient.ts
+++ import/src/storage/offThreadWorkerClient.ts
@@ -10,18 +10,10 @@
  * or restricted environments where `Worker` is unavailable.
  */
 
-import {
-  inspectParsedArchiveBeforeRestorePure,
-  PreRestoreArchiveInspection,
-} from '../core/archiveInspector';
-import {
+import type { PreRestoreArchiveInspection } from '../core/archiveInspector';
+import type {
   BackupArchiveBuildResult,
-  buildCompleteBackupZipArchive,
-  buildPhotosOnlyZipArchive,
-  parseBackupArchiveInput,
   ParsedBackupArchive,
-  streamCompleteBackupZipArchive,
-  streamPhotosOnlyZipArchive,
   StreamingZipArchiveSummary,
 } from '../core/backupArchive';
 import type {
@@ -29,14 +21,12 @@
   PlatformImportPreview,
   RawArchiveInput,
 } from '../core/importers/importerTypes';
-import { getPlatformImporterById } from '../core/importers/registry';
 import {
   type BarnDatabaseSnapshot,
   type BarnSettings,
   getCoreClockSkewMs,
 } from '../core/models';
-import {
-  buildSupportBundleZipArchive,
+import type {
   SupportBundleBuildParams,
   SupportBundleBuildResult,
 } from '../core/supportBundle';
@@ -298,6 +288,7 @@
     }
     return res;
   }
+  const { streamCompleteBackupZipArchive } = await import('../core/backupArchive');
   return runStreamedZipMainThreadFallback('archive', (onChunk) =>
     streamCompleteBackupZipArchive(snapshot, onChunk, filterSpecies, extraMeta)
   );
@@ -320,6 +311,7 @@
     }
     return res;
   }
+  const { streamPhotosOnlyZipArchive } = await import('../core/backupArchive');
   return runStreamedZipMainThreadFallback('photos-archive', (onChunk) =>
     streamPhotosOnlyZipArchive(snapshot, onChunk, filterSpecies)
   );
@@ -345,6 +337,7 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const { buildCompleteBackupZipArchive } = await import('../core/backupArchive');
   return buildCompleteBackupZipArchive(snapshot, filterSpecies, extraMeta);
 }
 
@@ -362,6 +355,7 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const { buildPhotosOnlyZipArchive } = await import('../core/backupArchive');
   return buildPhotosOnlyZipArchive(snapshot, filterSpecies);
 }
 
@@ -381,6 +375,7 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const { parseBackupArchiveInput } = await import('../core/backupArchive');
   return parseBackupArchiveInput(bytes, fileName, fallbackSettings);
 }
 
@@ -403,6 +398,7 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const { getPlatformImporterById } = await import('../core/importers/registry');
   const importer = getPlatformImporterById(platformId);
   return importer.parse(inputs, lightSnapshot, options);
 }
@@ -419,6 +415,7 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const { buildSupportBundleZipArchive } = await import('../core/supportBundle');
   return buildSupportBundleZipArchive(params);
 }
 
@@ -447,6 +444,11 @@
     return workerPromise;
   }
   await yieldToUiFrame();
+  const [{ parseBackupArchiveInput }, { inspectParsedArchiveBeforeRestorePure }] =
+    await Promise.all([
+      import('../core/backupArchive'),
+      import('../core/archiveInspector'),
+    ]);
   const parsed = parseBackupArchiveInput(
     bytes,
     fileName,
```

### `src/storage/opfsStorage.ts` (`+80` / `-26`, source: `part-15.md`)

```diff
--- working/src/storage/opfsStorage.ts
+++ import/src/storage/opfsStorage.ts
@@ -48,17 +48,26 @@
   isOpfsSupported,
   listDirEntries,
   markTempOpfsFileActive,
+  OpfsCloseableHandle,
   OpfsDirectoryHandle,
   OpfsFileHandle,
   OpfsNamespace,
+  OpfsSyncAccessHandle,
   OpfsWritableStream,
+  probeOpfsRuntime,
   purgeOpfsTmp,
   readOpfsFileBytes,
   readOpfsFileText,
   readTempOpfsFileAsBlob,
   registerOpfsDiagnosticLogger,
+  releaseActiveOpfsHandles,
   removeOpfsEntrySafe,
   removeTempOpfsFile,
+  resetOpfsProbesForTests,
+  safeAwaitOpfsClose,
+  safeAwaitOpfsFlush,
+  safeAwaitOpfsGetSize,
+  safeAwaitOpfsTruncate,
   setOpfsRootResolverForTest,
   StreamedOpfsTempFileResult,
   sweepOrphanedOpfsTmpOnBoot,
@@ -67,6 +76,12 @@
   writeTempOpfsFile,
   writeTempOpfsFileStreamed,
 } from './opfsTempStream';
+import {
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+} from './storageProbes';
 import { isQuotaExceededError } from './storageProtection';
 
 registerOpfsDiagnosticLogger((ev) => {
@@ -77,9 +92,16 @@
   getOpfsSubdir,
   isOpfsSupported,
   markTempOpfsFileActive,
+  probeOpfsRuntime,
   purgeOpfsTmp,
   readTempOpfsFileAsBlob,
+  releaseActiveOpfsHandles,
   removeTempOpfsFile,
+  resetOpfsProbesForTests,
+  safeAwaitOpfsClose,
+  safeAwaitOpfsFlush,
+  safeAwaitOpfsGetSize,
+  safeAwaitOpfsTruncate,
   setOpfsRootResolverForTest,
   sweepOrphanedOpfsTmpOnBoot,
   unmarkTempOpfsFileActive,
@@ -87,9 +109,11 @@
   writeTempOpfsFileStreamed,
 };
 export type {
+  OpfsCloseableHandle,
   OpfsDirectoryHandle,
   OpfsFileHandle,
   OpfsNamespace,
+  OpfsSyncAccessHandle,
   OpfsWritableStream,
   StreamedOpfsTempFileResult,
 };
@@ -138,9 +162,10 @@
 }
 
 export function readOpfsPruneSyncWarning(): OpfsPruneSyncWarning | null {
-  if (typeof localStorage === 'undefined') return null;
+  const ls = getSafeLocalStorage();
+  if (!ls) return null;
   try {
-    const raw = localStorage.getItem(OPFS_PRUNE_WARNING_KEY);
+    const raw = ls.getItem(OPFS_PRUNE_WARNING_KEY);
     if (!raw) return null;
     const parsed = JSON.parse(raw) as Partial<OpfsPruneSyncWarning>;
     if (!parsed || typeof parsed !== 'object' || typeof parsed.lastFileName !== 'string') {
@@ -170,9 +195,10 @@
 }
 
 export function clearOpfsPruneSyncWarning(): void {
-  if (typeof localStorage === 'undefined') return;
+  const ls = getSafeLocalStorage();
+  if (!ls) return;
   try {
-    localStorage.removeItem(OPFS_PRUNE_WARNING_KEY);
+    ls.removeItem(OPFS_PRUNE_WARNING_KEY);
   } catch {
     // Ignore
   }
@@ -209,9 +235,10 @@
       ? `${totalCount} expiring local backup(s) could not offload (${reasonNote}) and were retained locally until sync succeeds. Re-authorize your Backup Sync folder or export a manual backup.`
       : `${totalCount} aging local backup(s) rolled off storage without an off-device sync copy (${reasonNote}). Connect a sync folder or download a manual backup.`,
   };
-  if (typeof localStorage !== 'undefined') {
+  const ls = getSafeLocalStorage();
+  if (ls) {
     try {
-      localStorage.setItem(OPFS_PRUNE_WARNING_KEY, JSON.stringify(next));
+      ls.setItem(OPFS_PRUNE_WARNING_KEY, JSON.stringify(next));
     } catch {
       // Non-fatal
     }
@@ -896,9 +923,10 @@
 // ---------------------------------------------------------------------------
 
 export function readPriorUseSentinel(): PriorUseSentinel | null {
-  if (typeof localStorage === 'undefined') return null;
+  const ls = getSafeLocalStorage();
+  if (!ls) return null;
   try {
-    const raw = localStorage.getItem(PRIOR_USE_SENTINEL_KEY);
+    const raw = ls.getItem(PRIOR_USE_SENTINEL_KEY);
     if (!raw) return null;
     const parsed = JSON.parse(raw) as Partial<PriorUseSentinel>;
     if (!parsed || typeof parsed !== 'object') return null;
@@ -914,7 +942,8 @@
 }
 
 export function markPriorUseSentinelFromSnapshot(snapshot: BarnDatabaseSnapshot): void {
-  if (typeof localStorage === 'undefined') return;
+  const ls = getSafeLocalStorage();
+  if (!ls) return;
   const nonTestingCount = snapshot.animals.filter((a) => !isSampleTestingId(a.id)).length;
   const hasReal = hasNonTestingBarnData(snapshot) || Boolean(snapshot.settings.barnNameOnboarded);
   if (!hasReal && !readPriorUseSentinel()) {
@@ -927,16 +956,17 @@
       nonTestingCount,
       lastSeenIso: nowIsoUtc(),
     };
-    localStorage.setItem(PRIOR_USE_SENTINEL_KEY, JSON.stringify(next));
+    ls.setItem(PRIOR_USE_SENTINEL_KEY, JSON.stringify(next));
   } catch {
     // Ignore localStorage quota failures
   }
 }
 
 export function clearPriorUseSentinel(): void {
-  if (typeof localStorage === 'undefined') return;
+  const ls = getSafeLocalStorage();
+  if (!ls) return;
   try {
-    localStorage.removeItem(PRIOR_USE_SENTINEL_KEY);
+    ls.removeItem(PRIOR_USE_SENTINEL_KEY);
   } catch {
     // Ignore
   }
@@ -997,16 +1027,17 @@
 export function shouldRunExportCanary(nowMs: number = Date.now()): boolean {
   if (!isOpfsSupported()) return false;
   if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return false;
-  if (typeof localStorage === 'undefined') return true;
+  const ls = getSafeLocalStorage();
+  if (!ls) return true;
   try {
-    const failRaw = localStorage.getItem(CANARY_LAST_FAIL_KEY);
+    const failRaw = ls.getItem(CANARY_LAST_FAIL_KEY);
     if (failRaw) {
       const failMs = Number(failRaw);
       if (Number.isFinite(failMs) && failMs > 0 && nowMs - failMs < CANARY_FAILURE_COOLDOWN_MS) {
         return false;
       }
     }
-    const raw = localStorage.getItem(CANARY_LAST_RUN_KEY);
+    const raw = ls.getItem(CANARY_LAST_RUN_KEY);
     if (!raw) return true;
     const prevMs = Number(raw);
     if (!Number.isFinite(prevMs) || prevMs <= 0) return true;
@@ -1017,9 +1048,10 @@
 }
 
 function recordCanaryFailureTimestamp(): void {
-  if (typeof localStorage === 'undefined') return;
+  const ls = getSafeLocalStorage();
+  if (!ls) return;
   try {
-    localStorage.setItem(CANARY_LAST_FAIL_KEY, String(Date.now()));
+    ls.setItem(CANARY_LAST_FAIL_KEY, String(Date.now()));
   } catch {
     // Non-fatal
   }
@@ -1068,10 +1100,11 @@
       return { ok: false, skippedHeavyZip: policy.skipHeavyCanaryZip, reason: verified.reason };
     }
 
-    if (typeof localStorage !== 'undefined') {
+    const ls = getSafeLocalStorage();
+    if (ls) {
       try {
-        localStorage.setItem(CANARY_LAST_RUN_KEY, String(Date.now()));
-        localStorage.removeItem(CANARY_LAST_FAIL_KEY);
+        ls.setItem(CANARY_LAST_RUN_KEY, String(Date.now()));
+        ls.removeItem(CANARY_LAST_FAIL_KEY);
       } catch {
         // Non-fatal
       }
@@ -1245,9 +1278,11 @@
   dbName: string,
   reason: string
 ): Promise<VaultBackupMetadata | null> {
-  if (typeof indexedDB === 'undefined') return null;
+  const idb = getSafeIndexedDb();
+  if (!idb) return null;
 
   let rescuedDb: IDBDatabase | null = null;
+  let untrackDb: (() => void) | null = null;
   try {
     rescuedDb = await new Promise<IDBDatabase>((resolve, reject) => {
       let settled = false;
@@ -1257,7 +1292,7 @@
         reject(new Error('Rescue IndexedDB open timed out'));
       }, 4000);
       try {
-        const req = indexedDB.open(dbName);
+        const req = idb.open(dbName);
         req.onsuccess = () => {
           if (settled) {
             try {
@@ -1285,6 +1320,7 @@
         }
       }
     });
+    untrackDb = trackActiveIdbConnection(rescuedDb);
 
     const storeNames = Array.from(rescuedDb.objectStoreNames);
     const dumpedStores: Record<string, unknown[]> = {};
@@ -1294,6 +1330,7 @@
       await new Promise<void>((resolve) => {
         try {
           const tx = rescuedDb!.transaction(storeNames, 'readonly');
+          const untrackTx = trackActiveIdbTransaction(tx);
           let pending = storeNames.length;
           for (const storeName of storeNames) {
             const store = tx.objectStore(storeName);
@@ -1319,15 +1356,31 @@
                 }
               }
               pending--;
-              if (pending === 0) resolve();
+              if (pending === 0) {
+                untrackTx();
+                resolve();
+              }
             };
             getAllReq.onerror = () => {
               pending--;
-              if (pending === 0) resolve();
+              if (pending === 0) {
+                untrackTx();
+                resolve();
+              }
             };
           }
-          tx.oncomplete = () => resolve();
-          tx.onerror = () => resolve();
+          tx.oncomplete = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onerror = () => {
+            untrackTx();
+            resolve();
+          };
+          tx.onabort = () => {
+            untrackTx();
+            resolve();
+          };
         } catch {
           resolve();
         }
@@ -1349,6 +1402,7 @@
     });
     return null;
   } finally {
+    untrackDb?.();
     if (rescuedDb) {
       try {
         rescuedDb.close();
```

### `src/storage/opfsTempStream.ts` (`+266` / `-27`, source: `part-15.md`)

```diff
--- working/src/storage/opfsTempStream.ts
+++ import/src/storage/opfsTempStream.ts
@@ -11,19 +11,33 @@
 
 import { generateUuid } from '../core/models';
 import { readBlobAsArrayBuffer, readBlobAsText } from '../utils/es2018Shims';
+import { getSafeStorageManager } from './storageProbes';
 
 export type OpfsNamespace = 'tmp' | 'backups' | 'archives';
 
 export interface OpfsWritableStream {
   write(data: string | Uint8Array | ArrayBuffer | Blob): Promise<void>;
-  close(): Promise<void>;
-}
+  close(): void | Promise<void>;
+  flush?: () => void | Promise<void>;
+  truncate?: (size: number) => void | Promise<void>;
+}
+
+export interface OpfsSyncAccessHandle {
+  write(buffer: ArrayBuffer | ArrayBufferView, options?: { at?: number }): number;
+  flush(): void | Promise<void>;
+  getSize(): number | Promise<number>;
+  truncate(newSize: number): void | Promise<void>;
+  close(): void | Promise<void>;
+}
+
+export type OpfsCloseableHandle = OpfsWritableStream | OpfsSyncAccessHandle;
 
 export interface OpfsFileHandle {
   kind?: 'file';
   name: string;
   getFile(): Promise<File | Blob>;
-  createWritable(): Promise<OpfsWritableStream>;
+  createWritable?: () => Promise<OpfsWritableStream>;
+  createSyncAccessHandle?: () => Promise<OpfsSyncAccessHandle>;
 }
 
 export interface OpfsDirectoryHandle {
@@ -54,6 +68,9 @@
 const TEMP_TEXT_SLICE_CHARS = 128 * 1024;
 
 const activeTempFiles = new Set<string>();
+const activeOpfsHandles = new Set<OpfsCloseableHandle>();
+const closedOpfsHandles = new WeakSet<object>();
+let blockedStorageManagers = new WeakSet<object>();
 let testRootResolver: (() => Promise<OpfsDirectoryHandle | null>) | null = null;
 let diagnosticLogger: OpfsDiagnosticLogger | null = null;
 
@@ -81,6 +98,85 @@
   );
 }
 
+/**
+ * Safely awaits `handle.close()` across both modern synchronous returns (`void`)
+ * and legacy Promise returns (Safari 15.2–16.3), preventing double-close errors.
+ */
+export async function safeAwaitOpfsClose(handle: OpfsCloseableHandle | null | undefined): Promise<void> {
+  if (!handle) return;
+  activeOpfsHandles.delete(handle);
+  if (typeof handle === 'object' && closedOpfsHandles.has(handle)) {
+    return;
+  }
+  if (typeof handle === 'object') {
+    closedOpfsHandles.add(handle);
+  }
+  if (typeof handle.close === 'function') {
+    await Promise.resolve(handle.close());
+  }
+}
+
+/**
+ * Safely awaits `handle.flush()` across synchronous (`void`) and legacy Promise returns.
+ */
+export async function safeAwaitOpfsFlush(
+  handle: { flush?: () => void | Promise<void> } | null | undefined
+): Promise<void> {
+  if (!handle || typeof handle.flush !== 'function') return;
+  await Promise.resolve(handle.flush());
+}
+
+/**
+ * Safely awaits `handle.getSize()` across synchronous (`number`) and legacy Promise returns (Safari 15.2–16.3).
+ */
+export async function safeAwaitOpfsGetSize(
+  handle: { getSize?: () => number | Promise<number> } | null | undefined
+): Promise<number> {
+  if (!handle || typeof handle.getSize !== 'function') return 0;
+  const size = await Promise.resolve(handle.getSize());
+  return Number.isFinite(Number(size)) ? Number(size) : 0;
+}
+
+/**
+ * Safely awaits `handle.truncate(newSize)` across synchronous (`void`) and legacy Promise returns (Safari 15.2–16.3).
+ */
+export async function safeAwaitOpfsTruncate(
+  handle: { truncate?: (newSize: number) => void | Promise<void> } | null | undefined,
+  newSize: number
+): Promise<void> {
+  if (!handle || typeof handle.truncate !== 'function') return;
+  await Promise.resolve(handle.truncate(newSize));
+}
+
+export function trackActiveOpfsHandle<T extends OpfsCloseableHandle>(handle: T): () => void {
+  activeOpfsHandles.add(handle);
+  return () => {
+    activeOpfsHandles.delete(handle);
+  };
+}
+
+/**
+ * Closes any currently tracked open OPFS writable or sync handles cleanly on `pagehide`
+ * or `visibilitychange` (`hidden`) to protect bfcache and avoid stale locks.
+ */
+export async function releaseActiveOpfsHandles(): Promise<number> {
+  const handles = Array.from(activeOpfsHandles);
+  let released = 0;
+  for (const handle of handles) {
+    try {
+      await safeAwaitOpfsClose(handle);
+      released++;
+    } catch {
+      // Ignore release failures on already-closed or invalidated handles
+    }
+  }
+  return released;
+}
+
+export function getActiveOpfsHandleCountForTests(): number {
+  return activeOpfsHandles.size;
+}
+
 export function markTempOpfsFileActive(fileName: string): void {
   if (fileName) activeTempFiles.add(fileName);
 }
@@ -91,6 +187,12 @@
 
 export function isTempOpfsFileActive(fileName: string): boolean {
   return Boolean(fileName && activeTempFiles.has(fileName));
+}
+
+export function resetOpfsProbesForTests(): void {
+  blockedStorageManagers = new WeakSet<object>();
+  activeOpfsHandles.clear();
+  activeTempFiles.clear();
 }
 
 /**
@@ -103,30 +205,82 @@
   testRootResolver = resolver;
   if (!resolver) {
     activeTempFiles.clear();
+    activeOpfsHandles.clear();
   }
 }
 
 export function isOpfsSupported(): boolean {
   if (testRootResolver) return true;
-  if (typeof navigator === 'undefined') return false;
-  const storage = navigator.storage as (StorageManager & { getDirectory?: unknown }) | undefined;
-  return Boolean(storage && typeof storage.getDirectory === 'function');
+  const storage = getSafeStorageManager();
+  if (!storage) return false;
+  if (blockedStorageManagers.has(storage)) return false;
+  try {
+    return typeof storage.getDirectory === 'function';
+  } catch {
+    return false;
+  }
+}
+
+export async function probeOpfsRuntime(): Promise<{
+  supported: boolean;
+  reason?: string;
+}> {
+  if (testRootResolver) {
+    try {
+      const root = await testRootResolver();
+      return { supported: Boolean(root) };
+    } catch (err) {
+      return { supported: false, reason: err instanceof Error ? err.message : String(err) };
+    }
+  }
+  const storage = getSafeStorageManager();
+  if (!storage || typeof storage.getDirectory !== 'function') {
+    return { supported: false, reason: 'navigator.storage.getDirectory is unavailable' };
+  }
+  try {
+    const root = (await storage.getDirectory()) as OpfsDirectoryHandle | null;
+    if (!root) {
+      blockedStorageManagers.add(storage);
+      return { supported: false, reason: 'OPFS root directory returned null' };
+    }
+    return { supported: true };
+  } catch (err) {
+    blockedStorageManagers.add(storage);
+    return { supported: false, reason: err instanceof Error ? err.message : String(err) };
+  }
 }
 
 export async function getOpfsRoot(): Promise<OpfsDirectoryHandle | null> {
   if (testRootResolver) {
-    return testRootResolver();
-  }
-  if (typeof navigator === 'undefined') return null;
-  const storage = navigator.storage as
-    | (StorageManager & { getDirectory?: () => Promise<OpfsDirectoryHandle> })
-    | undefined;
-  if (!storage || typeof storage.getDirectory !== 'function') {
+    try {
+      return await testRootResolver();
+    } catch (err) {
+      emitOpfsLog({
+        level: 'warn',
+        category: 'storage',
+        message: 'OPFS root resolver rejected — using fallback storage',
+        error: err,
+      });
+      return null;
+    }
+  }
+  const storage = getSafeStorageManager();
+  if (!storage) return null;
+  if (blockedStorageManagers.has(storage)) return null;
+  let getDirFn: (() => Promise<unknown>) | undefined;
+  try {
+    getDirFn = typeof storage.getDirectory === 'function' ? storage.getDirectory : undefined;
+  } catch {
+    blockedStorageManagers.add(storage);
     return null;
   }
-  try {
-    return (await storage.getDirectory()) as unknown as OpfsDirectoryHandle;
+  if (!getDirFn) {
+    return null;
+  }
+  try {
+    return (await getDirFn.call(storage)) as unknown as OpfsDirectoryHandle;
   } catch (err) {
+    blockedStorageManagers.add(storage);
     emitOpfsLog({
       level: 'warn',
       category: 'storage',
@@ -256,8 +410,90 @@
   await writable.write(data);
 }
 
-/**
- * Writes payload to a file inside `dir`, guaranteeing `writable.close()` inside `try / finally`.
+async function chunkDataToUint8Arrays(data: string | Uint8Array | Blob): Promise<Uint8Array[]> {
+  if (typeof data === 'string') {
+    if (data.length === 0) return [];
+    const encoder = typeof TextEncoder === 'function' ? new TextEncoder() : null;
+    const chunks: Uint8Array[] = [];
+    let offset = 0;
+    while (offset < data.length) {
+      const { slice, nextOffset } = sliceUtf16Safe(data, offset, TEMP_TEXT_SLICE_CHARS);
+      if (slice.length > 0) {
+        if (encoder) {
+          chunks.push(encoder.encode(slice));
+        } else {
+          const buf = await readBlobAsArrayBuffer(new Blob([slice]));
+          chunks.push(new Uint8Array(buf));
+        }
+      }
+      offset = nextOffset;
+    }
+    return chunks;
+  }
+
+  if (data instanceof Uint8Array) {
+    if (data.byteLength <= TEMP_WRITE_CHUNK_BYTES) return [data];
+    const chunks: Uint8Array[] = [];
+    for (let offset = 0; offset < data.byteLength; offset += TEMP_WRITE_CHUNK_BYTES) {
+      chunks.push(
+        data.subarray(offset, Math.min(data.byteLength, offset + TEMP_WRITE_CHUNK_BYTES))
+      );
+    }
+    return chunks;
+  }
+
+  const buf = await readBlobAsArrayBuffer(data);
+  const bytes = new Uint8Array(buf);
+  return chunkDataToUint8Arrays(bytes);
+}
+
+async function openOpfsHandleSink(fh: OpfsFileHandle): Promise<{
+  handle: OpfsCloseableHandle;
+  writeChunk: (chunk: string | Uint8Array | Blob) => Promise<void>;
+  flushAndSize: () => Promise<number | null>;
+}> {
+  if (typeof fh.createWritable === 'function') {
+    const writable = await fh.createWritable();
+    trackActiveOpfsHandle(writable);
+    return {
+      handle: writable,
+      writeChunk: (chunk) => writeChunkedDataToWritable(writable, chunk),
+      flushAndSize: async () => {
+        await safeAwaitOpfsFlush(writable);
+        return null;
+      },
+    };
+  }
+
+  if (typeof fh.createSyncAccessHandle === 'function') {
+    // Standard Worker OPFS access (no Chromium-only { mode: 'readwrite-unsafe' })
+    const syncHandle = await fh.createSyncAccessHandle();
+    trackActiveOpfsHandle(syncHandle);
+    await safeAwaitOpfsTruncate(syncHandle, 0);
+    let cursor = 0;
+    return {
+      handle: syncHandle,
+      writeChunk: async (chunk) => {
+        const byteSlices = await chunkDataToUint8Arrays(chunk);
+        for (const slice of byteSlices) {
+          if (slice.byteLength === 0) continue;
+          const written = syncHandle.write(slice, { at: cursor });
+          cursor += Number(written) > 0 ? Number(written) : slice.byteLength;
+        }
+      },
+      flushAndSize: async () => {
+        await safeAwaitOpfsFlush(syncHandle);
+        return safeAwaitOpfsGetSize(syncHandle);
+      },
+    };
+  }
+
+  throw new Error('OPFS file handle supports neither createWritable nor createSyncAccessHandle.');
+}
+
+/**
+ * Writes payload to a file inside `dir`, guaranteeing handle flush + close inside `try / finally`
+ * across both `FileSystemWritableFileStream` and Safari 15.2–16.3 worker `FileSystemSyncAccessHandle`.
  * If `QuotaExceededError` occurs, purges `/tmp` and retries the write once cleanly.
  */
 export async function writeFileToOpfsDir(
@@ -267,17 +503,18 @@
 ): Promise<void> {
   const runWrite = async () => {
     const fh = await dir.getFileHandle(fileName, { create: true });
-    const writable = await fh.createWritable();
+    const sink = await openOpfsHandleSink(fh);
     let bodySucceeded = false;
     try {
-      await writeChunkedDataToWritable(writable, data);
+      await sink.writeChunk(data);
+      await sink.flushAndSize();
       bodySucceeded = true;
     } finally {
       if (bodySucceeded) {
-        await writable.close();
+        await safeAwaitOpfsClose(sink.handle);
       } else {
         try {
-          await writable.close();
+          await safeAwaitOpfsClose(sink.handle);
         } catch {
           // Preserve primary write error so QuotaExceededError recovery runs cleanly
         }
@@ -360,7 +597,7 @@
 
 /**
  * Streams incremental chunks directly into an OPFS `/tmp` file handle without materializing
- * full-export string or `Uint8Array` buffers in JS heap beforehand. Guarantees `writable.close()`
+ * full-export string or `Uint8Array` buffers in JS heap beforehand. Guarantees `safeAwaitOpfsClose()`
  * inside `try/finally`, cleans up partial files on abort, and recovers from `QuotaExceededError` once.
  */
 export async function writeTempOpfsFileStreamed<T = void>(
@@ -380,22 +617,24 @@
 
   const runAttempt = async (): Promise<StreamedOpfsTempFileResult<T>> => {
     const fh = await tmpDir.getFileHandle(fileName, { create: true });
-    const writable = await fh.createWritable();
+    const sink = await openOpfsHandleSink(fh);
     let bodySucceeded = false;
     let meta: T;
+    let flushedSize: number | null = null;
     try {
       meta = await produceChunks(async (chunk) => {
         if (typeof chunk === 'string' && chunk.length === 0) return;
         if (chunk instanceof Uint8Array && chunk.byteLength === 0) return;
-        await writeChunkedDataToWritable(writable, chunk);
+        await sink.writeChunk(chunk);
       });
+      flushedSize = await sink.flushAndSize();
       bodySucceeded = true;
     } finally {
       if (bodySucceeded) {
-        await writable.close();
+        await safeAwaitOpfsClose(sink.handle);
       } else {
         try {
-          await writable.close();
+          await safeAwaitOpfsClose(sink.handle);
         } catch {
           // Preserve primary write error so QuotaExceededError recovery triggers cleanly
         }
@@ -404,7 +643,7 @@
     const file = await fh.getFile();
     return {
       fileName,
-      byteSize: Number(file.size) || 0,
+      byteSize: Number(file.size) || flushedSize || 0,
       blob: file,
       meta,
     };
```

### `src/storage/pedigreeOcrScanner.ts` (`+22` / `-9`, source: `part-15.md`)

```diff
--- working/src/storage/pedigreeOcrScanner.ts
+++ import/src/storage/pedigreeOcrScanner.ts
@@ -38,6 +38,7 @@
 } from '../core/inputSanitization';
 import { WeightUnit } from '../core/models';
 import { readBlobAsArrayBuffer } from '../utils/es2018Shims';
+import { enforceCanvasDimensions, releaseCanvas } from './webImageOptimizer';
 
 export type PedigreeScanStatus =
   | 'detected'
@@ -145,16 +146,26 @@
     const objectUrl = URL.createObjectURL(blob);
     const img = new Image();
     img.decoding = 'async';
+    const releaseImageObjectUrl = () => {
+      img.onload = null;
+      img.onerror = null;
+      try {
+        img.src = '';
+      } catch {
+        // Ignore readonly src teardown
+      }
+      URL.revokeObjectURL(objectUrl);
+    };
     img.onload = () => {
       resolve({
         source: img,
         width: img.naturalWidth || img.width || 1,
         height: img.naturalHeight || img.height || 1,
-        cleanup: () => URL.revokeObjectURL(objectUrl),
+        cleanup: releaseImageObjectUrl,
       });
     };
     img.onerror = () => {
-      URL.revokeObjectURL(objectUrl);
+      releaseImageObjectUrl();
       reject(new Error('Could not decode pedigree scan image in this browser.'));
     };
     img.src = objectUrl;
@@ -169,14 +180,19 @@
 ): HTMLCanvasElement {
   const longest = Math.max(srcWidth, srcHeight, 1);
   const scale = longest > maxDimensionPx ? maxDimensionPx / longest : 1;
-  const targetWidth = Math.max(1, Math.round(srcWidth * scale));
-  const targetHeight = Math.max(1, Math.round(srcHeight * scale));
+  const safeDims = enforceCanvasDimensions(
+    Math.max(1, Math.round(srcWidth * scale)),
+    Math.max(1, Math.round(srcHeight * scale))
+  );
+  const targetWidth = safeDims.width;
+  const targetHeight = safeDims.height;
 
   const canvas = document.createElement('canvas');
   canvas.width = targetWidth;
   canvas.height = targetHeight;
   const ctx = canvas.getContext('2d');
   if (!ctx) {
+    releaseCanvas(canvas);
     throw new Error('2D Canvas context is unavailable for pedigree OCR.');
   }
 
@@ -471,11 +487,8 @@
       offlineReason,
     };
   } finally {
-    if (canvas) {
-      canvas.width = 0;
-      canvas.height = 0;
-      canvas = null;
-    }
+    releaseCanvas(canvas);
+    canvas = null;
     decoded.cleanup();
   }
 }
```

### `src/storage/photoHydration.ts` (`+37` / `-2`, source: `part-15.md`)

```diff
--- working/src/storage/photoHydration.ts
+++ import/src/storage/photoHydration.ts
@@ -120,11 +120,29 @@
   };
 }
 
+export const DEFAULT_PHOTO_HYDRATION_BATCH_SIZE = 12;
+export const CONSTRAINED_PHOTO_HYDRATION_BATCH_SIZE = 4;
+
+/**
+ * Safely revokes a `blob:` object URL when it is no longer needed. Ignores `data:`/`https:` strings.
+ */
+export function revokeBlobUrlIfNeeded(url: string | null | undefined): void {
+  if (!url || !url.startsWith('blob:')) return;
+  if (typeof URL !== 'undefined' && typeof URL.revokeObjectURL === 'function') {
+    try {
+      URL.revokeObjectURL(url);
+    } catch {
+      // Ignore already-revoked or invalid object URL errors
+    }
+  }
+}
+
 export async function hydrateSnapshotWithPhotoDataUrls(
   snapshot: BarnDatabaseSnapshot,
   fetchBatch: (photoIds: string[]) => Promise<Record<string, string>>,
   filterSpecies?: string,
-  cache?: BoundedPhotoDataCache
+  cache?: BoundedPhotoDataCache,
+  options?: { batchSize?: number; isConstrained?: boolean }
 ): Promise<BarnDatabaseSnapshot> {
   const photos = snapshot.animalPhotos ?? [];
   if (photos.length === 0) return snapshot;
@@ -158,7 +176,24 @@
     return snapshot;
   }
 
-  const fetched = missingIds.length > 0 ? await fetchBatch(missingIds) : {};
+  const defaultBatch = options?.isConstrained
+    ? CONSTRAINED_PHOTO_HYDRATION_BATCH_SIZE
+    : DEFAULT_PHOTO_HYDRATION_BATCH_SIZE;
+  const batchSize = Math.max(1, Math.floor(options?.batchSize ?? defaultBatch));
+
+  // Fetch sequentially in bounded chunks to avoid concurrent full-res bitmap/buffer spikes
+  const fetched: Record<string, string> = {};
+  for (let i = 0; i < missingIds.length; i += batchSize) {
+    const chunk = missingIds.slice(i, i + batchSize);
+    const chunkResult = await fetchBatch(chunk);
+    for (const id of chunk) {
+      const val = chunkResult[id];
+      if (val) {
+        fetched[id] = val;
+      }
+    }
+  }
+
   const nextPhotos: AnimalPhoto[] = photos.map((p) => {
     if (p.dataUrl) return p;
     const resolved = fetched[p.id] || cachedById.get(p.id);
```

### `src/storage/pwaUpdateManager.ts` (`+10` / `-6`, source: `part-15.md`)

```diff
--- working/src/storage/pwaUpdateManager.ts
+++ import/src/storage/pwaUpdateManager.ts
@@ -26,6 +26,7 @@
   getEffectiveOnlineStatus,
   recordServerDateHeaderSkew,
 } from './storageProtection';
+import { getSafeLocalStorage } from './storageProbes';
 
 export type PwaUpdatePolicy = 'auto' | 'notify' | 'pinned';
 
@@ -54,8 +55,9 @@
 
 function readPersistedUpdatePolicy(): PwaUpdatePolicy {
   try {
-    if (typeof localStorage === 'undefined') return 'auto';
-    const raw = localStorage.getItem(PWA_UPDATE_POLICY_KEY);
+    const ls = getSafeLocalStorage();
+    if (!ls) return 'auto';
+    const raw = ls.getItem(PWA_UPDATE_POLICY_KEY);
     if (raw === 'auto' || raw === 'notify' || raw === 'pinned') {
       return raw;
     }
@@ -109,8 +111,9 @@
 
 export function setPwaUpdatePolicy(policy: PwaUpdatePolicy): void {
   try {
-    if (typeof localStorage !== 'undefined') {
-      localStorage.setItem(PWA_UPDATE_POLICY_KEY, policy);
+    const ls = getSafeLocalStorage();
+    if (ls) {
+      ls.setItem(PWA_UPDATE_POLICY_KEY, policy);
     }
   } catch {
     // Ignore storage restriction
@@ -145,8 +148,9 @@
     teardownLifecycleListeners = null;
   }
   try {
-    if (typeof localStorage !== 'undefined') {
-      localStorage.removeItem(PWA_UPDATE_POLICY_KEY);
+    const ls = getSafeLocalStorage();
+    if (ls) {
+      ls.removeItem(PWA_UPDATE_POLICY_KEY);
     }
   } catch {
     // Ignore
```

### `src/storage/storageAdapter.ts` (`+27` / `-0`, source: `part-15.md`)

```diff
--- working/src/storage/storageAdapter.ts
+++ import/src/storage/storageAdapter.ts
@@ -13,18 +13,22 @@
 import {
   Animal,
   AnimalPhoto,
+  AnimalReservation,
   BarnDatabaseSnapshot,
   BarnSettings,
   BarnTask,
   BreedingRecord,
   CageLocation,
   CareLog,
+  ClientContact,
   FeedAllocation,
   FeedBatch,
   LedgerEntry,
   ProcessingLog,
   ShowEvent,
   SpeciesProfile,
+  WaitlistEntry,
+  WoolHarvest,
   YouthProjectBook,
 } from '../core/models';
 import type { WipedStorageRecoveryContext } from './opfsStorage';
@@ -46,6 +50,9 @@
 export interface StorageAdapter {
   /** Human-readable description of the active local storage engine (e.g., `"SQLite WASM + IndexedDB"`). */
   readonly engineName: string;
+
+  /** Returns true when IndexedDB is blocked (e.g. Lockdown/Private mode) and storage is session-ephemeral. */
+  isEphemeralMode?(): boolean;
 
   /** Initializes tables and seeds starter multi-species sample data on first launch if empty. */
   initialize(options?: SnapshotLoadOptions): Promise<BarnDatabaseSnapshot>;
@@ -132,6 +139,26 @@
   saveYouthProjectBooksBatch(projects: YouthProjectBook[]): Promise<void>;
   deleteYouthProjectBook(id: string): Promise<void>;
 
+  /** Upserts or deletes ClientContact CRM records (single or batch). */
+  saveClientContact(client: ClientContact): Promise<void>;
+  saveClientContactsBatch(clients: ClientContact[]): Promise<void>;
+  deleteClientContact(id: string): Promise<void>;
+
+  /** Upserts or deletes buyer WaitlistEntry records (single or batch). */
+  saveWaitlistEntry(entry: WaitlistEntry): Promise<void>;
+  saveWaitlistEntriesBatch(entries: WaitlistEntry[]): Promise<void>;
+  deleteWaitlistEntry(id: string): Promise<void>;
+
+  /** Upserts or deletes AnimalReservation records (single or batch). */
+  saveAnimalReservation(reservation: AnimalReservation): Promise<void>;
+  saveAnimalReservationsBatch(reservations: AnimalReservation[]): Promise<void>;
+  deleteAnimalReservation(id: string): Promise<void>;
+
+  /** Upserts or deletes WoolHarvest fiber & IAGARB records (single or batch). */
+  saveWoolHarvest(harvest: WoolHarvest): Promise<void>;
+  saveWoolHarvestsBatch(harvests: WoolHarvest[]): Promise<void>;
+  deleteWoolHarvest(id: string): Promise<void>;
+
   /** Exports the raw unencrypted `.sqlite` binary database file (when running SQLite engine). */
   exportRawSqliteBytes(): Promise<Uint8Array | null>;
 
```

### `src/storage/storageProtection.ts` (`+107` / `-40`, source: `part-15.md`)

```diff
--- working/src/storage/storageProtection.ts
+++ import/src/storage/storageProtection.ts
@@ -24,6 +24,13 @@
 import { NativeContainerInfo, pedigreeBridge } from '../native/pedigreeBridge';
 import { isOpfsSupported } from './opfsTempStream';
 import { stripPhotoDataUrlsFromSnapshot } from './photoHydration';
+import {
+  getSafeIndexedDb,
+  getSafeLocalStorage,
+  getSafeStorageManager,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+} from './storageProbes';
 
 const ROLLING_IDB_NAME = 'community_pedigree_rolling_backups';
 const ROLLING_STORE_NAME = 'snapshots';
@@ -53,6 +60,10 @@
   for (const yp of snapshot.youthProjectBooks ?? []) {
     bytes += 540 + (yp.feedLogs?.length || 0) * 140;
   }
+  bytes += (snapshot.clientContacts?.length || 0) * 320;
+  bytes += (snapshot.waitlistEntries?.length || 0) * 320;
+  bytes += (snapshot.animalReservations?.length || 0) * 440;
+  bytes += (snapshot.woolHarvests?.length || 0) * 420;
   for (const photo of snapshot.animalPhotos ?? []) {
     const estimatedDataUrlBytes =
       photo.dataUrl?.length || (photo.storedBytes ? Math.ceil(photo.storedBytes * 1.37) : 0);
@@ -103,7 +114,8 @@
     ? pedigreeBridge.getNativeContainerInfo(400)
     : Promise.resolve(null);
 
-  if (typeof navigator === 'undefined' || !navigator.storage) {
+  const storage = getSafeStorageManager();
+  if (!storage) {
     const nativeContainerInfo = await nativeInfoPromise;
     return {
       supported: false,
@@ -120,11 +132,11 @@
   // Never spoof navigator.storage.persisted() — Android WebView returns false honestly.
   let persisted = false;
   try {
-    if (navigator.storage.persisted) {
-      persisted = await navigator.storage.persisted();
-    }
-    if (!persisted && navigator.storage.persist) {
-      persisted = await navigator.storage.persist();
+    if (typeof storage.persisted === 'function') {
+      persisted = await storage.persisted();
+    }
+    if (!persisted && typeof storage.persist === 'function') {
+      persisted = await storage.persist();
     }
   } catch {
     persisted = false;
@@ -133,8 +145,8 @@
   let usageBytes = 0;
   let quotaBytes = 0;
   try {
-    if (navigator.storage.estimate) {
-      const est = await navigator.storage.estimate();
+    if (typeof storage.estimate === 'function') {
+      const est = await storage.estimate();
       usageBytes = Number(est.usage) || 0;
       quotaBytes = Number(est.quota) || 0;
     }
@@ -165,7 +177,8 @@
     ? pedigreeBridge.getNativeContainerInfo(400)
     : Promise.resolve(null);
 
-  if (typeof navigator === 'undefined' || !navigator.storage) {
+  const storage = getSafeStorageManager();
+  if (!storage) {
     const nativeContainerInfo = await nativeInfoPromise;
     return {
       supported: false,
@@ -182,11 +195,11 @@
   let usageBytes = 0;
   let quotaBytes = 0;
   try {
-    if (navigator.storage.persisted) {
-      persisted = await navigator.storage.persisted();
-    }
-    if (navigator.storage.estimate) {
-      const est = await navigator.storage.estimate();
+    if (typeof storage.persisted === 'function') {
+      persisted = await storage.persisted();
+    }
+    if (typeof storage.estimate === 'function') {
+      const est = await storage.estimate();
       usageBytes = Number(est.usage) || 0;
       quotaBytes = Number(est.quota) || 0;
     }
@@ -210,6 +223,11 @@
 
 function openRollingIdb(): Promise<IDBDatabase> {
   return new Promise((resolve, reject) => {
+    const idb = getSafeIndexedDb();
+    if (!idb) {
+      reject(new Error('Rolling backup IndexedDB is unavailable in this browser context.'));
+      return;
+    }
     let settled = false;
     const timer = setTimeout(() => {
       if (settled) return;
@@ -230,7 +248,7 @@
     };
 
     try {
-      const req = indexedDB.open(ROLLING_IDB_NAME, 1);
+      const req = idb.open(ROLLING_IDB_NAME, 1);
       req.onupgradeneeded = () => {
         try {
           const db = req.result;
@@ -296,7 +314,7 @@
     dehydratePhotos?: boolean;
   }
 ): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   try {
     const policy = getTierStoragePolicy(detectCurrentDeviceCapability().tier);
     const maxRollingCap = Math.max(
@@ -318,7 +336,9 @@
       snapshot: targetSnapshot,
     };
     const db = await openRollingIdb();
+    const untrackDb = trackActiveIdbConnection(db);
     const closeDb = () => {
+      untrackDb();
       try {
         db.close();
       } catch {
@@ -328,6 +348,7 @@
     try {
       await new Promise<void>((resolve, reject) => {
         const tx = db.transaction(ROLLING_STORE_NAME, 'readwrite');
+        const untrackTx = trackActiveIdbTransaction(tx);
         const store = tx.objectStore(ROLLING_STORE_NAME);
         store.put(entry);
 
@@ -352,9 +373,18 @@
           }
         };
 
-        tx.oncomplete = () => resolve();
-        tx.onerror = () => reject(tx.error);
-        tx.onabort = () => reject(tx.error || new Error('Rolling backup write aborted'));
+        tx.oncomplete = () => {
+          untrackTx();
+          resolve();
+        };
+        tx.onerror = () => {
+          untrackTx();
+          reject(tx.error);
+        };
+        tx.onabort = () => {
+          untrackTx();
+          reject(tx.error || new Error('Rolling backup write aborted'));
+        };
       });
     } finally {
       closeDb();
@@ -370,12 +400,14 @@
 }
 
 export async function listRollingSnapshotBackups(): Promise<RollingBackupMeta[]> {
-  if (typeof indexedDB === 'undefined') return [];
+  if (!getSafeIndexedDb()) return [];
   try {
     const db = await openRollingIdb();
+    const untrackDb = trackActiveIdbConnection(db);
     try {
       return await new Promise<RollingBackupMeta[]>((resolve, reject) => {
         const tx = db.transaction(ROLLING_STORE_NAME, 'readonly');
+        const untrackTx = trackActiveIdbTransaction(tx);
         const store = tx.objectStore(ROLLING_STORE_NAME);
         const items: RollingBackupMeta[] = [];
         const req = store.openCursor();
@@ -401,13 +433,21 @@
             cursor.continue();
           } else {
             items.sort((a, b) => b.savedAtIso.localeCompare(a.savedAtIso));
+            untrackTx();
             resolve(items);
           }
         };
-        req.onerror = () => reject(req.error);
-        tx.onabort = () => reject(tx.error || new Error('Rolling backup list aborted'));
+        req.onerror = () => {
+          untrackTx();
+          reject(req.error);
+        };
+        tx.onabort = () => {
+          untrackTx();
+          reject(tx.error || new Error('Rolling backup list aborted'));
+        };
       });
     } finally {
+      untrackDb();
       try {
         db.close();
       } catch {
@@ -422,16 +462,19 @@
 export async function loadRollingSnapshotBackup(
   key: string
 ): Promise<BarnDatabaseSnapshot | null> {
-  if (typeof indexedDB === 'undefined') return null;
+  if (!getSafeIndexedDb()) return null;
   try {
     const db = await openRollingIdb();
+    const untrackDb = trackActiveIdbConnection(db);
     try {
       return await new Promise<BarnDatabaseSnapshot | null>((resolve, reject) => {
         const tx = db.transaction(ROLLING_STORE_NAME, 'readonly');
+        const untrackTx = trackActiveIdbTransaction(tx);
         const req = tx.objectStore(ROLLING_STORE_NAME).get(key);
         req.onsuccess = () => {
           const rec = req.result as StoredRollingBackup | undefined;
           const snap = rec?.snapshot;
+          untrackTx();
           if (
             !snap ||
             typeof snap !== 'object' ||
@@ -444,10 +487,17 @@
           }
           resolve(snap);
         };
-        req.onerror = () => reject(req.error);
-        tx.onabort = () => reject(tx.error || new Error('Rolling backup load aborted'));
+        req.onerror = () => {
+          untrackTx();
+          reject(req.error);
+        };
+        tx.onabort = () => {
+          untrackTx();
+          reject(tx.error || new Error('Rolling backup load aborted'));
+        };
       });
     } finally {
+      untrackDb();
       try {
         db.close();
       } catch {
@@ -460,18 +510,30 @@
 }
 
 export async function deleteRollingSnapshotBackup(key: string): Promise<boolean> {
-  if (typeof indexedDB === 'undefined') return false;
+  if (!getSafeIndexedDb()) return false;
   try {
     const db = await openRollingIdb();
+    const untrackDb = trackActiveIdbConnection(db);
     try {
       return await new Promise<boolean>((resolve, reject) => {
         const tx = db.transaction(ROLLING_STORE_NAME, 'readwrite');
+        const untrackTx = trackActiveIdbTransaction(tx);
         tx.objectStore(ROLLING_STORE_NAME).delete(key);
-        tx.oncomplete = () => resolve(true);
-        tx.onerror = () => reject(tx.error);
-        tx.onabort = () => reject(tx.error || new Error('Rolling backup delete aborted'));
+        tx.oncomplete = () => {
+          untrackTx();
+          resolve(true);
+        };
+        tx.onerror = () => {
+          untrackTx();
+          reject(tx.error);
+        };
+        tx.onabort = () => {
+          untrackTx();
+          reject(tx.error || new Error('Rolling backup delete aborted'));
+        };
       });
     } finally {
+      untrackDb();
       try {
         db.close();
       } catch {
@@ -508,8 +570,9 @@
 
 function readPersistedManualOffline(): boolean {
   try {
-    if (typeof localStorage === 'undefined') return false;
-    return localStorage.getItem(MANUAL_OFFLINE_STORAGE_KEY) === 'true';
+    const ls = getSafeLocalStorage();
+    if (!ls) return false;
+    return ls.getItem(MANUAL_OFFLINE_STORAGE_KEY) === 'true';
   } catch {
     return false;
   }
@@ -517,8 +580,9 @@
 
 function readPersistedClockSkewMs(): number | null {
   try {
-    if (typeof localStorage === 'undefined') return null;
-    const raw = localStorage.getItem(CLOCK_SKEW_STORAGE_KEY);
+    const ls = getSafeLocalStorage();
+    if (!ls) return null;
+    const raw = ls.getItem(CLOCK_SKEW_STORAGE_KEY);
     if (!raw) return null;
     const parsed = Number(raw);
     return Number.isFinite(parsed) ? parsed : null;
@@ -588,8 +652,9 @@
   clockSkewMsState = skewMs;
   setCoreClockSkewMs(skewMs);
   try {
-    if (typeof localStorage !== 'undefined') {
-      localStorage.setItem(CLOCK_SKEW_STORAGE_KEY, String(Math.round(skewMs)));
+    const ls = getSafeLocalStorage();
+    if (ls) {
+      ls.setItem(CLOCK_SKEW_STORAGE_KEY, String(Math.round(skewMs)));
     }
   } catch {
     // Non-fatal in private browsing
@@ -635,8 +700,9 @@
 export function setManualOfflineMode(enabled: boolean): void {
   manualOfflineState = Boolean(enabled);
   try {
-    if (typeof localStorage !== 'undefined') {
-      localStorage.setItem(MANUAL_OFFLINE_STORAGE_KEY, manualOfflineState ? 'true' : 'false');
+    const ls = getSafeLocalStorage();
+    if (ls) {
+      ls.setItem(MANUAL_OFFLINE_STORAGE_KEY, manualOfflineState ? 'true' : 'false');
     }
   } catch {
     // Non-fatal in private browsing
@@ -659,9 +725,10 @@
   setCoreClockSkewMs(0);
   connectivityListeners.clear();
   try {
-    if (typeof localStorage !== 'undefined') {
-      localStorage.removeItem(MANUAL_OFFLINE_STORAGE_KEY);
-      localStorage.removeItem(CLOCK_SKEW_STORAGE_KEY);
+    const ls = getSafeLocalStorage();
+    if (ls) {
+      ls.removeItem(MANUAL_OFFLINE_STORAGE_KEY);
+      ls.removeItem(CLOCK_SKEW_STORAGE_KEY);
     }
   } catch {
     // Ignore
```

### `src/storage/webImageOptimizer.ts` (`+229` / `-38`, source: `part-15.md`)

```diff
--- working/src/storage/webImageOptimizer.ts
+++ import/src/storage/webImageOptimizer.ts
@@ -21,14 +21,17 @@
 import { dataUrlToBinary } from '../core/backupArchive';
 import {
   calculateSavingsPercent,
+  capCanvasDevicePixelRatio,
+  clampCanvasDimensionsToAreaCeiling,
   computeScaledDimensions,
   estimateDataUrlByteLength,
+  getCanvasAreaCeiling,
   ImageOptimizationPresetId,
   OptimizedImagePayload,
   resolveImageOptimizationPreset,
 } from '../core/imageOptimizationSpec';
 import { StagedImportedPhoto } from '../core/importers/importerTypes';
-import { readBlobAsArrayBuffer } from '../utils/es2018Shims';
+import { isFileReaderSupported, readBlobAsArrayBuffer } from '../utils/es2018Shims';
 import {
   isSvgImageInput,
   MAX_IMAGE_PIXEL_DIMENSION,
@@ -42,6 +45,80 @@
   detectCurrentDeviceCapability,
   probeWebpEncodeSupport,
 } from './deviceCapabilityDetector';
+
+export type ReleasableCanvas = HTMLCanvasElement | OffscreenCanvas;
+
+/**
+ * Releases canvas GPU/RAM backing memory promptly in `finally` blocks across Safari/WebKit/Chromium.
+ */
+export function releaseCanvas(canvas: ReleasableCanvas | null | undefined): void {
+  if (!canvas) return;
+  try {
+    canvas.width = 1;
+    canvas.height = 1;
+    const ctx = canvas.getContext('2d') as
+      | CanvasRenderingContext2D
+      | OffscreenCanvasRenderingContext2D
+      | null;
+    if (ctx && typeof ctx.clearRect === 'function') {
+      ctx.clearRect(0, 0, 1, 1);
+    }
+  } catch {
+    // Ignore context/clear errors during teardown
+  } finally {
+    try {
+      canvas.width = 0;
+      canvas.height = 0;
+    } catch {
+      // Ignore detached/readonly canvas teardown errors
+    }
+  }
+}
+
+/**
+ * Verifies both `OffscreenCanvas` global presence and a live 2D context before worker canvas usage.
+ */
+export function probeOffscreenCanvas2dSupport(): boolean {
+  if (typeof OffscreenCanvas === 'undefined') {
+    return false;
+  }
+  let probe: OffscreenCanvas | null = null;
+  try {
+    probe = new OffscreenCanvas(1, 1);
+    const ctx = probe.getContext('2d');
+    return ctx !== null;
+  } catch {
+    return false;
+  } finally {
+    releaseCanvas(probe);
+  }
+}
+
+export function isConstrainedCanvasTier(): boolean {
+  return detectCurrentDeviceCapability().shouldApplyLowMemoryHandling;
+}
+
+export function getEffectiveCanvasDevicePixelRatio(
+  isConstrained: boolean = isConstrainedCanvasTier()
+): number {
+  const rawDpr =
+    typeof window !== 'undefined' && typeof window.devicePixelRatio === 'number'
+      ? window.devicePixelRatio || 1
+      : 1;
+  return capCanvasDevicePixelRatio(rawDpr, isConstrained);
+}
+
+export function enforceCanvasDimensions(
+  width: number,
+  height: number,
+  isConstrained: boolean = isConstrainedCanvasTier()
+): { width: number; height: number; wasClamped: boolean } {
+  return clampCanvasDimensionsToAreaCeiling(
+    width,
+    height,
+    getCanvasAreaCeiling(isConstrained)
+  );
+}
 
 interface DecodedCanvasSource {
   source: CanvasImageSource;
@@ -74,16 +151,26 @@
     const objectUrl = URL.createObjectURL(blob);
     const img = new Image();
     img.decoding = 'async';
+    const releaseImageObjectUrl = () => {
+      img.onload = null;
+      img.onerror = null;
+      try {
+        img.src = '';
+      } catch {
+        // Ignore readonly src teardown
+      }
+      URL.revokeObjectURL(objectUrl);
+    };
     img.onload = () => {
       resolve({
         source: img,
         width: img.naturalWidth || img.width || 1,
         height: img.naturalHeight || img.height || 1,
-        cleanup: () => URL.revokeObjectURL(objectUrl),
+        cleanup: releaseImageObjectUrl,
       });
     };
     img.onerror = () => {
-      URL.revokeObjectURL(objectUrl);
+      releaseImageObjectUrl();
       const isHeic =
         /heic|heif/i.test(blob.type || '') || /\.(heic|heif)$/i.test(originalFileName);
       reject(
@@ -98,17 +185,19 @@
   });
 }
 
-function renderToDataUrl(
+function renderToMainThreadCanvasDataUrl(
   source: CanvasImageSource,
   targetWidth: number,
   targetHeight: number,
-  quality: number
+  quality: number,
+  isConstrained: boolean
 ): { dataUrl: string; mimeType: string } {
+  const safeDims = enforceCanvasDimensions(targetWidth, targetHeight, isConstrained);
   const canvas = document.createElement('canvas');
   let jpegCanvas: HTMLCanvasElement | null = null;
   try {
-    canvas.width = targetWidth;
-    canvas.height = targetHeight;
+    canvas.width = safeDims.width;
+    canvas.height = safeDims.height;
     const ctx = canvas.getContext('2d');
     if (!ctx) {
       throw new Error('2D Canvas context unavailable for image optimization.');
@@ -116,7 +205,7 @@
 
     ctx.imageSmoothingEnabled = true;
     ctx.imageSmoothingQuality = 'high';
-    ctx.drawImage(source, 0, 0, targetWidth, targetHeight);
+    ctx.drawImage(source, 0, 0, safeDims.width, safeDims.height);
 
     // Prefer modern WebP (supports alpha transparency + ~35% smaller than JPEG at equal visual clarity)
     if (probeWebpEncodeSupport()) {
@@ -128,34 +217,126 @@
 
     // Fallback to JPEG if browser lacks WebP canvas encoding: composite over warm neutral card fill first
     jpegCanvas = document.createElement('canvas');
-    jpegCanvas.width = targetWidth;
-    jpegCanvas.height = targetHeight;
+    jpegCanvas.width = safeDims.width;
+    jpegCanvas.height = safeDims.height;
     const jCtx = jpegCanvas.getContext('2d');
     if (!jCtx) {
       throw new Error('2D Canvas JPEG fallback context unavailable.');
     }
     jCtx.fillStyle = '#F7F2E7';
-    jCtx.fillRect(0, 0, targetWidth, targetHeight);
+    jCtx.fillRect(0, 0, safeDims.width, safeDims.height);
     jCtx.drawImage(canvas, 0, 0);
     const jpegUrl = jpegCanvas.toDataURL('image/jpeg', quality);
     return { dataUrl: jpegUrl, mimeType: 'image/jpeg' };
   } finally {
-    canvas.width = 0;
-    canvas.height = 0;
-    if (jpegCanvas) {
-      jpegCanvas.width = 0;
-      jpegCanvas.height = 0;
-    }
-  }
-}
-
-function blobToDataUrl(blob: Blob): Promise<string> {
-  return new Promise((resolve, reject) => {
-    const reader = new FileReader();
-    reader.onload = () => resolve(String(reader.result || ''));
-    reader.onerror = () => reject(reader.error || new Error('Failed reading image blob.'));
-    reader.readAsDataURL(blob);
-  });
+    releaseCanvas(canvas);
+    releaseCanvas(jpegCanvas);
+  }
+}
+
+async function renderToOffscreenWorkerDataUrl(
+  source: CanvasImageSource,
+  targetWidth: number,
+  targetHeight: number,
+  quality: number,
+  isConstrained: boolean
+): Promise<{ dataUrl: string; mimeType: string }> {
+  const safeDims = enforceCanvasDimensions(targetWidth, targetHeight, isConstrained);
+  const canvas = new OffscreenCanvas(safeDims.width, safeDims.height);
+  let jpegCanvas: OffscreenCanvas | null = null;
+  try {
+    const ctx = canvas.getContext('2d');
+    if (!ctx) {
+      throw new Error('OffscreenCanvas 2D context unavailable for worker image optimization.');
+    }
+    ctx.imageSmoothingEnabled = true;
+    ctx.imageSmoothingQuality = 'high';
+    ctx.drawImage(source, 0, 0, safeDims.width, safeDims.height);
+
+    if (typeof canvas.convertToBlob === 'function') {
+      try {
+        const webpBlob = await canvas.convertToBlob({ type: 'image/webp', quality });
+        if (webpBlob.type === 'image/webp') {
+          return { dataUrl: await blobToDataUrl(webpBlob), mimeType: 'image/webp' };
+        }
+      } catch {
+        // Fall through to JPEG OffscreenCanvas encode
+      }
+
+      jpegCanvas = new OffscreenCanvas(safeDims.width, safeDims.height);
+      const jCtx = jpegCanvas.getContext('2d');
+      if (!jCtx) {
+        throw new Error('OffscreenCanvas 2D JPEG fallback context unavailable.');
+      }
+      jCtx.fillStyle = '#F7F2E7';
+      jCtx.fillRect(0, 0, safeDims.width, safeDims.height);
+      jCtx.drawImage(canvas, 0, 0);
+      const jpegBlob = await jpegCanvas.convertToBlob({ type: 'image/jpeg', quality });
+      return { dataUrl: await blobToDataUrl(jpegBlob), mimeType: 'image/jpeg' };
+    }
+
+    throw new Error('OffscreenCanvas.convertToBlob unavailable.');
+  } finally {
+    releaseCanvas(canvas);
+    releaseCanvas(jpegCanvas);
+  }
+}
+
+async function renderToDataUrl(
+  source: CanvasImageSource,
+  targetWidth: number,
+  targetHeight: number,
+  quality: number,
+  isConstrained: boolean
+): Promise<{ dataUrl: string; mimeType: string }> {
+  if (typeof document !== 'undefined') {
+    return renderToMainThreadCanvasDataUrl(
+      source,
+      targetWidth,
+      targetHeight,
+      quality,
+      isConstrained
+    );
+  }
+  if (probeOffscreenCanvas2dSupport()) {
+    return renderToOffscreenWorkerDataUrl(
+      source,
+      targetWidth,
+      targetHeight,
+      quality,
+      isConstrained
+    );
+  }
+  throw new Error(
+    'Neither document 2D canvas nor OffscreenCanvas 2D context is available for image optimization.'
+  );
+}
+
+async function blobToDataUrl(blob: Blob): Promise<string> {
+  if (isFileReaderSupported()) {
+    try {
+      return await new Promise<string>((resolve, reject) => {
+        const reader = new FileReader();
+        reader.onload = () => resolve(String(reader.result || ''));
+        reader.onerror = () => reject(reader.error || new Error('Failed reading image blob.'));
+        reader.onabort = () => reject(new Error('Image blob read aborted.'));
+        reader.readAsDataURL(blob);
+      });
+    } catch {
+      // Fall through to ArrayBuffer + base64 conversion when FileReader is blocked (e.g. Lockdown Mode)
+    }
+  }
+
+  const buffer = await readBlobAsArrayBuffer(blob);
+  const bytes = new Uint8Array(buffer);
+  let binary = '';
+  const CHUNK = 0x8000;
+  for (let i = 0; i < bytes.length; i += CHUNK) {
+    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
+  }
+  const base64 = typeof btoa === 'function' ? btoa(binary) : '';
+  const mime = blob.type || 'application/octet-stream';
+  return `data:${mime};base64,${base64}`;
 }
 
 /**
@@ -200,19 +381,23 @@
         `Image "${originalFileName || 'photo'}" (${decoded.width}x${decoded.height} px) exceeds the safe pixel resolution limit (${MAX_IMAGE_PIXEL_DIMENSION.toLocaleString()}px / 100 MP).`
       );
     }
+    const isConstrained = isConstrainedCanvasTier();
+    const maxCanvasAreaPx = getCanvasAreaCeiling(isConstrained);
     let activePreset = preset;
     let mainDims = computeScaledDimensions(
       decoded.width,
       decoded.height,
-      activePreset.maxDimension
+      activePreset.maxDimension,
+      maxCanvasAreaPx
     );
     let mainEncoded: { dataUrl: string; mimeType: string };
     try {
-      mainEncoded = renderToDataUrl(
+      mainEncoded = await renderToDataUrl(
         decoded.source,
         mainDims.width,
         mainDims.height,
-        activePreset.quality
+        activePreset.quality,
+        isConstrained
       );
     } catch (renderErr) {
       // Automatic low-memory self-recovery: step down to Compact (960px) before failing
@@ -227,13 +412,15 @@
         mainDims = computeScaledDimensions(
           decoded.width,
           decoded.height,
-          activePreset.maxDimension
+          activePreset.maxDimension,
+          maxCanvasAreaPx
         );
-        mainEncoded = renderToDataUrl(
+        mainEncoded = await renderToDataUrl(
           decoded.source,
           mainDims.width,
           mainDims.height,
-          activePreset.quality
+          activePreset.quality,
+          isConstrained
         );
       } else {
         throw renderErr;
@@ -259,13 +446,15 @@
     const thumbDims = computeScaledDimensions(
       decoded.width,
       decoded.height,
-      activePreset.thumbnailDimension
+      activePreset.thumbnailDimension,
+      maxCanvasAreaPx
     );
-    const thumbEncoded = renderToDataUrl(
+    const thumbEncoded = await renderToDataUrl(
       decoded.source,
       thumbDims.width,
       thumbDims.height,
-      activePreset.thumbnailQuality
+      activePreset.thumbnailQuality,
+      isConstrained
     );
 
     return {
@@ -344,8 +533,10 @@
   let totalStoredBytes = 0;
 
   const detectedTier = detectCurrentDeviceCapability().tier;
-  const defaultChunkSize = detectedTier <= 2 ? 1 : detectedTier === 3 ? 2 : 4;
-  const CHUNK_SIZE = Math.max(1, Math.min(8, Math.round(options?.concurrency ?? defaultChunkSize)));
+  // Default sequential (1) to avoid concurrent decoded-bitmap memory spikes across devices
+  const requestedConcurrency = options?.concurrency ?? 1;
+  const CHUNK_SIZE =
+    detectedTier <= 2 ? 1 : Math.max(1, Math.min(4, Math.round(requestedConcurrency)));
   for (let i = 0; i < staged.length; i += CHUNK_SIZE) {
     const slice = staged.slice(i, i + CHUNK_SIZE);
     const chunkResults = await Promise.all(
```

### `src/storage/webSqliteAdapter.ts` (`+802` / `-92`, source: `part-15.md`)

```diff
--- working/src/storage/webSqliteAdapter.ts
+++ import/src/storage/webSqliteAdapter.ts
@@ -19,14 +19,14 @@
 import {
   Animal,
   AnimalPhoto,
+  AnimalReservation,
   BarnDatabaseSnapshot,
   BarnSettings,
   BarnTask,
   BreedingRecord,
-  BreedingStatus,
   CageLocation,
   CareLog,
-  CareLogType,
+  ClientContact,
   DEFAULT_CALENDAR_SYNC_SETTINGS,
   FeedAllocation,
   FeedAllocationTargetType,
@@ -35,6 +35,7 @@
   normalizeAnimalStatus,
   normalizeBreedScheduleOverrides,
   normalizeCalendarSyncSettings,
+  normalizeClientKind,
   normalizeCurrencyCode,
   normalizeFeedPurgeWindowDays,
   normalizeHousingUnitType,
@@ -44,22 +45,28 @@
   normalizeLitterWeightMilestones,
   normalizeOwnershipType,
   normalizePeltGrade,
+  normalizePreferredContactMethod,
   normalizeProcessingStatus,
+  normalizeReservationStatus,
   normalizeRufusLevel,
   normalizeServiceFeeDirection,
   normalizeTargetWeightCurve,
   normalizeUltrasoundResult,
+  normalizeWaitlistIntent,
+  normalizeWaitlistStatus,
   normalizeWeightUnit,
+  normalizeWoolHarvestMethod,
   normalizeYouthOrgType,
   normalizeYouthProjectFeedLogs,
   nowIsoUtc,
   ProcessingLog,
   ShowEvent,
   SpeciesProfile,
-  TaskCategory,
-  TaskPriority,
+  WaitlistEntry,
+  WoolHarvest,
   YouthProjectBook,
 } from '../core/models';
+import { normalizeIagarbScorecard } from '../core/woolFiber';
 import { buildFullPredefinedSampleSnapshot } from '../core/sampleData';
 import { reconcileCarrierTraitLists } from '../core/carrierGenetics';
 import { getTierStoragePolicy } from '../core/deviceCapability';
@@ -94,6 +101,12 @@
   loadRollingSnapshotBackup,
   saveRollingSnapshotBackup,
 } from './storageProtection';
+import {
+  getSafeIndexedDb,
+  isIndexedDbBlockedError,
+  trackActiveIdbConnection,
+  trackActiveIdbTransaction,
+} from './storageProbes';
 
 const IDB_DB_NAME = 'community_pedigree_local_db';
 const IDB_STORE_NAME = 'sqlite_files';
@@ -101,7 +114,7 @@
 const IDB_FALLBACK_SNAPSHOT_KEY = 'pedigree_fallback_json';
 export const IDB_WRITE_EPOCH_KEY = 'pedigree_write_epoch';
 export const DB_WRITE_LOCK_NAME = 'community_pedigree_db_write_v1';
-const SQLITE_SCHEMA_VERSION = 4;
+const SQLITE_SCHEMA_VERSION = 6;
 
 type SqlJsInitConfig = NonNullable<Parameters<typeof initSqlJs>[0]> & {
   useOldExtensionFunctions: boolean;
@@ -112,64 +125,6 @@
     locateFile: () => sqlWasmUrl,
     useOldExtensionFunctions: false,
   };
-}
-
-const VALID_BREEDING_STATUSES: ReadonlySet<BreedingStatus> = new Set([
-  'Planned',
-  'Bred',
-  'Palpated Positive',
-  'Born',
-  'Weaned',
-  'Missed',
-]);
-
-function normalizeSqliteBreedingStatus(raw: unknown): BreedingStatus {
-  const s = typeof raw === 'string' ? raw : String(raw ?? '');
-  return VALID_BREEDING_STATUSES.has(s as BreedingStatus)
-    ? (s as BreedingStatus)
-    : 'Planned';
-}
-
-const VALID_TASK_CATEGORIES: ReadonlySet<TaskCategory> = new Set([
-  'Care',
-  'Palpation',
-  'Nestbox',
-  'Birth Check',
-  'Weaning',
-  'Rebreed',
-  'Health',
-  'Show Prep',
-  'Other',
-]);
-
-function normalizeSqliteTaskCategory(raw: unknown): TaskCategory {
-  const s = typeof raw === 'string' ? raw : String(raw ?? '');
-  return VALID_TASK_CATEGORIES.has(s as TaskCategory) ? (s as TaskCategory) : 'Other';
-}
-
-function normalizeSqliteTaskPriority(raw: unknown): TaskPriority {
-  if (raw === 'High' || raw === 'Normal' || raw === 'Low') {
-    return raw;
-  }
-  return 'Normal';
-}
-
-const VALID_CARE_LOG_TYPES: ReadonlySet<CareLogType> = new Set([
-  'Weight Check',
-  'Show / Leg',
-  'Palpation',
-  'Ultrasound',
-  'Health / Vet',
-  'Health Score / BCS',
-  'Grooming & Hoof',
-  'Journal Note',
-]);
-
-function normalizeSqliteCareLogType(raw: unknown): CareLogType {
-  const s = typeof raw === 'string' ? raw : String(raw ?? '');
-  return VALID_CARE_LOG_TYPES.has(s as CareLogType)
-    ? (s as CareLogType)
-    : 'Journal Note';
 }
 
 export interface PersistedWriteEpochMeta {
@@ -522,13 +477,110 @@
   );
 
   CREATE INDEX IF NOT EXISTS idx_youth_project_books_species ON youth_project_books(species);
+
+  CREATE TABLE IF NOT EXISTS client_contacts (
+    id TEXT PRIMARY KEY NOT NULL,
+    species TEXT NOT NULL,
+    full_name TEXT NOT NULL,
+    ranch_or_herd_name TEXT NOT NULL DEFAULT '',
+    email TEXT NOT NULL DEFAULT '',
+    phone TEXT NOT NULL DEFAULT '',
+    preferred_contact TEXT NOT NULL DEFAULT 'sms',
+    client_kind TEXT NOT NULL DEFAULT 'pet_buyer',
+    city_state TEXT NOT NULL DEFAULT '',
+    shipping_address TEXT NOT NULL DEFAULT '',
+    tags_json TEXT NOT NULL DEFAULT '[]',
+    notes TEXT NOT NULL DEFAULT '',
+    created_at TEXT NOT NULL,
+    updated_at TEXT NOT NULL
+  );
+
+  CREATE INDEX IF NOT EXISTS idx_client_contacts_species ON client_contacts(species);
+
+  CREATE TABLE IF NOT EXISTS waitlist_entries (
+    id TEXT PRIMARY KEY NOT NULL,
+    species TEXT NOT NULL,
+    client_id TEXT NOT NULL,
+    client_name TEXT NOT NULL DEFAULT '',
+    priority_rank INTEGER NOT NULL DEFAULT 1,
+    status TEXT NOT NULL DEFAULT 'Active',
+    intent TEXT NOT NULL DEFAULT 'Show / Breeding',
+    desired_breed TEXT NOT NULL DEFAULT '',
+    desired_variety TEXT NOT NULL DEFAULT '',
+    preferred_sex TEXT NOT NULL DEFAULT 'Any',
+    preferred_breeding_id TEXT NOT NULL DEFAULT '',
+    requested_by_date_iso TEXT NOT NULL DEFAULT '',
+    inquiry_date_iso TEXT NOT NULL DEFAULT '',
+    follow_up_date_iso TEXT NOT NULL DEFAULT '',
+    last_contacted_date_iso TEXT NOT NULL DEFAULT '',
+    max_budget_cents INTEGER NOT NULL DEFAULT 0,
+    notes TEXT NOT NULL DEFAULT '',
+    created_at TEXT NOT NULL,
+    updated_at TEXT NOT NULL
+  );
+
+  CREATE INDEX IF NOT EXISTS idx_waitlist_entries_species ON waitlist_entries(species);
+
+  CREATE TABLE IF NOT EXISTS animal_reservations (
+    id TEXT PRIMARY KEY NOT NULL,
+    species TEXT NOT NULL,
+    agreement_number TEXT NOT NULL DEFAULT '',
+    client_id TEXT NOT NULL,
+    client_name TEXT NOT NULL DEFAULT '',
+    waitlist_entry_id TEXT NOT NULL DEFAULT '',
+    animal_id TEXT NOT NULL DEFAULT '',
+    breeding_id TEXT NOT NULL DEFAULT '',
+    pick_order INTEGER NOT NULL DEFAULT 0,
+    item_label TEXT NOT NULL DEFAULT '',
+    status TEXT NOT NULL DEFAULT 'Pending Deposit',
+    reserved_date_iso TEXT NOT NULL DEFAULT '',
+    hold_expires_date_iso TEXT NOT NULL DEFAULT '',
+    total_price_cents INTEGER NOT NULL DEFAULT 0,
+    deposit_required_cents INTEGER NOT NULL DEFAULT 0,
+    deposit_paid_cents INTEGER NOT NULL DEFAULT 0,
+    deposit_due_date_iso TEXT NOT NULL DEFAULT '',
+    deposit_paid_date_iso TEXT NOT NULL DEFAULT '',
+    pickup_scheduled_date_iso TEXT NOT NULL DEFAULT '',
+    completed_date_iso TEXT NOT NULL DEFAULT '',
+    balance_reminder_date_iso TEXT NOT NULL DEFAULT '',
+    payment_method TEXT NOT NULL DEFAULT '',
+    ledger_entry_id TEXT NOT NULL DEFAULT '',
+    terms_summary TEXT NOT NULL DEFAULT '',
+    health_guarantee_notes TEXT NOT NULL DEFAULT '',
+    notes TEXT NOT NULL DEFAULT '',
+    created_at TEXT NOT NULL,
+    updated_at TEXT NOT NULL
+  );
+
+  CREATE INDEX IF NOT EXISTS idx_animal_reservations_species ON animal_reservations(species);
+
+  CREATE TABLE IF NOT EXISTS wool_harvests (
+    id TEXT PRIMARY KEY NOT NULL,
+    species TEXT NOT NULL,
+    animal_id TEXT NOT NULL,
+    harvest_date_iso TEXT NOT NULL,
+    shearing_interval_days INTEGER NOT NULL DEFAULT 0,
+    prime_weight_grams INTEGER NOT NULL DEFAULT 0,
+    grade_weight_grams INTEGER NOT NULL DEFAULT 0,
+    harvest_method TEXT NOT NULL DEFAULT 'Sheared',
+    staple_length_mm REAL NOT NULL DEFAULT 0,
+    iagarb_score_json TEXT NOT NULL DEFAULT '{}',
+    witnessed_by TEXT NOT NULL DEFAULT '',
+    notes TEXT NOT NULL DEFAULT '',
+    created_at TEXT NOT NULL,
+    updated_at TEXT NOT NULL
+  );
+
+  CREATE INDEX IF NOT EXISTS idx_wool_harvests_species ON wool_harvests(species);
+  CREATE INDEX IF NOT EXISTS idx_wool_harvests_animal ON wool_harvests(animal_id);
 `;
 
 const IDB_OPEN_TIMEOUT_MS = 8000;
 
 function openIdb(): Promise<IDBDatabase> {
   return new Promise((resolve, reject) => {
-    if (typeof indexedDB === 'undefined') {
+    const idb = getSafeIndexedDb();
+    if (!idb) {
       reject(new Error('IndexedDB is unavailable in this browser context.'));
       return;
     }
@@ -552,7 +604,7 @@
     }, IDB_OPEN_TIMEOUT_MS);
 
     try {
-      const req = indexedDB.open(IDB_DB_NAME, 1);
+      const req = idb.open(IDB_DB_NAME, 1);
       req.onupgradeneeded = () => {
         try {
           const db = req.result;
@@ -594,17 +646,32 @@
 
 async function idbGet<T>(key: string): Promise<T | undefined> {
   const db = await openIdb();
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     return await new Promise<T | undefined>((resolve, reject) => {
       const tx = db.transaction(IDB_STORE_NAME, 'readonly');
+      const untrackTx = trackActiveIdbTransaction(tx);
       const req = tx.objectStore(IDB_STORE_NAME).get(key);
-      req.onsuccess = () => resolve(req.result as T | undefined);
-      req.onerror = () => reject(req.error);
-      tx.onabort = () =>
+      req.onsuccess = () => {
+        untrackTx();
+        resolve(req.result as T | undefined);
+      };
+      req.onerror = () => {
+        untrackTx();
+        reject(req.error);
+      };
+      tx.onabort = () => {
+        untrackTx();
         reject(tx.error || new Error('IndexedDB read transaction aborted.'));
+      };
     });
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
@@ -617,18 +684,29 @@
 ): Promise<void> {
   if (entries.length === 0) return;
   let db: IDBDatabase | null = null;
+  let untrackDb: (() => void) | null = null;
   try {
     db = await openIdb();
+    untrackDb = trackActiveIdbConnection(db);
     await new Promise<void>((resolve, reject) => {
       const tx = db!.transaction(IDB_STORE_NAME, 'readwrite');
+      const untrackTx = trackActiveIdbTransaction(tx);
       const store = tx.objectStore(IDB_STORE_NAME);
       for (const entry of entries) {
         store.put(entry.value, entry.key);
       }
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => reject(tx.error);
-      tx.onabort = () =>
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        reject(tx.error);
+      };
+      tx.onabort = () => {
+        untrackTx();
         reject(tx.error || new Error('IndexedDB write transaction aborted.'));
+      };
     });
   } catch (err) {
     if (isQuotaExceededError(err)) {
@@ -638,23 +716,44 @@
     }
     throw err;
   } finally {
-    db?.close();
+    untrackDb?.();
+    try {
+      db?.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
 async function idbDelete(key: string): Promise<void> {
-  if (typeof indexedDB === 'undefined') return;
+  if (!getSafeIndexedDb()) return;
   const db = await openIdb();
+  const untrackDb = trackActiveIdbConnection(db);
   try {
     await new Promise<void>((resolve) => {
       const tx = db.transaction(IDB_STORE_NAME, 'readwrite');
+      const untrackTx = trackActiveIdbTransaction(tx);
       tx.objectStore(IDB_STORE_NAME).delete(key);
-      tx.oncomplete = () => resolve();
-      tx.onerror = () => resolve();
-      tx.onabort = () => resolve();
+      tx.oncomplete = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onerror = () => {
+        untrackTx();
+        resolve();
+      };
+      tx.onabort = () => {
+        untrackTx();
+        resolve();
+      };
     });
   } finally {
-    db.close();
+    untrackDb();
+    try {
+      db.close();
+    } catch {
+      // Ignore close error
+    }
   }
 }
 
@@ -799,11 +898,21 @@
   private lastRollingSaveMs = 0;
   private wipedRecoveryContext: WipedStorageRecoveryContext | null = null;
   private loadedEpoch = 0;
+  private ephemeralMode = false;
 
   constructor(private readonly tabId: string = getCurrentTabId()) {}
 
   get engineName(): string {
+    if (this.ephemeralMode) {
+      return this.db
+        ? 'Local SQLite (Ephemeral Session)'
+        : 'Ephemeral In-Memory Store (Private/Restricted Mode)';
+    }
     return this.db ? 'Local SQLite (WASM + IndexedDB)' : 'Local IndexedDB Store';
+  }
+
+  isEphemeralMode(): boolean {
+    return this.ephemeralMode;
   }
 
   getWipedRecoveryContext(): WipedStorageRecoveryContext | null {
@@ -815,6 +924,9 @@
   }
 
   private async readPersistedWriteEpoch(): Promise<PersistedWriteEpochMeta> {
+    if (this.ephemeralMode || !getSafeIndexedDb()) {
+      return { epoch: 0, writerTabId: '', updatedAtIso: '' };
+    }
     try {
       const meta = await idbGet<Partial<PersistedWriteEpochMeta>>(IDB_WRITE_EPOCH_KEY);
       const epoch = Number(meta?.epoch);
@@ -837,6 +949,9 @@
    * initialization under lock).
    */
   private async syncFromPersistedStorageIfStaleLocked(): Promise<boolean> {
+    if (this.ephemeralMode || !getSafeIndexedDb()) {
+      return false;
+    }
     const persisted = await this.readPersistedWriteEpoch();
     if (persisted.epoch <= this.loadedEpoch) {
       return false;
@@ -893,6 +1008,9 @@
   }
 
   async syncFromPersistedStorageIfStale(): Promise<boolean> {
+    if (this.ephemeralMode || !getSafeIndexedDb()) {
+      return false;
+    }
     const persisted = await this.readPersistedWriteEpoch();
     if (persisted.epoch <= this.loadedEpoch) {
       return false;
@@ -904,6 +1022,9 @@
     snapshot: BarnDatabaseSnapshot;
     source: string;
   } | null> {
+    if (this.ephemeralMode || !getSafeIndexedDb()) {
+      return null;
+    }
     const saved = await idbGet<BarnDatabaseSnapshot>(IDB_FALLBACK_SNAPSHOT_KEY).catch(() => undefined);
     if (
       saved &&
@@ -979,11 +1100,12 @@
 
   private async initializeLocked(options?: SnapshotLoadOptions): Promise<BarnDatabaseSnapshot> {
     this.wipedRecoveryContext = null;
+    this.ephemeralMode = false;
     const finalizeSnapshot = (snap: BarnDatabaseSnapshot): BarnDatabaseSnapshot =>
       options?.lightweightPhotos ? stripPhotoDataUrlsFromSnapshot(snap) : snap;
 
     const tryDetectWipedStorage = async (): Promise<BarnDatabaseSnapshot | null> => {
-      if (options?.allowSeedFresh) return null;
+      if (this.ephemeralMode || !getSafeIndexedDb() || options?.allowSeedFresh) return null;
       const wiped = await detectReturningUserWipedStorage().catch(() => null);
       if (wiped && wiped.detected) {
         this.wipedRecoveryContext = wiped;
@@ -999,6 +1121,21 @@
 
     try {
       this.SQL = await initSqlJs(createSqlJsInitConfig());
+
+      if (!getSafeIndexedDb()) {
+        this.ephemeralMode = true;
+        this.db = new this.SQL.Database();
+        applySchemaMigrations(this.db);
+        const seeded = buildFullPredefinedSampleSnapshot();
+        await this.replaceSnapshotLocked(seeded, 'initializeEphemeralSeed');
+        logDiagnosticEvent({
+          level: 'warn',
+          category: 'storage',
+          message:
+            'IndexedDB unavailable (Private Browsing or Lockdown Mode) — running in ephemeral SQLite session mode',
+        });
+        return finalizeSnapshot(seeded);
+      }
 
       const [savedBytes, epochMeta] = await Promise.all([
         idbGet<Uint8Array>(IDB_PRIMARY_KEY),
@@ -1106,11 +1243,17 @@
         return finalizeSnapshot(seeded);
       }
     } catch (err) {
-      console.warn('WASM SQLite fallback to IndexedDB JSON / Rolling Snapshot:', err);
+      if (!getSafeIndexedDb() || isIndexedDbBlockedError(err)) {
+        this.ephemeralMode = true;
+      }
+
+      console.warn('WASM SQLite fallback to IndexedDB JSON / Ephemeral Session:', err);
       logDiagnosticEvent({
-        level: 'error',
+        level: this.ephemeralMode ? 'warn' : 'error',
         category: isMemoryLikeError(err) ? 'memory' : 'storage',
-        message: 'Primary SQLite load failed — attempting non-destructive recovery from fallback/rolling backup',
+        message: this.ephemeralMode
+          ? 'Browser storage restricted (Private Browsing or Lockdown Mode) — running safely in ephemeral session mode'
+          : 'Primary SQLite load failed — attempting non-destructive recovery from fallback/rolling backup',
         error: err,
       });
 
@@ -1118,6 +1261,19 @@
         await dumpIndexedDbDatabaseToOpfs(IDB_DB_NAME, 'Primary SQLite IndexedDB VersionError').catch(
           () => {}
         );
+      }
+
+      if (this.ephemeralMode) {
+        const seeded = buildFullPredefinedSampleSnapshot();
+        if (this.SQL) {
+          const rebuilt = await this.tryRestoreIntoFreshSqliteDbLocked(seeded);
+          if (rebuilt) {
+            return finalizeSnapshot(seeded);
+          }
+        }
+        this.fallbackSnapshot = seeded;
+        this.loadedEpoch = Math.max(this.loadedEpoch, 1);
+        return finalizeSnapshot(seeded);
       }
 
       const recovered = await this.findRecoveredBackupSnapshot();
@@ -1161,6 +1317,17 @@
     preloadedSnapshot?: BarnDatabaseSnapshot,
     reason?: string
   ): Promise<void> {
+    if (this.ephemeralMode || !getSafeIndexedDb()) {
+      this.ephemeralMode = true;
+      this.loadedEpoch = this.loadedEpoch + 1;
+      publishCrossTabDbCommit({
+        epoch: this.loadedEpoch,
+        writerTabId: this.tabId,
+        reason,
+      });
+      return;
+    }
+
     const persisted = await this.readPersistedWriteEpoch();
     const nextEpoch = Math.max(persisted.epoch, this.loadedEpoch) + 1;
     const epochMeta: PersistedWriteEpochMeta = {
@@ -1189,6 +1356,23 @@
         reason,
       });
     } catch (err) {
+      if (!isQuotaExceededError(err) && isIndexedDbBlockedError(err)) {
+        this.ephemeralMode = true;
+        this.loadedEpoch = nextEpoch;
+        logDiagnosticEvent({
+          level: 'warn',
+          category: 'storage',
+          message:
+            'IndexedDB write blocked by browser privacy/lockdown policy — degrading cleanly to ephemeral in-memory session mode',
+          error: err,
+        });
+        publishCrossTabDbCommit({
+          epoch: nextEpoch,
+          writerTabId: this.tabId,
+          reason,
+        });
+        return;
+      }
       logDiagnosticEvent({
         level: 'error',
         category: isMemoryLikeError(err) ? 'memory' : 'storage',
@@ -1553,7 +1737,7 @@
       fosteredCount: finiteNonNeg(r.fostered_count, 0),
       weanedCount: finiteNonNeg(r.weaned_count, 0),
       offspringCreated: Number(r.offspring_created) === 1,
-      status: normalizeSqliteBreedingStatus(r.status),
+      status: (r.status as any) || 'Bred',
       serviceFeeCents: finiteNonNeg(r.service_fee_cents, 0),
       serviceFeeDirection: normalizeServiceFeeDirection(r.service_fee_direction),
       ultrasoundDateIso: String(r.ultrasound_date_iso || ''),
@@ -1580,8 +1764,8 @@
       id: String(r.id),
       species: String(r.species),
       title: String(r.title),
-      category: normalizeSqliteTaskCategory(r.category),
-      priority: normalizeSqliteTaskPriority(r.priority),
+      category: (r.category as any) || 'Care',
+      priority: (r.priority as any) || 'Normal',
       dueDateIso: String(r.due_date_iso),
       linkedAnimalId: String(r.linked_animal_id),
       linkedAnimalName: String(r.linked_animal_name),
@@ -1598,7 +1782,7 @@
       species: String(r.species),
       animalId: String(r.animal_id),
       dateIso: String(r.date_iso),
-      type: normalizeSqliteCareLogType(r.type),
+      type: (r.type as any) || 'Weight Check',
       title: String(r.title),
       weightGrams: finiteNonNeg(r.weight_grams, 0),
       showLegEarned: Number(r.show_leg_earned) === 1,
@@ -1871,6 +2055,107 @@
       };
     });
 
+    const clientContacts: ClientContact[] = safeTableQuery(
+      'client_contacts',
+      'SELECT * FROM client_contacts ORDER BY full_name ASC, created_at DESC'
+    ).map((r) => {
+      const tags = safeArray<string>(
+        this.safeParseJson<string[]>(
+          r.tags_json || '[]',
+          [],
+          `client_contacts(${String(r.id)}).tags_json`
+        )
+      )
+        .filter((t) => typeof t === 'string' && t.trim().length > 0)
+        .map((t) => t.trim());
+      return {
+        id: String(r.id),
+        species: String(r.species),
+        fullName: String(r.full_name || ''),
+        ranchOrHerdName: String(r.ranch_or_herd_name || ''),
+        email: String(r.email || ''),
+        phone: String(r.phone || ''),
+        preferredContact: normalizePreferredContactMethod(r.preferred_contact, 'sms'),
+        clientKind: normalizeClientKind(r.client_kind, 'pet_buyer'),
+        cityState: String(r.city_state || ''),
+        shippingAddress: String(r.shipping_address || ''),
+        tags,
+        notes: String(r.notes || ''),
+        createdAt: String(r.created_at),
+        updatedAt: String(r.updated_at),
+      };
+    });
+
+    const waitlistEntries: WaitlistEntry[] = safeTableQuery(
+      'waitlist_entries',
+      'SELECT * FROM waitlist_entries ORDER BY priority_rank ASC, inquiry_date_iso ASC, created_at ASC'
+    ).map((r) => {
+      const rawSex = String(r.preferred_sex || 'Any');
+      const preferredSex: WaitlistEntry['preferredSex'] =
+        rawSex === 'Male' || rawSex === 'Female' ? rawSex : 'Any';
+      const maxBudgetRaw = Math.round(finiteNonNeg(r.max_budget_cents, 0));
+      return {
+        id: String(r.id),
+        species: String(r.species),
+        clientId: String(r.client_id || ''),
+        clientName: String(r.client_name || ''),
+        priorityRank: Math.max(1, Math.round(finiteNonNeg(r.priority_rank, 1))),
+        status: normalizeWaitlistStatus(r.status, 'Active'),
+        intent: normalizeWaitlistIntent(r.intent, 'Show / Breeding'),
+        desiredBreed: String(r.desired_breed || ''),
+        desiredVariety: String(r.desired_variety || ''),
+        preferredSex,
+        ...(r.preferred_breeding_id
+          ? { preferredBreedingId: String(r.preferred_breeding_id) }
+          : {}),
+        requestedByDateIso: String(r.requested_by_date_iso || ''),
+        inquiryDateIso: String(r.inquiry_date_iso || ''),
+        followUpDateIso: String(r.follow_up_date_iso || ''),
+        lastContactedDateIso: String(r.last_contacted_date_iso || ''),
+        ...(maxBudgetRaw > 0 ? { maxBudgetCents: maxBudgetRaw } : {}),
+        notes: String(r.notes || ''),
+        createdAt: String(r.created_at),
+        updatedAt: String(r.updated_at),
+      };
+    });
+
+    const animalReservations: AnimalReservation[] = safeTableQuery(
+      'animal_reservations',
+      'SELECT * FROM animal_reservations ORDER BY reserved_date_iso DESC, created_at DESC'
+    ).map((r) => {
+      const pickOrderRaw = Math.round(finiteNonNeg(r.pick_order, 0));
+      return {
+        id: String(r.id),
+        species: String(r.species),
+        agreementNumber: String(r.agreement_number || ''),
+        clientId: String(r.client_id || ''),
+        clientName: String(r.client_name || ''),
+        ...(r.waitlist_entry_id ? { waitlistEntryId: String(r.waitlist_entry_id) } : {}),
+        ...(r.animal_id ? { animalId: String(r.animal_id) } : {}),
+        ...(r.breeding_id ? { breedingId: String(r.breeding_id) } : {}),
+        ...(pickOrderRaw > 0 ? { pickOrder: pickOrderRaw } : {}),
+        itemLabel: String(r.item_label || ''),
+        status: normalizeReservationStatus(r.status, 'Pending Deposit'),
+        reservedDateIso: String(r.reserved_date_iso || ''),
+        holdExpiresDateIso: String(r.hold_expires_date_iso || ''),
+        totalPriceCents: Math.round(finiteNonNeg(r.total_price_cents, 0)),
+        depositRequiredCents: Math.round(finiteNonNeg(r.deposit_required_cents, 0)),
+        depositPaidCents: Math.round(finiteNonNeg(r.deposit_paid_cents, 0)),
+        depositDueDateIso: String(r.deposit_due_date_iso || ''),
+        depositPaidDateIso: String(r.deposit_paid_date_iso || ''),
+        pickupScheduledDateIso: String(r.pickup_scheduled_date_iso || ''),
+        completedDateIso: String(r.completed_date_iso || ''),
+        balanceReminderDateIso: String(r.balance_reminder_date_iso || ''),
+        paymentMethod: String(r.payment_method || ''),
+        ...(r.ledger_entry_id ? { ledgerEntryId: String(r.ledger_entry_id) } : {}),
+        termsSummary: String(r.terms_summary || ''),
+        healthGuaranteeNotes: String(r.health_guarantee_notes || ''),
+        notes: String(r.notes || ''),
+        createdAt: String(r.created_at),
+        updatedAt: String(r.updated_at),
+      };
+    });
+
     if (sanitizedNumericCount > 0) {
       logDiagnosticEvent({
         level: 'warn',
@@ -1894,6 +2179,43 @@
       ledgerEntries,
       processingLogs,
       youthProjectBooks,
+      clientContacts,
+      waitlistEntries,
+      animalReservations,
+      woolHarvests: safeTableQuery(
+        'wool_harvests',
+        'SELECT * FROM wool_harvests ORDER BY harvest_date_iso DESC, created_at DESC'
+      ).map((r): WoolHarvest => {
+        const intervalRaw = Math.round(finiteNonNeg(r.shearing_interval_days, 0));
+        const stapleRaw = finiteNonNeg(r.staple_length_mm, 0);
+        const rawScoreJson = r.iagarb_score_json
+          ? this.safeParseJson<Record<string, unknown> | null>(
+              r.iagarb_score_json,
+              null,
+              `wool_harvests(${String(r.id)}).iagarb_score_json`
+            )
+          : null;
+        const iagarbScore =
+          rawScoreJson && Object.keys(rawScoreJson).length > 0
+            ? normalizeIagarbScorecard(rawScoreJson)
+            : undefined;
+        return {
+          id: String(r.id),
+          species: String(r.species),
+          animalId: String(r.animal_id || ''),
+          harvestDateIso: String(r.harvest_date_iso || ''),
+          ...(intervalRaw > 0 ? { shearingIntervalDays: intervalRaw } : {}),
+          primeWeightGrams: Math.round(finiteNonNeg(r.prime_weight_grams, 0)),
+          gradeWeightGrams: Math.round(finiteNonNeg(r.grade_weight_grams, 0)),
+          harvestMethod: normalizeWoolHarvestMethod(r.harvest_method, 'Shear'),
+          ...(stapleRaw > 0 ? { stapleLengthMm: stapleRaw } : {}),
+          ...(iagarbScore ? { iagarbScore } : {}),
+          witnessedBy: String(r.witnessed_by || ''),
+          notes: String(r.notes || ''),
+          createdAt: String(r.created_at),
+          updatedAt: String(r.updated_at),
+        };
+      }),
     };
   }
 
@@ -2272,6 +2594,10 @@
       this.db.run('DELETE FROM ledger_entries;');
       this.db.run('DELETE FROM processing_logs;');
       this.db.run('DELETE FROM youth_project_books;');
+      this.db.run('DELETE FROM client_contacts;');
+      this.db.run('DELETE FROM waitlist_entries;');
+      this.db.run('DELETE FROM animal_reservations;');
+      this.db.run('DELETE FROM wool_harvests;');
 
       this.upsertSettingsRow(snapshot.settings);
       for (const sp of snapshot.speciesProfiles) this.upsertSpeciesRow(sp);
@@ -2292,6 +2618,10 @@
       for (const le of snapshot.ledgerEntries ?? []) this.upsertLedgerEntryRow(le);
       for (const pl of snapshot.processingLogs ?? []) this.upsertProcessingLogRow(pl);
       for (const yp of snapshot.youthProjectBooks ?? []) this.upsertYouthProjectBookRow(yp);
+      for (const cc of snapshot.clientContacts ?? []) this.upsertClientContactRow(cc);
+      for (const wl of snapshot.waitlistEntries ?? []) this.upsertWaitlistEntryRow(wl);
+      for (const ar of snapshot.animalReservations ?? []) this.upsertAnimalReservationRow(ar);
+      for (const wh of snapshot.woolHarvests ?? []) this.upsertWoolHarvestRow(wh);
 
       this.db.run('COMMIT;');
     } catch (e) {
@@ -2808,6 +3138,150 @@
     );
   }
 
+  private upsertClientContactRow(cc: ClientContact): void {
+    this.db?.run(
+      `INSERT OR REPLACE INTO client_contacts
+       (id, species, full_name, ranch_or_herd_name, email, phone, preferred_contact, client_kind, city_state, shipping_address, tags_json, notes, created_at, updated_at)
+       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
+      [
+        cc.id,
+        cc.species,
+        cc.fullName || '',
+        cc.ranchOrHerdName || '',
+        cc.email || '',
+        cc.phone || '',
+        normalizePreferredContactMethod(cc.preferredContact, 'sms'),
+        normalizeClientKind(cc.clientKind, 'pet_buyer'),
+        cc.cityState || '',
+        cc.shippingAddress || '',
+        JSON.stringify(Array.isArray(cc.tags) ? cc.tags : []),
+        cc.notes || '',
+        cc.createdAt,
+        cc.updatedAt,
+      ]
+    );
+  }
+
+  private upsertWaitlistEntryRow(wl: WaitlistEntry): void {
+    const cleanSex =
+      wl.preferredSex === 'Male' || wl.preferredSex === 'Female' ? wl.preferredSex : 'Any';
+    this.db?.run(
+      `INSERT OR REPLACE INTO waitlist_entries
+       (id, species, client_id, client_name, priority_rank, status, intent, desired_breed, desired_variety, preferred_sex, preferred_breeding_id, requested_by_date_iso, inquiry_date_iso, follow_up_date_iso, last_contacted_date_iso, max_budget_cents, notes, created_at, updated_at)
+       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
+      [
+        wl.id,
+        wl.species,
+        wl.clientId || '',
+        wl.clientName || '',
+        Number.isFinite(Number(wl.priorityRank)) && Number(wl.priorityRank) >= 1
+          ? Math.round(Number(wl.priorityRank))
+          : 1,
+        normalizeWaitlistStatus(wl.status, 'Active'),
+        normalizeWaitlistIntent(wl.intent, 'Show / Breeding'),
+        wl.desiredBreed || '',
+        wl.desiredVariety || '',
+        cleanSex,
+        wl.preferredBreedingId || '',
+        wl.requestedByDateIso || '',
+        wl.inquiryDateIso || '',
+        wl.followUpDateIso || '',
+        wl.lastContactedDateIso || '',
+        wl.maxBudgetCents && wl.maxBudgetCents > 0 ? Math.round(wl.maxBudgetCents) : 0,
+        wl.notes || '',
+        wl.createdAt,
+        wl.updatedAt,
+      ]
+    );
+  }
+
+  private upsertAnimalReservationRow(ar: AnimalReservation): void {
+    this.db?.run(
+      `INSERT OR REPLACE INTO animal_reservations
+       (id, species, agreement_number, client_id, client_name, waitlist_entry_id, animal_id, breeding_id, pick_order, item_label, status, reserved_date_iso, hold_expires_date_iso, total_price_cents, deposit_required_cents, deposit_paid_cents, deposit_due_date_iso, deposit_paid_date_iso, pickup_scheduled_date_iso, completed_date_iso, balance_reminder_date_iso, payment_method, ledger_entry_id, terms_summary, health_guarantee_notes, notes, created_at, updated_at)
+       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
+      [
+        ar.id,
+        ar.species,
+        ar.agreementNumber || '',
+        ar.clientId || '',
+        ar.clientName || '',
+        ar.waitlistEntryId || '',
+        ar.animalId || '',
+        ar.breedingId || '',
+        ar.pickOrder && ar.pickOrder > 0 ? Math.round(ar.pickOrder) : 0,
+        ar.itemLabel || '',
+        normalizeReservationStatus(ar.status, 'Pending Deposit'),
+        ar.reservedDateIso || '',
+        ar.holdExpiresDateIso || '',
+        Number.isFinite(Number(ar.totalPriceCents)) && Number(ar.totalPriceCents) >= 0
+          ? Math.round(Number(ar.totalPriceCents))
+          : 0,
+        Number.isFinite(Number(ar.depositRequiredCents)) && Number(ar.depositRequiredCents) >= 0
+          ? Math.round(Number(ar.depositRequiredCents))
+          : 0,
+        Number.isFinite(Number(ar.depositPaidCents)) && Number(ar.depositPaidCents) >= 0
+          ? Math.round(Number(ar.depositPaidCents))
+          : 0,
+        ar.depositDueDateIso || '',
+        ar.depositPaidDateIso || '',
+        ar.pickupScheduledDateIso || '',
+        ar.completedDateIso || '',
+        ar.balanceReminderDateIso || '',
+        ar.paymentMethod || '',
+        ar.ledgerEntryId || '',
+        ar.termsSummary || '',
+        ar.healthGuaranteeNotes || '',
+        ar.notes || '',
+        ar.createdAt,
+        ar.updatedAt,
+      ]
+    );
+  }
+
+  private upsertWoolHarvestRow(wh: WoolHarvest): void {
+    const interval =
+      typeof wh.shearingIntervalDays === 'number' &&
+      Number.isFinite(wh.shearingIntervalDays) &&
+      wh.shearingIntervalDays > 0
+        ? Math.round(wh.shearingIntervalDays)
+        : 0;
+    const staple =
+      typeof wh.stapleLengthMm === 'number' &&
+      Number.isFinite(wh.stapleLengthMm) &&
+      wh.stapleLengthMm > 0
+        ? wh.stapleLengthMm
+        : 0;
+    const scoreJson = wh.iagarbScore
+      ? JSON.stringify(normalizeIagarbScorecard(wh.iagarbScore))
+      : '{}';
+    this.db?.run(
+      `INSERT OR REPLACE INTO wool_harvests
+       (id, species, animal_id, harvest_date_iso, shearing_interval_days, prime_weight_grams, grade_weight_grams, harvest_method, staple_length_mm, iagarb_score_json, witnessed_by, notes, created_at, updated_at)
+       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
+      [
+        wh.id,
+        wh.species,
+        wh.animalId || '',
+        wh.harvestDateIso || '',
+        interval,
+        Number.isFinite(Number(wh.primeWeightGrams)) && Number(wh.primeWeightGrams) >= 0
+          ? Math.round(Number(wh.primeWeightGrams))
+          : 0,
+        Number.isFinite(Number(wh.gradeWeightGrams)) && Number(wh.gradeWeightGrams) >= 0
+          ? Math.round(Number(wh.gradeWeightGrams))
+          : 0,
+        normalizeWoolHarvestMethod(wh.harvestMethod, 'Shear'),
+        staple,
+        scoreJson,
+        wh.witnessedBy || '',
+        wh.notes || '',
+        wh.createdAt,
+        wh.updatedAt,
+      ]
+    );
+  }
+
   private async withLockedWrite(reason: string, mutate: () => void): Promise<void> {
     return withCrossTabLock(DB_WRITE_LOCK_NAME, async () => {
       await this.syncFromPersistedStorageIfStaleLocked();
@@ -2926,6 +3400,7 @@
         this.db.run('DELETE FROM animals WHERE id = ?', [id]);
         this.db.run('DELETE FROM animal_photos WHERE animal_id = ?', [id]);
         this.db.run('DELETE FROM care_logs WHERE animal_id = ?', [id]);
+        this.db.run('DELETE FROM wool_harvests WHERE animal_id = ?', [id]);
       } else if (this.fallbackSnapshot) {
         this.fallbackSnapshot.animals = this.fallbackSnapshot.animals.filter((a) => a.id !== id);
         this.fallbackSnapshot.animalPhotos = (this.fallbackSnapshot.animalPhotos || []).filter(
@@ -2934,6 +3409,9 @@
         this.fallbackSnapshot.careLogs = this.fallbackSnapshot.careLogs.filter(
           (l) => l.animalId !== id
         );
+        this.fallbackSnapshot.woolHarvests = (this.fallbackSnapshot.woolHarvests || []).filter(
+          (w) => w.animalId !== id
+        );
       }
     });
   }
@@ -2949,6 +3427,7 @@
             this.db.run('DELETE FROM animals WHERE id = ?', [id]);
             this.db.run('DELETE FROM animal_photos WHERE animal_id = ?', [id]);
             this.db.run('DELETE FROM care_logs WHERE animal_id = ?', [id]);
+            this.db.run('DELETE FROM wool_harvests WHERE animal_id = ?', [id]);
           }
           this.db.run('COMMIT;');
         } catch (e) {
@@ -2966,6 +3445,9 @@
         );
         this.fallbackSnapshot.careLogs = this.fallbackSnapshot.careLogs.filter(
           (l) => !idSet.has(l.animalId)
+        );
+        this.fallbackSnapshot.woolHarvests = (this.fallbackSnapshot.woolHarvests || []).filter(
+          (w) => !idSet.has(w.animalId)
         );
       }
     });
@@ -3466,6 +3948,222 @@
     });
   }
 
+  async saveClientContact(client: ClientContact): Promise<void> {
+    await this.withLockedWrite('saveClientContact', () => {
+      if (this.db) {
+        this.upsertClientContactRow(client);
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.clientContacts ?? [];
+        const idx = list.findIndex((x) => x.id === client.id);
+        if (idx >= 0) list[idx] = client;
+        else list.push(client);
+        this.fallbackSnapshot.clientContacts = list;
+      }
+    });
+  }
+
+  async saveClientContactsBatch(clients: ClientContact[]): Promise<void> {
+    if (clients.length === 0) return;
+    await this.withLockedWrite('saveClientContactsBatch', () => {
+      if (this.db) {
+        this.db.run('BEGIN TRANSACTION;');
+        try {
+          for (const cc of clients) this.upsertClientContactRow(cc);
+          this.db.run('COMMIT;');
+        } catch (err) {
+          try {
+            this.db.run('ROLLBACK;');
+          } catch {
+            // Ignore rollback error
+          }
+          throw err;
+        }
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.clientContacts ?? [];
+        for (const cc of clients) {
+          const idx = list.findIndex((x) => x.id === cc.id);
+          if (idx >= 0) list[idx] = cc;
+          else list.push(cc);
+        }
+        this.fallbackSnapshot.clientContacts = list;
+      }
+    });
+  }
+
+  async deleteClientContact(id: string): Promise<void> {
+    await this.withLockedWrite('deleteClientContact', () => {
+      if (this.db) {
+        this.db.run('DELETE FROM client_contacts WHERE id = ?', [id]);
+      } else if (this.fallbackSnapshot) {
+        this.fallbackSnapshot.clientContacts = (
+          this.fallbackSnapshot.clientContacts ?? []
+        ).filter((x) => x.id !== id);
+      }
+    });
+  }
+
+  async saveWaitlistEntry(entry: WaitlistEntry): Promise<void> {
+    await this.withLockedWrite('saveWaitlistEntry', () => {
+      if (this.db) {
+        this.upsertWaitlistEntryRow(entry);
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.waitlistEntries ?? [];
+        const idx = list.findIndex((x) => x.id === entry.id);
+        if (idx >= 0) list[idx] = entry;
+        else list.push(entry);
+        this.fallbackSnapshot.waitlistEntries = list;
+      }
+    });
+  }
+
+  async saveWaitlistEntriesBatch(entries: WaitlistEntry[]): Promise<void> {
+    if (entries.length === 0) return;
+    await this.withLockedWrite('saveWaitlistEntriesBatch', () => {
+      if (this.db) {
+        this.db.run('BEGIN TRANSACTION;');
+        try {
+          for (const wl of entries) this.upsertWaitlistEntryRow(wl);
+          this.db.run('COMMIT;');
+        } catch (err) {
+          try {
+            this.db.run('ROLLBACK;');
+          } catch {
+            // Ignore rollback error
+          }
+          throw err;
+        }
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.waitlistEntries ?? [];
+        for (const wl of entries) {
+          const idx = list.findIndex((x) => x.id === wl.id);
+          if (idx >= 0) list[idx] = wl;
+          else list.push(wl);
+        }
+        this.fallbackSnapshot.waitlistEntries = list;
+      }
+    });
+  }
+
+  async deleteWaitlistEntry(id: string): Promise<void> {
+    await this.withLockedWrite('deleteWaitlistEntry', () => {
+      if (this.db) {
+        this.db.run('DELETE FROM waitlist_entries WHERE id = ?', [id]);
+      } else if (this.fallbackSnapshot) {
+        this.fallbackSnapshot.waitlistEntries = (
+          this.fallbackSnapshot.waitlistEntries ?? []
+        ).filter((x) => x.id !== id);
+      }
+    });
+  }
+
+  async saveAnimalReservation(reservation: AnimalReservation): Promise<void> {
+    await this.withLockedWrite('saveAnimalReservation', () => {
+      if (this.db) {
+        this.upsertAnimalReservationRow(reservation);
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.animalReservations ?? [];
+        const idx = list.findIndex((x) => x.id === reservation.id);
+        if (idx >= 0) list[idx] = reservation;
+        else list.push(reservation);
+        this.fallbackSnapshot.animalReservations = list;
+      }
+    });
+  }
+
+  async saveAnimalReservationsBatch(reservations: AnimalReservation[]): Promise<void> {
+    if (reservations.length === 0) return;
+    await this.withLockedWrite('saveAnimalReservationsBatch', () => {
+      if (this.db) {
+        this.db.run('BEGIN TRANSACTION;');
+        try {
+          for (const ar of reservations) this.upsertAnimalReservationRow(ar);
+          this.db.run('COMMIT;');
+        } catch (err) {
+          try {
+            this.db.run('ROLLBACK;');
+          } catch {
+            // Ignore rollback error
+          }
+          throw err;
+        }
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.animalReservations ?? [];
+        for (const ar of reservations) {
+          const idx = list.findIndex((x) => x.id === ar.id);
+          if (idx >= 0) list[idx] = ar;
+          else list.push(ar);
+        }
+        this.fallbackSnapshot.animalReservations = list;
+      }
+    });
+  }
+
+  async deleteAnimalReservation(id: string): Promise<void> {
+    await this.withLockedWrite('deleteAnimalReservation', () => {
+      if (this.db) {
+        this.db.run('DELETE FROM animal_reservations WHERE id = ?', [id]);
+      } else if (this.fallbackSnapshot) {
+        this.fallbackSnapshot.animalReservations = (
+          this.fallbackSnapshot.animalReservations ?? []
+        ).filter((x) => x.id !== id);
+      }
+    });
+  }
+
+  async saveWoolHarvest(harvest: WoolHarvest): Promise<void> {
+    await this.withLockedWrite('saveWoolHarvest', () => {
+      if (this.db) {
+        this.upsertWoolHarvestRow(harvest);
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.woolHarvests ?? [];
+        const idx = list.findIndex((x) => x.id === harvest.id);
+        if (idx >= 0) list[idx] = harvest;
+        else list.push(harvest);
+        this.fallbackSnapshot.woolHarvests = list;
+      }
+    });
+  }
+
+  async saveWoolHarvestsBatch(harvests: WoolHarvest[]): Promise<void> {
+    if (harvests.length === 0) return;
+    await this.withLockedWrite('saveWoolHarvestsBatch', () => {
+      if (this.db) {
+        this.db.run('BEGIN TRANSACTION;');
+        try {
+          for (const wh of harvests) this.upsertWoolHarvestRow(wh);
+          this.db.run('COMMIT;');
+        } catch (err) {
+          try {
+            this.db.run('ROLLBACK;');
+          } catch {
+            // Ignore rollback error
+          }
+          throw err;
+        }
+      } else if (this.fallbackSnapshot) {
+        const list = this.fallbackSnapshot.woolHarvests ?? [];
+        for (const wh of harvests) {
+          const idx = list.findIndex((x) => x.id === wh.id);
+          if (idx >= 0) list[idx] = wh;
+          else list.push(wh);
+        }
+        this.fallbackSnapshot.woolHarvests = list;
+      }
+    });
+  }
+
+  async deleteWoolHarvest(id: string): Promise<void> {
+    await this.withLockedWrite('deleteWoolHarvest', () => {
+      if (this.db) {
+        this.db.run('DELETE FROM wool_harvests WHERE id = ?', [id]);
+      } else if (this.fallbackSnapshot) {
+        this.fallbackSnapshot.woolHarvests = (
+          this.fallbackSnapshot.woolHarvests ?? []
+        ).filter((x) => x.id !== id);
+      }
+    });
+  }
+
   async exportRawSqliteBytes(): Promise<Uint8Array | null> {
     await this.syncFromPersistedStorageIfStale();
     if (!this.db) return null;
@@ -3543,10 +4241,13 @@
       this.SQL = null;
       this.fallbackSnapshot = null;
       this.loadedEpoch = 0;
-      try {
-        await idbDelete(IDB_FALLBACK_SNAPSHOT_KEY);
-      } catch {
-        // Ignore fallback delete failure
+      this.ephemeralMode = false;
+      if (getSafeIndexedDb()) {
+        try {
+          await idbDelete(IDB_FALLBACK_SNAPSHOT_KEY);
+        } catch {
+          // Ignore fallback delete failure
+        }
       }
       return this.initializeLocked(options);
     });
@@ -3565,8 +4266,17 @@
       this.SQL = null;
       this.fallbackSnapshot = null;
       this.loadedEpoch = 0;
-      await idbDelete(IDB_PRIMARY_KEY);
-      await idbDelete(IDB_FALLBACK_SNAPSHOT_KEY);
+      this.ephemeralMode = false;
+      if (getSafeIndexedDb()) {
+        try {
+          await idbDelete(IDB_PRIMARY_KEY);
+          await idbDelete(IDB_FALLBACK_SNAPSHOT_KEY);
+        } catch (err) {
+          if (!isIndexedDbBlockedError(err)) {
+            throw err;
+          }
+        }
+      }
       return this.initializeLocked({ ...options, allowSeedFresh: options?.allowSeedFresh ?? true });
     });
   }
```

### `src/utils/es2018Shims.ts` (`+100` / `-74`, source: `part-16.md`)

```diff
--- working/src/utils/es2018Shims.ts
+++ import/src/utils/es2018Shims.ts
@@ -14,84 +14,117 @@
 
 type MarkedShimFn = ((...args: any[]) => any) & { __pedigreeEs2018Shim?: boolean };
 
+export function isFileReaderSupported(): boolean {
+  try {
+    if (typeof FileReader !== 'function') return false;
+    const probe = new FileReader();
+    return Boolean(probe && typeof probe.readAsArrayBuffer === 'function');
+  } catch {
+    return false;
+  }
+}
+
 /**
- * Reads any Blob/File into an ArrayBuffer safely on 2018 browsers (Chrome 68–75, Safari 12–13,
- * Firefox 63–68) where native `Blob.prototype.arrayBuffer()` does not exist yet.
+ * Reads any Blob/File into an ArrayBuffer safely across modern browsers (preferring native
+ * `blob.arrayBuffer()`), legacy 2018 browsers (`FileReader`), and Safari Lockdown Mode (`Response`).
  */
-export function readBlobAsArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
+export async function readBlobAsArrayBuffer(blob: Blob): Promise<ArrayBuffer> {
   const candidate = (blob as unknown as { arrayBuffer?: MarkedShimFn })?.arrayBuffer;
   if (typeof candidate === 'function' && !candidate.__pedigreeEs2018Shim) {
-    return Promise.resolve(candidate.call(blob));
-  }
-
-  if (typeof FileReader === 'function') {
-    return new Promise<ArrayBuffer>((resolve, reject) => {
-      const reader = new FileReader();
-      reader.onload = () => {
-        if (reader.result instanceof ArrayBuffer) {
-          resolve(reader.result);
-        } else {
-          reject(new Error('FileReader did not return an ArrayBuffer.'));
-        }
-      };
-      reader.onerror = () => {
-        reject(reader.error || new Error('Failed to read binary file data.'));
-      };
-      reader.onabort = () => {
-        reject(new Error('Binary file read was aborted.'));
-      };
-      reader.readAsArrayBuffer(blob);
-    });
+    try {
+      return await Promise.resolve(candidate.call(blob));
+    } catch {
+      // Fall through cleanly if native method rejects or is blocked
+    }
+  }
+
+  if (isFileReaderSupported()) {
+    try {
+      return await new Promise<ArrayBuffer>((resolve, reject) => {
+        const reader = new FileReader();
+        reader.onload = () => {
+          if (reader.result instanceof ArrayBuffer) {
+            resolve(reader.result);
+          } else {
+            reject(new Error('FileReader did not return an ArrayBuffer.'));
+          }
+        };
+        reader.onerror = () => {
+          reject(reader.error || new Error('Failed to read binary file data.'));
+        };
+        reader.onabort = () => {
+          reject(new Error('Binary file read was aborted.'));
+        };
+        reader.readAsArrayBuffer(blob);
+      });
+    } catch {
+      // Fall through cleanly to Response fallback
+    }
   }
 
   if (typeof Response === 'function') {
-    return new Response(blob).arrayBuffer();
-  }
-
-  return Promise.reject(new Error('Blob binary reader is unavailable in this browser.'));
+    try {
+      return await new Response(blob).arrayBuffer();
+    } catch {
+      // Fall through to structured error below
+    }
+  }
+
+  throw new Error('Blob binary reader is unavailable in this browser.');
 }
 
 /**
- * Reads any Blob/File as UTF-8 text safely on 2018 browsers where native `Blob.prototype.text()`
- * is unavailable, falling back to `FileReader.prototype.readAsText` or `TextDecoder`.
+ * Reads any Blob/File as UTF-8 text safely, preferring native `blob.text()` first, then
+ * `FileReader`, `Response`, and `TextDecoder` fallbacks.
  */
-export function readBlobAsText(blob: Blob): Promise<string> {
+export async function readBlobAsText(blob: Blob): Promise<string> {
   const candidate = (blob as unknown as { text?: MarkedShimFn })?.text;
   if (typeof candidate === 'function' && !candidate.__pedigreeEs2018Shim) {
-    return Promise.resolve(candidate.call(blob));
-  }
-
-  if (typeof FileReader === 'function') {
-    return new Promise<string>((resolve, reject) => {
-      const reader = new FileReader();
-      reader.onload = () => {
-        resolve(typeof reader.result === 'string' ? reader.result : '');
-      };
-      reader.onerror = () => {
-        reject(reader.error || new Error('Failed to read text file data.'));
-      };
-      reader.onabort = () => {
-        reject(new Error('Text file read was aborted.'));
-      };
-      reader.readAsText(blob, 'utf-8');
-    });
+    try {
+      return await Promise.resolve(candidate.call(blob));
+    } catch {
+      // Fall through cleanly if native method rejects or is blocked
+    }
+  }
+
+  if (isFileReaderSupported()) {
+    try {
+      return await new Promise<string>((resolve, reject) => {
+        const reader = new FileReader();
+        reader.onload = () => {
+          resolve(typeof reader.result === 'string' ? reader.result : '');
+        };
+        reader.onerror = () => {
+          reject(reader.error || new Error('Failed to read text file data.'));
+        };
+        reader.onabort = () => {
+          reject(new Error('Text file read was aborted.'));
+        };
+        reader.readAsText(blob, 'utf-8');
+      });
+    } catch {
+      // Fall through cleanly to Response / TextDecoder fallback
+    }
   }
 
   if (typeof Response === 'function') {
-    return new Response(blob).text();
-  }
-
-  return readBlobAsArrayBuffer(blob).then((buf) => {
-    if (typeof TextDecoder === 'function') {
-      return new TextDecoder('utf-8').decode(new Uint8Array(buf));
-    }
-    const bytes = new Uint8Array(buf);
-    let out = '';
-    for (let i = 0; i < bytes.length; i += 1) {
-      out += String.fromCharCode(bytes[i]);
-    }
-    return out;
-  });
+    try {
+      return await new Response(blob).text();
+    } catch {
+      // Fall through to ArrayBuffer decode fallback
+    }
+  }
+
+  const buf = await readBlobAsArrayBuffer(blob);
+  if (typeof TextDecoder === 'function') {
+    return new TextDecoder('utf-8').decode(new Uint8Array(buf));
+  }
+  const bytes = new Uint8Array(buf);
+  let out = '';
+  for (let i = 0; i < bytes.length; i += 1) {
+    out += String.fromCharCode(bytes[i]);
+  }
+  return out;
 }
 
 function defineNonEnumerableMethod(
@@ -190,25 +223,18 @@
     defineNonEnumerableMethod(blobCtor.prototype, 'text', textShim);
   }
 
-  const stringCtor = (g.String ?? String) as { prototype?: object } | undefined;
+  const stringCtor = (g.String ?? String) as { prototype?: Record<string, any> } | undefined;
   if (stringCtor?.prototype) {
-    interface LegacyTrimString {
-      trimLeft?: () => string;
-      trimRight?: () => string;
-    }
-
     const trimStartShim: MarkedShimFn = function stringTrimStartShim(this: string) {
-      const legacy = this as unknown as LegacyTrimString;
-      return typeof legacy.trimLeft === 'function'
-        ? legacy.trimLeft.call(this)
+      return typeof (this as any).trimLeft === 'function'
+        ? (this as any).trimLeft()
         : String(this).replace(/^[\s\uFEFF\xA0]+/, '');
     };
     defineNonEnumerableMethod(stringCtor.prototype, 'trimStart', trimStartShim);
 
     const trimEndShim: MarkedShimFn = function stringTrimEndShim(this: string) {
-      const legacy = this as unknown as LegacyTrimString;
-      return typeof legacy.trimRight === 'function'
-        ? legacy.trimRight.call(this)
+      return typeof (this as any).trimRight === 'function'
+        ? (this as any).trimRight()
         : String(this).replace(/[\s\uFEFF\xA0]+$/, '');
     };
     defineNonEnumerableMethod(stringCtor.prototype, 'trimEnd', trimEndShim);
```

### `src/utils/googleCalendarClient.ts` (`+82` / `-67`, source: `part-16.md`)

```diff
--- working/src/utils/googleCalendarClient.ts
+++ import/src/utils/googleCalendarClient.ts
@@ -11,15 +11,7 @@
  *   or when the Google Calendar API cannot be reached.
  */
 
-import { getApp, getApps, initializeApp } from 'firebase/app';
-import {
-  getAuth,
-  GoogleAuthProvider,
-  onAuthStateChanged,
-  signInWithPopup,
-  User,
-} from 'firebase/auth';
-import firebaseConfig from '../../firebase-applet-config.json';
+import type { Auth, User } from 'firebase/auth';
 import {
   buildGoogleCalendarEventPayload,
   CalendarExportContext,
@@ -34,35 +26,42 @@
   'https://www.googleapis.com/auth/calendar.calendarlist.readonly',
 ] as const;
 
-let cachedAuth: ReturnType<typeof getAuth> | null = null;
+let cachedAuth: Auth | null = null;
 let authInitAttempted = false;
-
-function getFirebaseAuthSafe(): ReturnType<typeof getAuth> | null {
+let authInitPromise: Promise<Auth | null> | null = null;
+
+async function getFirebaseAuthSafe(): Promise<Auth | null> {
   if (cachedAuth) return cachedAuth;
   if (authInitAttempted) return null;
-  authInitAttempted = true;
-  try {
-    const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
-    cachedAuth = getAuth(firebaseApp);
-    return cachedAuth;
-  } catch (err) {
-    logDiagnosticEvent({
-      level: 'warn',
-      category: 'runtime',
-      message:
-        'Corrective action: Firebase Auth unavailable during startup — continuing in offline .ICS calendar mode',
-      error: err,
-    });
-    return null;
-  }
-}
-
-function createCalendarProvider(): GoogleAuthProvider {
-  const provider = new GoogleAuthProvider();
-  for (const scope of GOOGLE_CALENDAR_SCOPES) {
-    provider.addScope(scope);
-  }
-  return provider;
+  if (authInitPromise) return authInitPromise;
+
+  authInitPromise = (async () => {
+    try {
+      const [{ getApp, getApps, initializeApp }, { getAuth }, { default: firebaseConfig }] =
+        await Promise.all([
+          import('firebase/app'),
+          import('firebase/auth'),
+          import('../../firebase-applet-config.json'),
+        ]);
+      const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
+      cachedAuth = getAuth(firebaseApp);
+      return cachedAuth;
+    } catch (err) {
+      logDiagnosticEvent({
+        level: 'warn',
+        category: 'runtime',
+        message:
+          'Corrective action: Firebase Auth unavailable during startup — continuing in offline .ICS calendar mode',
+        error: err,
+      });
+      return null;
+    } finally {
+      authInitAttempted = true;
+      authInitPromise = null;
+    }
+  })();
+
+  return authInitPromise;
 }
 
 let isSigningIn = false;
@@ -87,44 +86,62 @@
   onAuthSuccess?: (user: User, token: string) => void,
   onAuthFailure?: (user: User | null) => void
 ): () => void {
-  const authInstance = getFirebaseAuthSafe();
-  if (!authInstance) {
-    onAuthFailure?.(null);
-    return () => {};
-  }
-  try {
-    return onAuthStateChanged(authInstance, (user: User | null) => {
-      if (user && cachedAccessToken) {
-        onAuthSuccess?.(user, cachedAccessToken);
-      } else if (!isSigningIn) {
-        cachedAccessToken = null;
-        onAuthFailure?.(user);
-      }
-    });
-  } catch (err) {
-    logDiagnosticEvent({
-      level: 'warn',
-      category: 'runtime',
-      message:
-        'Corrective action: Google Calendar auth listener could not attach — using offline .ICS fallback',
-      error: err,
-    });
-    onAuthFailure?.(null);
-    return () => {};
-  }
+  let cancelled = false;
+  let unsubscribe = () => {};
+
+  void (async () => {
+    const authInstance = await getFirebaseAuthSafe();
+    if (cancelled) return;
+    if (!authInstance) {
+      onAuthFailure?.(null);
+      return;
+    }
+    try {
+      const { onAuthStateChanged } = await import('firebase/auth');
+      if (cancelled) return;
+      unsubscribe = onAuthStateChanged(authInstance, (user: User | null) => {
+        if (user && cachedAccessToken) {
+          onAuthSuccess?.(user, cachedAccessToken);
+        } else if (!isSigningIn) {
+          cachedAccessToken = null;
+          onAuthFailure?.(user);
+        }
+      });
+    } catch (err) {
+      logDiagnosticEvent({
+        level: 'warn',
+        category: 'runtime',
+        message:
+          'Corrective action: Google Calendar auth listener could not attach — using offline .ICS fallback',
+        error: err,
+      });
+      if (!cancelled) {
+        onAuthFailure?.(null);
+      }
+    }
+  })();
+
+  return () => {
+    cancelled = true;
+    unsubscribe();
+  };
 }
 
 export async function signInGoogleCalendar(): Promise<{
   user: User;
   accessToken: string;
 }> {
-  const authInstance = getFirebaseAuthSafe();
+  const authInstance = await getFirebaseAuthSafe();
   if (!authInstance) {
     throw new Error('Google Calendar sign-in is unavailable in this browser environment. Use offline .ICS export instead.');
   }
   try {
     isSigningIn = true;
-    const provider = createCalendarProvider();
+    const { GoogleAuthProvider, signInWithPopup } = await import('firebase/auth');
+    const provider = new GoogleAuthProvider();
+    for (const scope of GOOGLE_CALENDAR_SCOPES) {
+      provider.addScope(scope);
+    }
     const result = await signInWithPopup(authInstance, provider);
     const credential = GoogleAuthProvider.credentialFromResult(result);
     if (!credential?.accessToken) {
@@ -139,10 +156,8 @@
 
 export async function signOutGoogleCalendar(): Promise<void> {
   cachedAccessToken = null;
-  const authInstance = getFirebaseAuthSafe();
-  if (authInstance) {
-    await authInstance.signOut();
-  }
+  if (!cachedAuth) return;
+  await cachedAuth.signOut();
 }
 
 export function getGoogleCalendarAccessToken(): string | null {
@@ -150,7 +165,7 @@
 }
 
 export function getCurrentGoogleCalendarUser(): User | null {
-  return getFirebaseAuthSafe()?.currentUser ?? null;
+  return cachedAuth?.currentUser ?? null;
 }
 
 export async function listWritableGoogleCalendars(
```

### `src/utils/webFileActions.ts` (`+148` / `-41`, source: `part-16.md`)

```diff
--- working/src/utils/webFileActions.ts
+++ import/src/utils/webFileActions.ts
@@ -10,6 +10,7 @@
  */
 
 import { pedigreeBridge } from '../native/pedigreeBridge';
+import { logDiagnosticEvent } from '../storage/crashLogger';
 import {
   isOpfsSupported,
   markTempOpfsFileActive,
@@ -19,29 +20,31 @@
   writeTempOpfsFile,
   writeTempOpfsFileStreamed,
 } from '../storage/opfsStorage';
+import { isIosBrowser, isStandalonePwa } from '../storage/storageProtection';
+import { readBlobAsArrayBuffer } from './es2018Shims';
+
+export type FileShareOutcome = 'shared' | 'downloaded' | 'cancelled';
+
+export function isInstalledIosPwa(): boolean {
+  if (!isIosBrowser()) return false;
+  if (isStandalonePwa()) return true;
+  if (typeof navigator !== 'undefined') {
+    return (navigator as unknown as { standalone?: boolean }).standalone === true;
+  }
+  return false;
+}
+
+export function isFileShareAbortError(err: unknown): boolean {
+  if (!err || typeof err !== 'object') return false;
+  return (err as { name?: unknown }).name === 'AbortError';
+}
 
 export const OPFS_SCRATCHPAD_THRESHOLD_BYTES = 512 * 1024;
 const BLOB_DOWNLOAD_CLEANUP_DELAY_MS = 4000;
 
 async function blobToUint8Array(blob: Blob): Promise<Uint8Array> {
-  if (typeof blob.arrayBuffer === 'function') {
-    const buffer = await blob.arrayBuffer();
-    return new Uint8Array(buffer);
-  }
-  return new Promise<Uint8Array>((resolve, reject) => {
-    const reader = new FileReader();
-    reader.onload = () => {
-      if (reader.result instanceof ArrayBuffer) {
-        resolve(new Uint8Array(reader.result));
-      } else {
-        reject(new Error('Failed to read Blob as ArrayBuffer.'));
-      }
-    };
-    reader.onerror = () => {
-      reject(reader.error || new Error('FileReader failed to read Blob.'));
-    };
-    reader.readAsArrayBuffer(blob);
-  });
+  const buffer = await readBlobAsArrayBuffer(blob);
+  return new Uint8Array(buffer);
 }
 
 async function payloadToUint8Array(
@@ -117,6 +120,56 @@
   }
 }
 
+type WebShareFileAttempt =
+  | { status: 'shared' }
+  | { status: 'cancelled' }
+  | { status: 'unavailable' | 'unsupported' }
+  | { status: 'error'; error: unknown };
+
+async function tryShareFileViaWebShare(
+  filename: string,
+  blob: Blob,
+  fallbackMimeType?: string
+): Promise<WebShareFileAttempt> {
+  const hasShareApi =
+    typeof navigator !== 'undefined' &&
+    typeof navigator.share === 'function' &&
+    typeof navigator.canShare === 'function' &&
+    typeof File !== 'undefined';
+
+  if (!hasShareApi) {
+    return { status: 'unavailable' };
+  }
+
+  const resolvedMime = blob.type || fallbackMimeType || 'application/octet-stream';
+  const file =
+    blob instanceof File && blob.name === filename
+      ? blob
+      : new File([blob], filename, { type: resolvedMime });
+
+  let canShareFiles = false;
+  try {
+    canShareFiles = navigator.canShare({ files: [file] });
+  } catch {
+    canShareFiles = false;
+  }
+
+  if (!canShareFiles) {
+    return { status: 'unsupported' };
+  }
+
+  try {
+    // Pass only `{ files: [file] }` — iOS Share Sheet rejects or duplicates payloads with extra title/text/url fields
+    await navigator.share({ files: [file] });
+    return { status: 'shared' };
+  } catch (err) {
+    if (isFileShareAbortError(err)) {
+      return { status: 'cancelled' };
+    }
+    return { status: 'error', error: err };
+  }
+}
+
 async function dispatchBlobDownloadAndCleanup(
   filename: string,
   blob: Blob,
@@ -137,6 +190,38 @@
         throw new Error(res.error || `Native export failed for "${filename}".`);
       }
       return;
+    } finally {
+      if (stagedFileName) {
+        unmarkTempOpfsFileActive(stagedFileName);
+        await removeTempOpfsFile(stagedFileName);
+      }
+    }
+  }
+
+  if (isInstalledIosPwa()) {
+    try {
+      const shareResult = await tryShareFileViaWebShare(filename, blob, fallbackMimeType);
+      if (shareResult.status === 'shared' || shareResult.status === 'cancelled') {
+        return;
+      }
+      if (shareResult.status === 'error') {
+        const msg =
+          shareResult.error instanceof Error && shareResult.error.message
+            ? shareResult.error.message
+            : 'Share sheet failed.';
+        logDiagnosticEvent({
+          level: 'error',
+          category: 'storage',
+          message: `iOS standalone PWA file export failed for "${filename}": ${msg}`,
+          error: shareResult.error,
+        });
+        throw new Error(
+          `Could not export "${filename}" from the iOS Home Screen app (${msg}). Try opening in Safari or freeing device storage.`
+        );
+      }
+      throw new Error(
+        `Could not save "${filename}" because iOS Home Screen file sharing is unavailable here. Open this page in Safari to download or share files.`
+      );
     } finally {
       if (stagedFileName) {
         unmarkTempOpfsFileActive(stagedFileName);
@@ -310,8 +395,8 @@
   mimeType: string;
   title: string;
   text?: string;
-}): Promise<'shared' | 'downloaded'> {
-  const { filename, payload, mimeType, title, text } = params;
+}): Promise<FileShareOutcome> {
+  const { filename, payload, mimeType } = params;
   if (pedigreeBridge.isNativeWrapper()) {
     const bytes = await payloadToUint8Array(payload, mimeType);
     const resolvedMime = mimeType || 'application/octet-stream';
@@ -324,21 +409,30 @@
     if (res.ok) {
       return 'shared';
     }
-    await pedigreeBridge.exportOrShareBinary({
+    const saveRes = await pedigreeBridge.exportOrShareBinary({
       filename,
       mimeType: resolvedMime,
       mode: 'save',
       bytes,
     });
+    if (!saveRes.ok) {
+      throw new Error(saveRes.error || `Native export failed for "${filename}".`);
+    }
     return 'downloaded';
   }
 
+  const iosPwa = isInstalledIosPwa();
   const hasShareApi =
     typeof navigator !== 'undefined' &&
     typeof navigator.share === 'function' &&
     typeof navigator.canShare === 'function';
 
   if (!hasShareApi) {
+    if (iosPwa) {
+      throw new Error(
+        `Native file sharing is unavailable in this iOS Home Screen context for "${filename}". Open this page in Safari to save or share files.`
+      );
+    }
     await triggerBlobDownloadWithOpfsScratchpad(filename, payload, mimeType);
     return 'downloaded';
   }
@@ -347,31 +441,44 @@
   let handedOffToDownload = false;
 
   try {
-    const sharePart: BlobPart =
+    const shareBlob =
       staged && typeof Blob !== 'undefined' && staged.blob instanceof Blob
         ? staged.blob
-        : typeof payload === 'string'
-        ? payload
-        : toBlobCompatibleUint8Array(payload);
-    const file = new File([sharePart], filename, { type: mimeType });
-
-    if (navigator.canShare({ files: [file] })) {
-      try {
-        await navigator.share({
-          title,
-          text,
-          files: [file],
-        });
-        return 'shared';
-      } catch {
-        // Share sheet cancelled or unsupported by target — fall back to clean download
-      }
+        : toDirectBlob(payload, mimeType);
+    const shareResult = await tryShareFileViaWebShare(filename, shareBlob, mimeType);
+
+    if (shareResult.status === 'shared') {
+      return 'shared';
+    }
+    if (shareResult.status === 'cancelled') {
+      return 'cancelled';
+    }
+    if (shareResult.status === 'error') {
+      const msg =
+        shareResult.error instanceof Error && shareResult.error.message
+          ? shareResult.error.message
+          : 'Web Share request failed.';
+      logDiagnosticEvent({
+        level: 'warn',
+        category: 'storage',
+        message: `Web Share failed for "${filename}": ${msg}`,
+        error: shareResult.error,
+      });
+      if (iosPwa) {
+        throw new Error(
+          `Could not share "${filename}" from the iOS Home Screen app (${msg}). Open in Safari or try again.`
+        );
+      }
+    } else if (iosPwa) {
+      throw new Error(
+        `This iOS Home Screen app context cannot share "${filename}" directly. Open this page in Safari to download or share.`
+      );
     }
 
     const downloadBlob = staged ? staged.blob : toDirectBlob(payload, mimeType);
     const stagedName = staged ? staged.fileName : null;
     handedOffToDownload = true;
-    await dispatchBlobDownloadAndCleanup(filename, downloadBlob, stagedName);
+    await dispatchBlobDownloadAndCleanup(filename, downloadBlob, stagedName, mimeType);
     return 'downloaded';
   } finally {
     if (staged && !handedOffToDownload) {
@@ -387,7 +494,7 @@
   mimeType: string;
   title: string;
   text?: string;
-}): Promise<'shared' | 'downloaded'> {
+}): Promise<FileShareOutcome> {
   return sharePayloadOrDownload({
     filename: params.filename,
     payload: params.content,
@@ -411,7 +518,7 @@
   mimeType: string;
   title: string;
   text?: string;
-}): Promise<'shared' | 'downloaded'> {
+}): Promise<FileShareOutcome> {
   return sharePayloadOrDownload({
     filename: params.filename,
     payload: params.bytes,
```

### `src/utils/webPdfActions.ts` (`+29` / `-11`, source: `part-16.md`)

```diff
--- working/src/utils/webPdfActions.ts
+++ import/src/utils/webPdfActions.ts
@@ -16,6 +16,7 @@
   PedigreePdfExportParams,
   PdfRasterImage,
 } from '../core/pdfExporter';
+import { enforceCanvasDimensions, releaseCanvas } from '../storage/webImageOptimizer';
 import { downloadBinaryFile } from './webFileActions';
 
 function base64DataUrlToBytes(dataUrl: string): Uint8Array | null {
@@ -50,16 +51,30 @@
   return new Promise<PdfRasterImage | undefined>((resolve) => {
     const img = new Image();
     img.decoding = 'async';
+    const clearImageRef = () => {
+      img.onload = null;
+      img.onerror = null;
+      try {
+        img.src = '';
+      } catch {
+        // Ignore readonly src teardown
+      }
+    };
     img.onload = () => {
       const srcW = img.naturalWidth || img.width || 0;
       const srcH = img.naturalHeight || img.height || 0;
       if (srcW <= 0 || srcH <= 0) {
+        clearImageRef();
         resolve(undefined);
         return;
       }
       const scale = Math.min(1, maxDimension / Math.max(srcW, srcH));
-      const targetW = Math.max(1, Math.round(srcW * scale));
-      const targetH = Math.max(1, Math.round(srcH * scale));
+      const safeDims = enforceCanvasDimensions(
+        Math.max(1, Math.round(srcW * scale)),
+        Math.max(1, Math.round(srcH * scale))
+      );
+      const targetW = safeDims.width;
+      const targetH = safeDims.height;
 
       const canvas = document.createElement('canvas');
       try {
@@ -85,11 +100,14 @@
       } catch {
         resolve(undefined);
       } finally {
-        canvas.width = 0;
-        canvas.height = 0;
+        releaseCanvas(canvas);
+        clearImageRef();
       }
     };
-    img.onerror = () => resolve(undefined);
+    img.onerror = () => {
+      clearImageRef();
+      resolve(undefined);
+    };
     img.src = safeUrl;
   });
 }
@@ -107,12 +125,12 @@
       : params.settings.breederLogoDataUrl
     : undefined;
 
-  const [subjectPhotoJpeg, breederLogoJpeg] = await Promise.all([
-    params.primaryPhotoDataUrl
-      ? rasterDataUrlToPdfJpeg(params.primaryPhotoDataUrl, 420)
-      : Promise.resolve(undefined),
-    rawLogoUrl ? rasterDataUrlToPdfJpeg(rawLogoUrl, 360) : Promise.resolve(undefined),
-  ]);
+  const subjectPhotoJpeg = params.primaryPhotoDataUrl
+    ? await rasterDataUrlToPdfJpeg(params.primaryPhotoDataUrl, 420)
+    : undefined;
+  const breederLogoJpeg = rawLogoUrl
+    ? await rasterDataUrlToPdfJpeg(rawLogoUrl, 360)
+    : undefined;
 
   const pdfBytes = buildPedigreePdfBytes({
     subject: params.subject,
```

### `tsconfig.json` (`+1` / `-1`, source: `part-01_dfb892d4.md`)

```diff
--- working/tsconfig.json
+++ import/tsconfig.json
@@ -25,5 +25,5 @@
     "allowImportingTsExtensions": true,
     "noEmit": true
   },
-  "exclude": ["dist", "import"]
+  "exclude": ["dist"]
 }
```

### `vite.config.ts` (`+1` / `-45`, source: `part-01_dfb892d4.md`)

```diff
--- working/vite.config.ts
+++ import/vite.config.ts
@@ -4,7 +4,7 @@
 import path from 'path';
 import { defineConfig, type Plugin } from 'vite';
 import { VitePWA } from 'vite-plugin-pwa';
-import { buildPromptsCatalogManifest } from './src/core/promptsCatalog.ts';
+import { buildPromptsCatalogManifest } from './src/core/promptsCatalog';
 
 async function scanPromptsFolderOnDisk(rootDir: string) {
   const promptsDir = path.resolve(rootDir, 'prompts');
@@ -103,45 +103,6 @@
   };
 }
 
-function importFolderGuardPlugin(): Plugin {
-  const importRoot = path.resolve(import.meta.dirname, 'import') + path.sep;
-  return {
-    name: 'import-folder-isolation-guard',
-    resolveId(source, importer) {
-      if (
-        source.startsWith('/import/') ||
-        source === '/import' ||
-        source.startsWith('@/import/')
-      ) {
-        throw new Error(
-          `Blocked import from protected /import/ folder ("${source}"). Reading is allowed, but executing or bundling /import/ requires explicit confirmation.`
-        );
-      }
-      if (importer && source.startsWith('.')) {
-        const resolved = path.resolve(path.dirname(importer), source);
-        if (resolved.startsWith(importRoot)) {
-          throw new Error(
-            `Blocked import from protected /import/ folder ("${source}"). Reading is allowed, but executing or bundling /import/ requires explicit confirmation.`
-          );
-        }
-      }
-      return null;
-    },
-    configureServer(server) {
-      server.middlewares.use((req, res, next) => {
-        const url = req.url?.split('?')[0] || '';
-        if (url === '/import' || url.startsWith('/import/')) {
-          res.statusCode = 403;
-          res.setHeader('Content-Type', 'text/plain; charset=utf-8');
-          res.end('Forbidden: /import/ is read-only and cannot be served or executed without confirmation.');
-          return;
-        }
-        next();
-      });
-    },
-  };
-}
-
 export default defineConfig(() => {
   // Hardcoded '/' keeps AI Studio from prompting for VITE_BASE_PATH (IMP-008).
   // GitHub Pages subpath builds run via Bun in .github/workflows/deploy-pages.yml passing `--base=...` on CLI.
@@ -152,7 +113,6 @@
     plugins: [
       react(),
       tailwindcss(),
-      importFolderGuardPlugin(),
       devServiceWorkerCleanupPlugin(),
       promptsDirectoryPlugin(),
       VitePWA({
@@ -229,7 +189,6 @@
       },
     },
     optimizeDeps: {
-      entries: ['index.html'],
       include: [
         'react',
         'react-dom',
@@ -250,9 +209,6 @@
       host: '0.0.0.0',
       port: 3000,
       allowedHosts: true as const,
-      fs: {
-        deny: ['.env', '.env.*', '*.{crt,pem}', '**/.git/**', 'import', 'import/**'],
-      },
       // HMR, WebSocket server, and file watching are hardcoded disabled to prevent preview flickering,
       // mobile iframe reload loops, and AI Studio env-var prompts (production/Pages builds are unaffected).
       hmr: false,
```
