# Implementation Plan: Audit & Reduce Eager/Resident JS Heap Weight (2,000+ Animals)

**Status:** Archived (Phase 3 of `docs/archive/import-implementation-plan.md` Verified)  
**Last Audited:** 2026-11-22

## Hard Exclusions (Must Preserve)
- **NO Firebase / Cloud Auth SDKs:** Working intentionally removed `firebase/app` and `firebase/auth` from `package.json` and `src/utils/googleCalendarClient.ts`. **NEVER** re-add `firebase/*` imports (reject `/import/src/utils/googleCalendarClient.ts`). Keep offline `.ICS` calendar export intact.
- NO server-side storage of user information, NO marketplace, NO new encryption changes (`encryptedExport.ts` / `passphraseCrypto.ts` untouched).
- NO PDF layout redesign (`barnBinder.ts` / `pdfExporter.ts` / `PrintPreviewModal.tsx` layout untouched).
- Strict TypeScript (`tsc --noEmit`, zero `as any` / `@ts-ignore` / `@ts-expect-error`) and pure zero-DOM `src/core/`.
- Keep all `IMPROVEMENTS.md` / `src/core/improvementRegistry.ts` (`IMP-001`..`IMP-048`+) invariants intact.

## Revised Audit Findings (Working Tree Baseline)
1. **Initial Entry Chunk (`dist/assets/index-*.js` ~1,404 kB in working; `/import/` was incomplete):**
   - `src/hooks/useBarnStore.ts` statically imports `offThreadWorkerClient.ts`, which statically imports `backupArchive.ts` (`fflate`), `archiveInspector.ts`, `supportBundle.ts`, and `importers/registry.ts` — convert fallback paths to `import type` + dynamic `import()` inside fallback handlers.
   - Vite currently warns on `src/storage/opfsStorage.ts` (`[INEFFECTIVE_DYNAMIC_IMPORT]`) because both static and dynamic imports exist; clean up dynamic/static boundary if needed without breaking worker isolation.
   - `src/App.tsx` statically imports `WipedStorageRecoveryModal`. Lazy-loading it is safe **only** when wrapped in `<RouteErrorBoundary>` + visible fallback UI (reject `/import/`'s `<Suspense fallback={null}>` which causes a silent blank failure on the blocking storage-recovery gate).
   - `src/components/HerdScreen.tsx` statically imports `AnimalEditorModal`, `PrintPreviewModal`, `SpeciesMigrationModal`, and `ArchivedHerdsModal` — lazy-load these modals behind error boundaries + suspense fallbacks.
2. **Eager/Resident Heap & Per-Render Work (`useBarnStore.ts`, `webSqliteAdapter.ts`, `HerdScreen.tsx`):**
   - `useBarnStore.ts`: Scope `coiByAnimalId` lazily to active subject/visible rows, evict `pedigreeAncestorCacheRef` / `loadedPedigreeArchiveKeysRef` on `selectSpeciesWorkspace` and `onHidden`, and replace linear `nextEntityRev` scan with an O(1) `maxRevByEntityRef`.
   - `useBarnStore.ts`: When skipping heavy derivations on `NON_SPECIES_ROUTES`, verify `HomeSpeciesScreen` species alerts / cage over-capacity indicators and backup exports (`ImportExportHubScreen` / `SettingsAndSyncScreen`) still receive required counts and data.
   - `webSqliteAdapter.ts`: Extend `loadSnapshotUnlocked({ lightweightPhotos: true })` to strip full-res `feed_batches.tag_photo_data_url` and `ledger_entries.receipt_photo_data_url` from resident heap alongside on-demand photo fetchers.
   - `HerdScreen.tsx`: Compute `carrierAnalysisById` on visible rows + `activeAnimal` when no carrier filter/query is active, and constrain `herdVirtual` `overscan` / `initialFallbackCount` on low-memory devices while preserving `export const HERD_PAGE_SIZE = 50`.
3. **Dropdown Virtualization (`SearchableParentPicker.tsx`):**
   - **Already Virtualized in Working:** Working `src/components/SearchableParentPicker.tsx` already uses `useVirtualWindow` with fixed `OPTION_ROW_ESTIMATE_PX = 36` (avoiding `/import/`'s `measureRowRef` layout-measurement churn). Keep working's fixed-height virtualization; optionally tighten candidate string filtering if profiling shows allocation pressure.

## Progress Checklist
- [x] Step 1: Audit `useBarnStore.ts`, `App.tsx`, `HerdScreen.tsx`, `SearchableParentPicker.tsx`, `googleCalendarClient.ts`, and `/import/` diffs.
- [x] Step 2: Lazy fallback imports in `offThreadWorkerClient.ts`, lazy `WipedStorageRecoveryModal` (with `<RouteErrorBoundary>` + fallback UI) in `App.tsx`, lazy heavy modals in `HerdScreen.tsx`. *(Skipped `googleCalendarClient.ts` — already Firebase-free.)*
- [x] Step 3: Trim resident heap (`useBarnStore.ts` scoped `coiByAnimalId`, safe non-species route scoping, cache eviction, O(1) `maxRevByEntityRef`; `webSqliteAdapter.ts` lightweight feed/receipt photo loading + on-demand fetchers).
- [x] Step 4: Constrain `HerdScreen.tsx` carrier analysis & low-memory virtual window; verified `SearchableParentPicker.tsx` keeps fixed-height virtualization cleanly.
- [x] Step 5: Verified lazy/virtualization/lightweight-load unit tests pass and preserved `IMPROVEMENTS.md` / `src/core/improvementRegistry.ts` (`48/48`).
- [x] Step 6: Passed `npm run verify:improvements && npm run lint && npm test && npm run build`, marked Complete in `docs/plans/active-backlog-plan.md`.
