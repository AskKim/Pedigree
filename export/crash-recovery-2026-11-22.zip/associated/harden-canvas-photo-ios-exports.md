# Implementation Plan: Harden Canvas Dimensions, Photo Cleanup & iOS Standalone PWA Exports

**Status:** Archived (Phase 1 Verified & Integrated)  
**Last Audited:** 2026-11-22 (Phase 1 implemented and verified)

> **Audit Note (2026-11-22):** Reconciled and verified in Phase 1 of `docs/archive/import-implementation-plan.md`.

## Hard Exclusions (Must Preserve)
- NO server-side storage of user information.
- NO community sales board or marketplace features.
- NO new encryption features (`src/core/encryptedExport.ts` / `src/storage/passphraseCrypto.ts` untouched).
- NO PDF layout redesign (`src/core/barnBinder.ts` / PDF layout geometry untouched).
- **Preserve Working `IMP-047` Print/Share Fixes:** When updating `src/components/PrintPreviewModal.tsx`, keep `canShareHtmlDocument`, `extractScopedPrintCssFromRules`, `detectDocumentPrintOrientation`, `PrintBridge.kt` forwarding, and **do NOT** reintroduce `PedigreePrintNotice.tsx`.
- Strict TypeScript (`tsc --noEmit`, zero `as any` / `@ts-ignore` / `@ts-expect-error`).
- Keep `src/core/` 100% pure TypeScript with zero DOM/`window` dependencies.

## Progress Checklist
- [x] Step 1: Audit `webImageOptimizer.ts`, `photoHydration.ts`, `imageOptimizationSpec.ts`, `AnimalPhotoGallery.tsx`, `webFileActions.ts`, `PrintPreviewModal.tsx`, and `/import/` diffs.
- [x] Step 2: Port pure canvas area ceiling (`16_000_000` px / `3_000_000` px constrained), DPR cap (`Math.min(2, dpr)` / `1` constrained), and 4-arg `computeScaledDimensions` into `src/core/imageOptimizationSpec.ts` (unblocking `src/core/__tests__/imageOptimizationSpec.test.ts`).
- [x] Step 3: Harden `src/storage/webImageOptimizer.ts` (and canvas callers `feedTagOcr.ts`, `pedigreeOcrScanner.ts`, `deviceCapabilityDetector.ts`) with `probeOffscreenCanvas2dSupport()` + main-thread fallback, `releaseCanvas` in `finally` blocks (`1x1` clearRect then `width = 0; height = 0`), area ceiling enforcement, and sequential photo compression.
- [x] Step 4: Harden `src/storage/photoHydration.ts` and `src/components/AnimalPhotoGallery.tsx` with sequential photo hydration (`CONSTRAINED_PHOTO_HYDRATION_BATCH_SIZE = 4`), `blob:` URL revocation on replacement/trim/delete/animal-switch/unmount, guard against rapid animal-switch/lightbox unmount races, and visible error surfacing.
- [x] Step 5: Harden `src/utils/webFileActions.ts`, `src/utils/webPdfActions.ts`, `src/storage/localSyncChannels.ts`, `src/components/PrintPreviewModal.tsx` (merging iOS copy/`mailto:`/share without regressing `IMP-047`), `CrashErrorBoundary.tsx`, `DiagnosticsAndSupportPanel.tsx`, and `ImportExportHubScreen.tsx` for installed iOS/iPadOS PWA (`navigator.canShare({ files: [file] })` + `navigator.share({ files: [file] })`, clean `'cancelled'` on `AbortError`, delayed fallback `blob:` revocation).
- [x] Step 6: Run `npm run verify:improvements && npm run lint && npm test && npm run build`.
