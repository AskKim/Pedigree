# Unlogged Prompts & Undocumented Changes Found in `/import/`

> **STABILITY & CURRENT BASELINE WARNING (Updated 2026-11-22):**
> The prompts reconstructed below represent substantial bodies of work present in `/import/` (`AskKim/Pedigree` @ `847f8ec8`) that were **not** logged in `IMPROVEMENTS.md` / `src/core/improvementRegistry.ts` (`IMP-xxx`) and are **not** on `docs/plans/suggestions-backlog.md`.
>
> **Current Repo State:** Standalone new files from `/import/` (`ClientCrmScreen.tsx`, `WoolHarvestPanel.tsx`, `BarnSchedulerGantt.tsx`, `FounderAndHeritabilityPanel.tsx`, `storageProbes.ts`, `p2pSyncProtocol.ts`, plus unit tests `imageOptimizationSpec.test.ts` and `restrictedBrowserAndBfcache.test.ts`) are **already on disk in `src/`**, leaving `npm run lint` (`tsc --noEmit`) with **109 errors** and `npm test` with **5 failing suites** until core/storage/store contracts are reconciled. Follow the phased recovery sequence in **`docs/plans/active-backlog-plan.md`**—do **not** copy `/import/` files blindly over working files.

---

## Relationship to Tracked `IMP-xxx` Entries

- `IMP-001` through `IMP-046` match between the working tree and `/import/`.
- `IMP-047` & `IMP-048` diverged into two incompatible tracks and **must be renumbered when porting**:
  - **Working `IMP-047` (KEEP):** Post-Crash Alignment, Ready External Exporters (`herdboss-transfer-bundle`, `registry-worksheet-csv`), Feed/Archive Parity, and Android WebView Print/Share (`PrintBridge.kt`, `PrintPreviewModal.tsx`).
  - **Working `IMP-048` (KEEP):** Hybrid Architecture Guardrails & React-Only Core PWA Lock.
  - **Import `IMP-047` -> Port as `IMP-049`:** Client CRM, Buyer Waitlist, Reservations & Deposit Reminders (`ClientCrmScreen.tsx`, `clientCrm.ts`, SQLite v5).
  - **Import `IMP-048` -> Port as `IMP-050`:** Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking (`alternativeCertificates.ts`, `showDocuments.ts`, `woolFiber.ts`, `WoolHarvestPanel.tsx`, SQLite v6).
- **All items below (Prompts U-1 through U-6)** sit *outside* the `IMP` registry entirely.

---

## Prompt U-1: Restricted-Browser / Lockdown Mode Storage Probes & Active Handle Tracking

- **Tracking Status:** Unlogged (no `IMP-` entry, no plan doc).
- **Primary Files Touched in `/import/`:**
  - Consumes `src/storage/storageProbes.ts` across `capturedIdeasStore.ts`, `crashLogger.ts`, `deviceCapabilityDetector.ts`, `localSyncChannels.ts`, `opfsTempStream.ts`, `pwaUpdateManager.ts`, `storageProtection.ts`, `webSqliteAdapter.ts`.
  - Supporting tests in `src/storage/__tests__/es2018AndPwaUpdate.test.ts` and `src/storage/__tests__/restrictedBrowserAndBfcache.test.ts`.
- **What the Prompt Implemented:**
  - Replaced direct globals (`indexedDB`, `localStorage`, `navigator.storage`, `navigator.locks`, `BroadcastChannel`) with guarded probe helpers (`getSafeIndexedDb`, `getSafeLocalStorage`, `getSafeStorageManager`, `getSafeWebLocks`, `getSafeBroadcastChannelCtor`).
  - Wired active resource trackers (`trackActiveIdbConnection`, `trackActiveIdbTransaction`, `trackBroadcastChannel`, `registerPendingWebLockAbort`) so transactions, channels, and pending Web Locks can be aborted cleanly when permissions are restricted or the page enters bfcache/background.
- **Potential Instability Risks in `/import/` Implementation:**
  - Cross-cutting refactor touching almost every storage entry point; subtle error-swallowing or missed `untrack*()` calls on early returns/aborts can stall subsequent locks or drop persistence writes silently.
  - Needs careful per-module verification against `restrictedBrowserAndBfcache.test.ts` and `crossTabLockAndReload.test.ts`.

---

## Prompt U-2: OPFS Handle Compatibility (Safari/WebKit) & Background Freeze Resource Release

- **Tracking Status:** Unlogged (no `IMP-` entry, no plan doc).
- **Primary Files Touched in `/import/`:**
  - `src/storage/opfsTempStream.ts` (`+266 / -27`)
  - `src/storage/opfsStorage.ts` (`+80 / -26`)
  - `src/storage/backgroundFreezeCoordinator.ts` (`+86 / -11`)
  - `src/storage/localSyncChannels.ts`
- **What the Prompt Implemented:**
  - Added Safari 15.2–16.3 vs. Chromium compatibility shims (`safeAwaitOpfsClose`, `safeAwaitOpfsFlush`, `safeAwaitOpfsGetSize`, `safeAwaitOpfsTruncate`) handling both sync and Promise-returning `FileSystemSyncAccessHandle` / `WritableStream` methods with `WeakSet` double-close protection.
  - Added `probeOpfsRuntime()`, `activeOpfsHandles`, and `releaseActiveOpfsHandles()`.
  - Extended `backgroundFreezeCoordinator.ts` with `onReleaseResources(reason: 'hidden' | 'pagehide')` to automatically release OPFS handles and registered listeners when the tab hides or unloads.
- **Potential Instability Risks in `/import/` Implementation:**
  - Force-closing OPFS handles on `hidden` can race with active ZIP/backup writes or folder sync streams if mobile browsers briefly background the PWA (e.g., while opening the native share sheet or file picker), causing transient write failures or half-cleaned handles unless pause/resume checkpoints guard every step.

---

## Prompt U-3: Harden Canvas Dimensions, Sequential Photo Cleanup & iOS Standalone PWA Exports

- **Tracking Status:** Documented in `docs/plans/harden-canvas-photo-ios-exports.md` (marked *Complete* 2026-11-21), **never registered as an `IMP-` entry**.
- **Primary Files Touched in `/import/`:**
  - `src/core/imageOptimizationSpec.ts` (`+80 / -13`)
  - `src/storage/webImageOptimizer.ts` (`+229 / -38`)
  - `src/storage/photoHydration.ts` (`+37 / -2`)
  - `src/components/AnimalPhotoGallery.tsx` (`+105 / -23`)
  - `src/utils/webFileActions.ts` (`+148 / -41`), `src/utils/webPdfActions.ts` (`+29 / -11`)
  - `src/storage/feedTagOcr.ts`, `src/storage/pedigreeOcrScanner.ts`, `src/storage/deviceCapabilityDetector.ts`
  - `src/components/PrintPreviewModal.tsx`, `src/components/CrashErrorBoundary.tsx`, `src/components/DiagnosticsAndSupportPanel.tsx`, `src/components/ImportExportHubScreen.tsx`
- **What the Prompt Implemented:**
  - Enforced canvas backing-store area ceilings (`16,000,000` px normal / `3,000,000` px constrained) and DPR caps (`<= 2` / `1` constrained) plus `probeOffscreenCanvas2dSupport()` with main-thread fallback and `releaseCanvas()` in `finally` blocks.
  - Made photo hydration sequential (`CONSTRAINED_PHOTO_HYDRATION_BATCH_SIZE = 4`) and added `revokeBlobUrlIfNeeded()` across gallery mount/switch/delete/unmount.
  - Reworked `webFileActions.ts` for iOS Standalone PWA (`navigator.canShare({ files })` + `navigator.share({ files })` without extra fields, explicit `'cancelled'` handling on `AbortError`, delayed `blob:` revocation on fallback downloads).
- **Potential Instability Risks in `/import/` Implementation:**
  - Sequential `hydrationQueueRef` + immediate `img.src = ''` / `revokeBlobUrlIfNeeded()` in `AnimalPhotoGallery.tsx` can break lightbox previews if rapid animal switching or batch hydration interleaves.
  - In `/import/`, `PrintPreviewModal.tsx` also reverted Android WebView `NativePrintOptions` (`htmlContent` / `orientation`) and re-introduced `PedigreePrintNotice.tsx`—working's `IMP-047` fixes must be kept intact when porting the iOS share improvements.

---

## Prompt U-4: Audit & Reduce Eager / Resident JS Heap Weight (2,000+ Animals)

- **Tracking Status:** Partially documented in `docs/plans/reduce-eager-heap-weight.md` (marked *In Progress* 2026-11-21), **never registered as an `IMP-` entry**.
- **Primary Files Touched in `/import/`:**
  - `src/utils/googleCalendarClient.ts` (`+82 / -67`) — switched static `firebase/app` + `firebase/auth` imports to lazy `async getFirebaseAuthSafe()`.
  - `src/storage/offThreadWorkerClient.ts` (`+15 / -13`) — converted static importer/archive imports to `import type` + dynamic `import()` inside fallbacks.
  - `src/App.tsx` & `src/components/HerdScreen.tsx` — lazy-loaded `WipedStorageRecoveryModal`, `AnimalEditorModal`, `ArchivedHerdsModal`, `PrintPreviewModal`, `SpeciesMigrationModal`.
  - `src/hooks/useBarnStore.ts` — scoped `baseSpeciesData`, `conflictsBySpeciesAnimalId`, and `coiByAnimalId` off non-species routes, added O(1) `maxRevByEntityRef`, and cleared `pedigreeAncestorCacheRef` on hide/species switch.
  - `src/storage/webSqliteAdapter.ts` — extended `lightweightPhotos: true` stripping to feed tag photos & receipt photos plus on-demand fetchers.
  - `src/components/SearchableParentPicker.tsx` — virtualized dropdown options using `useVirtualWindow` (`measureRowRef` + `resetKey`).
- **Potential Instability Risks in `/import/` Implementation:**
  - **CRITICAL Boot Blocker (`googleCalendarClient.ts`):** Working `package.json` intentionally removed `firebase` for zero-cloud/zero-SDK operation; `/import/src/utils/googleCalendarClient.ts` tries to import `firebase/app` & `firebase/auth`, which fails to resolve/build cleanly. **Reject `/import/`'s Firebase restoration.**
  - **Recovery Modal Chunk Failure (`App.tsx`):** `/import/` wraps lazy `WipedStorageRecoveryModal` in bare `<Suspense fallback={null}>` without a `<RouteErrorBoundary>`, leaving users stranded on a blank screen if chunk loading fails offline. Always wrap lazy recovery modals in `<RouteErrorBoundary>` + visible fallback.
  - Because `reduce-eager-heap-weight.md` is still **In Progress**, `/import/` may hold half-finished lazy boundaries or route-scoping regressions (`HomeSpeciesScreen` alerts or backup export completeness on non-species routes).
  - Note: Working already received a cleaner virtualization pass in `SearchableParentPicker.tsx` (fixed-height estimate without `measureRowRef` churn); keep/compare carefully before touching it.

---

## Prompt U-5: ES2018 Compatibility Shims & Restricted `FileReader` Fallbacks

- **Tracking Status:** Unlogged (no `IMP-` entry, no plan doc).
- **Primary Files Touched in `/import/`:**
  - `src/utils/es2018Shims.ts` (`+100 / -74`)
  - `src/storage/__tests__/es2018AndPwaUpdate.test.ts` (`+50 / -1`)
- **What the Prompt Implemented:**
  - Added `isFileReaderSupported()` probe before calling `FileReader` in restricted/lockdown WebViews.
  - Added `Response`-based binary/text fallback when `FileReader` throws `SecurityError` and refined non-enumerable `Blob.prototype.arrayBuffer`/`text` & `String.prototype.trimStart`/`trimEnd` shims.
- **Potential Instability Risks in `/import/` Implementation:**
  - Prototype polyfills and `Response(blob)` wrapping can behave inconsistently across mocked Blobs, Safari Blob slices, and Worker contexts; `/import/src/utils/es2018Shims.ts` also uses `(this as any)` which must be fixed to strict TS when porting.

---

## Prompt U-6: Unscoped Regression / Hygiene Differences to Reject During Recovery

- **Observed Regressions in `/import/` (Do NOT Port):**
  - `src/utils/googleCalendarClient.ts` re-introduces `firebase/app` & `firebase/auth` despite `firebase` being absent from `package.json`.
  - `src/components/ExternalImporterPanel.tsx` uses `catch (err: any)` and `src/utils/es2018Shims.ts` uses `(this as any)` (violates strict TypeScript rules in `master_system_prompt.md`).
  - `package.json`, `public/version.json`, and `src/core/upgradeGate.ts` downgrade `0.1.0-alpha.2` -> `0.1.0-prealpha.1`.
  - `src/core/exporters/registry.ts` & `exporterTypes.ts` revert ready `herdboss-transfer-bundle` and `registry-worksheet-csv` (`binaryContent`) exporters to unimplemented stubs.
  - `android-wrapper/.../PrintBridge.kt`, `MainActivity.kt`, `src/native/pedigreeBridge.ts`, and `PrintPreviewModal.tsx` drop offscreen HTML / orientation print support from working `IMP-047` and re-add `PedigreePrintNotice.tsx`.
  - `vite.config.ts`, `tsconfig.json`, `AGENTS.md`, `prompts/master_system_prompt.md`, and `vitest.config.ts` in `/import/` drop `/import/` isolation and React-only PWA lock guards.

---

## Side Note: GitHub Workflows Verification Required Before Final Release

- GitHub Actions workflow updates (specifically `.github/workflows/build-android-apk.yml` for APK generation) are currently **half-finished / incomplete** on GitHub.
- As part of final testing (after code recovery stabilizes), **audit and verify all workflows** under `.github/workflows/` (`build-android-apk.yml`, `ci.yml`, `deploy-pages.yml`, `export_repo_to_md.yml`, `unzip.yml`) before treating any build or release pipeline as green.
