# Master Import Implementation Plan: Boot-Safe Reconciliation of `/import/` (`AskKim/Pedigree` @ `847f8ec8`)

**Status:** Archived (Phases 0–5 Complete)  
**Last Reviewed:** 2026-11-22  
**Consolidated Child Plans:** `docs/archive/harden-canvas-photo-ios-exports.md`, `docs/archive/reduce-eager-heap-weight.md`, `docs/archive/unlogged-import-prompts.md`  
**Completion Policy:** Applies **strictly to this Master Import Implementation Plan and all associated/temporary files** (later plans created for `docs/plans/suggestions-backlog.md` items must still follow the standard delete-on-completion rule in `prompts/start_new_backlog_prompt.md` and `prompts/resume_backlog_plan_prompt.md`). Upon completion of Phase 5, **do NOT delete** this plan or any temporary/associated files—retain everything for post-wrap-up deep review. Specifically: mark as `Status: Archived` and move into `docs/archive/` all plan/diff/audit docs (`docs/archive/import-implementation-plan.md`, `docs/archive/import-working-diff.md`, `docs/archive/harden-canvas-photo-ios-exports.md`, `docs/archive/reduce-eager-heap-weight.md`, `docs/archive/unlogged-import-prompts.md`, plus any temporary Phase 5 verification artifacts), keep `/import/` intact on disk, and update `IMPROVEMENTS.md` / `src/core/improvementRegistry.ts` file references if needed so `docs/plans/` is clear for future backlog plans.

---

## Progress Checklist
- [x] Step 0: Read & Digest `prompts/master_system_prompt.md`, `docs/import-working-diff.md`, `docs/unlogged-import-prompts.md`, and audit working baseline checks
- [x] Phase 0: Baseline Hygiene, Build/Isolation Lock & Restore Green `lint` + `test` Gate (20 `BarnTask.startDateIso` TS errors resolved; `barnScheduler.test.ts` + `p2pSyncProtocol.test.ts` green; 88 TS errors / 4 failing test suites queued cleanly across Phases 1, 2, 4)
- [x] Phase 1: ES2018 Shims, Canvas Area/DPR Ceilings, Photo Hydration Hygiene & iOS Export Cascade (U-5 + U-3, keeping `IMP-047`; 82 Phase 2/4 TS errors & 3 Phase 2/4 test suites remaining)
- [x] Phase 2: Restricted-Browser Storage Probes, Safari OPFS & Write-Safe bfcache Lifecycle (U-1 + U-2 — 0 Phase 2 TS errors; all `src/storage/` & `stageBResilience` suites green; 72 Phase 4 TS errors & 2 Phase 4 test suites remaining)
- [x] Phase 3: Safe Heap Weight Reduction, Worker Fallbacks & Lazy Boundaries (U-4 — NO Firebase)
- [x] Phase 4: SQLite v4→v6 Migration & Wire Import `IMP-049` (Client CRM) + `IMP-050` (Alt Certs, Show Docs & IAGARB Wool)
- [x] Phase 5: Resolve Orphaned Features (`IMP-051`: Gantt / Founder / P2P), Audit GitHub Workflows & Final Production Boot Recheck

---

## 1. Audited Repo Baseline (Verified Before Any Code Edits)

Do **not** treat `npm run build` passing as proof of health—Vite strips TypeScript types and tree-shakes unimported files:
- **`npm run verify:improvements`:** PASS (`48/48` improvements across `122` files).
- **`npm run build`:** PASS (`vite build` produces `dist/` + `dist/sw.js`), with an existing `[INEFFECTIVE_DYNAMIC_IMPORT]` warning on `src/storage/opfsStorage.ts`.
- **`npm run lint` (`tsc --noEmit`):** **FAIL (108 initial -> 88 remaining after Phase 0.2 across 8 files)** because orphaned new files from `/import/` already sit on disk while matching edits in `src/core/models.ts`, `src/core/imageOptimizationSpec.ts`, `src/storage/backgroundFreezeCoordinator.ts`, `src/storage/opfsTempStream.ts`, and `src/storage/webSqliteAdapter.ts` are **not** yet applied:
  - ~~Missing `BarnTask.startDateIso` in `src/core/barnScheduler.ts`, `src/components/BarnSchedulerGantt.tsx`, `src/core/__tests__/barnScheduler.test.ts`, `src/core/__tests__/p2pSyncProtocol.test.ts`~~ *(resolved in Phase 0.2 via `models.ts` + `inputSanitization.ts`)*.
  - Missing CRM exports/fields on `src/core/models.ts` for `src/core/clientCrm.ts` (10), `src/components/ClientCrmScreen.tsx` (49), `src/core/__tests__/clientCrm.test.ts` (3) -> Phase 4.
  - Missing wool exports on `src/core/models.ts` for `src/core/woolFiber.ts` (3), `src/components/WoolHarvestPanel.tsx` (6), `src/core/__tests__/woolFiber.test.ts` (1) -> Phase 4.
  - Missing canvas ceiling/DPR exports on `src/core/imageOptimizationSpec.ts` for `src/core/__tests__/imageOptimizationSpec.test.ts` (6) -> Phase 1.
  - Missing bfcache/OPFS/ephemeral exports on `src/storage/` for `src/storage/__tests__/restrictedBrowserAndBfcache.test.ts` (10) -> Phase 2.
- **`npm test` (`vitest run`):** **FAIL (5 initial -> 4 remaining test files / 11 tests failing)** out of 68 test files / 408 tests (`p2pSyncProtocol.test.ts` now PASS):
  - `src/core/__tests__/imageOptimizationSpec.test.ts` (4) -> Phase 1
  - `src/storage/__tests__/restrictedBrowserAndBfcache.test.ts` (5) -> Phase 2
  - `src/core/__tests__/clientCrm.test.ts` (1) -> Phase 4
  - `src/core/__tests__/woolFiber.test.ts` (1) -> Phase 4

---

## 2. Non-Negotiable Bootability & Regression Guardrails

### Architectural & Environment Locks
1. **React-Only Core PWA Lock (`IMP-048` / `AGENTS.md` / `prompts/master_system_prompt.md`):**
   - `/src/`, `index.html`, `vite.config.ts`, and `package.json` MUST remain a **React + Vite + TypeScript PWA** targeting ES2018 (`chrome68`, `safari12`, `firefox63`, `edge79`, `hmr: false`, `ws: false`, `watch: null`, `devOptions.enabled: false`, `basePath = '/'`).
   - `/android-wrapper/` is strictly a thin Kotlin WebView shell serving `dist/`. Never convert any PWA code to Kotlin.
2. **`/import/` Folder Isolation (MUST NOT Drop From Configs):**
   - `/import/` overwrote these protections upstream; **keep working's versions**:
     - `vite.config.ts`: `importFolderGuardPlugin()` and `server.fs.deny` including `'import', 'import/**'`.
     - `tsconfig.json`: `"exclude": ["dist", "import"]`.
     - `vitest.config.ts`: preserve file and `exclude: [...configDefaults.exclude, 'import/**', 'android-wrapper/**']`.
     - `AGENTS.md`, `.github/structure.txt`, `scripts/verify-improvements.ts`, and `prompts/*`: keep untouched/intact.
3. **Reject Firebase Auth / Missing Dependency Restoration (Boot Blocker):**
   - `/import/src/utils/googleCalendarClient.ts` dynamically imports `firebase/app` and `firebase/auth`, and `docs/plans/reduce-eager-heap-weight.md` originally instructed lazy-loading Firebase Auth.
   - **`firebase` is NOT in `package.json`** and was intentionally removed in working (`googleCalendarClient.ts` uses offline `.ICS` fallback). Restoring Firebase imports breaks builds/runtime and violates zero-cloud guardrails. Keep working `src/utils/googleCalendarClient.ts`.
4. **Reject `/import/` Regressions Against Working `IMP-047` & `IMP-048`:**
   - **Versions:** Keep `0.1.0-alpha.2` in `package.json`, `public/version.json`, and `src/core/upgradeGate.ts` (do NOT downgrade to `0.1.0-prealpha.1` or overwrite `public/version.json` blindly).
   - **Exporters:** Preserve `binaryContent` in `src/core/exporters/exporterTypes.ts` and ready implementations of `herdboss-transfer-bundle` (`.ZIP`) and `registry-worksheet-csv` (`.CSV`) in `src/core/exporters/registry.ts` + dispatch in `ImportExportHubScreen.tsx`.
   - **Android & Web Print/Share:** Keep `PrintBridge.kt` (`printFromBridge`, `printHtmlDocument`, `buildPrintAttributes`), `MainActivity.kt` bridge hookup, `src/native/pedigreeBridge.ts` (`NativePrintOptions`), and `PrintPreviewModal.tsx` (`canShareHtmlDocument`, `extractScopedPrintCssFromRules`, `detectDocumentPrintOrientation`). Do **not** recreate `src/components/PedigreePrintNotice.tsx`.
   - **Strict TypeScript:** Fix `/import/`'s `catch (err: any)` in `src/components/ExternalImporterPanel.tsx` -> `err: unknown` and `(this as any)` in `src/utils/es2018Shims.ts` -> typed descriptor/interface access. Zero `as any`, `@ts-ignore`, or `@ts-expect-error`.
   - **Species Migration & Archive Inspector:** Keep `feedBatchesMigrated` / `feedAllocationsMigrated` in `speciesMigration.ts` and v3/v4/v5/v6 record counts in `archiveInspector.ts`.
5. **Renumber `IMP-xxx` Cleanly (No Collisions):**
   - Working already owns `IMP-047` (Post-Crash Alignment / Exporters / Print) and `IMP-048` (Hybrid React-Only PWA Lock).
   - Register incoming features cleanly after `IMP-048` in **both** `IMPROVEMENTS.md` and `src/core/improvementRegistry.ts`:
     - **`IMP-049`:** Client CRM, Buyer Waitlist, Reservations & Deposit Reminders (`/import/`'s old `IMP-047`).
     - **`IMP-050`:** Alternative Certificates, Show Entry/Remark Cards & IAGARB Wool/Fiber Tracking (`/import/`'s old `IMP-048`).
     - **`IMP-051` (if wired in Phase 5):** Founder Loss / Heritability Analytics, Interactive Barn Scheduler Gantt & P2P LAN Outbox Sync.
6. **Runtime Safety Constraints (Do Not Blindly Port `/import/` Bugs):**
   - **`src/core/` Purity:** Zero DOM (`window`, `document`, `fetch`, `OffscreenCanvas`) or React imports in `src/core/`.
   - **Lazy `WipedStorageRecoveryModal` (`src/App.tsx`):** Wrap lazy-loaded `WipedStorageRecoveryModal` in `<RouteErrorBoundary>` + visible fallback (never `<Suspense fallback={null}>`, which strands the blocking recovery modal if a chunk fails offline).
   - **Active-Work Lock Before Background Resource Release:** When adding `backgroundFreezeCoordinator.ts` `onReleaseResources('hidden')`, abort/close idle IDB/OPFS handles only when **no active write, export ZIP stream, share-sheet handoff, or `<input type="file">` picker** is checked out (or await bounded flush first) so mobile OS pickers/share sheets do not corrupt saves.
   - **SQLite `v4 -> v6` Upgrade Safety:** Wrap `webSqliteAdapter.ts` schema migrations (`client_contacts`, `waitlist_entries`, `animal_reservations`, `wool_harvests`) in atomic `try/catch` with `CREATE TABLE IF NOT EXISTS` / idempotent `ALTER TABLE` and OPFS raw-dump rescue before reset; verify `public/version.json` (`schemaVersion: 6`, `minDirectUpgradeSchema: 4`) matches `upgradeGate.ts`.
   - **Heap Scoping Safety (`useBarnStore.ts`):** When lightening `baseSpeciesData` / `coiByAnimalId` on `NON_SPECIES_ROUTES`, verify `HomeSpeciesScreen` alerts, over-capacity warnings, active counts, and backup exports (`ImportExportHubScreen` / `SettingsAndSyncScreen`) still read full data.
   - **`suggestions-backlog.md` Timing:** Never delete items #1–#3 from `docs/plans/suggestions-backlog.md` until all implementation + tests + CI checks pass (`suggestionsBacklog.test.ts` parses exact counts).

---

## 3. Phased Porting Sequence & Verification Gates

Every phase below **MUST** end with all 4 automated checks run cleanly and inspected:
```bash
npm run verify:improvements && npm run lint && npm test && npm run build
```

### Phase 0: Baseline Audit, Config Lock & Green `lint`/`test` Gate
**Goal:** Establish an unbreakable build/isolation foundation and eliminate the 108 TS errors + 5 failing test suites cleanly before stacking changes.
- [x] **0.1 Verify Build & Config Locks:** Confirmed `vite.config.ts` (`importFolderGuardPlugin`, `fs.deny`, `hmr: false`, `devOptions.enabled: false`, ES2018 targets), `tsconfig.json` (`exclude: ["dist", "import"]`), `vitest.config.ts`, `index.html` preflight guard, and `public/version.json` (`0.1.0-alpha.2`, `schemaVersion: 6`, `minDirectUpgradeSchema: 4`) + `public/status.json`.
- [x] **0.2 Fix Minimal Shared Model Contract Blocking Baseline (`BarnTask.startDateIso`):** Added optional `startDateIso?: string` to `BarnTask` in `src/core/models.ts` and allowed `'startDateIso'` in `ALLOWED_SYNC_FIELDS_BY_ENTITY.task` (`src/core/inputSanitization.ts`). Eliminated all 20 TS errors across `barnScheduler.ts`, `BarnSchedulerGantt.tsx`, `barnScheduler.test.ts`, and `p2pSyncProtocol.test.ts`; `barnScheduler.test.ts` and `p2pSyncProtocol.test.ts` now pass.
- [x] **0.3 Reconcile `storageProbes.ts` & Orphaned New Tests (`clientCrm.test.ts`, `woolFiber.test.ts`, `imageOptimizationSpec.test.ts`, `restrictedBrowserAndBfcache.test.ts`):** Verified `src/storage/storageProbes.ts` exports already align cleanly; remaining 88 TS errors / 4 failing suites are strictly isolated to Phase 1 (`imageOptimizationSpec.test.ts`), Phase 2 (`restrictedBrowserAndBfcache.test.ts`), and Phase 4 (`clientCrm*`, `woolFiber*`, `ClientCrmScreen`, `WoolHarvestPanel`) and will burn to 0 systematically across Phases 1–4.
- **Gate:** `npm run verify:improvements` PASS (48/48); `npm run build` PASS; remaining TS errors 88 across 8 Phase 1/2/4 files; remaining test failures 4 suites (11 tests).

### Phase 1: ES2018 Shims + Canvas Area/DPR Ceilings + Photo & iOS Safe Exports (U-5 + U-3)
**Goal:** Protect mobile/iOS Safari GPUs, canvas memory, and standalone iOS file sharing while preserving working `IMP-047`.
- [x] **1.1 ES2018 & Restricted WebView Shims (`src/utils/es2018Shims.ts`, `src/storage/__tests__/es2018AndPwaUpdate.test.ts`):**
  - Port `isFileReaderSupported()`, `Response`-based blob fallbacks, and non-enumerable `Blob.prototype.arrayBuffer`/`text` + `String.prototype.trimStart`/`trimEnd` shims.
  - **Strict TS Fix:** Replace `(this as any)` with properly typed interfaces (`this: Blob`, typed prototype helper).
- [x] **1.2 Pure Canvas Ceilings (`src/core/imageOptimizationSpec.ts`, `src/core/__tests__/imageOptimizationSpec.test.ts`):**
  - Port `MAX_CANVAS_AREA_PX` (`16_000_000`), `MAX_CONSTRAINED_CANVAS_AREA_PX` (`3_000_000`), `getCanvasAreaCeiling`, `clampCanvasDimensionsToAreaCeiling`, `capCanvasDevicePixelRatio`, and 4-arg `computeScaledDimensions` (preserve `src/core/` zero-DOM purity).
- [x] **1.3 Canvas & OCR Memory Hardening (`src/storage/webImageOptimizer.ts`, `feedTagOcr.ts`, `pedigreeOcrScanner.ts`, `deviceCapabilityDetector.ts`):**
  - Port `probeOffscreenCanvas2dSupport()`, `releaseCanvas()` in `try/finally` (`1x1` clearRect then `0x0`), area-ceiling clamping, and sequential compression.
- [x] **1.4 Sequential Photo Hydration & URL Revocation (`src/storage/photoHydration.ts`, `src/components/AnimalPhotoGallery.tsx`, `src/storage/__tests__/photoHydrationAndWorker.test.ts`):**
  - Port sequential hydration batching (`CONSTRAINED_PHOTO_HYDRATION_BATCH_SIZE = 4`) and deterministic `blob:` revocation on animal change / photo replace / unmount.
  - Guard `hydrationQueueRef` / async state updates against stale-animal-switch races and lightbox unmount crashes.
- [x] **1.5 iOS Standalone Export Cascade & Error Surfacing (`src/utils/webFileActions.ts`, `webPdfActions.ts`, `localSyncChannels.ts`, `CrashErrorBoundary.tsx`, `DiagnosticsAndSupportPanel.tsx`, `ImportExportHubScreen.tsx`, `PrintPreviewModal.tsx`, `useBarnStore.ts`):**
  - Port `isInstalledIosPwa()` + `navigator.canShare({ files: [file] })` -> `navigator.share({ files: [file] })` (no `title`/`text`/`url`), clean `'cancelled'` on `AbortError`, and delayed fallback `blob:` revocation.
  - **Reconcile `PrintPreviewModal.tsx` Carefully:** Merge iOS copy-text / `mailto:` / `extraToolbarContent` / share cancellation feedback **onto working `PrintPreviewModal.tsx`** so `IMP-047` (`canShareHtmlDocument`, `extractScopedPrintCssFromRules`, `detectDocumentPrintOrientation`, `pedigreeBridge` HTML/orientation forwarding) is **100% preserved** and `PedigreePrintNotice.tsx` stays deleted.
- **Gate:** `npm run verify:improvements` PASS (48/48); `npm run build` PASS; `imageOptimizationSpec.test.ts`, `es2018AndPwaUpdate.test.ts`, `photoHydrationAndWorker.test.ts`, `printPreviewHelpers.test.ts`, `printPreviewFileActions.test.ts` PASS (65/68 suites / 406/413 tests green); 0 Phase 1 TS errors (82 remaining strictly in Phase 2 & Phase 4).

### Phase 2: Restricted-Browser Storage Probes, Safari OPFS & bfcache Resource Lifecycle (U-1 + U-2)
**Goal:** Prevent `SecurityError` in Safari Lockdown/Firefox Private mode and unblock `versionchange` / bfcache transitions without corrupting active writes or shares.
- [x] **2.1 Audit & Wire `src/storage/storageProbes.ts` Exports:** Reconcile `notifyPageHide`, `onReleaseResources`, `getActiveOpfsHandleCountForTests`, `OpfsCloseableHandle`, `resetOpfsProbesForTests`, `trackActiveOpfsHandle` between `storageProbes.ts`, `opfsTempStream.ts`, `backgroundFreezeCoordinator.ts`, and `restrictedBrowserAndBfcache.test.ts`.
- [x] **2.2 Safari/WebKit OPFS Shims (`src/storage/opfsTempStream.ts`, `src/storage/opfsStorage.ts`):**
  - Port `safeAwaitOpfsClose`/`Flush`/`GetSize`/`Truncate`, `WeakSet` double-close guard, `probeOpfsRuntime()`, and `try/finally` `.close()` invariants.
  - Preserve worker/DOM-free imports in `opfsTempStream.ts` (`IMP-032`).
- [x] **2.3 Pause/Freeze Safety (`src/storage/backgroundFreezeCoordinator.ts`, `crashLogger.ts`, `localSyncChannels.ts`, `pwaUpdateManager.ts`, `storageProtection.ts`, `capturedIdeasStore.ts`, `deviceCapabilityDetector.ts`):**
  - Port guarded global probes (`getSafeIndexedDb`, `getSafeLocalStorage`, `getSafeWebLocks`, etc.) and `onReleaseResources('hidden' | 'pagehide')`.
  - **Runtime Race Guard:** Track active OPFS/ZIP/share/file-picker leases so a transient `visibilitychange('hidden')` (e.g., iOS Share Sheet or `<input type="file">`) flushes or defers force-closing the *active* write handle rather than mid-write corruption; keep `pagehide` deterministic cleanup and keep `beforeunload` removed for bfcache.
- [x] **2.4 SQLite Ephemeral / Lockdown Fallback (`src/storage/webSqliteAdapter.ts`):**
  - Port `isEphemeralMode()` and restricted-IDB detection/fallback onto working `webSqliteAdapter.ts` (before adding v5/v6 tables in Phase 4).
- **Gate:** `npm run verify:improvements` PASS (48/48); `npm run build` PASS; `restrictedBrowserAndBfcache.test.ts`, `crossTabLockAndReload.test.ts`, `backgroundFreezeAndToast.test.ts`, `opfsStorage.test.ts`, `capturedIdeasStore.test.ts`, `es2018AndPwaUpdate.test.ts`, `stageBResilience.test.ts` PASS (0 Phase 2 TS errors; 72 Phase 4 CRM/Wool TS errors & 2 Phase 4 test suites remaining).

### Phase 3: Heap Weight Reduction, Lazy Modal Splitting & Worker Fallbacks (U-4 — NO Firebase)
**Goal:** Cut initial bundle weight and resident heap for 2,000+ animals without breaking offline chunk recovery, Firebase removal, or Home/Backup functionality.
- [x] **3.1 Dynamic Worker Fallbacks (`src/storage/offThreadWorkerClient.ts`):**
  - Convert static `backupArchive`, `archiveInspector`, `supportBundle`, and `importers/registry` imports into `import type` + dynamic `import()` inside fallback branches.
  - Also inspect and resolve Vite's `[INEFFECTIVE_DYNAMIC_IMPORT]` warning on `src/storage/opfsStorage.ts` if straightforward *(left intentional circular-break dynamic imports in `crashLogger.ts`/`localSyncChannels.ts`/`storageProtection.ts` untouched)*.
- [x] **3.2 Keep `googleCalendarClient.ts` Firebase-Free:** Explicitly **skip** any `/import/` delta re-introducing `firebase/app` or `firebase/auth` (and guarded `initGoogleCalendarAuth` on `calendarDeliveryMode === 'google_calendar'`). Verify `.ics` fallback continues to work 100% offline.
- [x] **3.3 Safe Lazy Modals (`src/App.tsx`, `src/components/HerdScreen.tsx`):**
  - Lazy-load `AnimalEditorModal`, `ArchivedHerdsModal`, `PrintPreviewModal`, `SpeciesMigrationModal` in `HerdScreen.tsx` via `lazyNamedRoute` / `<Suspense>` inside error boundaries, plus dynamic `webPdfActions` import in `HerdScreen.tsx` and `PedigreeScreen.tsx`.
  - In `src/App.tsx`, lazy-load `WipedStorageRecoveryModal` (mounted when `wipedRecoveryContext?.detected`) wrapped in `<RouteErrorBoundary>` + visible recovery fallback (never `fallback={null}`).
- [x] **3.4 Store & SQLite Heap Scoping (`src/hooks/useBarnStore.ts`, `src/storage/webSqliteAdapter.ts`, `src/storage/photoHydration.ts`):**
  - Port O(1) `maxRevByEntityRef`, cache eviction (`pedigreeAncestorCacheRef`) on `selectSpeciesWorkspace` & `onHidden`, and scoped `coiByAnimalId`.
  - Port lightweight loading of `feed_batches.tag_photo_data_url` & `ledger_entries.receipt_photo_data_url` when `lightweightPhotos: true` (plus non-destructive dehydrated saves, on-demand fetchers, and lightbox hydration in `FeedLedgerScreen.tsx` & `EconomicsLedgerScreen.tsx`).
  - Verify `NON_SPECIES_ROUTES` scoping never hides overdue/over-capacity alerts on `HomeSpeciesScreen` or omits records during backup/export flows.
- [x] **3.5 Parent Picker & Herd Virtualization (`src/components/HerdScreen.tsx`, `src/components/SearchableParentPicker.tsx`):**
  - Port constrained `overscan` / `initialFallbackCount` and visible-row `carrierAnalysisById` & `visibleCoiByAnimalId` optimization in `HerdScreen.tsx` (preserving `HERD_PAGE_SIZE = 50`).
  - Keep working's cleaner fixed-height virtualization (`OPTION_ROW_ESTIMATE_PX`) in `SearchableParentPicker.tsx` and tightened allocation-free `matchesParentCandidateQuery` filtering.
- **Gate:** `npm run verify:improvements` PASS (48/48); `npm run lint` PASS (`0` errors); `npm test` PASS (68/68 suites / 415/415 tests); `npm run build` PASS (`dist/assets/index-*.js` reduced from ~1,404 kB to `1,136.84 kB`).

### Phase 4: SQLite v4→v6 Upgrade & Wire Import `IMP-049` (CRM) + `IMP-050` (Alt Certs, Show Docs & IAGARB Wool)
**Goal:** Complete domain model, persistence, store CRUD, and UI wiring for CRM, alternative certificates, show forms, and wool/fiber tracking, restoring green `tsc --noEmit` & `vitest`.
- [x] **4.1 Core Domain Models & Input Sanitization (`src/core/models.ts`, `src/core/inputSanitization.ts`, `src/core/sampleData.ts`, `src/core/dataHealthCheck.ts`):**
  - Port `ClientContact`, `WaitlistEntry`, `AnimalReservation`, `WoolHarvest`, `IagarbScorecard`, normalizers, and `ActiveSpeciesData` collections cleanly.
  - Ensure strict TS (zero `any`), pure zero-DOM TS in `src/core/`, `"YYYY-MM-DD"` dates + `Date.UTC` math, and deterministic `_rev` ordering.
- [x] **4.2 Exporters, Reports, Sync, Prints & Offline PDF (`reportCatalog.ts`, `reportGenerators.ts`, `pedigreePrintStyles.ts`, `shareablePedigreeCard.ts`, `pdfExporter.ts`, `syncAndExports.ts`, `syncOutbox.ts`, `backupArchive.ts`, `backupStatus.ts`, `backupVault.ts`, `archiveInspector.ts`, `speciesMigration.ts`):**
  - Merge `/import/` CRM & Wool/Cert/ShowDoc support while **keeping all working `IMP-047` invariants** (`herdboss-transfer-bundle`, `registry-worksheet-csv`, `feedBatchesMigrated`, `feedAllocationsMigrated`, feed/ledger counts in `archiveInspector.ts`).
  - Fix `/import/`'s `ExternalImporterPanel.tsx` `catch (err: any)` -> `err: unknown`.
- [x] **4.3 SQLite v4→v6 Migration (`src/storage/webSqliteAdapter.ts`, `src/storage/storageAdapter.ts`, `src/core/upgradeGate.ts`):**
  - Implement atomic `try/catch` v4→v6 schema upgrade creating `client_contacts`, `waitlist_entries`, `animal_reservations`, and `wool_harvests` tables with `CREATE TABLE IF NOT EXISTS` and OPFS dump rescue before any fallback reset.
  - Verify `SQLITE_SCHEMA_VERSION = 6` matches `public/version.json` (`schemaVersion: 6, minDirectUpgradeSchema: 4`) while keeping `appVersion: "0.1.0-alpha.2"` across `package.json`, `public/version.json`, and `upgradeGate.ts`.
- [x] **4.4 Store CRUD & Screen Wiring (`src/hooks/useBarnStore.ts`, `src/App.tsx`, `SpeciesDashboardScreen.tsx`, `HerdScreen.tsx`, `BreedingScreen.tsx`, `PedigreeScreen.tsx`, `ClientCrmScreen.tsx`, `WoolHarvestPanel.tsx`):**
  - Wire CRM route (`clientCrm`) and lazy `ClientCrmScreen` in `App.tsx` + `SpeciesDashboardScreen.tsx`, wrapped in `<RouteErrorBoundary><Suspense>`.
  - Wire alternative certs, show remark/entry cards (`showDocuments.ts`), and `WoolHarvestPanel` (`woolFiber.ts`) in `HerdScreen.tsx`, `BreedingScreen.tsx`, `PedigreeScreen.tsx`, and `SpeciesDashboardScreen.tsx`.
- [x] **4.5 Register `IMP-049` & `IMP-050`:** Add tracked invariants & playbooks to `IMPROVEMENTS.md` and `src/core/improvementRegistry.ts` as `IMP-049` and `IMP-050`. Remove completed items #1 and #2 from `docs/plans/suggestions-backlog.md` **only after** all tests + checks pass.
- **Gate:** `npm run verify:improvements && npm run lint && npm test && npm run build` -> **0 errors / all passing (50/50 improvements, 68/68 suites / 416/416 tests)**.

### Phase 5: Resolve Orphaned Features (`IMP-051`), Audit Workflows & Final Boot Verification
**Goal:** Ensure zero dead/orphaned modules remain, CI/APK workflows are valid, and the compiled PWA boots cleanly in a real browser.
- [x] **5.1 Resolve Backlog Item #3 Partial Modules (`barnScheduler.ts`, `BarnSchedulerGantt.tsx`, `FounderAndHeritabilityPanel.tsx`, `p2pSyncProtocol.ts`, `p2pLanChannel.ts`):**
  - Completed UI/store/SQLite wiring (`PedigreeScreen.tsx`, `BreedingScreen.tsx`, `SpeciesDashboardScreen.tsx`, `useBarnStore.ts`, `webSqliteAdapter.ts` `barn_tasks.start_date_iso`, `App.tsx`) and registered as `IMP-051` (removed item #1 from `docs/plans/suggestions-backlog.md` and updated `suggestionsBacklog.test.ts` + `improvementRegistry.test.ts`).
  - Kept `src/utils/__tests__/printPreviewHelpers.test.ts` and `src/native/pedigreeBridge.test.ts` intact.
- [x] **5.2 Audit GitHub Workflows (`.github/workflows/`):**
  - Audited `build-android-apk.yml`, `ci.yml`, `deploy-pages.yml`, `export_repo_to_md.yml`, and `unzip.yml`; updated `unzip.yml` (`actions/checkout@v4`, `nullglob` empty-zip guard, safe nested flatten, empty-commit guard).
- [x] **5.3 Final Full Verification & Browser Boot Test:**
  - Confirmed zero `as any` / `@ts-ignore` / `@ts-expect-error`, zero `firebase/*` imports, zero DOM in `src/core/`, zero `/import/` references in `dist/`, and green `npm run verify:improvements && npm run lint && npm test && npm run build`.
  - Verified both subpath build (`npm run build -- --base=/Pedigree/`) and production preview (`vite preview`) serving `dist/index.html`, `dist/manifest.webmanifest`, `dist/version.json`, `dist/sw.js`, and `dist/prompts-manifest.json`.
  - Marked `Status: Archived` and moved import plan/diff/audit docs into `docs/archive/`, keeping `/import/` intact on disk and syncing `IMP-048` path references.
