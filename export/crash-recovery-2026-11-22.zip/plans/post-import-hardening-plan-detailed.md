# Post-Import Hardening Plan: Boot Stability, Load Speed & Memory Discipline

This plan addresses every regression and bottleneck identified in the post-import audit of the offline-first Pedigree PWA, starting with the Master System Prompt invariants and ending with a comprehensive recheck gate across project objectives, bootability, stability, and memory management. Once execution and verification complete, the tracked plan and associated artifacts will be marked `Status: Archived` and relocated to the archive directory rather than deleted, and the completed pass will be registered as `IMP-052`.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The three scope decisions below were confirmed prior to drafting this plan and govern execution. No source or repository files are modified until you approve this plan.

- **Confirmed Decision 1 — 3.6 MB AI Studio Export Dumps in Public Assets**: Move all stale export dumps out of the served public assets directory into the repository archive directory. Nothing is deleted, while the production web build and Android APK drop ~3.6 MB of dead weight immediately.
- **Confirmed Decision 2 — TypeScript Type-Safety Scope**: Eliminate all ~29 remaining explicit `any` annotations across the codebase while keeping the existing TypeScript compiler configuration unchanged (no global strict-mode flip in this pass).
- **Confirmed Decision 3 — Plan Tracking, Archiving & Registry (`IMP-052`)**: Track this hardening effort as an active plan document during execution, register the completed work as `IMP-052` in the improvement registry and ledger, and upon verification transition the plan (and any associated files) to `Status: Archived` inside the archive directory rather than deleting them.

---

## 1. Overview & Core Concept

- **What It Does**: Hardens the unified offline-first React + Vite + TypeScript Pedigree PWA (and its thin Android WebView wrapper build) so that every device tier—from older mobile browsers and Safari Lockdown/Private sessions to desktop barn stations—boots reliably, paints quickly even on flaky or captive barn Wi-Fi, stays well within mobile RAM ceilings during upgrades and saves, and passes every automated guardrail cleanly.
- **Target Audience / Persona**: Livestock and small-animal breeders working offline in barns, fairgrounds, and low-connectivity rural areas on mixed hardware (budget Android handsets, iOS standalone PWAs, and desktop browsers).
- **Key Value**:
  - **Restored CI & Packaging Integrity**: Fixes the failing improvement-verification gate, strips 3.6 MB of unreferenced dumps out of production builds and APKs, and ensures Android production builds emit zero dev-runtime chunks.
  - **Bulletproof Bootability**: Unblocks Ephemeral Mode when IndexedDB is unavailable, prevents false crash-loop resets on slower storage mounts, makes schema migrations atomic and silent on steady-state boots, protects lazy modals with error boundaries, and preserves iOS user-activation gestures during small file shares.
  - **Faster Cold Start**: Shrinks the initial JavaScript payload and eliminates render-blocking external font requests and serialized post-boot stalls so the barn workspace reaches first interactive paint rapidly.
  - **Disciplined Mobile Memory**: Removes full-resolution photo heap spikes during database upgrades and background fallback mirrors, eliminates whole-document DOM mutation scanning, and stops keeping unbounded sync-outbox history pinned in root UI state.

---

## 2. User Experience & Visual Design

Because this is a stability, speed, and memory hardening pass on an existing production interface, visual identity, color palette, and layout geometry remain intentionally preserved—changes focus strictly on **perceived speed, boot clarity, offline resilience, and error-recovery polish**.

- **Key User Flows**:
  1. **Cold Launch on Captive or Offline Barn Wi-Fi**: The app renders immediately using local system fallback typography while custom fonts load asynchronously in the background—never stalling on a blank white screen waiting for a remote font server.
  2. **Restricted Browser / Private Mode Launch**: When browser storage (`IndexedDB`) is blocked (e.g., Safari Lockdown or strict Private Browsing), the boot preflight no longer locks the user out on a dead-end error screen. Instead, React mounts normally into **Ephemeral Mode**, displaying a clear, non-blocking warning banner reminding the user to export a backup before closing the tab.
  3. **Slow-Device Boot & Crash-Loop Protection**: The boot stability sentinel remains armed until the database adapter and primary barn store actually finish hydrating (or the recovery screen mounts), avoiding premature disarming while large herds load from storage.
  4. **Offline Modal & Share Actions**: Opening lazy-loaded dialogs (including calendar sync confirmation) while offline displays a clean fallback/retry boundary rather than crashing the root view. Sharing or exporting small files (< 512 KB) on iOS standalone PWAs hands off directly to the native share sheet inside the original tap gesture, preventing silent gesture-expiration failures.
  5. **Large-Herd Photo Browsing & Background Saves**: Navigating herds, opening modals, and saving records run smoothly without frame drops from global DOM observers, photo-gallery effect loops, or 15-second full-photo heap spikes.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Existing utilitarian, high-legibility barn workbench interface—preserved unchanged with zero layout regressions.
  - *Color Palette & Mood*: Existing theme tokens (`--background`, `--foreground`, `--primary`, `--muted`, `--destructive`) and dark/light surfaces remain untouched.
  - *Typography & Hierarchy*: System sans-serif fallback stack renders instantaneously on first paint; web fonts swap in non-blockingly (`swap`) once available without blocking layout.
  - *Interactive Feedback & Motion*: Consistent loading placeholders and inline retry states across all lazy-loaded dialogs and routes; smooth scroll/input responsiveness free of background MutationObserver jank.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Master System Prompt as Mandatory Phase 0 Gate**
  - *Chosen Approach*: Re-verify and enforce every binding rule in the Master System Prompt before any code change: core PWA permanently locked to React + Vite + TypeScript, zero cloud/Firebase dependencies, pure domain core with zero browser globals, ES2018 compatibility, `"YYYY-MM-DD"` + `Date.UTC` calendar math with monotonic `_rev` counters, explicit OPFS handle `.close()` in `try/finally`, blob URL revocation, and strict protection of the master prompt and read-only import staging area.
  - *Why*: Guarantees hardening edits strengthen the architecture without accidentally breaking cross-layer boundaries or platform constraints.

- **Decision 2 — Non-Blocking Preflight for IndexedDB (Unlocking Ephemeral Mode)**
  - *Chosen Approach*: Downgrade missing or blocked `IndexedDB` in the HTML preflight from a fatal boot blocker to an advisory capability flag so the storage adapter can cleanly enter Ephemeral Mode.
  - *Why*: Ephemeral Mode was already engineered in the storage layer specifically for Safari Lockdown/Private sessions, but the preflight check made it unreachable.
  - *Alternatives Considered*: Leaving preflight fatal would continue locking out privacy-hardened iOS/Safari users.

- **Decision 3 — Atomic, Version-Gated Schema Migrations**
  - *Chosen Approach*: Run database schema migrations only when the stored schema version trails the current schema version, inspect existing columns via `PRAGMA table_info` before issuing `ALTER TABLE`, and wrap the entire migration sequence inside an explicit `BEGIN` / `COMMIT` / `ROLLBACK` transaction.
  - *Why*: Eliminates 59 thrown WASM-to-JS exceptions on every normal boot and prevents half-migrated schemas if a tab is killed mid-upgrade.

- **Decision 4 — Lightweight Pre-Upgrade Snapshots & Tier-3 Photo Dehydration**
  - *Chosen Approach*: Capture pre-upgrade safety backups without hydrating full-resolution photo binaries into the JS heap (using lightweight photo metadata or raw SQLite bytes), and enable dehydrated photo mirrors on Tier 3 mobile devices during periodic 15-second fallback mirrors.
  - *Why*: Primary SQLite already preserves every full-resolution photo safely; hydrating all photos into JSON strings during upgrades or background mirrors creates avoidable OOM crashes on mobile Safari/Chrome.
  - *Alternatives Considered*: Keeping full photo hydration in the 15-second fallback mirror on Tier 3 risks killing the tab right after a breeder adds photos.

- **Decision 5 — Deferred Non-Critical Startup Work & Slimmer Entry Bundle**
  - *Chosen Approach*: Break static imports of heavy archival, support-bundle, sample-data, and archive-inspection modules out of the initial entry graph so they load strictly on demand; defer persistent-storage requests, sync-outbox UI hydration, and background data-health scanning until after first interactive paint (while preserving causal revision tracking before any write occurs).
  - *Why*: Cuts initial JS parse/compile cost, resolves all bundler ineffective-dynamic-import warnings, and trims the PWA precache footprint dramatically.

- **Decision 6 — Archive, Never Delete**
  - *Chosen Approach*: Preserve audit records, export dumps, and the completed hardening plan by setting `Status: Archived` and relocating them to the archive directory, while locking in regression checks via `IMP-052`.
  - *Why*: Maintains full decision traceability and satisfies the repository's non-destructive archiving policy.

---

## 4. Technical Architecture & Data Strategy

### Hardened Boot, Stability & Preflight Pipeline

```
┌─────────────────────────────────────────────────────────────────────────┐
│ PHASE 0: MASTER PROMPT GATE                                             │
│ React+Vite+TS lock · Zero Cloud · Pure Core · ES2018 · Date.UTC + _rev  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ BOOT ENTRY (HTML Shell + Non-Blocking Font Swap + Advisory Preflight)   │
│  • External font loads async (media=print -> all) -> instant 1st paint  │
│  • Preflight flags IndexedDB as advisory (does NOT block Ephemeral Mode)│
│  • Crash-loop breaker stays ARMED until store finishes loading          │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ STORAGE HYDRATION (SQLite / OPFS / IDB / Ephemeral Fallback)            │
│  • Upgrade needed? Lightweight/raw pre-upgrade backup -> BEGIN TX ->    │
│    PRAGMA table_info column checks -> ALTER TABLE -> COMMIT / ROLLBACK  │
│  • Steady-state boot? Zero ALTER TABLE throws                           │
│  • Lightweight initial load (thumbnail/metadata only; photos lazy)      │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ FIRST INTERACTIVE PAINT  ──►  Disarm Crash-Loop Sentinel                │
│  • All lazy routes & modals wrapped in RouteErrorBoundary + fallback    │
│  • Dialog state tracked via lightweight counter (no body MutationObs.)  │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ POST-PAINT BACKGROUND WORK (Non-Blocking)                               │
│  • Request persistent storage quota                                     │
│  • Ensure causal revision counter before first mutation write           │
│  • Run data-health scan & lazy sync-outbox hydration only on sync views │
└─────────────────────────────────────────────────────────────────────────┘
```

### Memory, Photo & Export Discipline Architecture

```
┌───────────────────────────┐      ┌──────────────────────────────────────┐
│ Photo Gallery / Views     │      │ Export & Native Share Dispatcher     │
│  • Ref-guarded lazy load  │      │  • Payload < 512 KB?                 │
│  • No state-dep loop      │      │     YES -> Direct Blob/File handoff  │
│  • Revoke blob: URLs on   │      │            (preserves iOS gesture)   │
│    unmount / eviction     │      │     NO  -> OPFS /tmp stream in       │
└─────────────┬─────────────┘      │            try/finally (.close())    │
              │                    └──────────────────────────────────────┘
              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ Background Mirror & Sync State                                          │
│  • Tier 3 mobile fallback mirror: dehydrateMirrorPhotos = true          │
│    (full photos stay authoritative in SQLite; zero 15s RAM spike)       │
│  • Sync outbox lives in IndexedDB + lightweight causal ref; full list   │
│    hydrated on demand only inside sync/export screens                   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Phased Execution, Recheck & Archiving Roadmap

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Phase 1: CI, Packaging & Type Hygiene                                   │
│  • Restore required environment-example placeholder (IMP-008 pass)      │
│  • Move 3.6 MB AI Studio export dumps out of public assets to archive   │
│  • Enforce NODE_ENV=production in Android APK build workflow            │
│  • Replace ~29 explicit `any` annotations with concrete/unknown types   │
├─────────────────────────────────────────────────────────────────────────┤
│ Phase 2: Booting Stability                                              │
│  • Make IndexedDB check advisory in preflight (unblocks Ephemeral Mode) │
│  • Tie crash-loop disarm to actual store ready / recovery mount         │
│  • Wrap lazy Calendar Sync Confirmation dialog in RouteErrorBoundary    │
│  • Gate & wrap SQLite migrations in atomic transaction + column checks  │
│  • Enforce 512 KB OPFS threshold in file/share actions for iOS gestures │
├─────────────────────────────────────────────────────────────────────────┤
│ Phase 3: Loading Speed & Bundle Hygiene                                 │
│  • Eliminate all 3 ineffective-dynamic-import bundler warnings          │
│  • Split heavy archive/sample/support modules out of initial entry      │
│  • Make external font stylesheet non-render-blocking                    │
│  • Defer non-critical boot work off initial first-paint path            │
├─────────────────────────────────────────────────────────────────────────┤
│ Phase 4: Memory Management                                              │
│  • Prevent full-photo heap hydration during SQLite pre-upgrade backup   │
│  • Enable dehydrated photo mirrors on Tier 3 mobile devices             │
│  • Replace global body MutationObserver with dialog-hook counter        │
│  • Remove unbounded sync outbox array from root React state             │
│  • Remove photo-gallery hydration effect dependency churn               │
├─────────────────────────────────────────────────────────────────────────┤
│ Phase 5: Recheck Gate, IMP-052 Registration & Archive-Not-Delete        │
│  • Register IMP-052 in improvement registry & sync improvements ledger  │
│  • Add/update unit tests for every stability, boot, and memory fix      │
│  • Run full verification suite (guardrails, typecheck, tests, prod &    │
│    subpath builds, bundle/dist size inspection, zero bundler warnings)  │
│  • Recheck all work against: Core Objectives · Stability · Bootability  │
│    · Memory Management · Master System Prompt invariants                │
│  • Set tracked plan & associated files to Status: Archived and relocate │
│    into the archive directory (zero deletions)                          │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model, State & Handler Mapping

- **Barn Store & Causal Sync Outbox**: Primary animal, breeding, litter, event, and species records remain authoritative in local SQLite (with IndexedDB fallback and Ephemeral Mode when storage is restricted). The monotonic per-entity revision map (`_rev`) is guaranteed initialized before any mutation writes a new outbox entry, while the full historical outbox array is read from IndexedDB on demand inside sync and import/export views rather than cloned in root UI state on every unrelated edit.
- **Accessible Dialog Registry**: The shared accessible-dialog hook increments and decrements a tiny module-scoped open-dialog counter on mount/unmount and notifies subscribers synchronously. The root app subscribes to toggle background interactivity/scroll lock cleanly without observing every DOM mutation across virtualized tables and form inputs.
- **On-Demand Support, Archive & Sample Loaders**: Error boundaries load the support-bundle builder dynamically inside their click handlers; store actions load archive inspection, ZIP backup assembly, sample-herd generators, and maintenance utilities dynamically when triggered, with disabled button guards while promises are in flight.
- **Verification & Invariant Protection**: Existing `IMP-001` through `IMP-051` assertions are checked before and after each edit so no prior safeguard regresses, and `IMP-052` encodes automated structural assertions for the new stability, bootability, and memory fixes.
