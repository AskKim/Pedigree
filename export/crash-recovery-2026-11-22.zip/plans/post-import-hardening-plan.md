# Post-Import Hardening Implementation Plan

**Status:** Archived  
**Created:** 2026-11-22  
**Archived:** 2026-11-22  
**Registry Entry:** `IMP-052` (verified in `src/core/improvementRegistry.ts` & `IMPROVEMENTS.md`)  
**Binding Gate:** `prompts/master_system_prompt.md` (read and enforced before execution)

## Confirmed Scope & Decisions
1. Moved the 3.6 MB AI Studio export dumps out of `public/assets/aistudio/` into `docs/archive/aistudio-exports/` (archived, zero deletions).
2. Removed all explicit `: any` annotations across non-test `src/` while keeping `tsconfig.json` unchanged (which also surfaced and fixed a silent `AFTER_BRED` vs `AFTER_BREEDING` backup-parser bug in `src/core/syncAndExports.ts`).
3. Tracked this plan in `docs/plans/post-import-hardening-plan.md` during execution, registered `IMP-052` in `src/core/improvementRegistry.ts` and `IMPROVEMENTS.md`, verified all checks, and archived this file to `docs/archive/post-import-hardening-plan.md` instead of deleting.

## Execution Checklist

### Phase 0: Master System Prompt Gate
- [x] Read and enforce `prompts/master_system_prompt.md` (React + Vite + TypeScript core lock, zero cloud/Firebase, pure `src/core/`, ES2018 target, `"YYYY-MM-DD"` + `Date.UTC` + `_rev`, OPFS `.close()` in `try/finally`, blob URL revocation, `/import/` isolation).

### Phase 1: CI, Packaging & Type Hygiene
- [x] Restored `.env.example` (`IMP-008` pass; zero `VITE_BASE_PATH` / `DISABLE_HMR`).
- [x] Moved `public/assets/aistudio/*` to `docs/archive/aistudio-exports/` (removed 3.6 MB from `dist/` and Android APK).
- [x] Added `NODE_ENV: production` to `.github/workflows/build-android-apk.yml` PWA build step.
- [x] Replaced all explicit `: any` annotations across non-test `src/` without changing `tsconfig.json`.

### Phase 2: Booting Stability
- [x] Relaxed `index.html` preflight `indexedDB` check from fatal blocker to advisory `indexedDbAvailable` flag so Phase 2 Ephemeral Mode is reachable in Safari Lockdown / Private Mode.
- [x] Disarmed `__PEDIGREE_MARK_BOOT_STABLE__()` in `src/App.tsx` only after `!store.isLoading` completes hydration instead of blind 2.5s timer in `src/main.tsx`.
- [x] Wrapped lazy `CalendarSyncConfirmModal` in `<RouteErrorBoundary>` + visible modal loading fallback in `src/App.tsx`.
- [x] Gated `applySchemaMigrations` in `src/storage/webSqliteAdapter.ts` behind `currentVersion < SQLITE_SCHEMA_VERSION`, inspected columns via `PRAGMA table_info(...)`, and wrapped migrations atomically in `BEGIN TRANSACTION` / `COMMIT` / `ROLLBACK`.
- [x] Bypassed OPFS `/tmp` staging in `src/utils/webFileActions.ts` (`shouldBypassOpfsForIosGesture`) for `<512 KB` installed iOS PWA shares/downloads so `navigator.share({ files })` runs synchronously inside user tap activation while keeping `IMP-032` desktop/Android staging intact.

### Phase 3: Loading Speed & Bundle Hygiene
- [x] Eliminated all 3 `[INEFFECTIVE_DYNAMIC_IMPORT]` bundler warnings (`supportBundle.ts`, `archiveInspector.ts`, `opfsStorage.ts` via `storageProbes.ts` registry + dynamic imports).
- [x] Extracted pure `src/core/binaryEncoding.ts`, dynamic-imported cold maintenance/archive modules in `useBarnStore.ts`, and added Rolldown `codeSplitting` groups (`vendor-react`, `vendor-icons`, `vendor-sql`, `vendor-zip`) in `vite.config.ts`.
- [x] Made external Google Fonts stylesheet in `index.html` non-render-blocking (`media="print" onload="this.media='all'"` + `<noscript>`).
- [x] Deferred non-critical startup probes (`requestPersistentStorage`, `sync_conflicts`, `maxRevByEntityRef` outbox warming, startup `analyzeBarnDataHealth` auto-repair) off first paint while preserving `_rev` causality.

### Phase 4: Memory Management
- [x] Prevented full-resolution photo heap hydration during SQLite pre-upgrade OPFS safety backup and failure salvage in `src/storage/webSqliteAdapter.ts` (`{ lightweightPhotos: true }`).
- [x] Enabled `dehydrateMirrorPhotos: true` on Tier 3 mobile devices in `src/core/deviceCapability.ts` and updated unit tests.
- [x] Replaced global `document.body` `MutationObserver` in `src/App.tsx` with lightweight `subscribeOpenDialogCount` registered inside `src/utils/useAccessibleDialog.ts`.
- [x] Stopped holding the unbounded `syncOperations` array in root React state across non-sync routes in `src/hooks/useBarnStore.ts` (hydrates only on `importExport` / `dashboard`; IDB + `maxRevByEntityRef` stay canonical).
- [x] Removed `hydratedUrls` dependency churn from `src/components/AnimalPhotoGallery.tsx` using `hydratedUrlsRef` and `inFlightPhotoIdsRef`.

### Phase 5: Recheck Gate, `IMP-052` & Archiving
- [x] Registered `IMP-052` in `src/core/improvementRegistry.ts` and synced `IMPROVEMENTS.md` + `improvementRegistry.test.ts`.
- [x] Added `src/storage/__tests__/postImportHardening.test.ts` covering atomic SQLite migrations, iOS gesture-safe export bypass, pure `binaryEncoding`, dialog counter subscription, and `index.html` bootability.
- [x] Passed full verification gate (`npm run verify:improvements` 52/52, `npm run lint`, full `npm test` 69/69 files / 424/424 tests, root + subpath production Vite builds, `compile_applet`, `lint_applet`).
- [x] Rechecked all work against core objectives, booting stability, loading speed, memory management, and Master System Prompt invariants.
- [x] Marked this plan `Status: Archived` and moved it to `docs/archive/post-import-hardening-plan.md` (zero deletions).

## Recheck Sign-Off
- **Core Objectives & Master System Prompt:** Verified React + Vite + TypeScript core intact, zero cloud/Firebase, pure zero-DOM `src/core/` (including new `binaryEncoding.ts`), `/import/` untouched & isolated, `prompts/master_system_prompt.md` untouched, zero explicit `: any` in non-test `src/`.
- **Booting Stability:** Verified advisory `indexedDB` preflight, post-hydration boot-stability disarm, `<RouteErrorBoundary>` on `CalendarSyncConfirmModal`, atomic version-gated SQLite migrations, and gesture-safe iOS `<512 KB` exports.
- **Loading Speed:** Verified `dist/` dropped from 8.1 MB to 4.3 MB (-47%), entry `index-*.js` dropped from 1,211.26 kB to 687.35 kB (-43%; 181.68 kB gzip), Workbox precache dropped from 123 to 78 entries, 0 `[INEFFECTIVE_DYNAMIC_IMPORT]` warnings, non-blocking Google Fonts, and deferred non-critical startup probes.
- **Memory Management:** Verified `{ lightweightPhotos: true }` pre-upgrade backups, Tier 3 mirror photo dehydration, zero `document.body` `MutationObserver`, route-scoped `syncOperations` state, and ref-guarded `AnimalPhotoGallery` hydration.
